from PyQt5.QtWidgets import QDialog, QVBoxLayout, QTextEdit, QHBoxLayout, QPushButton
from PyQt5.QtCore import Qt
from .BaseGUI import BaseDialog

class ListDialog(BaseDialog):
    def __init__(self, title, existing_list=None, update_callback=None, preserve_formatting=False, parent=None):
        super().__init__()
        self.setWindowTitle(title)
        self.update_callback = update_callback
        self.preserve_formatting = preserve_formatting
        self.parent_gui = parent
        self.list_data = existing_list if existing_list else []
        main_layout = QVBoxLayout()
        self.text_edit = QTextEdit()
        self.text_edit.setAcceptRichText(True)
        if self.list_data:
            self.text_edit.setPlainText('\n'.join(self.list_data))
        main_layout.addWidget(self.text_edit)
        button_layout = QHBoxLayout()
        ok_button = QPushButton('OK')
        cancel_button = QPushButton('Cancel')
        ok_button.clicked.connect(self.accept)
        cancel_button.clicked.connect(self.reject)
        button_layout.addWidget(ok_button)
        button_layout.addWidget(cancel_button)
        main_layout.addLayout(button_layout)
        self.setLayout(main_layout)
        self.resize(400, 300)

    def accept(self):
        text = self.text_edit.toPlainText()
        lines = text.split('\n')
        self.list_data = [line.strip() for line in lines if line.strip()]
        if self.update_callback:
            self.update_callback(self.list_data)
        super().accept()
