import csv

def save_attribute_csv(file_path, item_value, part_full, sn_list, send_value):
    headers = ['NUMBER', 'PROMPT', 'KEY', 'DATA']
    rows = []
    number = 1
    try:
        sel_num = int(send_value)
    except Exception:
        sel_num = 0
    for sn in sn_list:
        rows.append({
            'NUMBER': number,
            'PROMPT': 'Item             >',
            'KEY': 'Item',
            'DATA': item_value
        })
        number += 1
        if sel_num == 0:
            pass
        elif 1 <= sel_num <= 9:
            rows.append({
                'NUMBER': number,
                'PROMPT': 'SEND',
                'KEY': 'BLANK',
                'DATA': str(sel_num)
            })
            number += 1
        elif sel_num >= 10:
            rows.append({
                'NUMBER': number,
                'PROMPT': 'DOWNARROW{0}'.format(sel_num - 1),
                'KEY': 'BLANK',
                'DATA': ''
            })
            number += 1
            rows.append({
                'NUMBER': number,
                'PROMPT': 'ENTER',
                'KEY': 'BLANK',
                'DATA': ''
            })
            number += 1
        rows.append({
            'NUMBER': number,
            'PROMPT': 'Serial #         :',
            'KEY': 'SN',
            'DATA': sn
        })
        number += 1
        rows.append({
            'NUMBER': number,
            'PROMPT': 'Number of Labels :',
            'KEY': 'QTY',
            'DATA': '1'
        })
        number += 1
        rows.append({
            'NUMBER': number,
            'PROMPT': '<Done>',
            'KEY': 'BLANK',
            'DATA': ''
        })
        number += 1
    rows.append({
        'NUMBER': number,
        'PROMPT': 'FINISHED',
        'KEY': '',
        'DATA': ''
    })
    number += 1
    rows.append({
        'NUMBER': number,
        'PROMPT': 'ASSETLABELS',
        'KEY': '',
        'DATA': ''
    })
    with open(file_path, 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=headers)
        writer.writeheader()
        writer.writerows(rows)
