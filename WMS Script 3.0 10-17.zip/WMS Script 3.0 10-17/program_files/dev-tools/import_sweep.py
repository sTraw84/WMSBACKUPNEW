#!/usr/bin/env python3
"""Import sweep moved into dev-tools. This script ensures the repository root is on sys.path
so it can import the `program_files` package regardless of the current working directory.
"""
import pkgutil
import importlib
import traceback
import sys
from pathlib import Path


def ensure_repo_root_on_path():
    # repo root is the parent directory of dev-tools
    repo_root = Path(__file__).resolve().parents[1]
    repo_root_str = str(repo_root)
    if repo_root_str not in sys.path:
        sys.path.insert(0, repo_root_str)


def main():
    ensure_repo_root_on_path()
    root_pkg = 'program_files'
    print(f"Starting import sweep for package: {root_pkg}\n")
    try:
        pkg = importlib.import_module(root_pkg)
    except Exception:
        print(f"Failed to import root package '{root_pkg}':")
        traceback.print_exc()
        return 2

    failures = []
    for finder, name, ispkg in pkgutil.walk_packages(pkg.__path__, pkg.__name__ + '.'):
        try:
            importlib.import_module(name)
            print('OK:', name)
        except Exception:
            print('FAIL:', name)
            tb = traceback.format_exc()
            print(tb)
            failures.append((name, tb))

    print('\nImport sweep complete. Totals:')
    print('  modules checked:', sum(1 for _ in pkgutil.walk_packages(pkg.__path__, pkg.__name__ + '.')))
    print('  failures:', len(failures))
    if failures:
        print('\nFailures details:')
        for name, tb in failures:
            print('\n' + '='*60)
            print(name)
            print(tb)
    return 1 if failures else 0


if __name__ == '__main__':
    raise SystemExit(main())
