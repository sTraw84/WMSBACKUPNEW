import sys
import tempfile
from PyQt5.QtWidgets import (
    QApplication,
    QVBoxLayout,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QLineEdit,
    QTextEdit,
    QScrollArea,
    QDialog,
    QDialogButtonBox,
    QSpacerItem,
    QSizePolicy,
    QTabWidget,
    QCheckBox,
    QWidget,
    QSplitter,
    QFileDialog,
)
from PyQt5.QtWidgets import QMessageBox
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QIntValidator
import qdarkstyle
from program_files.csv_writers import CSV_Writer_SubTransfer
from .MainButtons import MainButtons
from .BaseGUI import BaseWidget
from .InlineEditors import CollapsibleListEditor


class NumericLineEdit(QLineEdit):
    def __init__(self, parent=None):
        super(NumericLineEdit, self).__init__(parent)
        self.setValidator(QIntValidator(0, 999999, self))


class ChildPartRow(QWidget):
    def __init__(self, index: int, part_number: str = "", qty: int = 1, from_loc: str = ""):
        super(ChildPartRow, self).__init__()
        self.index = index
        row = QHBoxLayout()
        row.setContentsMargins(0, 0, 0, 0)
        row.setSpacing(6)

        self.lbl = QLabel(f"Child Part {index}:")
        self.ed_part = QLineEdit(part_number)
        self.ed_part.setPlaceholderText("Part Number")

        self.lbl_qty = QLabel("QTY:")
        self.ed_qty = NumericLineEdit()
        self.ed_qty.setText(str(qty))
        self.ed_qty.setFixedWidth(60)

        self.lbl_loc = QLabel("From Loc:")
        self.ed_loc = QLineEdit(from_loc)
        self.ed_loc.setPlaceholderText("From Loc:")

        row.addWidget(self.lbl)
        row.addWidget(self.ed_part)
        row.addWidget(self.lbl_qty)
        row.addWidget(self.ed_qty)
        row.addWidget(self.lbl_loc)
        row.addWidget(self.ed_loc)
        self.setLayout(row)


class TransferGUI(BaseWidget):
    def __init__(self):
        super(TransferGUI, self).__init__()
        self.setWindowTitle("Transfer Parts")
        self.resize(560, 540)
        self.setMinimumSize(540, 520)

        self._side_panel_width = 300
        self._min_left_width = 320
        self._min_side_panel_width = 220
        self._left_before_side_panel = None

        self.locators_list = []
        self.mode = "transfer"
        self.csv_writer = CSV_Writer_SubTransfer
        self.screen_indicator = "SUBTRANSFER"
        self.temp_csv_file = tempfile.NamedTemporaryFile(delete=False, mode='w', newline='')
        self.row_counter = 1
        self.csv_headers = ["NUMBER", "PROMPT", "KEY", "DATA"]
        self.csv_writer.write_csv_headers(self.temp_csv_file)
        self.temp_csv_file.close()

        self.status_label = QLabel("")
        self.main_layout = QVBoxLayout(self)

        self.splitter = QSplitter(Qt.Horizontal, self)  # type: ignore[attr-defined]
        self.splitter.setHandleWidth(1)
        self.main_layout.addWidget(self.splitter)

        self.left_container = QWidget(self.splitter)
        self.left_layout = QVBoxLayout(self.left_container)
        self.left_layout.setContentsMargins(0, 0, 0, 0)
        self.left_layout.setSpacing(5)

        top_bar = QWidget(self.left_container)
        self.top_layout = QHBoxLayout(top_bar)
        self.top_layout.setContentsMargins(0, 0, 0, 0)
        self.top_layout.addWidget(self.status_label)
        self.toggle_side_panel_button = QPushButton('Lists ▶', top_bar)
        self.toggle_side_panel_button.setToolTip('Show or hide the lists panel')
        self.toggle_side_panel_button.setMinimumWidth(
            self.toggle_side_panel_button.sizeHint().width()
        )
        self.toggle_side_panel_button.clicked.connect(self.toggle_side_panel)
        self.top_layout.addWidget(self.toggle_side_panel_button)
        self.left_layout.addWidget(top_bar)

        self.scroll = QScrollArea(self.left_container)
        self.scroll.setWidgetResizable(True)
        self.scroll_w = QWidget(self.scroll)
        self.scroll_v = QVBoxLayout(self.scroll_w)
        self.scroll.setWidget(self.scroll_w)
        self.left_layout.addWidget(self.scroll)

        warn = QLabel("WARNING! Verify locations and quantities before transfer.")
        warn.setStyleSheet("color: yellow;")
        self.scroll_v.addWidget(warn)

        header = QLabel("Child Parts")
        header.setStyleSheet("font-weight: bold; font-size: 14px;")
        self.scroll_v.addWidget(header)

        self.prompt_loc_checkbox = QCheckBox("Prompt Locations in WMS")
        self.prompt_loc_checkbox.setToolTip(
            "Add PROMPTLOC to CSV for manual location entry in WMS"
        )
        self.prompt_loc_checkbox.stateChanged.connect(self.toggle_locators_button)
        self.scroll_v.addWidget(self.prompt_loc_checkbox)

        btns = QHBoxLayout()
        self.btn_paste = QPushButton("Paste Multi.")
        self.btn_paste.setToolTip(
            "Open tabbed dialog to paste multiple part numbers, locations, and quantities"
        )
        self.btn_paste.clicked.connect(self.paste_multi_parts)

        self.btn_load = QPushButton("Load Template")
        self.btn_load.setToolTip("Load template from file or source")
        self.btn_load.clicked.connect(self.load_parts)

        self.btn_add = QPushButton("+")
        self.btn_add.setToolTip("Add child part row")
        self.btn_add.setFixedWidth(20)
        self.btn_add.clicked.connect(self.add_child_part)

        self.btn_remove = QPushButton("-")
        self.btn_remove.setToolTip("Remove last child part row")
        self.btn_remove.setFixedWidth(20)
        self.btn_remove.clicked.connect(self.remove_child_part)

        self.btn_locators = QPushButton("Locators")
        self.btn_locators.setToolTip("Manage locations for a specific prompt")
        self.btn_locators.clicked.connect(self._handle_locators_click)
        self.btn_locators.setEnabled(not self.prompt_loc_checkbox.isChecked())

        btns.addWidget(self.btn_paste)
        btns.addWidget(self.btn_load)
        btns.addWidget(self.btn_add)
        btns.addWidget(self.btn_remove)
        btns.addWidget(self.btn_locators)
        self.scroll_v.addLayout(btns)

        self.child_rows_container = QVBoxLayout()
        self.scroll_v.addLayout(self.child_rows_container)
        self.child_row_count = 0

        self.scroll_v.addItem(
            QSpacerItem(20, 20, QSizePolicy.Minimum, QSizePolicy.Expanding)
        )

        self.main_buttons = MainButtons(self)
        self.scroll_v.addLayout(self.main_buttons.get_layout())

        self.scroll_v.setSpacing(5)
        self.scroll_v.setContentsMargins(5, 5, 5, 5)

        self.side_panel = QWidget(self.splitter)
        self.side_layout = QVBoxLayout(self.side_panel)
        self.side_layout.setContentsMargins(6, 6, 6, 6)
        self.side_layout.setSpacing(8)

        self.inline_locators_editor = CollapsibleListEditor(
            self,
            title='Locators',
            attr_name='locators_list',
            is_active=lambda: not self.prompt_loc_checkbox.isChecked(),
        )
        self.side_layout.addWidget(self.inline_locators_editor)
        self.inline_locators_editor.apply_button.clicked.connect(self._refresh_inline_editors)
        self.side_layout.addStretch()

        self.splitter.addWidget(self.left_container)
        self.splitter.addWidget(self.side_panel)
        self.splitter.setStretchFactor(0, 1)
        self.splitter.setStretchFactor(1, 0)
        self.splitter.setSizes([1, 0])

        self._refresh_inline_editors()
        self.finalize_initial_size(extra_width=120)
        self._update_side_panel_button()

    def _handle_locators_click(self):
        # Only open dialog if button is enabled
        if self.btn_locators.isEnabled():
            self.show_locators_dialog()

    def toggle_locators_button(self, state):
        # Only enable/disable the Locators button, do not add widgets or layouts
        if self.prompt_loc_checkbox.isChecked():
            self.btn_locators.setEnabled(False)
        else:
            self.btn_locators.setEnabled(True)
        self._refresh_inline_editors()

    def clear_inputs(self):
        # Clear all input fields and child part rows
        self.status_label.setText("")
        # Remove all child part rows
        while self.child_rows_container.count():
            item = self.child_rows_container.takeAt(0)
            if item is not None:
                widget = item.widget() if hasattr(item, 'widget') else None
                if widget:
                    widget.deleteLater()
        self.child_row_count = 0
        # Clear locators list
        self.locators_list = []
        self._refresh_inline_editors()

    def clear_data_fields(self):
        """Alias for clear_inputs - used by MainButtons"""
        self.clear_inputs()
        self._refresh_inline_editors()

    def on_next_build(self):
        """Called when 'Add to CSV' button is clicked"""
        # Gather child part data
        child_parts = []
        for i in range(self.child_rows_container.count()):
            item = self.child_rows_container.itemAt(i)
            if item is not None:
                row_widget = item.widget()
                if row_widget:
                    child_parts.append({
                        'part_number': row_widget.ed_part.text(),
                        'quantity': row_widget.ed_qty.text(),
                        'from_loc': row_widget.ed_loc.text()
                    })
        
        if not child_parts:
            QMessageBox.warning(self, "No Data", "No child parts to add.")
            return

        # If checkbox is checked, bypass all locators checks and warnings
        if self.prompt_loc_checkbox.isChecked():
            locators_to_use = []
        else:
            if not self.locators_list:
                QMessageBox.warning(self, "No Locators", "No locators set. Please add locators.")
                return
            locators_to_use = self.locators_list

        try:
            # Add to CSV and update status
            self.row_counter = self.csv_writer.append_to_csv(
                self.temp_csv_file, self.row_counter, child_parts, locators_to_use
            )
            # Clear the form after adding to CSV
            self.clear_inputs()
            # Update status
            self.status_label.setText("Transfer data added to CSV successfully!")
            self.status_label.setStyleSheet("color: green;")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to add to CSV: {e}")
            self.status_label.setText(f"Error: {str(e)}")

        # Do not re-add or recreate the checkbox here; it already exists in the UI
    def create_csv(self):
        """Legacy method - now handled by MainButtons"""
        pass

    def on_finish_csv(self):
        """Called when 'Save CSV' button is clicked - finalize and save the CSV"""
        import os
        
        try:
            # Check if there's any data in the CSV
            with open(self.temp_csv_file.name, 'r') as file:
                lines = file.readlines()
                
            # If only headers exist, check if there's data in the form to auto-generate CSV
            if len(lines) <= 1:
                # Gather child part data from form
                child_parts = []
                for i in range(self.child_rows_container.count()):
                    item = self.child_rows_container.itemAt(i)
                    if item is not None:
                        row_widget = item.widget()
                        if row_widget:
                            part_num = row_widget.ed_part.text().strip()
                            qty = row_widget.ed_qty.text().strip()
                            from_loc = row_widget.ed_loc.text().strip()
                            # Only add if at least part number is filled
                            if part_num:
                                child_parts.append({
                                    'part_number': part_num,
                                    'quantity': qty if qty else '1',
                                    'from_loc': from_loc
                                })
                
                # If we have form data but no locators, warn about locators
                if child_parts and not self.locators_list:
                    QMessageBox.warning(self, "No Locators", "No locators set. Please add locators using the 'Locators' button.")
                    return
                
                # If we have both form data and locators, auto-generate the CSV
                if child_parts and self.locators_list:
                    self.row_counter = self.csv_writer.append_to_csv(
                        self.temp_csv_file, self.row_counter, child_parts, self.locators_list
                    )
                    self.status_label.setText("CSV generated from current form data")
                    self.status_label.setStyleSheet("color: blue;")
                elif not child_parts:
                    # No data at all
                    QMessageBox.warning(self, "No Data", "No data to save. Please fill out the form or add data via 'Add to CSV'.")

            # If PROMPTLOC is checked, bypass locators requirement for saving
            if not self.prompt_loc_checkbox.isChecked() and not self.locators_list:
                QMessageBox.warning(self, "No Locators", "No locators set. Please add locators.")
                return

            # Add FINISHED row at the end
            self.csv_writer.append_finished(self.temp_csv_file, self.row_counter)
            self.row_counter += 1

            # Get save location
            root_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
            csv_dir = os.path.join(root_dir, "CSV Files")
            file_path, _ = QFileDialog.getSaveFileName(self, "Save Transfer CSV", csv_dir, "CSV Files (*.csv)")

            if file_path:
                # Pass checkbox state to CSV writer
                screen_indicator = "SUBTRANSFER"
                if hasattr(self, "first_transfer_type") and self.first_transfer_type:
                    screen_indicator = (
                        "CGTRANSFER"
                        if self.first_transfer_type == "cost_group"
                        else "SUBTRANSFER"
                    )
                self.csv_writer.save_csv(
                    file_path,
                    self.temp_csv_file,
                    self.csv_headers,
                    add_promptloc=self.prompt_loc_checkbox.isChecked(),
                    screen_indicator=screen_indicator,
                )
                QMessageBox.information(self, "Success", f"CSV saved to {file_path}")
                self.status_label.setText("CSV saved successfully!")
                self.status_label.setStyleSheet("color: green;")
            else:
                # User cancelled, remove the FINISHED row we just added
                with open(self.temp_csv_file.name, 'r') as file:
                    lines = file.readlines()
                with open(self.temp_csv_file.name, 'w') as file:
                    file.writelines(lines[:-1])  # Remove last line
                self.row_counter -= 1
                
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to save CSV: {e}")
            self.status_label.setText(f"Error: {str(e)}")
            self.status_label.setStyleSheet("color: red;")

    def add_child_part(self, part_number="", qty=1, from_loc=""):
        self.child_row_count += 1
        # Ensure part_number is always a string
        safe_part_number = str(part_number) if not isinstance(part_number, bool) else ""
        row = ChildPartRow(self.child_row_count, safe_part_number, qty, from_loc)
        self.child_rows_container.addWidget(row)

    def remove_child_part(self):
        if self.child_row_count > 0:
            item_index = self.child_rows_container.count() - 1
            if item_index >= 0:
                item = self.child_rows_container.takeAt(item_index)
                if item is not None:
                    w = item.widget()
                    if w is not None:
                        w.deleteLater()
                self.child_row_count -= 1

    def paste_multi_parts(self):
        dlg = QDialog(self)
        dlg.setWindowTitle("Paste Multiple Values")
        dlg.resize(500, 400)
        
        main_layout = QVBoxLayout(dlg)
        
        # Create tab widget
        tab_widget = QTabWidget()
        
        # Part Numbers Tab
        part_tab = QWidget()
        part_layout = QVBoxLayout(part_tab)
        part_layout.addWidget(QLabel("Paste part numbers, one per line:"))
        self.part_text = QTextEdit()
        part_layout.addWidget(self.part_text)
        tab_widget.addTab(part_tab, "Part Numbers")
        
        # From Locations Tab
        location_tab = QWidget()
        location_layout = QVBoxLayout(location_tab)
        location_layout.addWidget(QLabel("Paste from locations, one per line:"))
        self.location_text = QTextEdit()
        location_layout.addWidget(self.location_text)
        tab_widget.addTab(location_tab, "From Locations")
        
        # Quantities Tab
        qty_tab = QWidget()
        qty_layout = QVBoxLayout(qty_tab)
        qty_layout.addWidget(QLabel("Paste quantities, one per line (numbers only):"))
        self.qty_text = QTextEdit()
        qty_layout.addWidget(self.qty_text)
        tab_widget.addTab(qty_tab, "Quantities")
        
        main_layout.addWidget(tab_widget)
        
        # Add information label
        info_label = QLabel("Tip: Fill out data in each tab, then click OK to apply all data at once.")
        info_label.setStyleSheet("color: #888; font-style: italic;")
        main_layout.addWidget(info_label)
        
        # Buttons
        btns = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        main_layout.addWidget(btns)
        
        btns.accepted.connect(lambda: self._apply_tabbed_paste(dlg))
        btns.rejected.connect(dlg.reject)
        
        dlg.exec_()

    def _apply_tabbed_paste(self, dialog: QDialog):
        """Apply data from all tabs of the paste dialog"""
        # Get data from all tabs
        part_lines = [line.strip() for line in self.part_text.toPlainText().splitlines() if line.strip()]
        location_lines = [line.strip() for line in self.location_text.toPlainText().splitlines() if line.strip()]
        qty_lines = [line.strip() for line in self.qty_text.toPlainText().splitlines() if line.strip()]
        
        # Determine the maximum number of rows needed
        max_rows = max(len(part_lines), len(location_lines), len(qty_lines))

        if max_rows == 0:
            dialog.reject()
            return

        # Ensure enough child rows exist to receive the pasted data
        while self.child_rows_container.count() < max_rows:
            self.add_child_part()

        # Apply pasted values row by row
        for i in range(max_rows):
            layout_item = self.child_rows_container.itemAt(i)
            if layout_item is None:
                continue
            row_widget = layout_item.widget()
            if not isinstance(row_widget, ChildPartRow):
                continue

            if i < len(part_lines):
                row_widget.ed_part.setText(part_lines[i])
            if i < len(location_lines):
                row_widget.ed_loc.setText(location_lines[i])
            if i < len(qty_lines):
                try:
                    qty = int(qty_lines[i])
                except ValueError:
                    continue
                if qty < 0:
                    continue
                row_widget.ed_qty.setText(str(qty))
        dialog.accept()

    def _apply_paste(self, text: str, dialog: QDialog, paste_mode: str = "Part Numbers"):
        lines = [line.strip() for line in text.splitlines() if line.strip()]

        if paste_mode == "Part Numbers":
            # Original behavior: add new rows for each part number
            for part in lines:
                self.add_child_part()
                # Set part text on the last row
                last_index = self.child_rows_container.count() - 1
                if last_index >= 0:
                    last_layout_item = self.child_rows_container.itemAt(last_index)
                    if last_layout_item is not None:
                        last_row_widget = last_layout_item.widget()
                        if isinstance(last_row_widget, ChildPartRow):
                            last_row_widget.ed_part.setText(part)

        elif paste_mode == "From Locations":
            # Fill existing rows with locations, add new rows if needed
            for i, location in enumerate(lines):
                # Check if we need to add a new row
                if i >= self.child_rows_container.count():
                    self.add_child_part()

                # Set location on the current row
                layout_item = self.child_rows_container.itemAt(i)
                if layout_item is not None:
                    row_widget = layout_item.widget()
                    if isinstance(row_widget, ChildPartRow):
                        row_widget.ed_loc.setText(location)

        elif paste_mode == "Quantities":
            # Fill existing rows with quantities, add new rows if needed
            for i, qty_text in enumerate(lines):
                # Validate that it's a number
                try:
                    qty = int(qty_text)
                    if qty < 0:
                        continue  # Skip negative numbers
                except ValueError:
                    continue  # Skip non-numeric values

                # Check if we need to add a new row
                if i >= self.child_rows_container.count():
                    self.add_child_part()

                # Set quantity on the current row
                layout_item = self.child_rows_container.itemAt(i)
                if layout_item is not None:
                    row_widget = layout_item.widget()
                    if isinstance(row_widget, ChildPartRow):
                        row_widget.ed_qty.setText(str(qty))

        dialog.accept()

    def load_parts(self):
        import pandas as pd
        import os
        root_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        templates_dir = os.path.join(root_dir, "Build Templates")
        file_path, _ = QFileDialog.getOpenFileName(self, "Select Excel File", templates_dir, "Excel Files (*.xlsx *.xls)")
        if not file_path:
            return
        try:
            df = pd.read_excel(file_path)
        except Exception as e:
            QMessageBox.warning(self, "Error", f"Failed to read Excel file: {e}")
            return
        # Expect columns: Part#, Location, QTY
        required_cols = ["Part#", "Location", "QTY"]
        if not all(col in df.columns for col in required_cols):
            QMessageBox.warning(self, "Error", f"Excel file must have columns: {', '.join(required_cols)}")
            return
        # Remove any existing child part rows
        while self.child_row_count > 0:
            self.remove_child_part()
        # Add a row for each entry in the Excel file, but leave part numbers blank for manual entry
        for _, row in df.iterrows():
            qty = int(row["QTY"]) if not pd.isna(row["QTY"]) else 1
            loc = str(row["Location"]) if not pd.isna(row["Location"]) else ""
            self.add_child_part("", qty, loc)  # part number intentionally blank

    def show_locators_dialog(self):
        self.open_locators_inline()

    def open_locators_inline(self):
        try:
            if not hasattr(self, 'inline_locators_editor'):
                return
            self._ensure_side_panel_visible()
            editor = self.inline_locators_editor
            if not editor.container.isVisible():
                editor.container.setVisible(True)
                editor._update_toggle_icon()
            editor.programmatic_update()
            editor.editor.setFocus()
        except Exception:
            pass

    def _update_side_panel_button(self) -> None:
        try:
            sizes = self.splitter.sizes() if hasattr(self, 'splitter') else []
            if sizes and len(sizes) >= 2 and sizes[1] > 0:
                self.toggle_side_panel_button.setText('Lists ◀')
            else:
                self.toggle_side_panel_button.setText('Lists ▶')
        except Exception:
            pass

    def _open_side_panel(self) -> None:
        if not hasattr(self, 'splitter'):
            return
        sizes = self.splitter.sizes()
        if len(sizes) < 2:
            return
        left_width = max(sizes[0], self._min_left_width)
        desired_right = max(self._min_side_panel_width, self._side_panel_width)
        self._left_before_side_panel = left_width
        self.resize(self.width() + desired_right, self.height())
        self.splitter.setSizes([left_width, desired_right])

    def _collapse_side_panel(self) -> None:
        if not hasattr(self, 'splitter'):
            return
        sizes = self.splitter.sizes()
        if len(sizes) < 2:
            return
        right_width = sizes[1]
        if right_width <= 0:
            return
        target_width = max(self.minimumWidth(), self.width() - right_width)
        self.resize(target_width, self.height())
        left_target = (
            self._left_before_side_panel
            if self._left_before_side_panel is not None
            else sizes[0]
        )
        left_target = max(self._min_left_width, min(left_target, target_width))
        self.splitter.setSizes([left_target, 0])
        self._left_before_side_panel = None

    def toggle_side_panel(self) -> None:
        try:
            if not hasattr(self, 'splitter'):
                return
            sizes = self.splitter.sizes()
            if len(sizes) < 2:
                return
            if sizes[1] == 0:
                self._open_side_panel()
            else:
                self._collapse_side_panel()
            self._update_side_panel_button()
        except Exception:
            pass

    def _ensure_side_panel_visible(self) -> None:
        try:
            sizes = self.splitter.sizes()
            if len(sizes) < 2:
                return
            if sizes[1] == 0:
                self._open_side_panel()
                self._update_side_panel_button()
        except Exception:
            pass

    def _refresh_inline_editors(self) -> None:
        if hasattr(self, 'inline_locators_editor'):
            self.inline_locators_editor.programmatic_update()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    # Apply qdarkstyle theme (support both v3 and v2 function names)
    try:
        app.setStyleSheet(qdarkstyle.load_stylesheet(qt_api='pyqt5'))
    except Exception:
        try:
            app.setStyleSheet(qdarkstyle.load_stylesheet_pyqt5())
        except Exception:
            pass
    w = TransferGUI()
    w.show()
    sys.exit(app.exec_())
