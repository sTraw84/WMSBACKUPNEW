import csv

def write_asset_capture_csv(file_path, assets):
	"""
	Write an asset capture CSV file using prompt-based format for each asset type.
	assets: list of dicts with keys including 'Type' and relevant fields
	"""
	headers = ["NUMBER", "TYPE", "PROMPT", "KEY", "DATA"]
	# Sort assets so that NS3160A6NODEINSDENSE123-T is first, then I24A6-AMD-123.ACTUAL.MNMFDJ.LINKEDIN, then the rest
	priority = ["NS3160A6NODEINSDENSE123-T", "I24A6-AMD-123.ACTUAL.MNMFDJ.LINKEDIN"]
	def asset_sort_key(asset):
		part = asset.get('part', '')
		if part == priority[0]:
			return (0,)
		elif part == priority[1]:
			return (1,)
		else:
			return (2,)
	sorted_assets = sorted(assets, key=asset_sort_key)
	rows = []
	number = 1
	for asset in sorted_assets:
		asset_type = asset.get('Type', 'Asset')
		if asset_type == "PDU":
			rows.append([number, "PDU", "Item       >", "part", asset.get('part',"")]); number += 1
			rows.append([number, "PDU", "SN         >", "serial", asset.get('serial',"")]); number += 1
			rows.append([number, "PDU", "Asset Number :", "asset", asset.get('asset',"")]); number += 1
			rows.append([number, "PDU", "Rack Position:", "ru", asset.get('ru',"")]); number += 1
		elif asset_type == "Rack":
			rows.append([number, "Rack", "Item       >", "part", asset.get('part',"")]); number += 1
			rows.append([number, "Rack", "SN         >", "serial", asset.get('serial',"")]); number += 1
			rows.append([number, "Rack", "Asset Number :", "asset", asset.get('asset',"")]); number += 1
			rows.append([number, "Rack", "MSF Part     :", "msf_part", asset.get('msf_part',"")]); number += 1
			rows.append([number, "Rack", "MSF Asset    :", "msf_asset", asset.get('msf_asset',"")]); number += 1
			rows.append([number, "Rack", "Rack Position:", "ru", asset.get('ru',"")]); number += 1
		elif asset_type == "Device":
			rows.append([number, "Device", "Item       >", "part", asset.get('part',"")]); number += 1
			rows.append([number, "Device", "SN         >", "serial", asset.get('serial',"")]); number += 1
			rows.append([number, "Device", "Asset Number :", "asset", asset.get('asset',"")]); number += 1
			rows.append([number, "Device", "MSF Part     :", "msf_part", asset.get('msf_part',"")]); number += 1
			rows.append([number, "Device", "Rack Position:", "ru", asset.get('ru',"")]); number += 1
		elif asset_type == "LinkDevice":
			rows.append([number, "LinkDevice", "Item       >", "part", asset.get('part',"")]); number += 1
			rows.append([number, "LinkDevice", "SN         >", "serial", asset.get('serial',"")]); number += 1
			rows.append([number, "LinkDevice", "Asset Number :", "asset", asset.get('asset',"")]); number += 1
			rows.append([number, asset_type, "Rack Position:", "ru2", "00"]); number += 1
		elif asset_type == "LinkNode":
			rows.append([number, "LinkNode", "Item       >", "part", asset.get('part',"")]); number += 1
			rows.append([number, "LinkNode", "SN         >", "serial", asset.get('serial',"")]); number += 1
			rows.append([number, asset_type, "MAC Address  :", "ENTER", ""]); number += 1
			rows.append([number, "LinkNode", "Asset Number :", "asset", asset.get('asset',"")]); number += 1
			rows.append([number, asset_type, "Mac Address 3:", "ENTER", ""]); number += 1
		else:
			rows.append([number, asset_type, "Item       >", "part", asset.get('part',"")]); number += 1
			rows.append([number, asset_type, "SN         >", "serial", asset.get('serial',"")]); number += 1
			rows.append([number, asset_type, "RU Location    >", "ru", asset.get('ru',"")]); number += 1
			rows.append([number, asset_type, "Asset Name     >", "asset", asset.get('asset',"")]); number += 1
		rows.append([number, asset_type, "<Attribute Confirm>", "ENTER", ""]); number += 1
	with open(file_path, "w", newline="") as f:
		writer = csv.writer(f)
		writer.writerow(headers)
		writer.writerows(rows)
		writer.writerow([str(len(rows)+1), "", "FINISHED", "", ""])
		writer.writerow([str(len(rows)+2), "", "ASSETCAPTURE", "", ""])
