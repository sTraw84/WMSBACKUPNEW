# Keyring (Secure Token Storage) — Notes and Usage

This document explains how the project uses the OS keyring to securely store the Smartsheet API token, how to configure it, and recommended next steps for enforcing secure practices.

Summary
- The GUI (`program_files/guis/SSLinkCreator.py`) prefers credentials in the following order:
  1. Environment variable `SS_API_TOKEN` (highest precedence)
 2. OS keyring via the `keyring` Python package
 3. Built-in fallback token (only present for compatibility)

- When you click "Set API Token" in the SS Link Creator UI you are prompted whether to save the token to the OS keyring for future runs.

Recommendation: make `keyring` required
- For company APIs we strongly recommend persisting tokens in the OS keyring rather than leaving them in code or files. Storing in the OS keyring reduces the risk of accidental commits and keeps credentials per-user and protected by the OS.
- I recommend making `keyring` required for this repository (it's already added to `dev-tools/requirements.txt`). The usual pattern is:
  - Keep `keyring` in `requirements.txt` and in `setup_env.ps1` so the environment installs it automatically.
  - Remove any hard-coded fallback API token from the code, and require either an env var or a keyring entry. (Optional: keep the fallback during a transition period.)

How keyring works (high-level)
- Windows: uses Credential Manager
- macOS: uses Keychain
- Linux: tries Secret Service / KWallet; if no backend is available keyring may fall back to a less-secure storage backend (documented below).

Commands and quick tests (PowerShell)
- Install environment and dependencies (from project root):
```powershell
cd .\dev-tools
.\setup_env.ps1
```

- Activate the created venv and run a Python REPL to test keyring manually:
```powershell
# from project root
.\.venv\Scripts\Activate.ps1
python -c "import keyring; keyring.set_password('WWT_WMS_SSLinkCreator','ss_api_token','test-token'); print(keyring.get_password('WWT_WMS_SSLinkCreator','ss_api_token'))"
# expected output: test-token
```

Using the GUI
- Open the launcher (from repo root, with the venv activated):
```powershell
python .\HomeGUI.pyw
```
- Other Tools → SS Link Creator → Set API Token. Enter the token (masked). After entering you'll be asked whether to save it to the OS keyring.

Environment variable override
- For CI or scripted runs you can set `SS_API_TOKEN` in the environment to override the stored keyring value.
  - PowerShell example (temporary for the session):
```powershell
$env:SS_API_TOKEN = 'xxxxxxxxxx'
python .\HomeGUI.pyw
```

How to remove a saved token
- Windows: open Credential Manager → Windows Credentials → find `WWT_WMS_SSLinkCreator` entry and remove it.
- Or use Python keyring to delete it:
```powershell
python -c "import keyring; keyring.delete_password('WWT_WMS_SSLinkCreator','ss_api_token')"
```

Troubleshooting (Linux)
- On some Linux installations the user keyring backend requires DBus (e.g., `dbus-user-session`) or `libsecret` to be available. If `keyring` cannot find an appropriate secure backend it may fall back to an insecure storage method; check `keyring.get_keyring()` in Python to inspect the backend.
- If you want to avoid those platform specifics you can continue to use environment variables for automated workflows and keep keyring for interactive desktop users.

Security considerations
- The OS keyring is significantly more secure than a plaintext file or a repo-stored token. However, keyring security is constrained by the underlying OS and user account security.
- For very high-security environments consider a centralized secrets manager (HashiCorp Vault, Azure Key Vault, AWS Secrets Manager) and integrate retrieval via an authenticated service account.

Suggested immediate actions
1. Keep `keyring` in `dev-tools/requirements.txt` (done).
2. Remove the hard-coded fallback token from `SSLinkCreator.py` and require either a keyring entry or env var. I can make this change for you in a follow-up commit.
3. Add a short README section in the repo root summarizing token handling and the one-liner to add a token via `keyring` (I can add that too).

If you want me to proceed
- I can remove the fallback token and require keyring/envvar (preferred for company security).
- I can add a small README entry at the repo root and a short help dialog inside the SS Link Creator UI.

Questions? Reply with which follow-up you want (remove fallback now / add top-level README / add UI help / persist token automatically without prompting). 
