import tempfile
from collections import defaultdict
from typing import Any, Dict, List, Mapping, Optional, Sequence, cast
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QIntValidator
from PyQt5.QtWidgets import QGridLayout, QGroupBox, QHBoxLayout, QLabel, QLineEdit, QMessageBox, QPushButton, QRadioButton, QSizePolicy, QVBoxLayout, QWidget

from program_files.csv_writers import CSV_Writer_DustinSpares


from .BaseGUI import BaseDialog
from .MainButtons import MainButtons


class IntLineEdit(QLineEdit):
    def __init__(self, parent: Optional[QWidget] = None) -> None:
        super().__init__(parent)
        self.setValidator(QIntValidator(0, 999999, self))


class DustinSparesGUI(BaseDialog):
    def _add_part_row(self):
        self.num_parts += 1
        self._initialize_part_entries()
        self._update_row_headers()
        self._clear_lpn_rows(add_blank=True, mark_dirty=True)
        self.plan_consumed = False
        self._update_add_button_state()

    def upload_spreadsheet(self) -> None:
        from PyQt5.QtWidgets import QFileDialog, QMessageBox
        import pandas as pd
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "Select Spreadsheet",
            "",
            "Excel Files (*.xlsx *.xls);;All Files (*)"
        )
        if not file_path:
            self.file_label.setText("No file selected")
            return
        self.starting_sheet_path = file_path
        self.file_label.setText(file_path.split("/")[-1])
        try:
            df = pd.read_excel(file_path)
        except Exception as e:
            self.file_label.setText(f"Error loading: {e}")
            QMessageBox.warning(self, "Error", f"Failed to read Excel file: {e}")
            return
        # Auto-detect part columns (StartX/EndX pairs)
        part_indices = []
        for col in df.columns:
            if col.lower().startswith("start"):
                idx = col[5:]  # Get the number after 'Start'
                if any(f"End{idx}".lower() == c.lower() for c in df.columns):
                    part_indices.append(idx)
        num_parts = len(part_indices)
        self.num_parts = num_parts
        self._initialize_part_entries()  # Create empty part entry boxes
        self._update_row_headers()
        # Build rows for C40 tab
        rows = []
        for _, row in df.iterrows():
            row_dict = {}
            lpn_col = next((c for c in df.columns if c.lower() == "lpn"), None)
            row_dict["lpn"] = str(row[lpn_col]) if lpn_col and pd.notna(row[lpn_col]) else ""
            for idx in part_indices:
                start_col = next((c for c in df.columns if c.lower() == f"start{idx}"), None)
                end_col = next((c for c in df.columns if c.lower() == f"end{idx}"), None)
                row_dict[f"start{idx}"] = str(row[start_col]) if start_col and pd.notna(row[start_col]) else ""
                row_dict[f"end{idx}"] = str(row[end_col]) if end_col and pd.notna(row[end_col]) else ""
            rows.append(row_dict)
        self._clear_lpn_rows(add_blank=False, mark_dirty=False)
        self._populate_rows(rows)
        self._set_status(f"Loaded {len(rows)} rows from {file_path.split('/')[-1]}", success=True)
    def _remove_part_row(self):
        if self.part_entries:
            entry = self.part_entries.pop()
            # Only remove if it's a QLineEdit widget
            if isinstance(entry, QLineEdit):
                self.part_entries_layout.removeWidget(entry)
                entry.deleteLater()
                self.part_entries_container.adjustSize()
        # Synchronize C40 tab header and rows
        self._rebuild_c40_headers_and_rows()
    # Removed: toggle_side_panel and related inline report logic (now handled by tab)
    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle("Dustin Spare Balancer")
        self.screen_indicator = "REPACK"
        self.csv_writer = CSV_Writer_DustinSpares
        self.temp_csv_file = tempfile.NamedTemporaryFile(delete=False, mode="w", newline="")
        self.csv_writer.write_csv_headers(self.temp_csv_file)
        self.temp_csv_file.flush()
        self.row_counter = 1
        self.csv_headers = ["NUMBER", "PROMPT", "KEY", "DATA"]
        self.starting_sheet_path = None
        self.spare_mode = None
        self.plan_consumed = False
        self.row_entries = []
        self.part_entries = []
        self.num_parts = 1  # Default to 1 part
        self._suppress_row_change = False
        # Ensure part entry layout is initialized before any method uses it
        self.part_entries_container = QWidget()
        self.part_entries_layout = QVBoxLayout(self.part_entries_container)
        self.part_entries_layout.setContentsMargins(0, 0, 0, 0)
        self.part_entries_layout.setSpacing(6)
        # Ensure header layout is initialized before any method uses it
        self.header_widget = QWidget()
        self.header_layout = QGridLayout(self.header_widget)
        self.header_layout.setContentsMargins(0, 0, 0, 0)
        self.header_layout.setHorizontalSpacing(10)
        self.header_layout.setVerticalSpacing(0)
        # Ensure rows layout is initialized before any method uses it
        self.rows_container = QWidget()
        self.rows_layout = QVBoxLayout(self.rows_container)
        self.rows_layout.setSpacing(4)
        self.rows_layout.setContentsMargins(0, 0, 0, 0)
        # Status label for messages
        self.status_label = QLabel("")
        self.status_label.setStyleSheet("color: #FFD700; font-size: 13px;")
        self.status_label.setAlignment(Qt.AlignmentFlag.AlignLeft)
        # Build UI
        self._build_ui()
        self._initialize_part_entries()
        self._update_row_headers()
        self._add_lpn_row(mark_dirty=False)
        self.finalize_initial_size(extra_width=80)
        self._update_add_button_state()


    def _build_ui(self) -> None:
        self.resize(800, 600)
        self.setMinimumSize(700, 500)
        self.main_layout = QVBoxLayout(self)

        # Tab widget setup
        from PyQt5.QtWidgets import QTabWidget, QTextEdit
        self.tabs = QTabWidget(self)
        self.main_layout.addWidget(self.tabs)

        # --- Tab 1: Main ---
        self.tab_main = QWidget()
        tab_main_layout = QVBoxLayout(self.tab_main)
        # Title
        title = QLabel("Balance Dustin Spares")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title.setStyleSheet("font-size: 18px; font-weight: bold;")
        tab_main_layout.addWidget(title)
        # Upload box
        upload_box = QHBoxLayout()
        self.upload_button = QPushButton("Upload Spreadsheet")
        self.upload_button.clicked.connect(self.upload_spreadsheet)
        upload_box.addWidget(self.upload_button)
        self.file_label = QLabel("No file selected")
        self.file_label.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        upload_box.addWidget(self.file_label)
        tab_main_layout.addLayout(upload_box)
        # Source radio group
        source_group = QGroupBox("Where are the spares coming from?")
        source_layout = QGridLayout()
        self.location_radio = QRadioButton("Location")
        self.location_radio.toggled.connect(lambda checked: checked and self._set_spare_mode("location"))
        source_layout.addWidget(self.location_radio, 0, 0)
        self.lpn_radio = QRadioButton("LPN")
        self.lpn_radio.toggled.connect(lambda checked: checked and self._set_spare_mode("lpn"))
        source_layout.addWidget(self.lpn_radio, 0, 1)
        source_group.setLayout(source_layout)
        tab_main_layout.addWidget(source_group)
        # Spare LPN entry
        self.spare_lpn_container = QWidget()
        spare_lpn_layout = QHBoxLayout(self.spare_lpn_container)
        spare_lpn_layout.setContentsMargins(0, 0, 0, 0)
        spare_lpn_layout.setSpacing(6)
        spare_label = QLabel("Spare LPN:")
        spare_lpn_layout.addWidget(spare_label)
        self.spare_lpn_edit = QLineEdit()
        self.spare_lpn_edit.textChanged.connect(self._on_rows_changed)
        spare_lpn_layout.addWidget(self.spare_lpn_edit)
        self.spare_lpn_container.hide()
        tab_main_layout.addWidget(self.spare_lpn_container)
        # Part Numbers Configuration
        parts_group = QGroupBox("Part Numbers Configuration")
        parts_layout = QVBoxLayout()
        part_controls_layout = QHBoxLayout()
        self.add_part_button = QPushButton("+")
        self.add_part_button.setFixedWidth(30)
        self.add_part_button.setToolTip("Add part type")
        self.add_part_button.clicked.connect(self._add_part_row)
        self.remove_part_button = QPushButton("-")
        self.remove_part_button.setFixedWidth(30)
        self.remove_part_button.setToolTip("Remove last part type")
        self.remove_part_button.clicked.connect(self._remove_part_row)
        part_controls_layout.addWidget(self.add_part_button)
        part_controls_layout.addWidget(self.remove_part_button)
        part_controls_layout.addStretch()
        parts_layout.addLayout(part_controls_layout)
        self.part_header_container = QWidget()
        self.part_header_layout = QVBoxLayout(self.part_header_container)
        self.part_header_layout.setContentsMargins(0, 0, 0, 0)
        self.part_header_layout.setSpacing(0)
        part_label_header = QLabel("Part Number(s)")
        part_label_header.setAlignment(Qt.AlignmentFlag.AlignCenter)
        part_label_header.setStyleSheet("font-weight: bold; font-size: 14px;")
        part_label_header.setMinimumWidth(200)
        self.part_header_layout.addWidget(part_label_header)
        parts_layout.addWidget(self.part_header_container)
        self.part_entries_container = QWidget()
        self.part_entries_layout = QVBoxLayout(self.part_entries_container)
        self.part_entries_layout.setContentsMargins(0, 0, 0, 0)
        self.part_entries_layout.setSpacing(6)
        parts_layout.addWidget(self.part_entries_container)
        parts_group.setLayout(parts_layout)
        tab_main_layout.addWidget(parts_group)
        # Add stretch to keep controls at top
        tab_main_layout.addStretch()
        self.tab_main.setLayout(tab_main_layout)
        self.tabs.addTab(self.tab_main, "Main")

        # --- Tab 2: C40 Builds ---
        self.tab_c40 = QWidget()
        tab_c40_layout = QVBoxLayout(self.tab_c40)
        controls_layout = QHBoxLayout()
        self.add_row_button = QPushButton("Add C40 Row")
        self.add_row_button.clicked.connect(lambda: self._add_lpn_row())
        controls_layout.addWidget(self.add_row_button)
        self.clear_rows_button = QPushButton("Clear Rows")
        self.clear_rows_button.clicked.connect(self._clear_lpn_rows)
        controls_layout.addWidget(self.clear_rows_button)
        controls_layout.addStretch()
        tab_c40_layout.addLayout(controls_layout)
        self.header_widget = QWidget()
        self.header_layout = QGridLayout(self.header_widget)
        self.header_layout.setContentsMargins(0, 0, 0, 0)
        self.header_layout.setHorizontalSpacing(10)
        self.header_layout.setVerticalSpacing(0)
        tab_c40_layout.addWidget(self.header_widget)
        self.rows_container = QWidget()
        self.rows_layout = QVBoxLayout(self.rows_container)
        self.rows_layout.setSpacing(4)
        self.rows_layout.setContentsMargins(0, 0, 0, 0)
        tab_c40_layout.addWidget(self.rows_container)
        tab_c40_layout.addStretch()
        self.tab_c40.setLayout(tab_c40_layout)
        self.tabs.addTab(self.tab_c40, "C40 Builds")

        # --- Tab 3: Balancing Report ---
        self.tab_report = QWidget()
        tab_report_layout = QVBoxLayout(self.tab_report)
        self.report_output = QTextEdit(self.tab_report)
        self.report_output.setReadOnly(True)
        self.report_output.setFrameStyle(QTextEdit.NoFrame)
        self.report_output.setStyleSheet("background: transparent; font-size: 13px; border: none;")
        tab_report_layout.addWidget(self.report_output)
        self.tab_report.setLayout(tab_report_layout)
        self.tabs.addTab(self.tab_report, "Balancing Report")

        # Main buttons always visible at bottom
        self.main_buttons = MainButtons(self)
        self.main_layout.addLayout(self.main_buttons.get_layout())
        # Add status label to main layout
        self.main_layout.addWidget(self.status_label)

    def _populate_rows(
        self,
        rows: Sequence[Mapping[str, Any]],
    ) -> None:
        self._suppress_row_change = True
        self._clear_lpn_rows(add_blank=False, mark_dirty=False)
        for row in rows:
            self._add_lpn_row(row, mark_dirty=False)
        if not rows:
            self._add_lpn_row(mark_dirty=False)
        self._suppress_row_change = False
        self.plan_consumed = False
        self._set_status("")
        self._update_add_button_state()

    def _initialize_part_entries(self) -> None:
        """Initialize the part number entry fields based on num_parts"""
        # Clear existing entries
        for entry in self.part_entries:
            entry['widget'].deleteLater()
        self.part_entries.clear()
        
        # Create new entries
        for i in range(self.num_parts):
            widget = QWidget()
            layout = QHBoxLayout(widget)
            layout.setContentsMargins(0, 0, 0, 0)
            
            label = QLabel(f"Part {i+1}:")
            layout.addWidget(label)
            
            line_edit = QLineEdit()
            line_edit.setPlaceholderText(f"Enter part number {i+1}")
            line_edit.setText(f"Linecard{i+1}")  # Default values
            line_edit.textChanged.connect(self._on_rows_changed)
            layout.addWidget(line_edit)
            
            entry = {
                'widget': widget,
                'label': label, 
                'line_edit': line_edit
            }
            self.part_entries.append(entry)
            self.part_entries_layout.addWidget(widget)

    def _on_num_parts_changed(self, value: str) -> None:
        """Handle change in number of parts"""
        try:
            new_num_parts = int(value)
            if new_num_parts == self.num_parts:
                return
                
            self.num_parts = new_num_parts
            self._initialize_part_entries()
            self._update_row_headers()
            self._clear_lpn_rows(add_blank=True, mark_dirty=True)
            self.plan_consumed = False
            self._update_add_button_state()
        except ValueError:
            pass

    def _update_row_headers(self) -> None:
        """Update the column headers based on number of parts"""
        # Clear existing header
        for i in reversed(range(self.header_layout.count())):
            item = self.header_layout.itemAt(i)
            if item is not None:
                widget = item.widget()
                if widget is not None:
                    widget.deleteLater()
        
        # Add new headers
        self.header_layout.addWidget(QLabel("#"), 0, 0)
        self.header_layout.addWidget(QLabel("LPN"), 0, 1)
        
        col_index = 2
        for i in range(self.num_parts):
            self.header_layout.addWidget(QLabel(f"Start{i+1}"), 0, col_index)
            self.header_layout.addWidget(QLabel(f"End{i+1}"), 0, col_index + 1)
            col_index += 2
        
        self.header_layout.addWidget(QLabel(""), 0, col_index)  # Remove button column

    def _get_part_numbers(self) -> List[str]:
        """Get the current part numbers from the entry fields"""
        return [entry['line_edit'].text().strip() or f"Linecard{i+1}" 
                for i, entry in enumerate(self.part_entries)]

    def _set_spare_mode(self, mode: str) -> None:
        if self.spare_mode == mode:
            return
        self.spare_mode = mode
        if mode == "lpn":
            self.spare_lpn_container.show()
            self.spare_lpn_edit.setFocus()
        else:
            self.spare_lpn_edit.clear()
            self.spare_lpn_container.hide()
        self.plan_consumed = False
        self._update_add_button_state()

    def _rows_complete(self) -> bool:
        if not self.row_entries:
            return False
        for entry in self.row_entries:
            if not entry["lpn"].text().strip():
                return False
            # Dynamic validation based on number of parts
            for i in range(self.num_parts):
                start_key = f"start{i+1}"
                end_key = f"end{i+1}"
                if start_key in entry and not entry[start_key].text().strip():
                    return False
                if end_key in entry and not entry[end_key].text().strip():
                    return False
        return True

    def _update_add_button_state(self) -> None:
        enabled = (
            not self.plan_consumed
            and self.spare_mode is not None
            and (
                self.spare_mode != "lpn"
                or bool(self.spare_lpn_edit.text().strip())
            )
            and self._rows_complete()
        )
        self.main_buttons.add_button.setEnabled(enabled)

    def _set_status(self, message: str, success: bool = False) -> None:
        if not message:
            self.status_label.clear()
            return
        color = "green" if success else "#ff5555"
        rich_text = f"<span style='color: {color};'>{message}</span>"
        self.status_label.setText(rich_text)

    def _collect_rows(self) -> List[Dict[str, object]]:
        if not self.row_entries:
            raise ValueError(
                "Add at least one C40 line before creating the CSV."
            )
        rows: List[Dict[str, object]] = []
        for idx, entry in enumerate(self.row_entries, start=1):
            lpn = entry["lpn"].text().strip()
            if not lpn:
                raise ValueError(f"Row {idx}: LPN is required.")
            values: Dict[str, object] = {"lpn": lpn}
            
            # Dynamic field validation based on number of parts
            for i in range(self.num_parts):
                start_key = f"start{i+1}"
                end_key = f"end{i+1}"
                start_label = f"Start{i+1}"
                end_label = f"End{i+1}"
                
                if start_key in entry:
                    text = entry[start_key].text().strip()
                    if not text:
                        raise ValueError(f"Row {idx}: {start_label} is required.")
                    try:
                        values[start_key] = int(text)
                    except ValueError as exc:
                        raise ValueError(
                            f"Row {idx}: {start_label} must be a whole number."
                        ) from exc
                
                if end_key in entry:
                    text = entry[end_key].text().strip()
                    if not text:
                        raise ValueError(f"Row {idx}: {end_label} is required.")
                    try:
                        values[end_key] = int(text)
                    except ValueError as exc:
                        raise ValueError(
                            f"Row {idx}: {end_label} must be a whole number."
                        ) from exc
            
            rows.append(values)
        return rows

    def on_next_build(self) -> None:
        try:
            rows = self._collect_rows()
        except ValueError as exc:
            self._set_status(str(exc))
            return
        if self.plan_consumed:
            self._set_status(
                "Plan already added. Start over or adjust the lines first."
            )
            return
        if self.spare_mode is None:
            self._set_status("Select where the spares are coming from.")
            return
        spare_value = (
            self.spare_lpn_edit.text().strip()
            if self.spare_mode == "lpn"
            else None
        )
        if self.spare_mode == "lpn" and not spare_value:
            self._set_status("Enter the spare LPN before adding to CSV.")
            return
        try:
            rows_for_writer = cast(List[Dict[str, int]], rows)
            
            # Build part columns from user input
            part_numbers = self._get_part_numbers()
            part_columns = []
            for i, part_number in enumerate(part_numbers):
                start_key = f"start{i+1}"
                end_key = f"end{i+1}"
                part_columns.append((start_key, end_key, part_number))
            
            transfers, leftovers = self.csv_writer.calculate_transfers(
                rows_for_writer, 
                part_columns
            )
            if not transfers:
                self._set_status(
                    "No transfers needed; everything is already balanced."
                )
                return
            self.row_counter = self.csv_writer.append_to_csv(
                self.temp_csv_file,
                self.row_counter,
                spare_mode=self.spare_mode,
                spare_value=spare_value,
                transfers=transfers,
                rows=rows_for_writer,
                part_columns=part_columns,
            )
        except Exception as exc:
            QMessageBox.critical(
                self,
                "Error",
                f"Failed to append to CSV: {exc}",
            )
            return

        # Only show final transfer summary and leftover overages in the inline report panel
        summary: Dict[str, int] = defaultdict(int)
        spare_summary: Dict[str, int] = defaultdict(int)
        for move in transfers:
            if isinstance(move, dict):
                part = str(move.get("part", ""))
                qty_value = move.get("qty", 0)
                if isinstance(qty_value, (int, float)):
                    qty = int(qty_value)
                elif isinstance(qty_value, str):
                    try:
                        qty = int(qty_value.strip()) if qty_value.strip() else 0
                    except ValueError:
                        qty = 0
                else:
                    qty = 0
                summary[part] += qty
                if move.get("from_spare", False):
                    spare_summary[part] += qty

        # Add leftovers from balancing, show which C40 had the extra
        leftover_report = []
        if leftovers:
            part_numbers = self._get_part_numbers()
            for part, qty in leftovers.items():
                # Find which C40(s) have the leftover for this part
                part_index = None
                for i, part_name in enumerate(part_numbers):
                    if part_name == part:
                        part_index = i
                        break
                
                if part_index is not None:
                    for entry in rows_for_writer:
                        lpn = entry["lpn"]
                        start_key = f"start{part_index+1}"
                        end_key = f"end{part_index+1}"
                        start_val = entry.get(start_key, 0)
                        end_val = entry.get(end_key, 0)
                        if start_val > end_val:
                            leftover_report.append(
                                f"C40 {lpn} has {qty} excess units of {part} after balancing. You may need to manually unpack these."
                            )
                            break

        # Build message with table formatting
        style = "font-size:12px;"
        leftover_table = ""
        if leftover_report:
            leftover_table += "<b>Leftover Report:</b><br>"
            leftover_table += f"<table border='1' cellpadding='4' cellspacing='0' style='border-collapse:collapse;width:100%;{style}'>"
            leftover_table += "<tr><th>LPN</th><th>Excess Units</th><th>Part</th><th>Note</th></tr>"
            for line in leftover_report:
                import re
                m = re.match(r"C40 (C40-[^ ]+) has (\d+) excess units of ([^ ]+) after balancing\. You may need to manually unpack these\.", line)
                if m:
                    lpn, qty, part = m.groups()
                    leftover_table += f"<tr><td>{lpn}</td><td>{qty}</td><td>{part}</td><td>Manual unpack required</td></tr>"
                else:
                    leftover_table += f"<tr><td colspan='4'>{line}</td></tr>"
            leftover_table += "</table><br>"
        if not leftover_table:
            leftover_table = "All C40s balanced. No leftover overages detected.<br><br>"

        transfer_table = "<b>Transfers:</b><br>"
        transfer_table += f"<table border='1' cellpadding='4' cellspacing='0' style='border-collapse:collapse;width:100%;{style}'>"
        transfer_table += "<tr><th>From C40</th><th>To C40</th><th>Part</th><th>Qty</th></tr>"
        for move in transfers:
            if isinstance(move, dict):
                # Use the same keys as the CSV writer for report output
                from_c40 = move.get('source', '')
                to_c40 = move.get('dest', '')
                part = str(move.get('part', ''))
                qty = str(move.get('qty', ''))
                transfer_table += f"<tr><td>{from_c40}</td><td>{to_c40}</td><td>{part}</td><td>{qty}</td></tr>"
        transfer_table += "</table><br>"

        summary_table = f"<table border='1' cellpadding='4' cellspacing='0' style='border-collapse:collapse;width:100%;{style}'>"
        summary_table += f"<tr><th>Move Instructions</th></tr><tr><td>{len(transfers)}</td></tr></table><br>"
        parts_table = f"<table border='1' cellpadding='4' cellspacing='0' style='border-collapse:collapse;width:100%;{style}'>"
        parts_table += "<tr><th>Part</th><th>Qty</th></tr>"
        for part, qty in summary.items():
            parts_table += f"<tr><td>{part}</td><td>{qty}</td></tr>"
        if any(spare_summary.values()):
            for part, qty in spare_summary.items():
                if qty:
                    parts_table += f"<tr><td>{part} (Spare)</td><td>{qty}</td></tr>"
        parts_table += "</table><br>"
        summary_msg = (
            f"<b>Summary:</b><br>{summary_table}"
            f"<b>Parts:</b><br>{parts_table}"
            f"{leftover_table}"
            f"{transfer_table}"
        )
        # Show report in the inline panel and open the panel
        self.report_output.setHtml(summary_msg)
        self.plan_consumed = True
        self._update_add_button_state()
    def _save_report_to_excel(self):
        import pandas as pd
        from PyQt5.QtWidgets import QFileDialog
        # Extract table data from the report (HTML)
        html = self.report_output.toHtml()
        # Use pandas to read HTML tables
        tables = pd.read_html(html)
        # Save to Excel file
        file_path, _ = QFileDialog.getSaveFileName(self, "Save Report", "report.xlsx", "Excel Files (*.xlsx)")
        if file_path:
            with pd.ExcelWriter(file_path) as writer:
                for i, table in enumerate(tables):
                    table.to_excel(writer, sheet_name=f"Table{i+1}", index=False)

    def _add_lpn_row(
        self,
        data: Optional[Mapping[str, Any]] = None,
        *,
        mark_dirty: bool = True,
    ) -> None:
        row_widget = QWidget()
        layout = QGridLayout(row_widget)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setHorizontalSpacing(10)

        index_label = QLabel("1.")
        layout.addWidget(index_label, 0, 0)

        lpn_edit = QLineEdit()
        lpn_edit.setPlaceholderText("C40-#")
        lpn_edit.textChanged.connect(self._on_rows_changed)
        layout.addWidget(lpn_edit, 0, 1)

        # Create dynamic start/end fields based on number of parts
        part_fields = {}
        col_index = 2
        for i in range(self.num_parts):
            start_key = f"start{i+1}"
            end_key = f"end{i+1}"
            
            start_edit = IntLineEdit()
            start_edit.textChanged.connect(self._on_rows_changed)
            layout.addWidget(start_edit, 0, col_index)
            part_fields[start_key] = start_edit
            col_index += 1
            
            end_edit = IntLineEdit()
            end_edit.textChanged.connect(self._on_rows_changed)
            layout.addWidget(end_edit, 0, col_index)
            part_fields[end_key] = end_edit
            col_index += 1

        remove_button = QPushButton("-")
        remove_button.setFixedWidth(30)
        remove_button.setToolTip("Remove this C40 row")
        layout.addWidget(remove_button, 0, col_index)

        # Build entry dictionary dynamically
        entry = {
            "widget": row_widget,
            "index": index_label,
            "lpn": lpn_edit,
            "remove": remove_button,
        }
        entry.update(part_fields)

        remove_button.clicked.connect(lambda _, e=entry: self._remove_row(e))

        self.row_entries.append(entry)
        self.rows_layout.addWidget(row_widget)

        if data is not None:
            self._suppress_row_change = True
            lpn_edit.setText(str(data.get("lpn", "")))
            for i in range(self.num_parts):
                start_key = f"start{i+1}"
                end_key = f"end{i+1}"
                if start_key in entry:
                    entry[start_key].setText(str(data.get(start_key, "")))
                if end_key in entry:
                    entry[end_key].setText(str(data.get(end_key, "")))
            self._suppress_row_change = False

        self._refresh_row_numbers()
        if mark_dirty:
            self._on_rows_changed()
        else:
            self._update_add_button_state()

    def _remove_row(self, entry: Dict[str, QWidget]) -> None:
        if entry not in self.row_entries:
            return
        self.row_entries.remove(entry)
        widget = entry.get("widget")
        if widget is not None:
            widget.deleteLater()
        if not self.row_entries:
            self._add_lpn_row(mark_dirty=False)
        self._refresh_row_numbers()
        self._on_rows_changed()

    def _clear_lpn_rows(
        self,
        add_blank: bool = True,
        mark_dirty: bool = True,
    ) -> None:
        self._suppress_row_change = True
        while self.row_entries:
            entry = self.row_entries.pop()
            widget = entry.get("widget")
            if widget is not None:
                widget.deleteLater()
        self._suppress_row_change = False
        if add_blank:
            self._add_lpn_row(mark_dirty=False)
        self._refresh_row_numbers()
        if mark_dirty:
            self._on_rows_changed()
        else:
            self._update_add_button_state()

    def _refresh_row_numbers(self) -> None:
        for idx, entry in enumerate(self.row_entries, start=1):
            entry["index"].setText(f"{idx}.")

    def _on_rows_changed(self) -> None:
        if self._suppress_row_change:
            return
        self.plan_consumed = False
        self._set_status("")
        # Update C40 tab header and rows to match part count
        self._update_row_headers()
        self._rebuild_c40_headers_and_rows()

    def _rebuild_c40_headers_and_rows(self):
        # Clear header layout
        while self.header_layout.count():
            item = self.header_layout.takeAt(0)
            if item is not None:
                widget = item.widget()
                if widget:
                    widget.deleteLater()
        # Add header columns: #, LPN, Start/End for each part, Remove
        self.header_layout.addWidget(QLabel("#"), 0, 0)
        self.header_layout.addWidget(QLabel("LPN"), 0, 1)
        col = 2
        for i in range(self.num_parts):
            self.header_layout.addWidget(QLabel(f"Start{i+1}"), 0, col)
            col += 1
            self.header_layout.addWidget(QLabel(f"End{i+1}"), 0, col)
            col += 1
        self.header_layout.addWidget(QLabel("Remove"), 0, col)
        # Rebuild all C40 rows to match part count
        row_count = self.rows_layout.count()
        row_widgets = []
        for idx in range(row_count):
            item = self.rows_layout.itemAt(idx)
            if item is not None:
                widget = item.widget()
                if widget:
                    row_widgets.append(widget)
        # Remove all rows
        while self.rows_layout.count():
            item = self.rows_layout.takeAt(0)
            if item is not None:
                widget = item.widget()
                if widget:
                    widget.deleteLater()
        # Re-add rows with correct structure
        for row_idx in range(len(row_widgets) if row_widgets else 1):
            row_widget = QWidget()
            row_layout = QHBoxLayout(row_widget)
            row_layout.setContentsMargins(0, 0, 0, 0)
            # Row number
            row_num_label = QLabel(str(row_idx+1))
            row_layout.addWidget(row_num_label)
            # LPN input
            lpn_edit = QLineEdit()
            lpn_edit.setPlaceholderText("C40-#")
            row_layout.addWidget(lpn_edit)
            # Start/End inputs for each part
            for i in range(self.num_parts):
                start_edit = QLineEdit()
                start_edit.setPlaceholderText(f"Start{i+1}")
                end_edit = QLineEdit()
                end_edit.setPlaceholderText(f"End{i+1}")
                row_layout.addWidget(start_edit)
                row_layout.addWidget(end_edit)
            # Remove button
            remove_btn = QPushButton("Remove")
            remove_btn.setFixedWidth(60)
            # TODO: Connect remove_btn to row removal logic
            row_layout.addWidget(remove_btn)
            self.rows_layout.addWidget(row_widget)

        row_layout.addWidget(remove_btn)
        def remove_row():
            row_widget.deleteLater()
        remove_btn.clicked.connect(remove_row)
        self.rows_layout.addWidget(row_widget)

    # Removed duplicate placeholder upload_spreadsheet
    def clear_data_fields(self):
        # Placeholder for clear logic
        QMessageBox.information(self, "Clear Data", "Clear Data Fields functionality not yet implemented.")
