import tempfile
from collections import defaultdict
from PyQt5.QtWidgets import QSplitter
from typing import Any, Dict, List, Mapping, Optional, Sequence, cast

from PyQt5.QtCore import Qt
from PyQt5.QtGui import QIntValidator
from PyQt5.QtWidgets import (
    QGridLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QRadioButton,
    QSizePolicy,
    QVBoxLayout,
    QWidget,
    QScrollArea,
)

from program_files.csv_writers import CSV_Writer_DustinSpares


from .BaseGUI import BaseDialog
from .MainButtons import MainButtons


class IntLineEdit(QLineEdit):
    def __init__(self, parent: Optional[QWidget] = None) -> None:
        super().__init__(parent)
        self.setValidator(QIntValidator(0, 999999, self))


class DustinSparesGUI(BaseDialog):
    def toggle_side_panel(self):
        # Toggle visibility of the report panel
        if self.report_panel.isVisible():
            self.report_panel.hide()
            self.toggle_side_panel_button.setText('Balancing Report ▶')
        else:
            self.report_panel.show()
            self.toggle_side_panel_button.setText('Balancing Report ◀')
    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle("Dustin Spare Balancer")
        self.screen_indicator = "REPACK"
        self.csv_writer = CSV_Writer_DustinSpares
        self.temp_csv_file = tempfile.NamedTemporaryFile(delete=False, mode="w", newline="")
        self.csv_writer.write_csv_headers(self.temp_csv_file)
        self.temp_csv_file.flush()
        self.row_counter = 1
        self.csv_headers = ["NUMBER", "PROMPT", "KEY", "DATA"]
        self.starting_sheet_path = None
        self.spare_mode = None
        self.plan_consumed = False
        self.row_entries = []
        self._suppress_row_change = False
        self._build_ui()
        self._add_lpn_row(mark_dirty=False)
        self.finalize_initial_size(extra_width=80)
        self._update_add_button_state()

    def _build_ui(self) -> None:
        self.resize(800, 600)
        self.setMinimumSize(700, 500)
        self.main_layout = QVBoxLayout(self)

        # Splitter for left (form/buttons) and right (collapsible report)
        self.splitter = QSplitter(Qt.Orientation.Horizontal, self)
        self.splitter.setHandleWidth(1)
        self.main_layout.addWidget(self.splitter)

        # Left panel: scroll area for form and buttons
        self.left_container = QWidget(self.splitter)
        self.left_container.setMinimumWidth(500)
        self.left_layout = QVBoxLayout(self.left_container)
        self.left_layout.setContentsMargins(0, 0, 0, 0)
        self.left_layout.setSpacing(5)

        # Top bar with status and toggle button
        top_bar = QWidget(self.left_container)
        self.top_layout = QHBoxLayout(top_bar)
        self.top_layout.setContentsMargins(0, 0, 0, 0)
        self.status_label = QLabel(top_bar)
        self.top_layout.addWidget(self.status_label)
        self.toggle_side_panel_button = QPushButton('Balancing Report ▶', top_bar)
        self.toggle_side_panel_button.setToolTip('Show or hide the report panel')
        self.toggle_side_panel_button.setMinimumWidth(
            self.toggle_side_panel_button.sizeHint().width()
        )
        self.toggle_side_panel_button.clicked.connect(self.toggle_side_panel)
        self.top_layout.addWidget(self.toggle_side_panel_button)
        self.left_layout.addWidget(top_bar)

        # Scroll area for form
        self.scroll_area = QScrollArea(self.left_container)
        self.scroll_area.setWidgetResizable(True)
        self.scroll_content = QWidget(self.scroll_area)
        self.scroll_layout = QVBoxLayout(self.scroll_content)
        self.scroll_layout.setSpacing(6)
        self.scroll_layout.setContentsMargins(5, 5, 5, 5)
        self.scroll_area.setWidget(self.scroll_content)
        self.left_layout.addWidget(self.scroll_area)

        # Title
        title = QLabel("Balance Dustin Spares")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title.setStyleSheet("font-size: 18px; font-weight: bold;")
        self.scroll_layout.addWidget(title)

        # Upload box
        upload_box = QHBoxLayout()
        self.upload_button = QPushButton("Upload Spreadsheet")
        self.upload_button.clicked.connect(self.upload_spreadsheet)
        upload_box.addWidget(self.upload_button)
        self.file_label = QLabel("No file selected")
        self.file_label.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        upload_box.addWidget(self.file_label)
        self.scroll_layout.addLayout(upload_box)

        # Source radio group
        source_group = QGroupBox("Where are the spares coming from?")
        source_layout = QGridLayout()
        self.location_radio = QRadioButton("Location")
        self.location_radio.toggled.connect(lambda checked: checked and self._set_spare_mode("location"))
        source_layout.addWidget(self.location_radio, 0, 0)
        self.lpn_radio = QRadioButton("LPN")
        self.lpn_radio.toggled.connect(lambda checked: checked and self._set_spare_mode("lpn"))
        source_layout.addWidget(self.lpn_radio, 0, 1)
        source_group.setLayout(source_layout)
        self.scroll_layout.addWidget(source_group)

        # Spare LPN entry
        self.spare_lpn_container = QWidget()
        spare_lpn_layout = QHBoxLayout(self.spare_lpn_container)
        spare_lpn_layout.setContentsMargins(0, 0, 0, 0)
        spare_lpn_layout.setSpacing(6)
        spare_label = QLabel("Spare LPN:")
        spare_lpn_layout.addWidget(spare_label)
        self.spare_lpn_edit = QLineEdit()
        self.spare_lpn_edit.textChanged.connect(self._on_rows_changed)
        spare_lpn_layout.addWidget(self.spare_lpn_edit)
        self.spare_lpn_container.hide()
        self.scroll_layout.addWidget(self.spare_lpn_container)

        # Controls for adding/removing rows (move above rows)
        controls_layout = QHBoxLayout()
        self.add_row_button = QPushButton("Add C40 Row")
        self.add_row_button.clicked.connect(lambda: self._add_lpn_row())
        controls_layout.addWidget(self.add_row_button)
        self.clear_rows_button = QPushButton("Clear Rows")
        self.clear_rows_button.clicked.connect(self._clear_lpn_rows)
        controls_layout.addWidget(self.clear_rows_button)
        controls_layout.addStretch()
        self.scroll_layout.addLayout(controls_layout)

        # Header for C40 Balancing Lines
        header_widget = QWidget()
        header_layout = QGridLayout(header_widget)
        header_layout.setContentsMargins(0, 0, 0, 0)
        header_layout.setHorizontalSpacing(10)
        header_layout.addWidget(QLabel("#"), 0, 0)
        header_layout.addWidget(QLabel("LPN"), 0, 1)
        header_layout.addWidget(QLabel("Start1"), 0, 2)
        header_layout.addWidget(QLabel("End1"), 0, 3)
        header_layout.addWidget(QLabel("Start2"), 0, 4)
        header_layout.addWidget(QLabel("End2"), 0, 5)
        header_layout.addWidget(QLabel(""), 0, 6)
        self.scroll_layout.addWidget(header_widget)

        # C40 rows
        self.rows_container = QWidget()
        self.rows_layout = QVBoxLayout(self.rows_container)
        self.rows_layout.setSpacing(4)
        self.rows_layout.setContentsMargins(0, 0, 0, 0)
        self.scroll_layout.addWidget(self.rows_container)

        # Add stretch so extra space is at the bottom when resizing
        self.scroll_layout.addStretch()
        # Main buttons at bottom of scroll area
        self.main_buttons = MainButtons(self)
        self.scroll_layout.addLayout(self.main_buttons.get_layout())

        # Add left panel to splitter
        self.splitter.addWidget(self.left_container)

        # Right panel: collapsible report
        from PyQt5.QtWidgets import QTextEdit
        self.report_panel = QWidget(self.splitter)
        self.report_panel.setMinimumWidth(400)
        self.report_panel.setMaximumWidth(600)
        self.report_layout = QVBoxLayout(self.report_panel)
        self.report_layout.setContentsMargins(6, 6, 6, 6)
        self.report_layout.setSpacing(8)
        self.report_output = QTextEdit(self.report_panel)
        self.report_output.setReadOnly(True)
        self.report_output.setFrameStyle(QTextEdit.NoFrame)
        self.report_output.setStyleSheet("background: transparent; font-size: 13px; border: none;")
        self.report_output.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.report_layout.addWidget(self.report_output)
        self.splitter.addWidget(self.report_panel)
        self.splitter.setStretchFactor(0, 4)
        self.splitter.setStretchFactor(1, 2)
        # Start with report panel closed
        self.splitter.setSizes([700, 0])

    def upload_spreadsheet(self) -> None:
        from PyQt5.QtWidgets import QFileDialog, QMessageBox
        import pandas as pd
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "Select Spreadsheet",
            "",
            "Excel Files (*.xlsx *.xls);;All Files (*)"
        )
        if not file_path:
            self.file_label.setText("No file selected")
            return
        self.starting_sheet_path = file_path
        self.file_label.setText(file_path.split("/")[-1])
        try:
            df = pd.read_excel(file_path)
        except Exception as e:
            self.file_label.setText(f"Error loading: {e}")
            QMessageBox.warning(self, "Error", f"Failed to read Excel file: {e}")
            return
        required_cols = ["lpn", "start1", "end1", "start2", "end2"]
        # Map actual columns to lowercase for matching
        col_map = {col.lower(): col for col in df.columns}
        missing = [col for col in required_cols if col not in col_map]
        if missing:
            self.file_label.setText(f"Missing columns: {', '.join(missing)}")
            QMessageBox.warning(self, "Error", f"Spreadsheet must have columns: {', '.join(required_cols)}")
            return
        self._clear_lpn_rows(add_blank=False, mark_dirty=False)
        rows = []
        for _, row in df.iterrows():
            lpn = str(row[col_map["lpn"]]) if pd.notna(row[col_map["lpn"]]) else ""
            start1 = str(row[col_map["start1"]]) if pd.notna(row[col_map["start1"]]) else ""
            end1 = str(row[col_map["end1"]]) if pd.notna(row[col_map["end1"]]) else ""
            start2 = str(row[col_map["start2"]]) if pd.notna(row[col_map["start2"]]) else ""
            end2 = str(row[col_map["end2"]]) if pd.notna(row[col_map["end2"]]) else ""
            rows.append({"lpn": lpn, "start1": start1, "end1": end1, "start2": start2, "end2": end2})
        self._populate_rows(rows)
        self._set_status(f"Loaded {len(rows)} rows from {file_path.split('/')[-1]}", success=True)

    def _populate_rows(
        self,
        rows: Sequence[Mapping[str, Any]],
    ) -> None:
        self._suppress_row_change = True
        self._clear_lpn_rows(add_blank=False, mark_dirty=False)
        for row in rows:
            self._add_lpn_row(row, mark_dirty=False)
        if not rows:
            self._add_lpn_row(mark_dirty=False)
        self._suppress_row_change = False
        self.plan_consumed = False
        self._set_status("")
        self._update_add_button_state()

    def _set_spare_mode(self, mode: str) -> None:
        if self.spare_mode == mode:
            return
        self.spare_mode = mode
        if mode == "lpn":
            self.spare_lpn_container.show()
            self.spare_lpn_edit.setFocus()
        else:
            self.spare_lpn_edit.clear()
            self.spare_lpn_container.hide()
        self.plan_consumed = False
        self._update_add_button_state()

    def _rows_complete(self) -> bool:
        if not self.row_entries:
            return False
        for entry in self.row_entries:
            if not entry["lpn"].text().strip():
                return False
            for key in ("start1", "end1", "start2", "end2"):
                if not entry[key].text().strip():
                    return False
        return True

    def _update_add_button_state(self) -> None:
        enabled = (
            not self.plan_consumed
            and self.spare_mode is not None
            and (
                self.spare_mode != "lpn"
                or bool(self.spare_lpn_edit.text().strip())
            )
            and self._rows_complete()
        )
        self.main_buttons.add_button.setEnabled(enabled)

    def _set_status(self, message: str, success: bool = False) -> None:
        if not message:
            self.status_label.clear()
            return
        color = "green" if success else "#ff5555"
        rich_text = f"<span style='color: {color};'>{message}</span>"
        self.status_label.setText(rich_text)

    def _collect_rows(self) -> List[Dict[str, object]]:
        if not self.row_entries:
            raise ValueError(
                "Add at least one C40 line before creating the CSV."
            )
        rows: List[Dict[str, object]] = []
        for idx, entry in enumerate(self.row_entries, start=1):
            lpn = entry["lpn"].text().strip()
            if not lpn:
                raise ValueError(f"Row {idx}: LPN is required.")
            values: Dict[str, object] = {"lpn": lpn}
            for field_key, label in (
                ("start1", "Start1"),
                ("end1", "End1"),
                ("start2", "Start2"),
                ("end2", "End2"),
            ):
                text = entry[field_key].text().strip()
                if not text:
                    raise ValueError(f"Row {idx}: {label} is required.")
                try:
                    values[field_key] = int(text)
                except ValueError as exc:
                    raise ValueError(
                        f"Row {idx}: {label} must be a whole number."
                    ) from exc
            rows.append(values)
        return rows

    def on_next_build(self) -> None:
        try:
            rows = self._collect_rows()
        except ValueError as exc:
            self._set_status(str(exc))
            return
        if self.plan_consumed:
            self._set_status(
                "Plan already added. Start over or adjust the lines first."
            )
            return
        if self.spare_mode is None:
            self._set_status("Select where the spares are coming from.")
            return
        spare_value = (
            self.spare_lpn_edit.text().strip()
            if self.spare_mode == "lpn"
            else None
        )
        if self.spare_mode == "lpn" and not spare_value:
            self._set_status("Enter the spare LPN before adding to CSV.")
            return
        try:
            rows_for_writer = cast(List[Dict[str, int]], rows)
            transfers, leftovers = self.csv_writer.calculate_transfers(rows_for_writer)
            if not transfers:
                self._set_status(
                    "No transfers needed; everything is already balanced."
                )
                return
            self.row_counter = self.csv_writer.append_to_csv(
                self.temp_csv_file,
                self.row_counter,
                spare_mode=self.spare_mode,
                spare_value=spare_value,
                transfers=[transfers] if isinstance(transfers, dict) else transfers,
                rows=rows_for_writer,
            )
        except Exception as exc:
            QMessageBox.critical(
                self,
                "Error",
                f"Failed to append to CSV: {exc}",
            )
            return

        # Only show final transfer summary and leftover overages in the inline report panel
        summary: Dict[str, int] = defaultdict(int)
        spare_summary: Dict[str, int] = defaultdict(int)
        for move in transfers:
            if isinstance(move, dict):
                part = str(move.get("part", ""))
                qty_value = move.get("qty", 0)
                if isinstance(qty_value, (int, float)):
                    qty = int(qty_value)
                elif isinstance(qty_value, str):
                    try:
                        qty = int(qty_value.strip()) if qty_value.strip() else 0
                    except ValueError:
                        qty = 0
                else:
                    qty = 0
                summary[part] += qty
                if move.get("from_spare", False):
                    spare_summary[part] += qty

        # Add leftovers from balancing, show which C40 had the extra
        leftover_report = []
        if leftovers:
            for part, qty in leftovers.items():
                # Find which C40(s) have the leftover for this part
                for entry in rows_for_writer:
                    lpn = entry["lpn"]
                    start_val = entry["start1"] if part == "Linecard1" else entry["start2"]
                    end_val = entry["end1"] if part == "Linecard1" else entry["end2"]
                    if start_val > end_val:
                        leftover_report.append(
                            f"C40 {lpn} has {qty} excess units of {part} after balancing. You may need to manually unpack these."
                        )
                        break

        parts_text = ", ".join(
            f"{part}: {qty}" for part, qty in summary.items()
        )
        spare_text = ""
        if any(spare_summary.values()):
            spare_details = ", ".join(
                f"{part}: {qty}" for part, qty in spare_summary.items() if qty
            )
            spare_text = f" | Spares supplied: {spare_details}"

        # Build message with table formatting
        style = "font-size:12px;"
        leftover_table = ""
        if leftover_report:
            leftover_table += "<b>Leftover Report:</b><br>"
            leftover_table += f"<table border='1' cellpadding='4' cellspacing='0' style='border-collapse:collapse;width:100%;{style}'>"
            leftover_table += "<tr><th>LPN</th><th>Excess Units</th><th>Linecard</th><th>Note</th></tr>"
            for line in leftover_report:
                import re
                m = re.match(r"C40 (C40-[^ ]+) has (\d+) excess units of (Linecard\d+) after balancing\. You may need to manually unpack these\.", line)
                if m:
                    lpn, qty, part = m.groups()
                    leftover_table += f"<tr><td>{lpn}</td><td>{qty}</td><td>{part}</td><td>Manual unpack required</td></tr>"
                else:
                    leftover_table += f"<tr><td colspan='4'>{line}</td></tr>"
            leftover_table += "</table><br>"
        if not leftover_table:
            leftover_table = "All C40s balanced. No leftover overages detected.<br><br>"

        transfer_table = "<b>Transfers:</b><br>"
        transfer_table += f"<table border='1' cellpadding='4' cellspacing='0' style='border-collapse:collapse;width:100%;{style}'>"
        transfer_table += "<tr><th>From C40</th><th>To C40</th><th>Part</th><th>Qty</th></tr>"
        for move in transfers:
            if isinstance(move, dict):
                # Use the same keys as the CSV writer for report output
                from_c40 = move.get('source', '')
                to_c40 = move.get('dest', '')
                part = str(move.get('part', ''))
                qty = str(move.get('qty', ''))
                transfer_table += f"<tr><td>{from_c40}</td><td>{to_c40}</td><td>{part}</td><td>{qty}</td></tr>"
        transfer_table += "</table><br>"

        summary_table = f"<table border='1' cellpadding='4' cellspacing='0' style='border-collapse:collapse;width:100%;{style}'>"
        summary_table += f"<tr><th>Move Instructions</th></tr><tr><td>{len(transfers)}</td></tr></table><br>"
        parts_table = f"<table border='1' cellpadding='4' cellspacing='0' style='border-collapse:collapse;width:100%;{style}'>"
        parts_table += f"<tr><th>Part</th><th>Qty</th></tr>"
        for part, qty in summary.items():
            parts_table += f"<tr><td>{part}</td><td>{qty}</td></tr>"
        if any(spare_summary.values()):
            for part, qty in spare_summary.items():
                if qty:
                    parts_table += f"<tr><td>{part} (Spare)</td><td>{qty}</td></tr>"
        parts_table += "</table><br>"
        summary_msg = (
            f"<b>Summary:</b><br>{summary_table}"
            f"<b>Parts:</b><br>{parts_table}"
            f"{leftover_table}"
            f"{transfer_table}"
        )
        # Show report in the inline panel and open the panel
        self.report_output.setHtml(summary_msg)
        self.splitter.setSizes([500, 400])
        self.plan_consumed = True
        self._update_add_button_state()

    def _add_lpn_row(
        self,
        data: Optional[Mapping[str, Any]] = None,
        *,
        mark_dirty: bool = True,
    ) -> None:
        row_widget = QWidget()
        layout = QGridLayout(row_widget)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setHorizontalSpacing(10)

        index_label = QLabel("1.")
        layout.addWidget(index_label, 0, 0)

        lpn_edit = QLineEdit()
        lpn_edit.setPlaceholderText("C40-#")
        lpn_edit.textChanged.connect(self._on_rows_changed)
        layout.addWidget(lpn_edit, 0, 1)

        start1_edit = IntLineEdit()
        start1_edit.textChanged.connect(self._on_rows_changed)
        layout.addWidget(start1_edit, 0, 2)

        end1_edit = IntLineEdit()
        end1_edit.textChanged.connect(self._on_rows_changed)
        layout.addWidget(end1_edit, 0, 3)

        start2_edit = IntLineEdit()
        start2_edit.textChanged.connect(self._on_rows_changed)
        layout.addWidget(start2_edit, 0, 4)

        end2_edit = IntLineEdit()
        end2_edit.textChanged.connect(self._on_rows_changed)
        layout.addWidget(end2_edit, 0, 5)

        remove_button = QPushButton("Remove")
        layout.addWidget(remove_button, 0, 6)

        entry = {
            "widget": row_widget,
            "index": index_label,
            "lpn": lpn_edit,
            "start1": start1_edit,
            "end1": end1_edit,
            "start2": start2_edit,
            "end2": end2_edit,
            "remove": remove_button,
        }
        remove_button.clicked.connect(lambda _, e=entry: self._remove_row(e))

        self.row_entries.append(entry)
        self.rows_layout.addWidget(row_widget)

        if data is not None:
            self._suppress_row_change = True
            lpn_edit.setText(str(data.get("lpn", "")))
            start1_edit.setText(str(data.get("start1", "")))
            end1_edit.setText(str(data.get("end1", "")))
            start2_edit.setText(str(data.get("start2", "")))
            end2_edit.setText(str(data.get("end2", "")))
            self._suppress_row_change = False

        self._refresh_row_numbers()
        if mark_dirty:
            self._on_rows_changed()
        else:
            self._update_add_button_state()

    def _remove_row(self, entry: Dict[str, QWidget]) -> None:
        if entry not in self.row_entries:
            return
        self.row_entries.remove(entry)
        widget = entry.get("widget")
        if widget is not None:
            widget.deleteLater()
        if not self.row_entries:
            self._add_lpn_row(mark_dirty=False)
        self._refresh_row_numbers()
        self._on_rows_changed()

    def _clear_lpn_rows(
        self,
        add_blank: bool = True,
        mark_dirty: bool = True,
    ) -> None:
        self._suppress_row_change = True
        while self.row_entries:
            entry = self.row_entries.pop()
            widget = entry.get("widget")
            if widget is not None:
                widget.deleteLater()
        self._suppress_row_change = False
        if add_blank:
            self._add_lpn_row(mark_dirty=False)
        self._refresh_row_numbers()
        if mark_dirty:
            self._on_rows_changed()
        else:
            self._update_add_button_state()

    def _refresh_row_numbers(self) -> None:
        for idx, entry in enumerate(self.row_entries, start=1):
            entry["index"].setText(f"{idx}.")

    def _on_rows_changed(self) -> None:
        if self._suppress_row_change:
            return
        self.plan_consumed = False
        self._set_status("")
        self._update_add_button_state()

    def clear_data_fields(self) -> None:
        self.starting_sheet_path = None
        self.file_label.setText("No file selected")
        self._clear_lpn_rows(add_blank=True, mark_dirty=False)
        self.plan_consumed = False
        self.spare_mode = None
        self.location_radio.blockSignals(True)
        self.lpn_radio.blockSignals(True)
        self.location_radio.setChecked(False)
        self.lpn_radio.setChecked(False)
        self.location_radio.blockSignals(False)
        self.lpn_radio.blockSignals(False)
        self.spare_lpn_edit.clear()
        self.spare_lpn_container.hide()
        self._set_status("")
        self._update_add_button_state()

    def on_csv_reset(self) -> None:
        self.plan_consumed = False
        try:
            self.temp_csv_file.flush()
        except Exception:
            pass
        self._update_add_button_state()

    def on_csv_loaded(self) -> None:
        self.plan_consumed = False
        self._update_add_button_state()
