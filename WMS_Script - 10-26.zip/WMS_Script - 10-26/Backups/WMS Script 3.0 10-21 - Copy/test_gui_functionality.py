#!/usr/bin/env python3
"""
Test GUI creation to verify imports and basic functionality
"""

import sys
import os

# Add the project root to Python path
project_root = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, project_root)

try:
    from PyQt5.QtWidgets import QApplication
    from program_files.guis.DustinSparesGUI import DustinSparesGUI
    
    # Test that the GUI can be instantiated without errors
    print("Testing GUI instantiation...")
    
    app = QApplication([])
    gui = DustinSparesGUI()
    
    print("✓ GUI created successfully!")
    print(f"✓ Default number of parts: {gui.num_parts}")
    print(f"✓ Number of part entries: {len(gui.part_entries)}")
    
    # Test dynamic part number functionality
    gui.num_parts_combo.setCurrentText("3")
    gui._on_num_parts_changed("3")
    
    print(f"✓ Changed to {gui.num_parts} parts")
    print(f"✓ Number of part entries after change: {len(gui.part_entries)}")
    
    # Test getting part numbers
    part_numbers = gui._get_part_numbers()
    print(f"✓ Part numbers: {part_numbers}")
    
    print("\n🎉 GUI functionality test passed!")
    
except ImportError as e:
    print(f"❌ Import error: {e}")
except Exception as e:
    print(f"❌ Error: {e}")
    import traceback
    traceback.print_exc()