import csv
from pathlib import Path
from typing import Dict, List, Optional, Union, Tuple

from openpyxl.worksheet.worksheet import Worksheet

from openpyxl import load_workbook

HEADERS = ["NUMBER", "PROMPT", "KEY", "DATA"]
PART_COLUMNS = (
    ("start1", "end1", "Linecard1"),
    ("start2", "end2", "Linecard2"),
)


def write_csv_headers(file) -> None:
    writer = csv.writer(file)
    writer.writerow(HEADERS)


def _safe_int(value) -> int:
    if value is None:
        return 0
    if isinstance(value, bool):
        return int(value)
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        return int(round(value))
    text = str(value).strip()
    if not text:
        return 0
    try:
        if "." in text:
            return int(float(text))
        return int(text)
    except ValueError as exc:
        raise ValueError(f"Invalid numeric value '{text}'.") from exc


def _normalise_header(header: object) -> Optional[str]:
    if header is None:
        return None
    text = str(header).strip().lower()
    return text or None


def _load_from_excel(path: Path) -> List[Dict[str, int]]:
    workbook = load_workbook(path, data_only=True)
    sheet_obj = workbook.active
    if not isinstance(sheet_obj, Worksheet):
        raise ValueError("Workbook has no active sheet.")
    sheet = sheet_obj
    header_row = next(
        sheet.iter_rows(min_row=1, max_row=1, values_only=True),
        None,
    )
    if not header_row:
        raise ValueError("Starting sheet is missing a header row.")
    header_map: Dict[str, int] = {}
    for idx, raw in enumerate(header_row):
        key = _normalise_header(raw)
        if key is not None:
            header_map[key] = idx
    required = {"lpn", "start1", "end1", "start2", "end2"}
    if not required.issubset(header_map):
        missing = ", ".join(sorted(required - set(header_map)))
        raise ValueError(
            f"Starting sheet is missing required columns: {missing}."
        )
    rows: List[Dict[str, int]] = []
    for raw_row in sheet.iter_rows(min_row=2, values_only=True):
        if raw_row is None:
            continue
        lpn_cell = raw_row[header_map["lpn"]]
        lpn = str(lpn_cell).strip() if lpn_cell is not None else ""
        if not lpn:
            if not any(raw_row):
                continue
            raise ValueError("Encountered a row without an LPN value.")
        entry = {
            "lpn": lpn,
            "start1": _safe_int(raw_row[header_map["start1"]]),
            "end1": _safe_int(raw_row[header_map["end1"]]),
            "start2": _safe_int(raw_row[header_map["start2"]]),
            "end2": _safe_int(raw_row[header_map["end2"]]),
        }
        rows.append(entry)
    if not rows:
        raise ValueError("Starting sheet does not contain any LPN rows.")
    return rows


def _load_from_csv(path: Path) -> List[Dict[str, int]]:
    with path.open(newline="") as handle:
        reader = csv.reader(handle)
        try:
            header_row = next(reader)
        except StopIteration as exc:
            raise ValueError("Starting sheet CSV is empty.") from exc
        header_map: Dict[str, int] = {}
        for idx, raw in enumerate(header_row):
            key = _normalise_header(raw)
            if key is not None:
                header_map[key] = idx
        required = {"lpn", "start1", "end1", "start2", "end2"}
        if not required.issubset(header_map):
            missing = ", ".join(sorted(required - set(header_map)))
            raise ValueError(
                f"Starting sheet CSV is missing required columns: {missing}."
            )
        rows: List[Dict[str, int]] = []
        for raw_row in reader:
            if not raw_row:
                continue
            lpn_idx = header_map["lpn"]
            lpn_cell = raw_row[lpn_idx] if lpn_idx < len(raw_row) else ""
            lpn = str(lpn_cell).strip()
            if not lpn:
                if not any(
                    cell.strip() for cell in raw_row if isinstance(cell, str)
                ):
                    continue
                raise ValueError("Encountered a row without an LPN value.")

            def _cell(idx: str) -> Optional[str]:
                column_index = header_map[idx]
                if column_index >= len(raw_row):
                    return None
                return raw_row[column_index]
            entry = {
                "lpn": lpn,
                "start1": _safe_int(_cell("start1")),
                "end1": _safe_int(_cell("end1")),
                "start2": _safe_int(_cell("start2")),
                "end2": _safe_int(_cell("end2")),
            }
            rows.append(entry)
    if not rows:
        raise ValueError("Starting sheet CSV does not contain any LPN rows.")
    return rows


def load_starting_sheet(
    spreadsheet_path: Union[str, Path]
) -> List[Dict[str, int]]:
    path = Path(spreadsheet_path)
    if not path.exists():
        raise FileNotFoundError(f"Starting sheet not found: {path}")
    suffix = path.suffix.lower()
    if suffix in {".xlsx", ".xlsm", ".xltx", ".xltm"}:
        return _load_from_excel(path)
    if suffix == ".csv":
        return _load_from_csv(path)
    raise ValueError("Unsupported starting sheet format. Use .xlsx or .csv.")


def _calculate_transfers_for_part(
    rows: List[Dict[str, int]],
    start_key: str,
    end_key: str,
    part_name: str,
) -> List[Dict[str, object]]:
    surplus: List[Dict[str, int]] = []
    deficits: List[Dict[str, int]] = []
    for row in rows:
        start_value = row[start_key]
        end_value = row[end_key]
        diff = start_value - end_value
        if diff > 0:
            surplus.append({"lpn": row["lpn"], "qty": diff})
        elif diff < 0:
            deficits.append({"lpn": row["lpn"], "qty": -diff})
    transfers: List[Dict[str, object]] = []
    for deficit in deficits:
        dest_lpn = deficit["lpn"]
        needed = deficit["qty"]
        while needed > 0 and surplus:
            source_slot = surplus[0]
            available = source_slot["qty"]
            qty = needed if needed < available else available
            transfers.append(
                {
                    "part": part_name,
                    "source": str(source_slot["lpn"]),
                    "dest": str(dest_lpn),
                    "qty": int(qty),
                    "from_spare": False,
                }
            )
            available -= qty
            needed -= qty
            if available == 0:
                surplus.pop(0)
            else:
                source_slot["qty"] = available
        if needed > 0:
            transfers.append(
                {
                    "part": part_name,
                    "source": None,
                    "dest": str(dest_lpn),
                    "qty": int(needed),
                    "from_spare": True,
                }
            )
            needed = 0
    leftover = sum(slot["qty"] for slot in surplus)
    # Instead of raising, return leftover info for reporting
    return transfers, leftover


def calculate_transfers(rows: List[Dict[str, int]], part_names: Optional[List[str]] = None) -> Tuple[List[Dict[str, object]], Dict[str, int]]:
    """
    Calculate transfers for the provided rows.

    This function requires the caller to supply explicit `part_names` (one name per
    Start/End pair). The CSV writer will not auto-fill or infer part names. If
    `part_names` is missing or empty, a ValueError is raised so the GUI must ensure
    the user provides Part identifiers before calling this function.
    """
    if not rows:
        raise ValueError("Starting sheet is empty.")
    if not part_names:
        raise ValueError(
            "Part names must be supplied by the caller. Provide a list of part names "
            "(one per Start/End pair) before calculating transfers."
        )
    # Build part columns from provided part_names
    part_columns = []
    for idx, name in enumerate(part_names, start=1):
        part_label = name if name else f"Linecard{idx}"
        part_columns.append((f"start{idx}", f"end{idx}", part_label))

    transfers: List[Dict[str, object]] = []
    leftovers: Dict[str, int] = {}
    for start_key, end_key, part in part_columns:
        part_transfers, leftover = _calculate_transfers_for_part(rows, start_key, end_key, part)
        transfers.extend(part_transfers)
        if leftover > 0:
            leftovers[part] = leftover
    return transfers, leftovers


def _resolve_spare_source(
    spare_mode: str, spare_value: Optional[str]
) -> Dict[str, Optional[str]]:
    mode = spare_mode.lower()
    if mode not in {"location", "lpn"}:
        raise ValueError("Spare mode must be either 'Location' or 'LPN'.")
    spare_value_clean = (
        (spare_value or "").strip() if spare_value is not None else ""
    )
    if mode == "lpn" and not spare_value_clean:
        raise ValueError("Provide a spare LPN before adding to the CSV.")
    return {
        "from_value": "" if mode == "location" else spare_value_clean,
        "locator_value": spare_value_clean if mode == "location" else "",
    }


def _write_transfers(
    temp_csv_file,
    row_counter: int,
    transfers: List[Dict[str, object]],
    spare_mode: str,
    spare_value: Optional[str],
) -> int:
    spare = _resolve_spare_source(spare_mode, spare_value)
    from_value_default = spare["from_value"]
    locator_default = spare["locator_value"]
    with open(temp_csv_file.name, "a", newline="") as handle:
        writer = csv.writer(handle, delimiter=",")
        for move in transfers:
            source_value = move["source"]
            if source_value is None:
                source_value = from_value_default
            locator_value = locator_default if move["from_spare"] else ""
            writer.writerow(
                [row_counter, "From LPN  :", "ChildLPN", source_value]
            )
            row_counter += 1
            writer.writerow([row_counter, "To LPN    :", "C40", move["dest"]])
            row_counter += 1
            writer.writerow(
                [row_counter, "Locator   :", "BLANK", locator_value]
            )
            row_counter += 1
            writer.writerow(
                [row_counter, "Item      :", "ChildPart", move["part"]]
            )
            row_counter += 1
            writer.writerow(
                [row_counter, "Quantity  :", "ChildQty", str(move["qty"])]
            )
            row_counter += 1
            writer.writerow([row_counter, "<Done>", "BLANK", ""])
            row_counter += 1
    return row_counter


def append_to_csv(
    temp_csv_file,
    row_counter: int,
    spreadsheet_path: Optional[str] = None,
    spare_mode: str = "location",
    spare_value: Optional[str] = None,
    transfers: Optional[List[Dict[str, object]]] = None,
    rows: Optional[List[Dict[str, int]]] = None,
    part_names: Optional[List[str]] = None,
) -> int:
    if transfers is None:
        if rows is None:
            if spreadsheet_path is None:
                raise ValueError(
                    "A starting sheet path is required when transfers are not "
                    "provided."
                )
            rows = load_starting_sheet(spreadsheet_path)
        # If caller didn't provide transfers, calculate them; allow caller to
        # supply part_names to control the Part labels (Part 1/2/3...)
    transfers, leftovers = calculate_transfers(rows, part_names=part_names)
    if not transfers:
        raise ValueError(
            "No transfers are required; the starting sheet already matches "
            "the target quantities."
        )
    return _write_transfers(
        temp_csv_file,
        row_counter,
        transfers,
        spare_mode,
        spare_value,
    )


def read_csv(temp_csv_file):
    with open(temp_csv_file.name, "r", newline="") as handle:
        reader = csv.reader(handle)
        return list(reader)


def append_finished(temp_csv_file, row_counter: int) -> None:
    with open(temp_csv_file.name, "a", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow([row_counter, "FINISHED", "", ""])


def save_csv(
    file_name,
    temp_file,
    csv_headers=None,
    screen_indicator: str = "REPACK",
    **_,
):
    try:
        headers = csv_headers or HEADERS
        with open(temp_file.name, "r", newline="") as source:
            reader = csv.reader(source)
            rows = list(reader)
        if not rows:
            rows = [headers]
        else:
            first_row = [col.strip() for col in rows[0]]
            if first_row != headers:
                rows.insert(0, headers)
        last_number = 0
        for row in rows[1:]:
            if not row:
                continue
            try:
                last_number = max(last_number, int(row[0]))
            except (ValueError, IndexError):
                continue
        rows.append([str(last_number + 1), screen_indicator, "", ""])
        with open(file_name, "w", newline="") as handle:
            writer = csv.writer(handle)
            writer.writerows(rows)
        return True
    except Exception as exc:
        print("Error saving Dustin spare CSV:", exc)
        return False
