import sys
import tempfile
from typing import List

from PyQt5.QtCore import Qt, QTimer
from PyQt5.QtWidgets import (
    QApplication,
    QLabel,
    QLineEdit,
    QHBoxLayout,
    QVBoxLayout,
    QPushButton,
    QScrollArea,
    QSizePolicy,
    QSpacerItem,
    QSplitter,
    QWidget,
    QMessageBox,
)
import qdarkstyle

from program_files.csv_writers import CSV_Writer_QuickLPNRepack
from .BaseGUI import BaseWidget
from .InlineEditors import CollapsibleListEditor
from .MainButtons import MainButtons


class QuickLPNRepackGUI(BaseWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Quick LPN Repack")
        self.resize(540, 420)
        self.setMinimumSize(520, 400)

        self._side_panel_width = 280
        self._min_left_width = 320
        self._min_side_panel_width = 220
        self._left_before_side_panel = None

        self.mode = "quick_lpn_repack"
        self.screen_indicator = "REPACK"
        self.csv_writer = CSV_Writer_QuickLPNRepack
        self.temp_csv_file = tempfile.NamedTemporaryFile(delete=False, mode='w', newline='')
        self.row_counter = 1
        self.csv_headers = ["NUMBER", "PROMPT", "KEY", "DATA"]
        self.csv_writer.write_csv_headers(self.temp_csv_file)
        self.temp_csv_file.flush()
        self.temp_csv_file.close()

        self.from_lpn_list: List[str] = []

        self._build_ui()
        self.finalize_initial_size(extra_width=80)

    def _build_ui(self) -> None:
        self.status_label = QLabel("")
        self.status_label.setTextFormat(Qt.RichText)  # type: ignore[attr-defined]

        self.main_layout = QVBoxLayout(self)

        self.splitter = QSplitter(Qt.Horizontal, self)  # type: ignore[attr-defined]
        self.splitter.setHandleWidth(1)
        self.main_layout.addWidget(self.splitter)

        self.left_container = QWidget(self.splitter)
        self.left_layout = QVBoxLayout(self.left_container)
        self.left_layout.setContentsMargins(0, 0, 0, 0)
        self.left_layout.setSpacing(5)

        top_bar = QWidget(self.left_container)
        top_layout = QHBoxLayout(top_bar)
        top_layout.setContentsMargins(0, 0, 0, 0)
        top_layout.addWidget(self.status_label)

        self.toggle_side_panel_button = QPushButton('LPN List ▶', top_bar)
        self.toggle_side_panel_button.setToolTip('Show or hide the inline LPN editor')
        self.toggle_side_panel_button.clicked.connect(self.toggle_side_panel)
        top_layout.addWidget(self.toggle_side_panel_button)
        self.left_layout.addWidget(top_bar)

        self.scroll_area = QScrollArea(self.left_container)
        self.scroll_area.setWidgetResizable(True)
        self.scroll_content = QWidget(self.scroll_area)
        self.scroll_layout = QVBoxLayout(self.scroll_content)
        self.scroll_layout.setContentsMargins(6, 6, 6, 6)
        self.scroll_layout.setSpacing(8)
        self.scroll_area.setWidget(self.scroll_content)
        self.left_layout.addWidget(self.scroll_area)

        warning = QLabel(
            "Paste the source LPNs using the inline editor and provide the destination LPN."
        )
        warning.setWordWrap(True)
        warning.setStyleSheet("color: #CCCC66;")
        self.scroll_layout.addWidget(warning)

        note_label = QLabel(
            "Note: This will repack all child parts from the source LPNs onto the destination LPN."
        )
        note_label.setWordWrap(True)
        note_label.setStyleSheet("color: #AAAAAA;")
        self.scroll_layout.addWidget(note_label)

        from_section = QWidget()
        from_layout = QVBoxLayout(from_section)
        from_layout.setContentsMargins(0, 0, 0, 0)
        from_layout.setSpacing(6)

        from_header = QHBoxLayout()
        from_header.setContentsMargins(0, 0, 0, 0)
        from_header.addWidget(QLabel("From LPNs"))
        self.from_lpn_count_label = QLabel("0 LPNs")
        self.from_lpn_count_label.setStyleSheet("color: lightgray;")
        from_header.addStretch()
        from_header.addWidget(self.from_lpn_count_label)
        from_layout.addLayout(from_header)

        from_buttons = QHBoxLayout()
        from_buttons.setContentsMargins(0, 0, 0, 0)
        from_buttons.setSpacing(6)
        enter_lpns_button = QPushButton("Enter From LPNs")
        enter_lpns_button.setToolTip("Open the inline editor to paste LPNs")
        enter_lpns_button.clicked.connect(self.open_from_lpn_editor)
        from_buttons.addWidget(enter_lpns_button)

        clear_lpns_button = QPushButton("Clear List")
        clear_lpns_button.setToolTip("Remove all From LPN entries")
        clear_lpns_button.clicked.connect(self._clear_from_lpn_list)
        from_buttons.addWidget(clear_lpns_button)

        from_buttons.addStretch()
        from_layout.addLayout(from_buttons)

        self.scroll_layout.addWidget(from_section)

        to_section = QWidget()
        to_layout = QHBoxLayout(to_section)
        to_layout.setContentsMargins(0, 0, 0, 0)
        to_layout.setSpacing(6)
        to_layout.addWidget(QLabel("To LPN:"))
        self.to_lpn_edit = QLineEdit()
        self.to_lpn_edit.setPlaceholderText("Destination LPN (e.g., RC40-8458362)")
        to_layout.addWidget(self.to_lpn_edit)
        self.scroll_layout.addWidget(to_section)

        self.scroll_layout.addItem(QSpacerItem(20, 20, QSizePolicy.Minimum, QSizePolicy.Expanding))

        self.main_buttons = MainButtons(self)
        self.scroll_layout.addLayout(self.main_buttons.get_layout())

        self.side_panel = QWidget(self.splitter)
        self.side_layout = QVBoxLayout(self.side_panel)
        self.side_layout.setContentsMargins(6, 6, 6, 6)
        self.side_layout.setSpacing(8)

        self.inline_from_lpn_editor = CollapsibleListEditor(
            self,
            title='From LPNs',
            attr_name='from_lpn_list',
        )
        self.side_layout.addWidget(self.inline_from_lpn_editor)
        self.inline_from_lpn_editor.apply_button.clicked.connect(
            lambda: QTimer.singleShot(0, self.refresh_from_lpn_display)
        )

        self.side_layout.addStretch()

        self.splitter.addWidget(self.left_container)
        self.splitter.addWidget(self.side_panel)
        self.splitter.setStretchFactor(0, 1)
        self.splitter.setStretchFactor(1, 0)
        self.splitter.setSizes([1, 0])

        self.refresh_from_lpn_display()
        self._update_side_panel_button()

    def open_from_lpn_editor(self) -> None:
        self._ensure_side_panel_visible()
        if not self.inline_from_lpn_editor.container.isVisible():
            self.inline_from_lpn_editor.container.setVisible(True)
            self.inline_from_lpn_editor._update_toggle_icon()
        self.inline_from_lpn_editor.programmatic_update()
        self.inline_from_lpn_editor.editor.setFocus()

    def _clear_from_lpn_list(self) -> None:
        self.from_lpn_list = []
        self.refresh_from_lpn_display()
        self.inline_from_lpn_editor.programmatic_update()

    def refresh_from_lpn_display(self) -> None:
        count = len(self.from_lpn_list)
        self.from_lpn_count_label.setText(f"{count} LPN{'s' if count != 1 else ''}")
        color = 'lightgray' if count else '#888888'
        self.from_lpn_count_label.setStyleSheet(f"color: {color};")

    def toggle_side_panel(self) -> None:
        sizes = self.splitter.sizes()
        if len(sizes) < 2:
            return
        if sizes[1] == 0:
            self._open_side_panel()
        else:
            self._collapse_side_panel()
        self._update_side_panel_button()

    def _open_side_panel(self) -> None:
        sizes = self.splitter.sizes()
        if len(sizes) < 2:
            return
        left = max(sizes[0], self._min_left_width)
        desired_right = max(self._min_side_panel_width, self._side_panel_width)
        self._left_before_side_panel = left
        self.resize(self.width() + desired_right, self.height())
        self.splitter.setSizes([left, desired_right])

    def _collapse_side_panel(self) -> None:
        sizes = self.splitter.sizes()
        if len(sizes) < 2:
            return
        right = sizes[1]
        if right <= 0:
            return
        target_width = max(self.minimumWidth(), self.width() - right)
        left_target = self._left_before_side_panel if self._left_before_side_panel is not None else sizes[0]
        left_target = max(self._min_left_width, min(left_target, target_width))
        self.resize(target_width, self.height())
        self.splitter.setSizes([left_target, 0])
        self._left_before_side_panel = None

    def _ensure_side_panel_visible(self) -> None:
        sizes = self.splitter.sizes()
        if len(sizes) < 2:
            return
        if sizes[1] == 0:
            self._open_side_panel()
            self._update_side_panel_button()

    def _update_side_panel_button(self) -> None:
        sizes = self.splitter.sizes()
        if len(sizes) >= 2 and sizes[1] > 0:
            self.toggle_side_panel_button.setText('LPN List ◀')
        else:
            self.toggle_side_panel_button.setText('LPN List ▶')

    def clear_data_fields(self) -> None:
        self.from_lpn_list = []
        self.to_lpn_edit.clear()
        self.refresh_from_lpn_display()
        self.inline_from_lpn_editor.programmatic_update()
        self.status_label.setText("")

    def _close_temp_handle(self) -> None:
        try:
            if self.temp_csv_file and not self.temp_csv_file.closed:
                self.temp_csv_file.flush()
                self.temp_csv_file.close()
        except Exception:
            pass

    def on_csv_reset(self) -> None:
        self._close_temp_handle()
        self.status_label.setText("<span style='color: lightgray;'>Ready for new entries.</span>")

    def on_csv_loaded(self) -> None:
        self._close_temp_handle()
        self.status_label.setText("<span style='color: lightgray;'>CSV loaded. Continue adding rows as needed.</span>")

    def on_next_build(self) -> None:
        from_lpns = [value.strip() for value in self.from_lpn_list if value.strip()]
        to_lpn = self.to_lpn_edit.text().strip()

        if not from_lpns:
            QMessageBox.warning(self, "Missing LPNs", "Add at least one From LPN before adding to CSV.")
            return
        if not to_lpn:
            QMessageBox.warning(self, "Missing To LPN", "Enter the destination LPN before adding to CSV.")
            return

        try:
            self.row_counter = self.csv_writer.append_to_csv(
                self.temp_csv_file,
                self.row_counter,
                from_lpns,
                to_lpn,
            )
        except Exception as exc:
            QMessageBox.critical(self, "Error", f"Failed to add data to CSV: {exc}")
            return

        self.status_label.setText(
            f"<span style='color: lightgreen;'>Added {len(from_lpns)} LPN{'s' if len(from_lpns) != 1 else ''} to CSV.</span>"
        )
        self.from_lpn_list = []
        self.refresh_from_lpn_display()
        self.inline_from_lpn_editor.programmatic_update()

    def on_finish_csv(self) -> None:
        # Handled by MainButtons; method present for compatibility if called directly.
        pass


if __name__ == "__main__":
    app = QApplication.instance() or QApplication(sys.argv)
    if isinstance(app, QApplication):
        app.setStyleSheet(qdarkstyle.load_stylesheet_pyqt5())
    gui = QuickLPNRepackGUI()
    gui.show()
    sys.exit(app.exec_())
