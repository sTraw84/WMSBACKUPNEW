from PyQt5.QtWidgets import (
    QVBoxLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QCheckBox,
    QMessageBox,
    QScrollArea,
    QWidget,
    QSpacerItem,
    QSizePolicy,
    QFileDialog,
    QSplitter,
)
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont
from .BaseGUI import BaseDialog
from .InlineEditors import CollapsibleListEditor
from program_files.csv_writers import CSV_Writer_SingleWIP
from ..utils.file_paths import get_default_save_path_for_csv_writer

class SingleDevicesGUI(BaseDialog):
    def __init__(self, lpn_value="", job_value=""):
        super().__init__()
        self.lpn_value = lpn_value
        self.job_value = job_value
        self.sn_list = []
        self._side_panel_width = 260
        self._min_left_width = 320
        self._min_side_panel_width = 200
        self._left_before_side_panel = None
        self.initUI()

    def initUI(self):
        self.setWindowTitle('Single Devices')
        self.resize(540, 420)
        self.setMinimumSize(520, 380)

        self.main_layout = QVBoxLayout(self)

        self.splitter = QSplitter(Qt.Horizontal, self)  # type: ignore[attr-defined]
        self.splitter.setHandleWidth(1)
        self.main_layout.addWidget(self.splitter)

        self.left_container = QWidget(self.splitter)
        self.left_layout = QVBoxLayout(self.left_container)
        self.left_layout.setContentsMargins(0, 0, 0, 0)
        self.left_layout.setSpacing(5)

        top_bar = QWidget(self.left_container)
        self.top_layout = QHBoxLayout(top_bar)
        self.top_layout.setContentsMargins(0, 0, 0, 0)
        self.status_label = QLabel('', top_bar)
        self.top_layout.addWidget(self.status_label)
        self.toggle_side_panel_button = QPushButton('Lists ▶', top_bar)
        self.toggle_side_panel_button.setToolTip('Show or hide the list panel')
        self.toggle_side_panel_button.setMinimumWidth(
            self.toggle_side_panel_button.sizeHint().width()
        )
        self.toggle_side_panel_button.clicked.connect(self.toggle_side_panel)
        self.top_layout.addWidget(self.toggle_side_panel_button)
        self.left_layout.addWidget(top_bar)

        title_label = QLabel("Single Devices")
        title_label.setFont(QFont("Arial", 18, weight=QFont.Bold))
        title_label.setStyleSheet("color: #CCCCCC;")
        title_label.setAlignment(Qt.AlignCenter)
        self.left_layout.addWidget(title_label)
        self.scroll_area = QScrollArea(self.left_container)
        self.scroll_area.setWidgetResizable(True)
        self.scroll_content = QWidget(self.scroll_area)
        self.scroll_layout = QVBoxLayout(self.scroll_content)
        self.scroll_area.setWidget(self.scroll_content)
        self.left_layout.addWidget(self.scroll_area)
        lpn_layout = QHBoxLayout()
        self.lpn_checkbox = QCheckBox("Enable LPN Entry", self)
        self.lpn_checkbox.stateChanged.connect(self.toggle_lpn_editing)
        lpn_layout.addWidget(self.lpn_checkbox)
        self.scroll_layout.addLayout(lpn_layout)
        lpn_text_layout = QHBoxLayout()
        lpn_label = QLabel("LPN:", self)
        self.lpn_input = QLineEdit(self)
        self.lpn_input.setPlaceholderText("Check the box to enter WIP LPN manually")
        self.lpn_input.setReadOnly(True)
        self.lpn_input.setStyleSheet("color: grey;")
        lpn_text_layout.addWidget(lpn_label)
        lpn_text_layout.addWidget(self.lpn_input)
        self.scroll_layout.addLayout(lpn_text_layout)
        job_layout = QHBoxLayout()
        job_label = QLabel("Job#:", self)
        self.job_input = QLineEdit(self)
        self.job_input.setPlaceholderText("Enter WIP Job# here")
        job_layout.addWidget(job_label)
        job_layout.addWidget(self.job_input)
        self.scroll_layout.addLayout(job_layout)
        if self.lpn_value:
            self.lpn_layout = QHBoxLayout()
            self.lpn_label = QLabel("LPN:", self)
            self.lpn_display = QLineEdit(self)
            self.lpn_display.setText(self.lpn_value)
            self.lpn_display.setReadOnly(True)
            self.lpn_display.setStyleSheet("color: grey;")
            self.lpn_layout.addWidget(self.lpn_label)
            self.lpn_layout.addWidget(self.lpn_display)
            self.scroll_layout.addLayout(self.lpn_layout)
        if self.job_value:
            self.job_layout = QHBoxLayout()
            self.job_label = QLabel("Job#:", self)
            self.job_display = QLineEdit(self)
            self.job_display.setText(self.job_value)
            self.job_display.setReadOnly(True)
            self.job_display.setStyleSheet("color: grey;")
            self.job_layout.addWidget(self.job_label)
            self.job_layout.addWidget(self.job_display)
            self.scroll_layout.addLayout(self.job_layout)
        sn_button_layout = QHBoxLayout()
        self.sn_list_button = QPushButton('SN List', self)
        self.sn_list_button.clicked.connect(self.open_sn_list_dialog)
        sn_button_layout.addWidget(self.sn_list_button)
        self.scroll_layout.addLayout(sn_button_layout)
        self.scroll_layout.addItem(QSpacerItem(20, 20, QSizePolicy.Minimum, QSizePolicy.Expanding))
        self.action_buttons_layout = QHBoxLayout()
        self.generate_csv_button = QPushButton("Generate CSV", self)
        self.generate_csv_button.clicked.connect(self.generate_csv)
        self.cancel_button = QPushButton("Cancel", self)
        self.cancel_button.clicked.connect(self.close)
        self.action_buttons_layout.addWidget(self.generate_csv_button)
        self.action_buttons_layout.addWidget(self.cancel_button)
        self.scroll_layout.addLayout(self.action_buttons_layout)

        self.side_panel = QWidget(self.splitter)
        self.side_layout = QVBoxLayout(self.side_panel)
        self.side_layout.setContentsMargins(6, 6, 6, 6)
        self.side_layout.setSpacing(8)

        self.inline_sn_editor = CollapsibleListEditor(
            self,
            title='SN List',
            attr_name='sn_list',
        )
        self.side_layout.addWidget(self.inline_sn_editor)
        self.inline_sn_editor.apply_button.clicked.connect(self._refresh_inline_editors)
        self.side_layout.addStretch()

        self.splitter.addWidget(self.left_container)
        self.splitter.addWidget(self.side_panel)
        self.splitter.setStretchFactor(0, 1)
        self.splitter.setStretchFactor(1, 0)
        self.splitter.setSizes([1, 0])

        self._refresh_inline_editors()
        self.finalize_initial_size(extra_width=120)
        self._update_side_panel_button()

    def toggle_lpn_editing(self, state):
        if state == Qt.Checked:
            self.lpn_input.setReadOnly(False)
            self.lpn_input.setStyleSheet("color: white;")
            self.lpn_input.clear()
            self.lpn_input.setPlaceholderText("Enter WIP LPN...")
        else:
            self.lpn_input.setReadOnly(True)
            self.lpn_input.setStyleSheet("color: grey;")
            self.lpn_input.clear()
            self.lpn_input.setPlaceholderText("Check the box to enter WIP LPN manually")

    def open_sn_list_dialog(self):
        self.open_sn_list_inline()

    def open_sn_list_inline(self):
        try:
            if not hasattr(self, 'inline_sn_editor'):
                return
            self._ensure_side_panel_visible()
            editor = self.inline_sn_editor
            if not editor.container.isVisible():
                editor.container.setVisible(True)
                editor._update_toggle_icon()
            editor.programmatic_update()
            editor.editor.setFocus()
        except Exception:
            pass

    def _update_side_panel_button(self) -> None:
        try:
            sizes = self.splitter.sizes() if hasattr(self, 'splitter') else []
            if sizes and len(sizes) >= 2 and sizes[1] > 0:
                self.toggle_side_panel_button.setText('Lists ◀')
            else:
                self.toggle_side_panel_button.setText('Lists ▶')
        except Exception:
            pass

    def _open_side_panel(self) -> None:
        if not hasattr(self, 'splitter'):
            return
        sizes = self.splitter.sizes()
        if len(sizes) < 2:
            return
        left_width = max(sizes[0], self._min_left_width)
        desired_right = max(self._min_side_panel_width, self._side_panel_width)
        self._left_before_side_panel = left_width
        self.resize(self.width() + desired_right, self.height())
        self.splitter.setSizes([left_width, desired_right])

    def _collapse_side_panel(self) -> None:
        if not hasattr(self, 'splitter'):
            return
        sizes = self.splitter.sizes()
        if len(sizes) < 2:
            return
        right_width = sizes[1]
        if right_width <= 0:
            return
        target_width = max(self.minimumWidth(), self.width() - right_width)
        self.resize(target_width, self.height())
        left_target = (
            self._left_before_side_panel
            if self._left_before_side_panel is not None
            else sizes[0]
        )
        left_target = max(self._min_left_width, min(left_target, target_width))
        self.splitter.setSizes([left_target, 0])
        self._left_before_side_panel = None

    def toggle_side_panel(self) -> None:
        try:
            if not hasattr(self, 'splitter'):
                return
            sizes = self.splitter.sizes()
            if len(sizes) < 2:
                return
            if sizes[1] == 0:
                self._open_side_panel()
            else:
                self._collapse_side_panel()
            self._update_side_panel_button()
        except Exception:
            pass

    def _ensure_side_panel_visible(self) -> None:
        try:
            sizes = self.splitter.sizes()
            if len(sizes) < 2:
                return
            if sizes[1] == 0:
                self._open_side_panel()
                self._update_side_panel_button()
        except Exception:
            pass

    def _refresh_inline_editors(self) -> None:
        if hasattr(self, 'inline_sn_editor'):
            self.inline_sn_editor.programmatic_update()
        if hasattr(self, 'sn_list_button'):
            count = len(self.sn_list)
            self.sn_list_button.setText('SN List' if count == 0 else f'SN List ({count})')

    def generate_csv(self):
        try:
            job_value = self.job_input.text().strip()
            if not job_value:
                QMessageBox.warning(self, "Missing Job#", "Please enter WIP Job# before proceeding.")
                return
            if not self.sn_list:
                QMessageBox.warning(self, "No SNs", "Please enter at least one serial number via SN List.")
                return
            file_path, _ = QFileDialog.getSaveFileName(self, "Save WIP CSV File", get_default_save_path_for_csv_writer("WIP_Single.csv"), "CSV files (*.csv);;All files (*)")
            if not file_path:
                return
            if not file_path.lower().endswith('.csv'):
                file_path += '.csv'
            lpn_value = self.lpn_input.text().strip() if self.lpn_checkbox.isChecked() else ""
            success = CSV_Writer_SingleWIP.save_wip_single_csv(file_path, self.sn_list, lpn_value, job_value)
            if success:
                QMessageBox.information(self, "Success", f"WIP CSV file saved successfully:\n{file_path}")
                self.close()
            else:
                QMessageBox.critical(self, "Error", "Failed to save CSV file.")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"An error occurred: {str(e)}")

    def closeEvent(self, event):
        event.accept()
