import os
import re
import sys
import openpyxl
import csv
import argparse
from PyQt5.QtWidgets import (
    QApplication,
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QPushButton,
    QLabel,
    QFileDialog,
    QMessageBox,
    QLineEdit,
    QCheckBox,
)
from PyQt5.QtGui import QFont, QIcon
from PyQt5.QtCore import Qt
import qdarkstyle
import CSV_Writer_ISRWIP

def extract_serials_from_log(log_content):
    """
    Extracts serial numbers from a log file content.
    Returns a list of [Chassis SN, NIM-24A SN1, ..., NIM-24A SN5] (up to 5 NIMs).
    If a SN is missing, fills with "Missing".
    """
    # Find Chassis SN - look for the first ISR4351/K9 that appears after "Chassis"
    chassis_sn = "Missing"
    lines = log_content.split('\n')
    
    for i, line in enumerate(lines):
        if '"Chassis"' in line and i + 1 < len(lines):
            # Look at the next line for PID and SN
            next_line = lines[i + 1]
            if 'PID: ISR4351/K9' in next_line:
                # Extract SN from this line
                sn_match = re.search(r'SN:\s*(\S+)', next_line)
                if sn_match and sn_match.group(1).strip():
                    chassis_sn = sn_match.group(1).strip()
                break

    # Find NIM-24A SNs in order of appearance
    nim_sns = []
    for i, line in enumerate(lines):
        if 'NIM subslot' in line and i + 1 < len(lines):
            # Look at the next line for PID and SN
            next_line = lines[i + 1]
            if 'PID: NIM-24A' in next_line:
                # Extract SN from the next line
                sn_match = re.search(r'SN:\s*(\S*)', next_line)
                if sn_match:
                    sn = sn_match.group(1).strip()
                    if sn:  # Only add if SN is not empty
                        nim_sns.append(sn)
                    else:
                        nim_sns.append("Missing")
    
    # Ensure we have exactly 5 NIM entries
    while len(nim_sns) < 5:
        nim_sns.append("Missing")
    
    # Limit to 5 NIMs maximum
    nim_sns = nim_sns[:5]
    
    return [chassis_sn] + nim_sns

class InventoryExporterApp(QWidget):
    def __init__(self, lpn_value="", job_value=""):
        super().__init__()
        self.setWindowTitle("ISR4351 Data Extraction")
        self.setWindowIcon(QIcon('bolt.ico'))
        self.lpn_value = lpn_value
        self.job_value = job_value
        self._build_ui()

    def _build_ui(self):
        layout = QVBoxLayout()

        title_label = QLabel("ISR4351 Data Extraction")
        title_label.setFont(QFont("Arial", 24, weight=QFont.Bold))
        title_label.setStyleSheet("color: #CCCCCC;")
        title_label.setAlignment(Qt.AlignCenter)
        layout.addWidget(title_label)

        # LPN section with checkbox
        lpn_layout = QHBoxLayout()
        self.lpn_checkbox = QCheckBox("Enable LPN Entry", self)
        self.lpn_checkbox.stateChanged.connect(self.toggle_lpn_editing)
        lpn_layout.addWidget(self.lpn_checkbox)
        layout.addLayout(lpn_layout)

        lpn_text_layout = QHBoxLayout()
        lpn_label = QLabel("LPN:", self)
        self.lpn_edit = QLineEdit()
        self.lpn_edit.setText(self.lpn_value)
        self.lpn_edit.setPlaceholderText("Check the box to enter WIP LPN manually")
        self.lpn_edit.setReadOnly(True)
        self.lpn_edit.setStyleSheet("color: grey;")
        lpn_text_layout.addWidget(lpn_label)
        lpn_text_layout.addWidget(self.lpn_edit)
        layout.addLayout(lpn_text_layout)

        # Job section
        job_layout = QHBoxLayout()
        job_label = QLabel("Job#:")
        self.job_edit = QLineEdit()
        self.job_edit.setText(self.job_value)
        self.job_edit.setPlaceholderText("Enter job number")
        job_layout.addWidget(job_label)
        job_layout.addWidget(self.job_edit)
        layout.addLayout(job_layout)

        prompt_label = QLabel("Select folder containing log files:")
        layout.addWidget(prompt_label)

        path_row = QHBoxLayout()
        self.folder_edit = QLineEdit()
        self.folder_edit.setReadOnly(True)
        browse_button = QPushButton("Browse")
        browse_button.clicked.connect(self.browse_folder)
        path_row.addWidget(self.folder_edit)
        path_row.addWidget(browse_button)
        layout.addLayout(path_row)

        # Button row
        button_row = QHBoxLayout()
        export_xlsx_button = QPushButton("Export XLXS Report")
        export_xlsx_button.clicked.connect(self.export_xlsx_report)
        export_script_button = QPushButton("Export Script CSV")
        export_script_button.clicked.connect(self.export_script_csv)
        button_row.addWidget(export_xlsx_button)
        button_row.addWidget(export_script_button)
        layout.addLayout(button_row)

        self.setLayout(layout)

    def toggle_lpn_editing(self, state):
        """Toggle LPN text box editing based on checkbox state"""
        if state == Qt.Checked:
            self.lpn_edit.setReadOnly(False)
            self.lpn_edit.setStyleSheet("color: white;")
            self.lpn_edit.clear()
            self.lpn_edit.setPlaceholderText("Enter WIP LPN...")
        else:
            self.lpn_edit.setReadOnly(True)
            self.lpn_edit.setStyleSheet("color: grey;")
            self.lpn_edit.clear()
            self.lpn_edit.setPlaceholderText("Check the box to enter WIP LPN manually")

    def browse_folder(self):
        folder_selected = QFileDialog.getExistingDirectory(self, "Select Folder")
        if folder_selected:
            self.folder_edit.setText(folder_selected)

    def export_xlsx_report(self):
        folder = self.folder_edit.text()
        if not folder or not os.path.isdir(folder):
            QMessageBox.critical(self, "Error", "Please select a valid folder.")
            return

        txt_files = [f for f in os.listdir(folder) if f.lower().endswith('.txt')]
        if not txt_files:
            QMessageBox.critical(self, "Error", "No .txt files found in selected folder.")
            return

        rows = []
        for filename in txt_files:
            file_path = os.path.join(folder, filename)
            try:
                with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
                    content = f.read()
                    serials = extract_serials_from_log(content)
                    rows.append(serials)
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Failed to read {filename}: {str(e)}")
                return

        header = ["ISR4351/K9", "NIM-24A 1", "NIM-24A 2", "NIM-24A 3", "NIM-24A 4", "NIM-24A 5"]

        # Default to ISR_WIPREPORT.xlsx in the same folder
        default_path = os.path.join(folder, "ISR_WIPREPORT.xlsx")
        save_path, _ = QFileDialog.getSaveFileName(self, "Save XLXS Report", default_path, filter="Excel files (*.xlsx)")
        if not save_path:
            return

        # Ensure .xlsx extension
        if not save_path.lower().endswith('.xlsx'):
            save_path += '.xlsx'

        try:
            wb = openpyxl.Workbook()
            ws = wb.active
            ws.append(header)
            for row in rows:
                ws.append(row)
            wb.save(save_path)
            QMessageBox.information(self, "Success", f"XLXS Report saved: {save_path}")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to write XLXS file: {str(e)}")

    def export_script_csv(self):
        folder = self.folder_edit.text()
        if not folder or not os.path.isdir(folder):
            QMessageBox.critical(self, "Error", "Please select a valid folder.")
            return

        # Get LPN and Job values from the form
        lpn_value = self.lpn_edit.text().strip()
        job_value = self.job_edit.text().strip()
        
        if not job_value:
            QMessageBox.critical(self, "Error", "Please enter a Job#.")
            return

        txt_files = [f for f in os.listdir(folder) if f.lower().endswith('.txt')]
        if not txt_files:
            QMessageBox.critical(self, "Error", "No .txt files found in selected folder.")
            return

        rows = []
        for filename in txt_files:
            file_path = os.path.join(folder, filename)
            try:
                with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
                    content = f.read()
                    serials = extract_serials_from_log(content)
                    rows.append(serials)
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Failed to read {filename}: {str(e)}")
                return

        # Default to WIP_ISR_TEST.csv in the same folder
        default_path = os.path.join(folder, "WIP_ISR_TEST.csv")
        save_path, _ = QFileDialog.getSaveFileName(self, "Save Script CSV", default_path, filter="CSV files (*.csv)")
        if not save_path:
            return

        # Ensure .csv extension
        if not save_path.lower().endswith('.csv'):
            save_path += '.csv'

        try:
            success = CSV_Writer_ISRWIP.save_wip_csv(save_path, rows, lpn_value, job_value)
            if success:
                QMessageBox.information(self, "Success", f"Script CSV saved: {save_path}")
            else:
                QMessageBox.critical(self, "Error", "Failed to save Script CSV file.")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to write Script CSV file: {str(e)}")

def process_logs_and_save_csv(folder_path, lpn_value="", job_value="", output_path=None):
    """
    Process log files and save as WIP CSV format
    
    Args:
        folder_path: Path to folder containing log files
        lpn_value: LPN value to use
        job_value: Job number to use
        output_path: Output CSV file path (optional)
    """
    try:
        import CSV_Writer_ISRWIP
        
        txt_files = [f for f in os.listdir(folder_path) if f.lower().endswith('.txt')]
        if not txt_files:
            print("No .txt files found in selected folder.")
            return False

        rows = []
        for filename in txt_files:
            file_path = os.path.join(folder_path, filename)
            try:
                with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
                    content = f.read()
                    serials = extract_serials_from_log(content)
                    rows.append(serials)
            except Exception as e:
                print(f"Failed to read {filename}: {str(e)}")
                return False

        # Set default output path if not provided
        if not output_path:
            output_path = os.path.join(folder_path, "WIP_ISR_TEST.csv")
        
        # Save as WIP CSV
        success = CSV_Writer_ISRWIP.save_wip_csv(output_path, rows, lpn_value, job_value)
        
        if success:
            print(f"WIP CSV file saved successfully: {output_path}")
            return True
        else:
            print("Failed to save WIP CSV file.")
            return False
            
    except Exception as e:
        print(f"Error processing logs: {str(e)}")
        return False

def main():
    # Parse command line arguments
    parser = argparse.ArgumentParser(description='Cisco Inventory Exporter')
    parser.add_argument('--lpn', default='', help='LPN value for WIP CSV')
    parser.add_argument('--job', default='1234567', help='Job number for WIP CSV')
    parser.add_argument('--folder', help='Folder containing log files (for command line mode)')
    parser.add_argument('--output', help='Output CSV file path (for command line mode)')
    
    args = parser.parse_args()
    
    # If folder is provided via command line, process in batch mode
    if args.folder:
        if os.path.isdir(args.folder):
            success = process_logs_and_save_csv(args.folder, args.lpn, args.job, args.output)
            sys.exit(0 if success else 1)
        else:
            print(f"Error: Folder '{args.folder}' does not exist.")
            sys.exit(1)
    
    # Otherwise, run in GUI mode
    app = QApplication(sys.argv)
    app.setStyleSheet(qdarkstyle.load_stylesheet_pyqt5())
    app.setWindowIcon(QIcon('bolt.ico'))
    window = InventoryExporterApp(args.lpn, args.job)
    window.resize(600, 300)
    window.show()
    sys.exit(app.exec_())

if __name__ == "__main__":
    main()