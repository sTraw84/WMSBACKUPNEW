import tempfile
from PyQt5.QtWidgets import (
    QDialog,
    QVBoxLayout,
    QLabel,
    QScrollArea,
    QWidget,
    QHBoxLayout,
    QLineEdit,
    QCheckBox,
    QPushButton,
    QMessageBox,
    QSpacerItem,
    QSizePolicy,
    QInputDialog,
    QTextEdit,
    QTabWidget,
    QDialogButtonBox,
    QSplitter,
    QGridLayout,
)
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QIntValidator
from typing import Optional
from program_files.csv_writers import CSV_Writer_Split
from .MainButtons import MainButtons
from .BaseGUI import BaseDialog
from .InlineEditors import CollapsibleListEditor, ChildSNsTabbedEditor
import csv

class NumericLineEdit(QLineEdit):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setValidator(QIntValidator(0, 999999, self))

class SplitGUI(BaseDialog):
    def __init__(self):
        super().__init__()
        self.mode = "split"  # Set the mode for CSV loading
        self.csv_writer = CSV_Writer_Split  # Set the CSV writer
        self.screen_indicator = "SPLIT"
        
        # Initialize CSV-related variables
        self.temp_csv_file = tempfile.NamedTemporaryFile(delete=False, mode='w', newline='')
        self.row_counter = 1
        
        # Write headers to the CSV file
        self.csv_writer.write_csv_headers(self.temp_csv_file)
        
        self.total_builds = 0  # Initialize total builds counter
        self.child_part_counter = 0
        self.c40_list = []
        self.master_sn_list = []
        self.child_sn_list = []
        self.lpn_changed = False  # Track if the LPN has been changed
        self._side_panel_width = 320
        self._min_left_width = 320
        self._min_side_panel_width = 220
        self._left_before_side_panel: Optional[int] = None

        # Initialize the UI
        self.initUI()

    def initUI(self):
        self.setWindowTitle('Split Questions')
        self.resize(640, 560)
        self.setMinimumSize(640, 520)

        self.main_layout = QVBoxLayout(self)

        self.splitter = QSplitter(Qt.Horizontal, self)  # type: ignore[attr-defined]
        self.splitter.setHandleWidth(1)
        self.main_layout.addWidget(self.splitter)

        # Left container (main form)
        self.left_container = QWidget(self.splitter)
        self.left_layout = QVBoxLayout(self.left_container)
        self.left_layout.setContentsMargins(0, 0, 0, 0)
        self.left_layout.setSpacing(5)

        top_bar = QWidget(self.left_container)
        self.top_layout = QHBoxLayout(top_bar)
        self.top_layout.setContentsMargins(0, 0, 0, 0)
        self.status_label = QLabel(top_bar)
        self.top_layout.addWidget(self.status_label)
        self.counter_label = QLabel('Total Builds: 0', top_bar)
        self.counter_label.setAlignment(Qt.AlignRight)
        self.top_layout.addWidget(self.counter_label)
        self.toggle_side_panel_button = QPushButton('Lists ▶', top_bar)
        self.toggle_side_panel_button.setToolTip('Show or hide the lists panel')
        self.toggle_side_panel_button.setMinimumWidth(
            self.toggle_side_panel_button.sizeHint().width()
        )
        self.toggle_side_panel_button.clicked.connect(self.toggle_side_panel)
        self.top_layout.addWidget(self.toggle_side_panel_button)
        self.left_layout.addWidget(top_bar)

        self.scroll_area = QScrollArea(self.left_container)
        self.scroll_area.setWidgetResizable(True)
        self.scroll_content = QWidget(self.scroll_area)
        self.scroll_layout = QVBoxLayout(self.scroll_content)
        self.scroll_layout.setSpacing(6)
        self.scroll_layout.setContentsMargins(5, 5, 5, 5)
        self.scroll_area.setWidget(self.scroll_content)
        self.left_layout.addWidget(self.scroll_area)

        form_grid = QGridLayout()
        form_grid.setHorizontalSpacing(8)
        form_grid.setVerticalSpacing(6)

        def _prep_label(text: str) -> QLabel:
            label = QLabel(text, self)
            label.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)  # type: ignore[attr-defined]
            return label

        row = 0
        self.from_lpn_label = _prep_label('From LPN:')
        self.from_lpn_textbox = QLineEdit(self)
        self.from_lpn_textbox.textChanged.connect(self._on_from_lpn_changed)
        self.from_lpn_layout = QHBoxLayout()
        self.from_lpn_layout.setSpacing(6)
        self.from_lpn_layout.addWidget(self.from_lpn_textbox)
        form_grid.addWidget(self.from_lpn_label, row, 0)
        form_grid.addLayout(self.from_lpn_layout, row, 1)
        row += 1

        q1_label = _prep_label('Do you need master parts packed onto a C40?')
        self.question1_checkbox = QCheckBox(self)
        self.question1_checkbox.stateChanged.connect(self.toggle_part_number)
        form_grid.addWidget(q1_label, row, 0)
        form_grid.addWidget(self.question1_checkbox, row, 1)
        row += 1

        self.master_part_label = _prep_label('Master Part:')
        self.master_part_textbox = QLineEdit(self)
        master_row = QHBoxLayout()
        master_row.setSpacing(6)
        master_row.addWidget(self.master_part_textbox)
        self.master_sn_list_button = QPushButton('Master SN List', self)
        self.master_sn_list_button.clicked.connect(self.open_master_sn_list_inline)
        master_row.addWidget(self.master_sn_list_button)
        form_grid.addWidget(self.master_part_label, row, 0)
        form_grid.addLayout(master_row, row, 1)
        self.master_part_label.hide()
        self.master_part_textbox.hide()
        self.master_sn_list_button.hide()
        row += 1

        q2_label = _prep_label('How many child parts per C40?')
        q2_controls = QHBoxLayout()
        q2_controls.setSpacing(6)
        paste_multiple_button = QPushButton('Paste Multi.', self)
        paste_multiple_button.clicked.connect(self.open_paste_multiple_dialog)
        load_template_button = QPushButton('Load Template', self)
        load_template_button.setToolTip(
            'Load Part#/QTY from an Excel template (expects columns: Part#, QTY)'
        )
        load_template_button.clicked.connect(self.load_template_parts)
        add_button = QPushButton('+', self)
        remove_button = QPushButton('-', self)
        add_button.setFixedWidth(22)
        remove_button.setFixedWidth(22)
        add_button.clicked.connect(self.add_child_part)
        remove_button.clicked.connect(self.remove_child_part)
        add_child_sns_button = QPushButton("Add Child SN's", self)
        add_child_sns_button.clicked.connect(self.prompt_child_sns)
        q2_controls.addWidget(paste_multiple_button)
        q2_controls.addWidget(load_template_button)
        q2_controls.addWidget(add_button)
        q2_controls.addWidget(remove_button)
        q2_controls.addWidget(add_child_sns_button)
        form_grid.addWidget(q2_label, row, 0)
        form_grid.addLayout(q2_controls, row, 1)
        row += 1

        child_parts_label = _prep_label('Child Parts:')
        form_grid.addWidget(child_parts_label, row, 0)
        self.child_parts_layout = QVBoxLayout()
        self.child_parts_layout.setSpacing(4)
        form_grid.addLayout(self.child_parts_layout, row, 1)
        row += 1

        q3_label = _prep_label("How many C40's are built this way?")
        q3_row = QHBoxLayout()
        q3_row.setSpacing(6)
        self.question3_textbox = NumericLineEdit(self)
        self.add_c40_list_button = QPushButton('C40 List', self)
        self.add_c40_list_button.clicked.connect(self.open_c40_list_inline)
        q3_row.addWidget(self.question3_textbox)
        q3_row.addWidget(self.add_c40_list_button)
        form_grid.addWidget(q3_label, row, 0)
        form_grid.addLayout(q3_row, row, 1)

        form_grid.setColumnStretch(0, 0)
        form_grid.setColumnStretch(1, 1)
        self.scroll_layout.addLayout(form_grid)
        self.scroll_layout.addItem(
            QSpacerItem(20, 20, QSizePolicy.Minimum, QSizePolicy.Expanding)
        )

        self.main_buttons = MainButtons(self)
        self.left_layout.addLayout(self.main_buttons.get_layout())

        # Side panel with inline editors
        self.side_panel = QWidget(self.splitter)
        self.side_layout = QVBoxLayout(self.side_panel)
        self.side_layout.setContentsMargins(6, 6, 6, 6)
        self.side_layout.setSpacing(8)

        self.inline_c40_editor = CollapsibleListEditor(
            self,
            title='C40 List',
            attr_name='c40_list',
            get_expected=lambda: int(self.question3_textbox.text())
            if self.question3_textbox.text().strip().isdigit()
            else None,
        )
        self.inline_master_sn_editor = CollapsibleListEditor(
            self,
            title='Master SN List',
            attr_name='master_sn_list',
            get_expected=lambda: int(self.question3_textbox.text())
            if (
                self.question3_textbox.text().strip().isdigit()
                and self.question1_checkbox.isChecked()
            )
            else None,
            is_active=lambda: self.question1_checkbox.isChecked(),
        )
        self.inline_child_sn_tabs = ChildSNsTabbedEditor(
            self,
            title='Child SNs',
        )
        self.side_layout.addWidget(self.inline_c40_editor)
        self.side_layout.addWidget(self.inline_master_sn_editor)
        self.side_layout.addWidget(self.inline_child_sn_tabs)
        self.side_layout.addStretch()

        self.splitter.addWidget(self.left_container)
        self.splitter.addWidget(self.side_panel)
        self.splitter.setStretchFactor(0, 1)
        self.splitter.setStretchFactor(1, 0)
        self.splitter.setSizes([1, 0])

        self._refresh_inline_editors()

        self.question3_textbox.textChanged.connect(
            self._handle_question3_changed
        )

        self.finalize_initial_size(extra_width=120)
        self._update_side_panel_button()

    def _update_side_panel_button(self) -> None:
        try:
            sizes = self.splitter.sizes() if hasattr(self, 'splitter') else []
            if sizes and len(sizes) >= 2 and sizes[1] > 0:
                self.toggle_side_panel_button.setText('Lists ◀')
            else:
                self.toggle_side_panel_button.setText('Lists ▶')
        except Exception:
            pass

    def _open_side_panel(self) -> None:
        if not hasattr(self, 'splitter'):
            return
        sizes = self.splitter.sizes()
        if len(sizes) < 2:
            return
        left_width = max(sizes[0], self._min_left_width)
        desired_right = max(self._min_side_panel_width, self._side_panel_width)
        self._left_before_side_panel = left_width
        self.resize(self.width() + desired_right, self.height())
        self.splitter.setSizes([left_width, desired_right])

    def _collapse_side_panel(self) -> None:
        if not hasattr(self, 'splitter'):
            return
        sizes = self.splitter.sizes()
        if len(sizes) < 2:
            return
        right_width = sizes[1]
        if right_width <= 0:
            return
        target_width = max(self.minimumWidth(), self.width() - right_width)
        self.resize(target_width, self.height())
        left_target = (
            self._left_before_side_panel
            if self._left_before_side_panel is not None
            else sizes[0]
        )
        left_target = max(self._min_left_width, min(left_target, target_width))
        self.splitter.setSizes([left_target, 0])
        self._left_before_side_panel = None

    def toggle_side_panel(self) -> None:
        try:
            if not hasattr(self, 'splitter'):
                return
            sizes = self.splitter.sizes()
            if len(sizes) < 2:
                return
            if sizes[1] == 0:
                self._open_side_panel()
            else:
                self._collapse_side_panel()
            self._update_side_panel_button()
        except Exception:
            pass

    def _ensure_side_panel_visible(self) -> None:
        try:
            sizes = self.splitter.sizes()
            if len(sizes) < 2:
                return
            if sizes[1] == 0:
                self._open_side_panel()
                self._update_side_panel_button()
        except Exception:
            pass

    def _handle_question3_changed(self) -> None:
        self._refresh_inline_editors()

    def _refresh_inline_editors(self) -> None:
        if hasattr(self, 'inline_c40_editor'):
            self.inline_c40_editor.programmatic_update()
        if hasattr(self, 'inline_master_sn_editor'):
            self.inline_master_sn_editor.programmatic_update()
        if hasattr(self, 'inline_child_sn_tabs'):
            self.inline_child_sn_tabs.programmatic_update()

    def open_c40_list_inline(self) -> None:
        try:
            if not hasattr(self, 'inline_c40_editor'):
                return
            self._ensure_side_panel_visible()
            editor = self.inline_c40_editor
            if not editor.container.isVisible():
                editor.container.setVisible(True)
                editor._update_toggle_icon()
            editor.programmatic_update()
            editor.editor.setFocus()
        except Exception:
            pass

    def open_master_sn_list_inline(self) -> None:
        try:
            if not hasattr(self, 'inline_master_sn_editor'):
                return
            self._ensure_side_panel_visible()
            editor = self.inline_master_sn_editor
            if not editor.container.isVisible():
                editor.container.setVisible(True)
                editor._update_toggle_icon()
            editor.programmatic_update()
            editor.editor.setFocus()
        except Exception:
            pass

    def prompt_child_sns(self) -> None:
        if self.child_part_counter == 0:
            QMessageBox.warning(
                self,
                'No Child Parts',
                'Add at least one child part before adding child SNs.',
            )
            return
        num_sns, ok = QInputDialog.getInt(
            self,
            'Input',
            'How many child parts lines have SNs?',
        )
        if ok:
            self.add_child_sns(num_sns)

    def add_child_sns(self, num_sns: int) -> None:
        if self.child_part_counter == 0:
            QMessageBox.warning(
                self,
                'No Child Parts',
                'Add at least one child part before adding child SNs.',
            )
            return
        # Remove existing SN buttons
        for i in range(self.child_parts_layout.count()):
            item = self.child_parts_layout.itemAt(i)
            child_layout = item.layout() if item is not None else None
            if not child_layout:
                continue
            for j in reversed(range(child_layout.count())):
                widget = child_layout.itemAt(j).widget()
                if isinstance(widget, QPushButton) and widget.text() == 'SNs':
                    widget.deleteLater()
        if num_sns > self.child_part_counter:
            QMessageBox.information(
                self,
                'Child Part Limit',
                'Only existing child part rows can track SNs. Creating slots '
                'for the available rows.',
            )
        max_rows = min(max(num_sns, 0), self.child_part_counter)
        self.child_sn_list = [None] * self.child_part_counter
        for i in range(max_rows):
            self.child_sn_list[i] = []
            item = self.child_parts_layout.itemAt(i)
            child_layout = item.layout() if item is not None else None
            if not child_layout:
                continue
            sn_button = QPushButton('SNs', self)
            sn_button.clicked.connect(
                lambda _, idx=i: self.open_child_sn_inline(idx)
            )
            child_layout.addWidget(sn_button)
        self._refresh_inline_editors()

    def open_child_sn_inline(self, index: int) -> None:
        try:
            if not hasattr(self, 'inline_child_sn_tabs'):
                return
            self._ensure_side_panel_visible()
            editor = self.inline_child_sn_tabs
            container = editor.container
            if not container.isVisible():
                container.setVisible(True)
                editor._update_toggle_icon()
            editor.rebuild_tabs()
            label = f'ChildSN{index + 1}'
            for tab_index in range(editor.tabs.count()):
                if editor.tabs.tabText(tab_index) == label:
                    editor.tabs.setCurrentIndex(tab_index)
                    tab_editor = editor._tab_editors.get(index)
                    if tab_editor is not None:
                        tab_editor.setFocus()
                    break
        except Exception:
            pass

    def load_template_parts(self):
        """Load child part numbers and quantities from an Excel template (columns: Part#, QTY)."""
        from PyQt5.QtWidgets import QFileDialog
        import os
        try:
            import pandas as pd
        except ImportError:
            QMessageBox.warning(self, 'Missing Dependency', 'pandas is required to load templates.')
            return
        root_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        templates_dir = os.path.join(root_dir, 'Build Templates')
        file_path, _ = QFileDialog.getOpenFileName(self, 'Select Excel File', templates_dir, 'Excel Files (*.xlsx *.xls)')
        if not file_path:
            return
        try:
            df = pd.read_excel(file_path)
        except Exception as e:
            QMessageBox.warning(self, 'Error', f'Failed to read Excel file: {e}')
            return
        required_cols = ['Part#', 'QTY']
        if not all(col in df.columns for col in required_cols):
            QMessageBox.warning(self, 'Error', 'Excel file must have columns: Part#, QTY')
            return
        while self.child_part_counter > 0:
            self.remove_child_part()
        for _, row in df.iterrows():
            part = str(row['Part#']) if 'Part#' in row and not pd.isna(row['Part#']) else ''
            qty_val = row['QTY'] if 'QTY' in row else 1
            try:
                qty = int(qty_val) if not pd.isna(qty_val) else 1
            except Exception:
                qty = 1
            self.add_child_part()
            last_index = self.child_parts_layout.count() - 1
            if last_index >= 0:
                last_item = self.child_parts_layout.itemAt(last_index)
                if last_item:
                    lay = last_item.layout()
                    if lay and lay.itemAt(1) and lay.itemAt(3):
                        part_widget = lay.itemAt(1).widget()
                        qty_widget = lay.itemAt(3).widget()
                        if part_widget:
                            part_widget.setText(part)
                        if qty_widget:
                            qty_widget.setText(str(qty))
        self.status_label.setText(
            '<span style="color: green;">Template loaded successfully.</span>'
        )
        self._refresh_inline_editors()

    def toggle_part_number(self, state):
        visible = state == Qt.Checked
        self.master_part_label.setVisible(visible)
        self.master_part_textbox.setVisible(visible)
        self.master_sn_list_button.setVisible(visible)
        self._refresh_inline_editors()
        
        # Disconnect any existing text change validation
        try:
            self.master_part_textbox.textChanged.disconnect()
        except Exception:
            pass
            
        # Add text change validation for Master Part only when visible
        if visible:
            self.master_part_textbox.textChanged.connect(self._on_master_part_changed)

    def validate_master_part_text(self, text):
        """Validate master part text to ensure it doesn't start with forbidden prefixes"""
        if text and any(text.startswith(prefix) for prefix in ['C40-', 'L40-', 'RC40-', 'BTS40-']):
            self.status_label.setText('<span style="color: red;">Master part numbers cannot start with C40-, L40-, RC40-, or BTS40-</span>')
            self.master_part_textbox.setStyleSheet("color: red;")
            self.master_part_label.setStyleSheet("color: red;")
            return False
        else:
            self.master_part_textbox.setStyleSheet("")
            self.master_part_label.setStyleSheet("")
            if not text:
                self.status_label.clear()
            return True

    def add_child_part(self):
        self.child_part_counter += 1
        self.child_sn_list.append(None)
        child_part_layout = QHBoxLayout()
        child_part_label = QLabel(f'Child Part {self.child_part_counter}:', self)
        child_part_textbox = QLineEdit(self)
        # Add text change validation
        child_part_textbox.textChanged.connect(lambda text, tb=child_part_textbox: self._on_child_part_changed(text, tb))
        qty_label = QLabel('QTY:', self)
        qty_textbox = NumericLineEdit(self)
        qty_textbox.setFixedWidth(50)
        # Add quantity validation
        qty_textbox.textChanged.connect(lambda text, ql=qty_label: self._on_quantity_changed(text, ql))
        child_part_layout.addWidget(child_part_label)
        child_part_layout.addWidget(child_part_textbox)
        child_part_layout.addWidget(qty_label)
        child_part_layout.addWidget(qty_textbox)
        self.child_parts_layout.addLayout(child_part_layout)
        self._refresh_inline_editors()

    # --- Signal handler wrappers (return None) ---
    def _on_from_lpn_changed(self, text: str):
        self.validate_from_lpn(text)

    def _on_master_part_changed(self, text: str):
        self.validate_master_part_text(text)

    def _on_child_part_changed(self, text: str, textbox: QLineEdit):
        self.validate_child_part_text(text, textbox)

    def _on_quantity_changed(self, text: str, qty_label: QLabel):
        self.validate_quantity(text, qty_label)

    def validate_from_lpn(self, text):
        """Validate From LPN format and highlight if invalid"""
        text = text.strip()  # Strip whitespace from the text
        if text and not any(text.startswith(prefix) for prefix in ['C40-', 'L40-', 'RC40-', 'BTS40-']):
            self.status_label.setText('<span style="color: red;">From LPN must start with C40-, L40-, RC40-, or BTS40-</span>')
            self.from_lpn_textbox.setStyleSheet("color: red;")
            self.from_lpn_label.setStyleSheet("color: red;")
            return False
        else:
            self.from_lpn_textbox.setStyleSheet("")
            self.from_lpn_label.setStyleSheet("")
            self.status_label.clear()  # Clear the error message when valid
            return True

    def validate_child_part_text(self, text, textbox, qty_label=None):
        """Validate child part text to ensure it doesn't start with forbidden prefixes and check for duplicates"""
        # Check for forbidden prefixes
        if text and any(text.startswith(prefix) for prefix in ['C40-', 'L40-', 'RC40-', 'BTS40-']):
            self.status_label.setText('<span style="color: red;">Child part numbers cannot start with C40-, L40-, RC40-, or BTS40-</span>')
            textbox.setStyleSheet("color: red;")
            return False

        # Check for duplicates
        if text:
            for i in range(self.child_parts_layout.count()):
                child_part_layout = self.child_parts_layout.itemAt(i).layout()
                other_textbox = child_part_layout.itemAt(1).widget()
                if other_textbox != textbox and other_textbox.text().strip() == text.strip():
                    self.status_label.setText(f'<span style="color: red;">Duplicate child part number found: {text}</span>')
                    textbox.setStyleSheet("color: red;")
                    return False

        textbox.setStyleSheet("")
        if not text:
            self.status_label.clear()
        return True

    def validate_quantity(self, text, qty_label):
        """Validate quantity field and highlight label if empty"""
        if not text.strip():
            qty_label.setStyleSheet("color: red;")
            return False
        qty_label.setStyleSheet("")
        return True

    def remove_child_part(self):
        if self.child_part_counter > 0:
            self.child_sn_list.pop()
            item = self.child_parts_layout.takeAt(self.child_part_counter - 1)
            if item:
                layout = item.layout()
                if layout:
                    while layout.count():
                        child = layout.takeAt(0)
                        widget = child.widget() if child is not None else None
                        if widget:
                            widget.deleteLater()
                self.child_part_counter -= 1
        self._refresh_inline_editors()

    def enable_lpn_editing(self):
        self.lpn_changed = True  # Set flag to indicate LPN has been changed
        self.from_lpn_textbox.setReadOnly(False)
        self.from_lpn_textbox.setFocus()

    def append_uparrow(self):
        # Read all rows from the CSV
        rows = []
        with open(self.temp_csv_file.name, 'r', newline='') as file:
            reader = csv.reader(file)
            rows = list(reader)
        
        # Find the last UPARROW row and replace it with UPARROW2
        for i in range(len(rows)-1, -1, -1):
            if rows[i][1] == "UPARROW":
                rows[i][1] = "UPARROW2"
                rows[i][2] = "UPARROW2"
                break
        
        # Write all rows back to the CSV
        with open(self.temp_csv_file.name, 'w', newline='') as file:
            writer = csv.writer(file, delimiter=',')
            writer.writerows(rows)

    def validate_inputs(self):
        # Validate From LPN format
        from_lpn = self.from_lpn_textbox.text().strip()
        if from_lpn and not any(from_lpn.startswith(prefix) for prefix in ['C40-', 'L40-', 'RC40-', 'BTS40-']):
            self.status_label.setText('<span style="color: red;">From LPN must start with C40-, L40-, RC40-, or BTS40-</span>')
            return False

        # Check for duplicate child parts
        child_parts = []
        for i in range(self.child_parts_layout.count()):
            child_part_layout = self.child_parts_layout.itemAt(i).layout()
            part_number = child_part_layout.itemAt(1).widget().text().strip()
            if part_number:  # Only add non-empty part numbers
                child_parts.append(part_number)

        # Find duplicates
        seen = set()
        duplicates = []
        for part in child_parts:
            if part in seen:
                duplicates.append(part)
            else:
                seen.add(part)

        if duplicates:
            self.status_label.setText(f'<span style="color: red;">Duplicate child part numbers found: {", ".join(duplicates)}</span>')
            return False

        # Validate child parts
        for i in range(self.child_parts_layout.count()):
            child_part_layout = self.child_parts_layout.itemAt(i).layout()
            part_number = child_part_layout.itemAt(1).widget().text().strip()
            if part_number and any(part_number.startswith(prefix) for prefix in ['C40-', 'L40-', 'RC40-', 'BTS40-']):
                self.status_label.setText(f'<span style="color: red;">Child Part {i+1} cannot start with C40-, L40-, RC40-, or BTS40-</span>')
                return False

        # Validate child SN lists
        for i, sn_list in enumerate(self.child_sn_list):
            if sn_list:
                for sn in sn_list:
                    if any(sn.startswith(prefix) for prefix in ['C40-', 'L40-', 'RC40-', 'BTS40-']):
                        self.status_label.setText(f'<span style="color: red;">Child Part {i+1} SN list contains invalid SN starting with C40-, L40-, RC40-, or BTS40-</span>')
                        return False

        return True

    def on_next_build(self):
        try:
            # Check if number of C40s is entered
            if not self.question3_textbox.text().strip():
                self.status_label.setText('<span style="color: red;">Please enter the number of C40s to build.</span>')
                self.question3_textbox.setStyleSheet("color: red;")
                return
            else:
                self.question3_textbox.setStyleSheet("")
                
            num_builds = int(self.question3_textbox.text())
            
            # Check if From LPN is entered and validate
            if not self.from_lpn_textbox.text().strip():
                self.status_label.setText('<span style="color: red;">Please enter the From LPN.</span>')
                self.from_lpn_textbox.setStyleSheet("color: red;")
                self.from_lpn_label.setStyleSheet("color: red;")
                return
            elif not self.validate_from_lpn(self.from_lpn_textbox.text().strip()):
                return
                
            # Check if there is either a master part or child part
            has_master_part = self.question1_checkbox.isChecked() and self.master_part_textbox.text().strip()
            has_child_parts = self.child_parts_layout.count() > 0
            
            if not (has_master_part or has_child_parts):
                self.status_label.setText('<span style="color: red;">Add either a master or child part.</span>')
                return
                
            # Check if Master Part is entered when checkbox is checked
            if self.question1_checkbox.isChecked():
                if not self.master_part_textbox.text().strip():
                    self.status_label.setText('<span style="color: red;">Please enter the Master Part number.</span>')
                    self.master_part_textbox.setStyleSheet("color: red;")
                    self.master_part_label.setStyleSheet("color: red;")
                    return
                elif not self.validate_master_part_text(self.master_part_textbox.text().strip()):
                    return
            else:
                self.master_part_textbox.setStyleSheet("")
                self.master_part_label.setStyleSheet("")
                
            # Check C40 list count matches number of builds
            if len(self.c40_list) != num_builds:
                self.status_label.setText(f'<span style="color: red;">C40 List requires exactly {num_builds} entries. Current count: {len(self.c40_list)}</span>')
                return
                
            # Check Master SN list count matches number of builds when checkbox is checked
            if self.question1_checkbox.isChecked() and len(self.master_sn_list) != num_builds:
                self.status_label.setText(f'<span style="color: red;">Master SN List requires exactly {num_builds} entries. Current count: {len(self.master_sn_list)}</span>')
                return
            self._refresh_inline_editors()
                
            # Check each child part for required information and validate
            for i in range(self.child_parts_layout.count()):
                child_part_layout = self.child_parts_layout.itemAt(i).layout()
                part_number = child_part_layout.itemAt(1).widget().text().strip()
                quantity = child_part_layout.itemAt(3).widget().text().strip()
                qty_label = child_part_layout.itemAt(2).widget()
                
                # Check if part number is entered
                if not part_number:
                    self.status_label.setText(f'<span style="color: red;">Missing part number for Child Part {i+1}.</span>')
                    child_part_layout.itemAt(1).widget().setStyleSheet("color: red;")
                    return
                    
                # Check if quantity is entered
                if not quantity:
                    self.status_label.setText(f'<span style="color: red;">Missing quantity for Child Part {i+1}.</span>')
                    qty_label.setStyleSheet("color: red;")
                    return
                    
                # Check if quantity is a valid number
                try:
                    qty = int(quantity)
                except ValueError:
                    self.status_label.setText(f'<span style="color: red;">Invalid quantity for Child Part {i+1}. Please enter a number.</span>')
                    qty_label.setStyleSheet("color: red;")
                    return
                    
                # Check SN list count matches expected quantity
                if self.child_sn_list[i] is not None:
                    expected_sns_count = qty * num_builds
                    if len(self.child_sn_list[i]) != expected_sns_count:
                        self.status_label.setText(f'<span style="color: red;">Child Part {i+1} requires exactly {expected_sns_count} SNs. Current count: {len(self.child_sn_list[i])}</span>')
                        return

                # Validate child part text (including duplicate check)
                if not self.validate_child_part_text(part_number, child_part_layout.itemAt(1).widget()):
                    return

            # All checks passed, proceed with adding to CSV
            if self.lpn_changed:
                self.append_uparrow()
                self.lpn_changed = False

            # Clear any existing error messages
            self.status_label.clear()
            
            # Add to CSV and update status
            self.row_counter = CSV_Writer_Split.append_to_csv(self.temp_csv_file, self.row_counter, self.c40_list, self.master_sn_list, self.child_sn_list, self.from_lpn_textbox, self.master_part_textbox, self.question1_checkbox, self.child_parts_layout, num_builds)
            self.total_builds += num_builds
            
            # Set success message and ensure it's not overwritten
            success_message = f'<span style="color: green;">{num_builds} New builds added to CSV.</span>'
            self.status_label.setText(success_message)
            self.counter_label.setText('Total Builds: {}'.format(self.total_builds))
            
            # Make LPN read-only and show change button
            self.from_lpn_textbox.setReadOnly(True)
            self.show_change_button()
            
            # Clear all fields except LPN and status
            self.question1_checkbox.setChecked(False)
            self.master_part_textbox.clear()
            self.question3_textbox.clear()
            self.c40_list = []
            self.master_sn_list = []
            self.child_sn_list = []
            
            # Clear child parts
            while self.child_parts_layout.count():
                item = self.child_parts_layout.takeAt(0)
                if item.layout():
                    while item.layout().count():
                        widget = item.layout().takeAt(0).widget()
                        if widget:
                            widget.deleteLater()
            self.child_part_counter = 0
            
            # Hide master part fields
            self.master_part_label.hide()
            self.master_part_textbox.hide()
            self.master_sn_list_button.hide()
            self._refresh_inline_editors()

        except ValueError:
            self.status_label.setText('<span style="color: red;">Invalid number entered for C40 quantity.</span>')
        except Exception as e:
            self.status_label.setText(f'<span style="color: red;">An unexpected error occurred: {str(e)}</span>')

    def show_change_button(self):
        try:
            if hasattr(self, 'change_lpn_button'):
                self.change_lpn_button.setParent(None)
            self.change_lpn_button = QPushButton('Change', self)
            self.change_lpn_button.clicked.connect(self.enable_lpn_editing)
            self.from_lpn_layout.addWidget(self.change_lpn_button)
        except Exception as e:
            print(f"Error showing change button: {e}")

    def clear_layout(self, layout):
        try:
            while layout.count():
                child = layout.takeAt(0)
                if child.widget():
                    child.widget().deleteLater()
        except Exception as e:
            print(f"Error clearing layout: {e}")

    def clear_data_fields(self):
        # Clear all input fields
        self.question1_checkbox.setChecked(False)
        self.master_part_textbox.clear()
        self.question3_textbox.clear()
        self.from_lpn_textbox.clear()
        self.from_lpn_textbox.setReadOnly(False)
        
        # Clear all lists
        self.c40_list = []
        self.master_sn_list = []
        self.child_sn_list = []
        
        # Clear child parts
        while self.child_parts_layout.count():
            item = self.child_parts_layout.takeAt(0)
            if item.layout():
                while item.layout().count():
                    widget = item.layout().takeAt(0).widget()
                    if widget:
                        widget.deleteLater()
        self.child_part_counter = 0
        self._refresh_inline_editors()
        
        # Hide master part fields
        self.master_part_label.hide()
        self.master_part_textbox.hide()
        self.master_sn_list_button.hide()
        
        # Clear status message
        self.status_label.clear()
        
        # Reset counter
        self.total_builds = 0
        self.counter_label.setText('Total Builds: 0')
        
        # Remove change button if it exists
        if hasattr(self, 'change_lpn_button'):
            self.change_lpn_button.setParent(None)

    def open_paste_multiple_dialog(self):
        dialog = QDialog(self)
        dialog.setWindowTitle("Paste Multiple Child Parts")
        dialog.setModal(True)

        layout = QVBoxLayout(dialog)

        # Create tab widget with Part Numbers and Quantities tabs
        tab_widget = QTabWidget()

        # Part Numbers tab
        part_tab = QWidget()
        part_layout = QVBoxLayout(part_tab)
        part_layout.addWidget(QLabel("Paste child part numbers below (one per line):"))
        self.part_text = QTextEdit()
        self.part_text.setPlaceholderText("Paste child part numbers here...")
        part_layout.addWidget(self.part_text)
        tab_widget.addTab(part_tab, "Part Numbers")

        # Quantities tab
        qty_tab = QWidget()
        qty_layout = QVBoxLayout(qty_tab)
        qty_layout.addWidget(QLabel("Paste quantities below (one per line, numbers only):"))
        self.qty_text = QTextEdit()
        self.qty_text.setPlaceholderText("Paste quantities here...")
        qty_layout.addWidget(self.qty_text)
        tab_widget.addTab(qty_tab, "Quantities")

        layout.addWidget(tab_widget)

        # Dialog buttons
        btns = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        layout.addWidget(btns)

        btns.accepted.connect(lambda: self._apply_tabbed_paste(dialog))
        btns.rejected.connect(dialog.reject)

        dialog.exec_()

    def _apply_tabbed_paste(self, dialog: QDialog):
        """Apply data from both tabs to the child parts list."""
        # Gather lines
        part_lines = [line.strip() for line in self.part_text.toPlainText().splitlines() if line.strip()]
        qty_lines = [line.strip() for line in self.qty_text.toPlainText().splitlines() if line.strip()]

        if not part_lines and not qty_lines:
            QMessageBox.warning(self, "Warning", "No data pasted!")
            return

        # Validate part prefixes
        invalid_parts = [p for p in part_lines if any(p.startswith(prefix) for prefix in ['C40-', 'L40-', 'RC40-', 'BTS40-'])]
        if invalid_parts:
            QMessageBox.warning(self, "Warning", f"The following parts are invalid (cannot start with C40-, L40-, RC40-, or BTS40-):\n\n{', '.join(invalid_parts)}")
            return

        # Check for duplicates within pasted parts
        seen = set()
        duplicates = []
        for p in part_lines:
            if p in seen:
                duplicates.append(p)
            else:
                seen.add(p)
        if duplicates:
            QMessageBox.warning(self, "Warning", f"Duplicate child part numbers found in pasted text: {', '.join(sorted(set(duplicates)))}")
            return

        # Check duplicates against existing parts
        existing_parts = []
        for i in range(self.child_parts_layout.count()):
            layout_item = self.child_parts_layout.itemAt(i)
            if layout_item is None:
                continue
            row_layout = layout_item.layout()
            if row_layout is None:
                continue
            part_item = row_layout.itemAt(1)
            if part_item is None:
                continue
            part_widget = part_item.widget()
            if part_widget is None:
                continue
            existing = part_widget.text().strip()
            if existing:
                existing_parts.append(existing)
        dup_against_existing = [p for p in part_lines if p in existing_parts]
        if dup_against_existing:
            QMessageBox.warning(self, "Warning", f"The following parts already exist in the list: {', '.join(sorted(set(dup_against_existing)))}")
            return

        # Add parts as new rows
        for part in part_lines:
            self.add_child_part()
            last_index = self.child_parts_layout.count() - 1
            if last_index >= 0:
                last_item = self.child_parts_layout.itemAt(last_index)
                if last_item is not None:
                    last_layout = last_item.layout()
                    if last_layout is not None:
                        part_item = last_layout.itemAt(1)
                        if part_item is not None:
                            part_widget = part_item.widget()
                            if part_widget is not None:
                                part_widget.setText(part)

        # Apply quantities (add rows if needed)
        for i, qty_text in enumerate(qty_lines):
            try:
                qty = int(qty_text)
                if qty < 0:
                    continue
            except ValueError:
                continue
            if i >= self.child_parts_layout.count():
                self.add_child_part()
            row_item = self.child_parts_layout.itemAt(i)
            if row_item is not None:
                row_layout = row_item.layout()
                if row_layout is not None:
                    qty_item = row_layout.itemAt(3)
                    if qty_item is not None:
                        qty_field = qty_item.widget()
                        if qty_field is not None:
                            qty_field.setText(str(qty))

        dialog.accept()
        
    def process_pasted_parts(self, pasted_text, dialog, text_edit):
        """Process the pasted text and add child parts"""
        text = pasted_text
        if not text.strip():
            QMessageBox.warning(self, "Warning", "No data pasted!")
            return
            
        # Split text into lines and remove empty lines
        parts = [line.strip() for line in text.split('\n') if line.strip()]
        
        if not parts:
            QMessageBox.warning(self, "Warning", "No valid parts found in pasted text!")
            return

        # Check for duplicates in pasted text
        seen = set()
        duplicates = []
        duplicate_indices = []  # Store indices of duplicate lines
        first_occurrences = set()  # Store the first occurrence of each part
        parts_with_duplicates = set()  # Store parts that have duplicates
        
        # First pass: identify duplicates and their first occurrences
        for i, part in enumerate(parts):
            if part in seen:
                duplicates.append(part)
                duplicate_indices.append(i)
                parts_with_duplicates.add(part)
            else:
                seen.add(part)
                first_occurrences.add(i)

        if duplicates:
            # Create formatted text with first occurrences in green (only if they have duplicates) and duplicates in red
            formatted_text = ""
            for i, part in enumerate(parts):
                if i in duplicate_indices:
                    formatted_text += f'<span style="color: red;">{part}</span><br>'
                elif i in first_occurrences and part in parts_with_duplicates:
                    formatted_text += f'<span style="color: green;">{part}</span><br>'
                else:
                    formatted_text += f'{part}<br>'
            
            text_edit.setHtml(formatted_text)
            QMessageBox.warning(self, "Warning", f"Duplicate child part numbers found in pasted text: {', '.join(duplicates)}")
            return

        # Validate parts before adding them
        invalid_parts = [part for part in parts if any(part.startswith(prefix) for prefix in ['C40-', 'L40-', 'RC40-', 'BTS40-'])]
        if invalid_parts:
            # Create formatted text with invalid parts in red
            formatted_text = ""
            for part in parts:
                if any(part.startswith(prefix) for prefix in ['C40-', 'L40-', 'RC40-', 'BTS40-']):
                    formatted_text += f'<span style="color: red;">{part}</span><br>'
                else:
                    formatted_text += f'{part}<br>'
            
            text_edit.setHtml(formatted_text)
            QMessageBox.warning(self, "Warning", f"The following parts are invalid (cannot start with C40-, L40-, RC40-, or BTS40-):\n\n{', '.join(invalid_parts)}")
            return
            
        # Check for duplicates with existing parts
        existing_parts = []
        for i in range(self.child_parts_layout.count()):
            layout_item = self.child_parts_layout.itemAt(i)
            if layout_item is None:
                continue
            child_part_layout = layout_item.layout()
            if child_part_layout is None:
                continue
            part_item = child_part_layout.itemAt(1)
            if part_item is None:
                continue
            widget = part_item.widget()
            if widget is None:
                continue
            part_number = widget.text().strip()
            if part_number:
                existing_parts.append(part_number)

        duplicates = []
        duplicate_indices = []
        for i, part in enumerate(parts):
            if part in existing_parts:
                duplicates.append(part)
                duplicate_indices.append(i)

        if duplicates:
            # Create formatted text with duplicates in red
            formatted_text = ""
            for i, part in enumerate(parts):
                if i in duplicate_indices:
                    formatted_text += f'<span style="color: red;">{part}</span><br>'
                else:
                    formatted_text += f'{part}<br>'
            
            text_edit.setHtml(formatted_text)
            QMessageBox.warning(self, "Warning", f"The following parts already exist in the list: {', '.join(duplicates)}")
            return
            
        # If we get here, the input is valid
        # Add new child parts without clearing existing ones
        for part in parts:
            self.add_child_part()
            last_index = self.child_parts_layout.count() - 1
            layout_item = self.child_parts_layout.itemAt(last_index)
            if layout_item is None:
                continue
            last_layout = layout_item.layout()
            if last_layout is None:
                continue
            part_item = last_layout.itemAt(1)
            if part_item is None:
                continue
            widget = part_item.widget()
            if widget is None:
                continue
            widget.setText(part)
            
        dialog.accept()

    def closeEvent(self, event):
        """Handle the window close event."""
        event.accept()
