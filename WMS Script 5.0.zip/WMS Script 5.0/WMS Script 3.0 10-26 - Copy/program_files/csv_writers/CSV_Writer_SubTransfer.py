import csv

def write_csv_headers(file):
    """Write CSV headers to file"""
    headers = ["NUMBER", "PROMPT", "KEY", "DATA"]
    writer = csv.writer(file)
    writer.writerow(headers)

def append_to_csv(temp_file, row_counter, child_parts, locators):
    """
    Append transfer data to the temporary CSV file.
    Returns the updated row counter.
    """
    with open(temp_file.name, 'a', newline='') as f:
        writer = csv.writer(f)
        # If no locators provided, write rows with blank To Loc to support PROMPTLOC flow
        loc_iter = locators if locators else [""]
        # For each locator, write all child parts to that locator
        for locator in loc_iter:
            for part in child_parts:
                # LPN row
                writer.writerow([row_counter, "LPN          >", "BLANK", ""])
                row_counter += 1
                # From Loc row
                writer.writerow([row_counter, "From Loc     >", "From Loc:", part.get('from_loc', "")])
                row_counter += 1
                # Item row
                writer.writerow([row_counter, "Item         >", "Item:", part.get('part_number', "")])
                row_counter += 1
                # Qty row
                writer.writerow([row_counter, "Qty          :", "QTY:", str(part.get('quantity', ""))])
                row_counter += 1
                # To Loc row (use current locator)
                writer.writerow([row_counter, "To Loc       >", "To Loc:", locator])
                row_counter += 1
                # <Done> row
                writer.writerow([row_counter, "<Done>", "BLANK", ""])
                row_counter += 1
    
    return row_counter

def append_finished(temp_file, row_counter):
    """Add FINISHED row to the CSV"""
    with open(temp_file.name, 'a', newline='') as f:
        writer = csv.writer(f)
        writer.writerow([str(row_counter), "FINISHED", "", ""])

def read_csv(temp_file):
    """Read CSV data from temporary file"""
    with open(temp_file.name, 'r') as f:
        reader = csv.reader(f)
        return list(reader)

def save_csv(file_path, temp_file, headers=None, add_promptloc=False, screen_indicator="SUBTRANSFER", **_):
    """Save the temporary CSV to the specified file path"""
    try:
        headers = headers or ["NUMBER", "PROMPT", "KEY", "DATA"]

        with open(temp_file.name, 'r', newline='') as temp_file_r:
            reader = csv.reader(temp_file_r)
            rows = list(reader)

        if not rows:
            rows = [headers]
        else:
            first_row = rows[0] if rows[0] else []
            normalized_first = [col.strip() for col in first_row]
            if normalized_first != headers:
                rows.insert(0, headers)

        last_row_number = 0
        for existing_row in rows[1:]:
            if not existing_row:
                continue
            try:
                last_row_number = max(last_row_number, int(existing_row[0]))
            except (ValueError, IndexError):
                continue

        rows.append([str(last_row_number + 1), screen_indicator, "", ""])
        # Optionally add PROMPTLOC row if requested
        if add_promptloc:
            rows.append(["", "PROMPTLOC", "", ""])
        with open(file_path, 'w', newline='') as file:
            writer = csv.writer(file)
            writer.writerows(rows)
        return True
    except Exception as e:
        print('Error saving sub-transfer CSV:', e)
        return False

def append_lpn_transfer_to_csv(temp_file, row_counter, lpns, to_locations, to_cost_group=""):
    """
    Append LPN transfer data to the temporary CSV file.
    lpns: list of LPN numbers
    to_locations: list of destination locations (same length as lpns for 1:1 mapping, or single location repeated for all)
    to_cost_group: cost group (optional, for Cost Group transfers)
    Returns the updated row counter.
    """
    with open(temp_file.name, 'a', newline='') as f:
        writer = csv.writer(f)
        
        # Handle both single location (repeated) and multiple locations (1:1 mapping)
        for i, lpn in enumerate(lpns):
            # Get the location for this LPN
            if isinstance(to_locations, list) and len(to_locations) == len(lpns):
                # 1:1 mapping case
                to_location = to_locations[i]
            elif isinstance(to_locations, list) and len(to_locations) == 1:
                # Single location for all LPNs case
                to_location = to_locations[0]
            else:
                # Fallback: treat as single location string
                to_location = to_locations
            
            # LPN row
            writer.writerow([row_counter, "LPN          >", "LPN", lpn])
            row_counter += 1
            # To Loc row
            writer.writerow([row_counter, "To Loc       >", "LOC", to_location])
            row_counter += 1
            # To CG row (only for Cost Group transfers)
            if to_cost_group:
                writer.writerow([row_counter, "To CG        >", "CG", to_cost_group])
                row_counter += 1
            # <Done> row
            writer.writerow([row_counter, "<Done>", "BLANK", ""])
            row_counter += 1
    
    return row_counter

def append_loose_parts_cg_to_csv(temp_file, row_counter, child_parts, locators, to_cost_group):
    """
    Append loose parts cost group transfer data to the temporary CSV file.
    child_parts: list of dicts with keys 'part_number', 'quantity', 'from_loc'
    locators: list of destination locations
    to_cost_group: cost group for all transfers
    Returns the updated row counter.
    """
    with open(temp_file.name, 'a', newline='') as f:
        writer = csv.writer(f)
        
        # If no locators provided, write rows with blank To Loc to support PROMPTLOC flow
        loc_iter = locators if locators else [""]
        
        # For each locator, write all child parts to that locator
        for locator in loc_iter:
            for part in child_parts:
                # LPN row
                writer.writerow([row_counter, "LPN          >", "BLANK", ""])
                row_counter += 1
                # From Loc row
                writer.writerow([row_counter, "From Loc     >", "From Loc:", part.get('from_loc', "")])
                row_counter += 1
                # Item row
                writer.writerow([row_counter, "Item         >", "Item:", part.get('part_number', "")])
                row_counter += 1
                # Qty row
                writer.writerow([row_counter, "Qty          :", "QTY:", str(part.get('quantity', ""))])
                row_counter += 1
                # To Loc row (use current locator)
                writer.writerow([row_counter, "To Loc       >", "To Loc:", locator])
                row_counter += 1
                # To CG row
                writer.writerow([row_counter, "To CG        >", "CG", to_cost_group])
                row_counter += 1
                # <Done> row
                writer.writerow([row_counter, "<Done>", "BLANK", ""])
                row_counter += 1
    
    return row_counter

def write_subtransfer_csv(file_path, child_parts, locators):
    """
    Write a subtransfer CSV file based on child_parts and locators.
    child_parts: list of dicts with keys 'part_number', 'quantity', 'from_loc', 'item' (if present)
    locators: list of location strings (e.g., ZL4ASSET01, ZL4ASSET02, ...)
    """
    headers = ["NUMBER", "PROMPT", "KEY", "DATA"]
    rows = []
    number = 1
    # For each locator, write all child parts to that locator
    for locator in locators:
        for part in child_parts:
            # LPN row
            rows.append([number, "LPN          >", "BLANK", ""])
            number += 1
            # From Loc row
            rows.append([number, "From Loc     >", "From Loc:", part.get('from_loc', "")])
            number += 1
            # Item row
            rows.append([number, "Item         >", "Item:", part.get('part_number', "")])
            number += 1
            # Qty row
            rows.append([number, "Qty          :", "QTY:", str(part.get('quantity', ""))])
            number += 1
            # To Loc row (use current locator)
            rows.append([number, "To Loc       >", "To Loc:", locator])
            number += 1
            # <Done> row
            rows.append([number, "<Done>", "BLANK", ""])
            number += 1
    with open(file_path, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(headers)
        writer.writerows(rows)
        # Add FINISHED and SUBTRANSFER rows
        writer.writerow([str(len(rows)+1), "FINISHED", "", ""])
        writer.writerow([str(len(rows)+2), "SUBTRANSFER", "", ""])
