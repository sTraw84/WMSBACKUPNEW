import csv
from typing import Iterable, Sequence


def write_csv_headers(file_obj) -> None:
    """Write the standard header row used by WMS repack CSVs."""
    writer = csv.writer(file_obj)
    writer.writerow(["NUMBER", "PROMPT", "KEY", "DATA"])


def _clean_lpns(values: Iterable[str]) -> list[str]:
    return [value.strip() for value in values if value and value.strip()]


def append_to_csv(temp_file, row_counter: int, from_lpns: Sequence[str], to_lpn: str) -> int:
    """Append quick repack rows for each source LPN."""
    cleaned_from = _clean_lpns(from_lpns)
    destination = to_lpn.strip()

    if not cleaned_from:
        raise ValueError("No From LPNs provided.")
    if not destination:
        raise ValueError("Destination LPN is required.")

    with open(temp_file.name, 'a', newline='') as handle:
        writer = csv.writer(handle)
        for source in cleaned_from:
            writer.writerow([row_counter, "From LPN  :", "LPN", source])
            row_counter += 1
            writer.writerow([row_counter, "To LPN    :", "LPN2", destination])
            row_counter += 1
            writer.writerow([row_counter, "Locator   :", "BLANK", ""])
            row_counter += 1
            writer.writerow([row_counter, "Item      :", "BLANK", ""])
            row_counter += 1
            writer.writerow([row_counter, "<Done>", "BLANK", ""])
            row_counter += 1
    return row_counter


def append_finished(temp_file, row_counter: int) -> None:
    with open(temp_file.name, 'a', newline='') as handle:
        writer = csv.writer(handle)
        writer.writerow([row_counter, "FINISHED", "", ""])


def read_csv(temp_file) -> list[list[str]]:
    with open(temp_file.name, 'r', newline='') as handle:
        reader = csv.reader(handle)
        return [row for row in reader]


def save_csv(file_path: str, temp_file, csv_headers=None, screen_indicator: str = "REPACK", **_ignored) -> bool:
    try:
        headers = csv_headers or ["NUMBER", "PROMPT", "KEY", "DATA"]

        with open(temp_file.name, 'r', newline='') as source:
            reader = csv.reader(source)
            rows = list(reader)

        if not rows:
            rows = [headers]
        else:
            first = rows[0] if rows[0] else []
            normalized = [cell.strip() for cell in first]
            if normalized != headers:
                rows.insert(0, headers)

        last_number = 0
        for row in rows[1:]:
            if not row:
                continue
            try:
                last_number = max(last_number, int(row[0]))
            except (ValueError, IndexError):
                continue

        rows.append([str(last_number + 1), screen_indicator, "", ""])

        with open(file_path, 'w', newline='') as target:
            writer = csv.writer(target)
            writer.writerows(rows)
        return True
    except Exception as exc:
        print("Error saving quick LPN repack CSV:", exc)
        return False
