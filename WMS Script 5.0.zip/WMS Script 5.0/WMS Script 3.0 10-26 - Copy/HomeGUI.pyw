import sys
from PyQt5.QtWidgets import QApplication
from PyQt5.QtGui import QIcon
import qdarkstyle

# Import the relocated HomeGUI from package-safe program_files
from program_files.guis.HomeGUI import HomeGUI

if __name__ == "__main__":
    app = QApplication(sys.argv)
    app.setStyleSheet(qdarkstyle.load_stylesheet_pyqt5())
    app.setWindowIcon(QIcon('bolt.ico'))
    ex = HomeGUI()
    ex.show()
    ret = app.exec_()
    sys.exit(ret)
