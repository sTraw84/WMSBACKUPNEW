# GUI Creator User Guide

## Overview

The GUI Creator is a powerful feature that allows you to create custom automation workflows for WMS tasks without needing to program new GUI components. You can design forms, define how data flows into CSV files, and generate working automation tools that integrate seamlessly with your existing WMS Script system.

## Key Concepts

### 1. Field Types
The GUI Creator supports several types of input fields:

- **Text**: Simple text input (locations, part numbers, etc.)
- **Number**: Numeric input with validation
- **Checkbox**: True/false selections
- **Dropdown**: Select from predefined options
- **List**: Multiple items that can be added/edited
- **Table**: Structured rows with named columns, usually for repeat sets

### 2. Data Sources
When defining CSV output, you can specify where data comes from:

- **field:[fieldname]**: Use value from a form field
- **literal:[value]**: Use a fixed text value
- **blank**: Use empty string

### 3. Conditions
You can make CSV rows conditional using the format:
- **field:[fieldname]=[value]**: Only include row if field equals value

## How to Use

### Step 1: Basic Information
1. Open GUI Creator from the main menu
2. Enter a name for your automation (e.g., "Location Transfer")
3. Add a description explaining what it does

### Step 2: Design Form Fields
1. Go to the "Form Fields" tab
2. Click "Add Field" to create each input
3. For each field, specify:
   - **Field Type**: What kind of input (text, number, etc.)
   - **Label**: What users see (e.g., "From Location:")
   - **Key**: Variable name (e.g., "from_location")
   - **Default Value**: Starting value (optional)
   - **Required**: Whether field must be filled
   - **Tooltip**: Help text for users
   - **Visible When**: Optional condition (e.g., `field:need_master=true`) that controls when the field is shown
   - **Required When**: Optional condition that makes the field required only when the expression evaluates true

### Conditional Form Fields
- Conditions use the same syntax as CSV rows: `field:other_key=value`
- Comparisons are case-insensitive and operate on the text version of the source field
- If no condition is provided the field stays visible/required based on the checkboxes
- Hidden fields automatically become optional while hidden and retain their values if re-shown

### Step 3: Define CSV Output
1. Go to the "CSV Template" tab
2. Click "Add Row" for each line in your CSV
3. For each row, specify:
   - **Prompt**: What appears in WMS (e.g., "From Location:")
   - **Key**: Variable name for SecureCRT script
   - **Data Source**: Where to get the value
   - **Condition**: When to include this row (optional)

### Step 4: Test and Save
1. Click "Generate & Test" to see how your GUI works
2. Use "Save" to store your definition for later use
3. Use "Load" to open previously created GUIs

## Examples

### Simple Transfer
```
Fields:
- From Location (text, required)
- To Location (text, required)  
- Part Number (text, required)
- Quantity (number, required)

CSV Output:
Row 1: "From Location:" -> field:from_location
Row 2: "To Location  :" -> field:to_location
Row 3: "Part Number  :" -> field:part_number
Row 4: "Quantity     :" -> field:quantity
Row 5: "<Done>" -> blank
```

### Conditional Example
```
Fields:
- Create Label (checkbox)
- Label Text (text)

CSV Output:
Row 1: "Create Label :" -> literal:Y (condition: field:create_label=true)
Row 2: "Label Text   :" -> field:label_text (condition: field:create_label=true)
```

## Best Practices

### Field Design
- Use clear, descriptive labels
- Set sensible default values
- Mark essential fields as required
- Add helpful tooltips

### CSV Structure
- Follow your WMS prompt patterns exactly
- Use consistent variable naming
- Test with simple examples first
- Document complex workflows

### File Organization
- Save GUI definitions with descriptive names
- Keep examples for reference
- Create templates for common patterns

## Technical Details

### File Format
GUI definitions are saved as JSON files with the extension `.gui.json`. These contain:
- Basic information (name, description)
- Field definitions (type, label, validation)
- CSV row templates (prompts, data sources, conditions)

### Integration
Generated GUIs:
- Follow the same CSV format as existing tools
- Work with your existing SecureCRT script
- Support the same NUMBER, PROMPT, KEY, DATA structure
- Include FINISHED marker automatically

### Data Flow
1. User fills out the generated form
2. System validates required fields
3. CSV rows are generated based on templates
4. Data substitution occurs from form values
5. Final CSV is saved for SecureCRT script use

## Troubleshooting

### Common Issues
1. **Field validation errors**: Check required fields are filled
2. **CSV generation fails**: Verify data source references match field keys
3. **Conditional rows not appearing**: Check condition syntax matches exactly

### Getting Help
- Use the "Preview CSV" button to test output before saving
- Check example files in the CSV Files/Examples folder
- Refer to existing GUI patterns (RepackGUI, TransferGUI, etc.)

## Advanced Features

### Multiple Builds
For automation that needs to repeat patterns:
- Use number fields for "Number of Builds"
- Reference the count in your CSV template
- Consider using lists for varying data per build

### Dynamic Content
- Use dropdown fields populated from files
- Implement list fields for variable-length data
- Create conditional workflows based on checkboxes
- Tie visibility/required state of related fields to driver inputs using the new *Visible When* and *Required When* expressions

This system gives you the flexibility to automate virtually any WMS workflow while maintaining the same reliability and integration as the pre-built tools.