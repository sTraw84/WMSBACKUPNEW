import os
from pathlib import Path
from PyQt5.QtWidgets import QVBoxLayout, QPushButton, QLabel, QFileDialog, QTextEdit, QInputDialog, QLineEdit, QMessageBox
from PyQt5.QtCore import Qt
from .BaseGUI import BaseDialog

# Keep heavy imports local to methods to avoid import-time failures when dependencies
# are not installed in the environment used for static checks.

CSV_SMARTSHEET_DIR_NAME = 'CSV Smartsheet Files'
TRACKER_DIR_NAME = 'MES Tracker Files'


class SSLinkCreator(BaseDialog):
    def set_api_token(self):
        """Prompt user for an API token and store it (optionally in keyring)."""
        token, ok = QInputDialog.getText(self, 'Set API Token', 'Enter Smartsheet API Token:', QLineEdit.Normal, '')
        if not ok or not token:
            return
        self.api_token = token.strip()
        # Offer to save to keyring
        try:
            save_q = QMessageBox.question(self, 'Save token?', 'Save this API token securely to the OS keyring for future runs?', QMessageBox.Yes | QMessageBox.No, QMessageBox.Yes)
            if save_q == QMessageBox.Yes:
                import keyring
                keyring.set_password(SSLinkCreator._KEYRING_SERVICE, SSLinkCreator._KEYRING_USERNAME, self.api_token)
                self.log_append('🔐 API token saved securely to OS keyring.')
        except Exception as e:
            self.log_append(f'⚠️ Failed to save token to keyring: {e}')
        # Update UI state
        self.update_token_status()
        if self.input_path:
            self.run_btn.setEnabled(True)
    """GUI for creating Smartsheet links for SO Numbers.

    This is a lightweight GUI wrapper around the existing smartsheet_excel_matcher
    functionality. Heavy libraries (pandas, smartsheet, openpyxl) are imported
    inside the handler methods so the module can be imported in environments
    that don't have those packages installed.
    """

    API_TOKEN = None
    SHEET_ID = "9xwh2FwVR9WMgxpJ483m3wVxvCx6PJf8HqHc2q81"
    # keyring service identifiers
    _KEYRING_SERVICE = "WWT_WMS_SSLinkCreator"
    _KEYRING_USERNAME = "ss_api_token"

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle('SS Link Creator')
        self.setWindowFlags(self.windowFlags() | Qt.Window)
        self.repo_root = Path(__file__).resolve().parents[2]
        self.tracker_dir = self.repo_root / TRACKER_DIR_NAME
        self.csv_dir = self.repo_root / CSV_SMARTSHEET_DIR_NAME
        self.input_path = None
        self.output_df = None
        # Prefer MES Tracker Files/Results, fallback to CSV Smartsheet Files/Results
        self.results_dir = (self.tracker_dir / 'Results') if self.tracker_dir.exists() else (self.csv_dir / 'Results')
        # Prefer environment variable SS_API_TOKEN if present
        env_token = os.environ.get('SS_API_TOKEN')
        if env_token:
            self.api_token = env_token
        else:
            # try to load from keyring
            try:
                import keyring
                kr = keyring.get_password(SSLinkCreator._KEYRING_SERVICE, SSLinkCreator._KEYRING_USERNAME)
                if kr:
                    self.api_token = kr
                else:
                    self.api_token = None
            except Exception:
                # if keyring is unavailable, treat as no token
                self.api_token = None

        layout = QVBoxLayout(self)
        title = QLabel('Smartsheet SO Link Creator')
        title.setAlignment(Qt.AlignCenter)
        layout.addWidget(title)

        # Token status indicator (green/red)
        self.token_status = QLabel('')
        self.token_status.setAlignment(Qt.AlignCenter)
        layout.addWidget(self.token_status)
        self.update_token_status()

        self.select_btn = QPushButton('Select Excel File (from MES Tracker Files)')
        self.select_btn.clicked.connect(self.select_file)
        layout.addWidget(self.select_btn)

        # Button to let user change API token at runtime
        self.token_btn = QPushButton('Set API Token')
        self.token_btn.clicked.connect(self.set_api_token)
        layout.addWidget(self.token_btn)

        self.run_btn = QPushButton('Run Check')
        self.run_btn.clicked.connect(self.run_check)
        # Only enable run button if a token and a file are available
        self.run_btn.setEnabled(bool(self.api_token and self.input_path))
        layout.addWidget(self.run_btn)

        self.save_btn = QPushButton('Save Results')
        self.save_btn.clicked.connect(self.save_results)
        self.save_btn.setEnabled(False)
        layout.addWidget(self.save_btn)

        self.log = QTextEdit()
        self.log.setReadOnly(True)
        layout.addWidget(self.log)

    def log_append(self, msg: str):
        self.log.append(msg)

    def select_file(self):
        # Default to MES Tracker Files if present, else legacy CSV Smartsheet Files, else repo root
        if self.tracker_dir.exists():
            start_dir = str(self.tracker_dir)
        elif self.csv_dir.exists():
            start_dir = str(self.csv_dir)
        else:
            start_dir = str(self.repo_root)
        path, _ = QFileDialog.getOpenFileName(self, 'Open Excel File', start_dir, 'Excel Files (*.xlsx *.xls)')
        if not path:
            return
        self.input_path = path
        self.log_append(f'📂 Selected: {path}')
        # enable run button only if API token is present
        if self.api_token:
            self.run_btn.setEnabled(True)
            self.update_token_status()
        else:
            self.log_append('⚠️ No API token configured — please set via environment variable SS_API_TOKEN or use Set API Token to store one securely.')
            self.update_token_status()

    def normalize_so(self, value):
        try:
            return str(int(float(value)))
        except Exception:
            return str(value).strip() if value is not None else ""

    def extract_work_order_link(self, work_order_val):
        if work_order_val is None:
            return ""
        import re
        match = re.search(r"(\d+)", str(work_order_val))
        if match:
            return f"https://configit.apps.wwt.com/work-order/{match.group(1)}"
        return ""

    def run_check(self):
        if not self.input_path:
            return
        if not self.api_token:
            self.log_append('❌ No API token available. Set it via SS_API_TOKEN env var or use Set API Token.')
            return
        # local imports
        try:
            import pandas as pd
        except Exception as e:
            self.log_append(f'❌ pandas is required: {e}')
            return

        try:
            import smartsheet
        except Exception as e:
            self.log_append(f'❌ smartsheet SDK is required: {e}')
            return

        try:
            df = pd.read_excel(self.input_path, header=0)
        except Exception as e:
            self.log_append(f'❌ Failed to read Excel: {e}')
            return

        expected_cols = {"WO#", "SO#", "Program(SS)"}
        if not expected_cols.issubset(df.columns):
            self.log_append('❌ Excel file must have "WO#", "SO#", and "Program(SS)" columns.')
            return

        self.log_append('📂 Excel loaded successfully.')

        ss = smartsheet.Smartsheet(self.api_token)
        try:
            sheet = ss.Sheets.get_sheet(self.SHEET_ID)
        except Exception as e:
            self.log_append(f'❌ Error accessing Smartsheet: {e}')
            return

        # find SO Number column id
        so_col_id = None
        for col in sheet.columns:
            if col.title.strip().lower() == 'so number':
                so_col_id = col.id
                break

        if not so_col_id:
            self.log_append("❌ Could not find 'SO Number' column in Smartsheet.")
            return

        lookup = {}
        for row in sheet.rows:
            for cell in row.cells:
                if cell.column_id == so_col_id and cell.value is not None:
                    key = self.normalize_so(cell.value)
                    lookup[key] = row.id

        self.log_append('\n📋 First 10 SO Numbers from Smartsheet:')
        for i, (k, v) in enumerate(lookup.items()):
            if i >= 10:
                break
            self.log_append(f'  Smartsheet SO: {repr(k)} (row.id={v})')

        # Compute links per row without altering the DataFrame
        self._links_by_row = []  # list of dicts: {'so_link': str, 'prog_link': str}
        for _, row in df.iterrows():
            wo_val = row.get('WO#')
            so_val = row.get('SO#')
            # SO# hyperlink → ConfigIT work order (derived from WO#)
            so_link = self.extract_work_order_link(wo_val)
            # Program(SS) hyperlink → Smartsheet row if SO# is found
            so_key = self.normalize_so(so_val)
            if so_key in lookup:
                row_id = lookup[so_key]
                prog_link = f"https://app.smartsheet.com/sheets/{self.SHEET_ID}?rowId={row_id}"
            else:
                prog_link = ""
            self._links_by_row.append({'so_link': so_link, 'prog_link': prog_link})

        # Preserve all columns for output
        self.output_df = df.copy()
        self.save_btn.setEnabled(True)
        self.log_append('✅ Results ready to save')

    def save_results(self):
        if self.output_df is None:
            return
        # Ensure Results folder exists in preferred location
        try:
            # Recompute preferred results dir in case folders were created during runtime
            self.results_dir = (self.tracker_dir / 'Results') if self.tracker_dir.exists() else (self.csv_dir / 'Results')
            self.results_dir.mkdir(parents=True, exist_ok=True)
        except Exception:
            # fallback to csv_dir or repo root
            pass

        if self.results_dir.exists():
            default_name = (Path(self.input_path).stem + '_results.xlsx') if self.input_path else 'ss_link_results.xlsx'
            initial_path = str(self.results_dir / default_name)
        else:
            # Fallback: Tracker dir, CSV Smartsheet dir, then repo root
            if self.tracker_dir.exists():
                initial_path = str(self.tracker_dir)
            elif self.csv_dir.exists():
                initial_path = str(self.csv_dir)
            else:
                initial_path = str(self.repo_root)

        out_path, _ = QFileDialog.getSaveFileName(self, 'Save Excel File', initial_path, 'Excel Files (*.xlsx)')
        if not out_path:
            return

        if not out_path.lower().endswith('.xlsx'):
            out_path += '.xlsx'

        # Use openpyxl to load the original workbook to preserve existing hyperlinks/formatting
        try:
            from openpyxl import load_workbook
            from openpyxl.styles import Font
        except Exception as e:
            self.log_append(f'❌ openpyxl is required for saving: {e}')
            return

        try:
            # Load the original input workbook so we don't lose existing hyperlinks/styles
            wb = load_workbook(self.input_path)
            ws = wb.active
            # Identify target columns by header names in row 1
            headers = [c.value for c in next(ws.iter_rows(min_row=1, max_row=1))]
            so_col_idx = (headers.index('SO#') + 1) if 'SO#' in headers else None
            prog_col_idx = (headers.index('Program(SS)') + 1) if 'Program(SS)' in headers else None
            # Apply hyperlinks for rows we computed during run_check
            if (so_col_idx or prog_col_idx) and hasattr(self, '_links_by_row'):
                max_rows = min(ws.max_row - 1, len(self._links_by_row))
                for offset in range(max_rows):
                    row_idx = offset + 2
                    link_info = self._links_by_row[offset]
                    if so_col_idx and link_info.get('so_link'):
                        cell_so = ws.cell(row=row_idx, column=so_col_idx)
                        # Only add hyperlink; keep existing value/formatting
                        cell_so.hyperlink = link_info['so_link']
                        cell_so.font = Font(color='0000FF', underline='single')
                    if prog_col_idx and link_info.get('prog_link'):
                        cell_prog = ws.cell(row=row_idx, column=prog_col_idx)
                        cell_prog.hyperlink = link_info['prog_link']
                        cell_prog.font = Font(color='0000FF', underline='single')
            # Save to the user-selected output path
            wb.save(out_path)
            self.log_append(f'✅ Excel saved with hyperlinks → {out_path}')
        except Exception as e:
            self.log_append(f'❌ Failed to save results: {e}')

    def update_token_status(self):
        # Show green when token available, red when not
        if getattr(self, 'api_token', None):
            self.token_status.setText('● API token set')
            self.token_status.setStyleSheet('color: white; background-color: #138000; padding: 4px; border-radius: 4px;')
        else:
            self.token_status.setText('● API token not set')
            self.token_status.setStyleSheet('color: white; background-color: #C00000; padding: 4px; border-radius: 4px;')
