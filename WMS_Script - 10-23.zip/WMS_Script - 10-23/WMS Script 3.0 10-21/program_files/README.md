Project layout

This repository was reorganized so the root contains only the launcher, the WMS script, CSV data, program files package, and backups.

Top-level layout

- CSV Files/         # CSV data files used by the app (kept as-is)
- Program Files/     # Archive folder + helper (contains Program Files/Other)
- program_files/     # Active Python package used by the launcher (guis, csv_writers, CSV_Loader)
- __pycache__/       # Python bytecode cache
- HomeGUI.pyw        # Launcher: starts the PyQt application using `program_files.guis.HomeGUI`
- WMS_Script_1.5.2.py

Backups

Original flat modules were archived to `Program Files/Other/`. If you need to restore a file to the root or to the package, use the copies there as the source.

How to run

1) Create a Python environment with the required packages (see `requirements.txt`).

2) From the project root run (PowerShell):

```powershell
python .\HomeGUI.pyw
```

or use the convenience script:

```powershell
./run_launcher.ps1
```

Developer notes

- The active code imports from the package `program_files` (e.g. `program_files.guis.HomeGUI`).
- If you prefer to use the old flat layout, either restore files from `Program Files/Other/` or change imports accordingly. The package approach is more robust for packaging and IDE support.

If you want, I can:
- Add a small test harness to exercise CSV writers (non-interactive).
- Convert the archived copies to import from `program_files` so the `Program Files/` tree can be used as the active codebase.
- Remove backups once you're satisfied.

Token storage / Keyring
-----------------------
This project supports secure storage of the Smartsheet API token using the OS keyring via `keyring`. See `dev-tools/KEYRING_README.md` for setup, usage, and recommendations. The SS Link Creator UI also provides a "Set API Token" button and will offer to save the token to the OS keyring for future runs.

MES Extractor quick reference
-----------------------------
The launcher exposes the MES Extractor from the Home screen. Below is a quick guide to the controls you see on the main window.

- **Filter File** combo: lists JSON payloads in `program_files/guis/json files`. The selected file is posted to the MES API and controls which work orders are returned. Use **Refresh** after dropping in a new JSON.
- **Layout** combo: lists layout JSONs in `program_files/guis/json files/layouts`. Each layout dictates which columns appear in the export, how values are transformed, and which columns should receive hyperlinks. **Refresh** re-scans the folder, and **Edit Layout...** opens the layout editor.
- **Paste Cookie String** textbox: paste the value of the `Cookie` request header captured from the MES site (DevTools > Network > Headers). The extractor copies this string into the outgoing request session.
- **Export My MES Orders to Excel**: runs the extraction, applies the selected layout (unless base report mode is checked), and writes an `.xlsx` to the path you choose.
- **Run base report with all columns**: bypasses the layout system and writes every column returned by MES. Use this if you need a raw dump for troubleshooting.
- **Autorun Smartsheets Extractor**: when checked, the finished workbook is post-processed to add ConfigIT order links and Smartsheet row links. Requires a Smartsheet API token to be available (environment variable or OS keyring entry).
- Log panel: displays status messages, HTTP errors, and post-processing notes. Useful for diagnosing missing columns or invalid cookies.

Layout editor guide
-------------------
Open **Edit Layout...** to tailor the export column set. The dialog edits the underlying JSON layout directly.

- **Columns list**: shows every column in the layout in export order. Use **Add**, **Remove**, **Up**, and **Down** to manage the list.
- **Header**: text that will become the Excel column name.
- **Source Field**: optional MES field name to pull from. Leave empty if you want to use a default value or a hyperlink display-only column.
- **Default Value**: optional fallback text when no source field is provided or a row is blank.
- **Transform**: applies a predefined conversion.
	- `raw`: pass the data through unchanged.
	- `clean_program`: strips the common prefixes and whitespace from `serviceTemplateDesc` values (used for Program(SS)).
	- `clean_location`: normalizes frequently noisy lab location strings.
	- `date`: parses the source as a date and formats it as `MM/DD/YYYY`.
	- `blank`: ignores the source and fills the default value (helpful for technician or notes columns).
	- `hyperlink`: reserves the column for hyperlink metadata; populate the link fields below and provide a `Source Field` for the display text if desired.
- **Link ID Field** and **Link URL Template**: only enabled for `hyperlink` transforms. `id_source` should match a column in the raw MES data (for example `jobHeaderId`). `url_template` can include `{value}`, which will be replaced by the ID for each row.
- **SS Link / MES Link / Configit Link** checkboxes: mark at most one option per column. The extractor uses these flags after export to convert the column into a hyperlink:
	- **SS Link**: builds Smartsheet row URLs for each SO number.
	- **MES Link**: builds ConfigIT/MES work-order links using the document number.
	- **Configit Link**: also uses the document number but targets the ConfigIT site.
- **Rules** list: lets you define conditional overrides (IF/THEN pairs) that run after all columns are built. Choose source/destination columns and the text to compare/assign.
- **Save** writes back to the current layout file. **Save As...** prompts for a new layout name and creates a fresh JSON in the layouts folder.

Example column definitions
--------------------------
- Program column pulling from MES:
	- Header: `Program(SS)`
	- Source Field: `serviceTemplateDesc`
	- Transform: `clean_program`
	- SS Link: checked (the extractor will add Smartsheet links for each SO).
- Static technician column:
	- Header: `Tech`
	- Transform: `blank`
	- Default Value: `Unassigned`
- MES work-order hyperlink column:
	- Header: `WO#`
	- Source Field: `documentNumber`
	- Transform: `raw`
	- Link ID Field: `jobHeaderId`
	- Link URL Template: `https://mes.apps.wwt.com/orders/{value}`
	- MES Link: checked to ensure autorun also creates the ConfigIT hyperlink if requested.
