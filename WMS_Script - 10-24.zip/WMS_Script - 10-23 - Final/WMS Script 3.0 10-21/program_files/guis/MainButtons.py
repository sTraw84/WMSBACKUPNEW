from PyQt5.QtWidgets import (QHBoxLayout, QPushButton, QMessageBox, QFileDialog,
                           QTableWidget, QTableWidgetItem, QDialog, QVBoxLayout)
import csv
import tempfile
import inspect
from ..utils.file_paths import get_default_save_path_for_csv_writer

class MainButtons:
    def __init__(self, parent):
        self.parent = parent
        self.layout = QHBoxLayout()
        self.init_buttons()

    def init_buttons(self):
        self.add_button = QPushButton('Add to CSV')
        self.load_button = QPushButton('Load CSV')
        self.save_button = QPushButton('Save CSV')
        self.preview_button = QPushButton('Preview CSV')
        self.clear_button = QPushButton('Clear Inputs')
        self.new_button = QPushButton('New CSV')
        self.add_button.clicked.connect(self.parent.on_next_build)
        self.load_button.clicked.connect(self.load_csv)
        self.save_button.clicked.connect(self.on_finish_csv)
        self.preview_button.clicked.connect(self.preview_csv)
        self.clear_button.clicked.connect(self.parent.clear_data_fields)
        self.new_button.clicked.connect(self.start_over)
        self.layout.addWidget(self.add_button)
        self.layout.addWidget(self.load_button)
        self.layout.addWidget(self.save_button)
        self.layout.addWidget(self.preview_button)
        self.layout.addWidget(self.clear_button)
        self.layout.addWidget(self.new_button)

    def get_layout(self):
        return self.layout

    def load_csv(self):
        try:
            options = QFileDialog.Options()
            options |= QFileDialog.DontUseNativeDialog
            file_name, _ = QFileDialog.getOpenFileName(self.parent, "Load CSV", get_default_save_path_for_csv_writer(""), "CSV Files (*.csv);;All Files (*)", options=options)
            if file_name:
                self.parent.temp_csv_file = tempfile.NamedTemporaryFile(delete=False, mode='w', newline='')
                with open(file_name, 'r') as input_file, open(self.parent.temp_csv_file.name, 'w', newline='') as output_file:
                    reader = csv.reader(input_file)
                    writer = csv.writer(output_file, delimiter=',')
                    for row in reader:
                        writer.writerow(row)
                with open(self.parent.temp_csv_file.name, 'r') as file:
                    self.parent.row_counter = sum(1 for _ in csv.reader(file))
                self.parent.clear_data_fields()
                QMessageBox.information(self.parent, "Success", "CSV file loaded successfully.")
                if hasattr(self.parent, "on_csv_loaded"):
                    self.parent.on_csv_loaded()
        except Exception as e:
            QMessageBox.critical(self.parent, "Error", f"Failed to load CSV file: {str(e)}")

    def preview_csv(self):
        try:
            csv_data = self.parent.csv_writer.read_csv(self.parent.temp_csv_file)
            dialog = QDialog(self.parent)
            dialog.setWindowTitle('Preview CSV')
            dialog.setFixedSize(600, 400)
            layout = QVBoxLayout(dialog)
            table = QTableWidget(dialog)
            table.setRowCount(len(csv_data))
            table.setColumnCount(3)
            table.setHorizontalHeaderLabels(["PROMPT", "KEY", "DATA"])
            for row_idx, row_data in enumerate(csv_data):
                for col_idx, col_data in enumerate(row_data[1:4]):
                    table.setItem(row_idx, col_idx, QTableWidgetItem(col_data))
            layout.addWidget(table)
            ok_button = QPushButton('OK', dialog)
            ok_button.clicked.connect(dialog.accept)
            layout.addWidget(ok_button)
            dialog.exec_()
        except Exception as e:
            QMessageBox.critical(self.parent, "Error", f"Failed to preview CSV: {str(e)}")

    def start_over(self):
        try:
            reply = QMessageBox.question(self.parent, 'Warning', 'This will delete all unsaved CSV data and will start over. Do you want to proceed?',
                                         QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
            if reply == QMessageBox.Yes:
                self.parent.clear_data_fields()
                self.parent.temp_csv_file = tempfile.NamedTemporaryFile(delete=False, mode='w', newline='')
                self.parent.csv_writer.write_csv_headers(self.parent.temp_csv_file)
                self.parent.row_counter = 1
                self.parent.total_builds = 0
                if hasattr(self.parent, 'counter_label'):
                    self.parent.counter_label.setText('# of C40s to Consolidate: 0')
                if hasattr(self.parent, "on_csv_reset"):
                    self.parent.on_csv_reset()
        except Exception as e:
            QMessageBox.critical(self.parent, "Error", f"Failed to start over: {str(e)}")

    def on_finish_csv(self):
        try:
            with open(self.parent.temp_csv_file.name, 'r') as file:
                csv_data = list(csv.reader(file))
                if len(csv_data) <= 1:
                    QMessageBox.warning(self.parent, "CSV is Empty", "CSV is currently blank. Fill out the information and add it via 'Add to CSV' and then 'Save As'.")
                    return
            if len(csv_data) > 1 and csv_data[-1][1].strip() == "UPARROW":
                csv_data.pop()
                with open(self.parent.temp_csv_file.name, 'w', newline='') as rewrite_file:
                    csv_writer = csv.writer(rewrite_file)
                    for row in csv_data:
                        csv_writer.writerow(row)
                self.parent.row_counter -= 1
            self.parent.csv_writer.append_finished(self.parent.temp_csv_file, self.parent.row_counter)
            self.parent.row_counter += 1
            options = QFileDialog.Options()
            options |= QFileDialog.DontUseNativeDialog
            file_name, _ = QFileDialog.getSaveFileName(self.parent, "Save CSV As", get_default_save_path_for_csv_writer(""), "CSV (MS-DOS) (*.csv);;All Files (*)", options=options)
            if file_name:
                if not file_name.endswith('.csv'):
                    file_name += '.csv'
                screen_indicator = getattr(self.parent, "screen_indicator", "SUBTRANSFER")
                if screen_indicator == "SUBTRANSFER" and hasattr(self.parent, "first_transfer_type") and self.parent.first_transfer_type:
                    screen_indicator = (
                        "CGTRANSFER"
                        if self.parent.first_transfer_type == "cost_group"
                        else "SUBTRANSFER"
                    )
                save_signature = inspect.signature(self.parent.csv_writer.save_csv)
                save_kwargs = {}

                if hasattr(self.parent, "csv_headers"):
                    if "csv_headers" in save_signature.parameters:
                        save_kwargs["csv_headers"] = self.parent.csv_headers
                    elif "headers" in save_signature.parameters:
                        save_kwargs["headers"] = self.parent.csv_headers

                if "add_promptloc" in save_signature.parameters and hasattr(self.parent, "prompt_loc_checkbox"):
                    save_kwargs["add_promptloc"] = bool(self.parent.prompt_loc_checkbox.isChecked())

                if "screen_indicator" in save_signature.parameters:
                    save_kwargs["screen_indicator"] = screen_indicator

                self.parent.csv_writer.save_csv(
                    file_name,
                    self.parent.temp_csv_file,
                    **save_kwargs,
                )
                msg_box = QMessageBox()
                msg_box.setWindowTitle('CSV Saved')
                msg_box.setText('Would you like to start a new CSV or continue adding to the existing one?')
                new_csv_button = msg_box.addButton('New CSV', QMessageBox.ActionRole)
                continue_button = msg_box.addButton('Continue', QMessageBox.ActionRole)
                msg_box.exec_()
                if msg_box.clickedButton() == new_csv_button:
                    self.start_over()
                elif msg_box.clickedButton() == continue_button:
                    with open(self.parent.temp_csv_file.name, 'r') as file:
                        lines = file.readlines()
                    with open(self.parent.temp_csv_file.name, 'w') as file:
                        for line in lines:
                            if "FINISHED" not in line:
                                file.write(line)
        except Exception as e:
            QMessageBox.critical(self.parent, "Error", f"Failed to save CSV: {str(e)}")
