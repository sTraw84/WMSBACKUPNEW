import os
from PyQt5.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit,
                             QPushButton, QMessageBox, QFileDialog)
from PyQt5.QtGui import QFont
from PyQt5.QtCore import Qt
from .BaseGUI import BaseDialog
from .Dialogs import ListDialog
from program_files.csv_writers import CSV_Writer_Consolidate
from ..utils.file_paths import get_default_save_path_for_csv_writer

class WIPJobsGUI(BaseDialog):
    def __init__(self):
        super().__init__()
        self.initUI()

    def initUI(self):
        self.setWindowTitle('WIP Jobs')
        self.setFixedSize(480, 360)
        layout = QVBoxLayout(self)
        title = QLabel('WIP Jobs')
        title.setFont(QFont('Arial', 16, weight=QFont.Bold))
        title.setAlignment(Qt.AlignCenter)
        layout.addWidget(title)
        job_layout = QHBoxLayout()
        job_label = QLabel('Job#:', self)
        self.job_input = QLineEdit(self)
        job_layout.addWidget(job_label)
        job_layout.addWidget(self.job_input)
        layout.addLayout(job_layout)
        self.sn_btn = QPushButton('SN List', self)
        self.sn_btn.clicked.connect(self.open_sn_list)
        layout.addWidget(self.sn_btn)
        self.generate_btn = QPushButton('Generate WIP CSV', self)
        self.generate_btn.clicked.connect(self.generate_wip_csv)
        layout.addWidget(self.generate_btn)
        self.cancel_btn = QPushButton('Cancel', self)
        self.cancel_btn.clicked.connect(self.close)
        layout.addWidget(self.cancel_btn)

        self.sn_list = []

    def open_sn_list(self):
        dlg = ListDialog('SN List', existing_list=self.sn_list,
                         update_callback=lambda data: setattr(self, 'sn_list', [s.strip() for s in data if s.strip()]),
                         parent=self)
        dlg.exec_()

    def generate_wip_csv(self):
        job = self.job_input.text().strip()
        if not job:
            QMessageBox.warning(self, 'Missing Job#', 'Please enter a WIP Job# before generating CSV.')
            return
        if not self.sn_list:
            QMessageBox.warning(self, 'No SNs', 'Please provide at least one serial number via SN List.')
            return
        path, _ = QFileDialog.getSaveFileName(self, 'Save WIP CSV', get_default_save_path_for_csv_writer(f'WIP_{job}.csv'), 'CSV files (*.csv);;All files (*)')
        if not path:
            return
        if not path.lower().endswith('.csv'):
            path += '.csv'
        try:
            success = CSV_Writer_Consolidate.save_csv(path, job, self.sn_list)
            if success:
                QMessageBox.information(self, 'Saved', f'WIP CSV saved to:\n{path}')
                self.close()
            else:
                QMessageBox.critical(self, 'Error', 'Failed to save WIP CSV')
        except Exception as e:
            QMessageBox.critical(self, 'Exception', str(e))
