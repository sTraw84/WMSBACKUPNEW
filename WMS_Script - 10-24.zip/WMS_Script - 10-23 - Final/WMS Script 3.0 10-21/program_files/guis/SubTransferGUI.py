import sys
import tempfile
import csv
from PyQt5.QtWidgets import (
    QApplication,
    QVBoxLayout,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QLineEdit,
    QTextEdit,
    QScrollArea,
    QDialog,
    QDialogButtonBox,
    QSpacerItem,
    QSizePolicy,
    QTabWidget,
    QCheckBox,
    QWidget,
    QSplitter,
    QRadioButton,
    QButtonGroup,
    QGroupBox,
    QInputDialog,
)
from PyQt5.QtWidgets import QMessageBox
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QIntValidator
import qdarkstyle
from program_files.csv_writers import CSV_Writer_SubTransfer
from .MainButtons import MainButtons
from .BaseGUI import BaseWidget
from .InlineEditors import CollapsibleListEditor


class NumericLineEdit(QLineEdit):
    def __init__(self, parent=None):
        super(NumericLineEdit, self).__init__(parent)
        self.setValidator(QIntValidator(0, 999999, self))


class ChildPartRow(QWidget):
    def __init__(
        self,
        index: int,
        part_number: str = "",
        qty: int = 1,
        from_loc: str = "",
    ):
        super(ChildPartRow, self).__init__()
        self.index = index
        row = QHBoxLayout()
        row.setContentsMargins(0, 0, 0, 0)
        row.setSpacing(6)

        self.lbl = QLabel(f"Child Part {index}:")
        self.ed_part = QLineEdit(part_number)
        self.ed_part.setPlaceholderText("Part Number")

        self.lbl_qty = QLabel("QTY:")
        self.ed_qty = NumericLineEdit()
        self.ed_qty.setText(str(qty))
        self.ed_qty.setFixedWidth(60)

        self.lbl_loc = QLabel("From Loc:")
        self.ed_loc = QLineEdit(from_loc)
        self.ed_loc.setPlaceholderText("From Loc:")

        row.addWidget(self.lbl)
        row.addWidget(self.ed_part)
        row.addWidget(self.lbl_qty)
        row.addWidget(self.ed_qty)
        row.addWidget(self.lbl_loc)
        row.addWidget(self.ed_loc)
        self.setLayout(row)


class SubTransferGUI(BaseWidget):
    def __init__(self):
        super(SubTransferGUI, self).__init__()
        self.setWindowTitle("Sub Transfer Parts")
        self.resize(560, 640)
        self.setMinimumSize(540, 620)

        self._side_panel_width = 300
        self._min_left_width = 320
        self._min_side_panel_width = 220
        self._left_before_side_panel = None

        self.locators_list = []
        self.lpn_list = []
        self.locations_list = []
        self.mode = "subtransfer"
        self.csv_writer = CSV_Writer_SubTransfer
        self.temp_csv_file = tempfile.NamedTemporaryFile(
            delete=False, mode='w', newline=''
        )
        self.row_counter = 1
        self.csv_headers = ["NUMBER", "PROMPT", "KEY", "DATA"]
        self.csv_writer.write_csv_headers(self.temp_csv_file)
        self.temp_csv_file.close()
        self.first_transfer_type = None
        self.last_lpn_data = None
        self.last_transfer_mode = None

        self.status_label = QLabel("")
        self.main_layout = QVBoxLayout(self)

        # type: ignore[attr-defined] -- PyQt stubs miss QSplitter attr metadata
        self.splitter = QSplitter(Qt.Horizontal, self)
        self.splitter.setHandleWidth(1)
        self.main_layout.addWidget(self.splitter)

        self.left_container = QWidget(self.splitter)
        self.left_layout = QVBoxLayout(self.left_container)
        self.left_layout.setContentsMargins(0, 0, 0, 0)
        self.left_layout.setSpacing(5)

        top_bar = QWidget(self.left_container)
        self.top_layout = QHBoxLayout(top_bar)
        self.top_layout.setContentsMargins(0, 0, 0, 0)
        self.top_layout.addWidget(self.status_label)
        self.toggle_side_panel_button = QPushButton('Lists ▶', top_bar)
        self.toggle_side_panel_button.setToolTip(
            'Show or hide the lists panel'
        )
        self.toggle_side_panel_button.setMinimumWidth(
            self.toggle_side_panel_button.sizeHint().width()
        )
        self.toggle_side_panel_button.clicked.connect(self.toggle_side_panel)
        self.top_layout.addWidget(self.toggle_side_panel_button)
        self.left_layout.addWidget(top_bar)

        self.scroll = QScrollArea(self.left_container)
        self.scroll.setWidgetResizable(True)
        self.scroll_w = QWidget(self.scroll)
        self.scroll_v = QVBoxLayout(self.scroll_w)
        self.scroll.setWidget(self.scroll_w)
        self.left_layout.addWidget(self.scroll)

        warn = QLabel(
            "WARNING! Verify locations and quantities before transfer."
        )
        warn.setStyleSheet("color: yellow;")
        self.scroll_v.addWidget(warn)

        # Transfer Type Selection
        transfer_type_group = QGroupBox("Transfer Type")
        transfer_type_layout = QVBoxLayout()
        self.transfer_type_group = QButtonGroup()
        
        self.sub_inventory_radio = QRadioButton("Sub Inventory Transfer")
        self.cost_group_radio = QRadioButton("Cost Group Transfer")
        self.sub_inventory_radio.setChecked(True)  # Default selection
        
        self.transfer_type_group.addButton(self.sub_inventory_radio, 0)
        self.transfer_type_group.addButton(self.cost_group_radio, 1)
        
        transfer_type_layout.addWidget(self.sub_inventory_radio)
        transfer_type_layout.addWidget(self.cost_group_radio)
        transfer_type_group.setLayout(transfer_type_layout)
        self.scroll_v.addWidget(transfer_type_group)

        # Parts Type Selection
        parts_type_group = QGroupBox("Parts Type")
        parts_type_layout = QVBoxLayout()
        self.parts_type_group = QButtonGroup()
        
        self.loose_parts_radio = QRadioButton("Loose Parts")
        self.lpn_transfer_radio = QRadioButton("LPN Transfer")
        self.loose_parts_radio.setChecked(True)  # Default selection
        
        self.parts_type_group.addButton(self.loose_parts_radio, 0)
        self.parts_type_group.addButton(self.lpn_transfer_radio, 1)
        
        parts_type_layout.addWidget(self.loose_parts_radio)
        parts_type_layout.addWidget(self.lpn_transfer_radio)
        parts_type_group.setLayout(parts_type_layout)
        self.scroll_v.addWidget(parts_type_group)

        # Connect signals to update UI based on selection
        self.parts_type_group.buttonToggled.connect(self.on_parts_type_changed)
        self.transfer_type_group.buttonToggled.connect(
            self.on_transfer_type_changed
        )

        # LPN Transfer UI (initially hidden)
        self.lpn_container = QWidget()
        lpn_layout = QVBoxLayout(self.lpn_container)
        
        # LPN entry section
        lpn_entry_section = QWidget()
        lpn_entry_layout = QVBoxLayout(lpn_entry_section)
        lpn_entry_layout.setContentsMargins(0, 0, 0, 0)
        
        lpn_instructions = QLabel("Use the side panel editors to enter LPNs and locations")
        lpn_instructions.setStyleSheet("font-style: italic; color: gray;")
        lpn_entry_layout.addWidget(lpn_instructions)
        
        # Buttons row for LPN and location access
        buttons_row = QHBoxLayout()
        buttons_row.setContentsMargins(0, 0, 0, 0)
        buttons_row.setSpacing(6)
        
        self.btn_enter_lpns = QPushButton("Enter LPNs")
        self.btn_enter_lpns.setToolTip("Open the LPN List editor in the side panel")
        self.btn_enter_lpns.clicked.connect(self._open_lpn_editor)
        buttons_row.addWidget(self.btn_enter_lpns)
        
        self.btn_enter_locations = QPushButton("Enter Locations")
        self.btn_enter_locations.setToolTip("Open the Locations List editor in the side panel")
        self.btn_enter_locations.clicked.connect(self._open_locations_editor)
        buttons_row.addWidget(self.btn_enter_locations)
        
        # Initially hide the locations button (only show when multiple locations mode is active)
        self.btn_enter_locations.setVisible(False)
        
        buttons_row.addStretch()  # Push buttons to the left
        lpn_entry_layout.addLayout(buttons_row)
        
        lpn_layout.addWidget(lpn_entry_section)
        
        # Location mode selection
        location_mode_group = QGroupBox("Location Assignment Mode")
        location_mode_layout = QVBoxLayout(location_mode_group)
        
        self.location_mode_group = QButtonGroup()
        self.single_location_radio = QRadioButton("Single Location (All LPNs go to same location)")
        self.multiple_locations_radio = QRadioButton("Multiple Locations (1:1 mapping with LPNs)")
        self.single_location_radio.setChecked(True)  # Default to single location mode
        
        self.location_mode_group.addButton(self.single_location_radio, 0)
        self.location_mode_group.addButton(self.multiple_locations_radio, 1)
        self.location_mode_group.buttonClicked.connect(self._on_location_mode_changed)
        
        location_mode_layout.addWidget(self.single_location_radio)
        location_mode_layout.addWidget(self.multiple_locations_radio)
        lpn_layout.addWidget(location_mode_group)
        
        # Single location input (default mode)
        self.single_location_container = QWidget()
        to_loc_layout = QHBoxLayout(self.single_location_container)
        to_loc_layout.setContentsMargins(0, 0, 0, 0)
        to_loc_layout.addWidget(QLabel("To Location:"))
        self.to_location_edit = QLineEdit()
        self.to_location_edit.setPlaceholderText("Enter destination location")
        to_loc_layout.addWidget(self.to_location_edit)
        lpn_layout.addWidget(self.single_location_container)
        
        # Multiple locations input (initially hidden) - now just shows instruction
        self.multiple_locations_container = QWidget()
        multi_loc_layout = QVBoxLayout(self.multiple_locations_container)
        multi_loc_layout.setContentsMargins(0, 0, 0, 0)
        
        # Instructions for multiple locations
        multi_loc_label = QLabel("📍 1:1 Mapping Mode: Each LPN will go to its corresponding location")
        multi_loc_label.setStyleSheet("font-style: italic; color: #4CAF50; font-weight: bold;")
        multi_loc_layout.addWidget(multi_loc_label)
        
        lpn_layout.addWidget(self.multiple_locations_container)
        self.multiple_locations_container.setVisible(False)

        # Cost Group field (only for Cost Group Transfer - LPN mode)
        self.lpn_cost_group_container = QWidget()
        self.lpn_cost_group_layout = QHBoxLayout(self.lpn_cost_group_container)
        self.lpn_cost_group_layout.setContentsMargins(0, 0, 0, 0)
        self.lpn_cost_group_layout.addWidget(QLabel("To Cost Group:"))
        self.lpn_cost_group_edit = QLineEdit()
        self.lpn_cost_group_edit.setPlaceholderText("Enter cost group")
        self.lpn_cost_group_layout.addWidget(self.lpn_cost_group_edit)
        lpn_layout.addWidget(self.lpn_cost_group_container)
        self.lpn_cost_group_container.setVisible(False)
        
        self.lpn_container.setVisible(False)  # Initially hidden
        self.scroll_v.addWidget(self.lpn_container)

        # Loose Parts UI (initially visible)
        self.loose_parts_container = QWidget()
        loose_parts_layout = QVBoxLayout(self.loose_parts_container)
        
        header = QLabel("Child Parts")
        header.setStyleSheet("font-weight: bold; font-size: 14px;")
        loose_parts_layout.addWidget(header)

        self.prompt_loc_checkbox = QCheckBox("Prompt Locations in WMS")
        self.prompt_loc_checkbox.setToolTip(
            "Add PROMPTLOC to CSV for manual location entry in WMS"
        )
        self.prompt_loc_checkbox.stateChanged.connect(
            self.toggle_locators_button
        )
        loose_parts_layout.addWidget(self.prompt_loc_checkbox)

        btns = QHBoxLayout()
        self.btn_paste = QPushButton("Paste Multi.")
        self.btn_paste.setToolTip(
            "Open tabbed dialog to paste multiple part numbers, "
            "locations, and quantities"
        )
        self.btn_paste.clicked.connect(self.paste_multi_parts)

        self.btn_load = QPushButton("Load Template")
        self.btn_load.setToolTip("Load template from file or source")
        self.btn_load.clicked.connect(self.load_parts)

        self.btn_add = QPushButton("+")
        self.btn_add.setToolTip("Add child part row")
        self.btn_add.setFixedWidth(20)
        self.btn_add.clicked.connect(self.add_child_part)

        self.btn_remove = QPushButton("-")
        self.btn_remove.setToolTip("Remove last child part row")
        self.btn_remove.setFixedWidth(20)
        self.btn_remove.clicked.connect(self.remove_child_part)

        self.btn_locators = QPushButton("Locators")
        self.btn_locators.setToolTip("Manage locations for a specific prompt")
        self.btn_locators.clicked.connect(self._handle_locators_click)
        self.btn_locators.setEnabled(not self.prompt_loc_checkbox.isChecked())

        btns.addWidget(self.btn_paste)
        btns.addWidget(self.btn_load)
        btns.addWidget(self.btn_add)
        btns.addWidget(self.btn_remove)
        btns.addWidget(self.btn_locators)
        loose_parts_layout.addLayout(btns)

        self.child_rows_container = QVBoxLayout()
        loose_parts_layout.addLayout(self.child_rows_container)
        self.child_row_count = 0

        # Cost Group input for loose parts mode
        self.loose_cost_group_container = QWidget()
        loose_cost_group_layout = QHBoxLayout(self.loose_cost_group_container)
        loose_cost_group_layout.setContentsMargins(0, 0, 0, 0)
        loose_cost_group_layout.addWidget(QLabel("To Cost Group:"))
        self.loose_cost_group_edit = QLineEdit()
        self.loose_cost_group_edit.setPlaceholderText("Enter cost group")
        loose_cost_group_layout.addWidget(self.loose_cost_group_edit)
        loose_parts_layout.addWidget(self.loose_cost_group_container)
        self.loose_cost_group_container.setVisible(False)

        self.loose_parts_container.setLayout(loose_parts_layout)
        self.scroll_v.addWidget(self.loose_parts_container)

        self.scroll_v.addItem(
            QSpacerItem(20, 20, QSizePolicy.Minimum, QSizePolicy.Expanding)
        )

        self.main_buttons = MainButtons(self)
        self.switch_transfer_button = QPushButton("Switch Transfer Type")
        self.switch_transfer_button.setEnabled(False)
        self.switch_transfer_button.setToolTip("Available after adding CSV entries")
        self.switch_transfer_button.clicked.connect(self.on_switch_transfer_type)

        buttons_row = QHBoxLayout()
        buttons_row.addLayout(self.main_buttons.get_layout())
        buttons_row.addWidget(self.switch_transfer_button)
        self.scroll_v.addLayout(buttons_row)

        self.scroll_v.setSpacing(5)
        self.scroll_v.setContentsMargins(5, 5, 5, 5)

        self._update_cost_group_visibility()

        self.side_panel = QWidget(self.splitter)
        self.side_layout = QVBoxLayout(self.side_panel)
        self.side_layout.setContentsMargins(6, 6, 6, 6)
        self.side_layout.setSpacing(8)

        self.inline_locators_editor = CollapsibleListEditor(
            self,
            title='Locators',
            attr_name='locators_list',
            is_active=lambda: (
                not self.prompt_loc_checkbox.isChecked()
                and self.loose_parts_radio.isChecked()
            ),
        )
        self.side_layout.addWidget(self.inline_locators_editor)
        self.inline_locators_editor.apply_button.clicked.connect(
            self._refresh_inline_editors
        )
        
        # LPN List inline editor (for LPN transfers)
        self.inline_lpn_editor = CollapsibleListEditor(
            self,
            title='LPN List',
            attr_name='lpn_list',
            is_active=lambda: self.lpn_transfer_radio.isChecked(),
        )
        self.side_layout.addWidget(self.inline_lpn_editor)
        self.inline_lpn_editor.apply_button.clicked.connect(
            self._refresh_inline_editors
        )
        
        # Locations List inline editor (for multiple locations mode)
        self.inline_locations_editor = CollapsibleListEditor(
            self,
            title='Locations List',
            attr_name='locations_list',
            get_expected=lambda: len(self.lpn_list) if self.multiple_locations_radio.isChecked() else None,
            is_active=lambda: (
                self.lpn_transfer_radio.isChecked() 
                and self.multiple_locations_radio.isChecked()
            ),
        )
        self.side_layout.addWidget(self.inline_locations_editor)
        self.inline_locations_editor.apply_button.clicked.connect(
            self._refresh_inline_editors
        )
        self.side_layout.addStretch()

        self.splitter.addWidget(self.left_container)
        self.splitter.addWidget(self.side_panel)
        self.splitter.setStretchFactor(0, 1)
        self.splitter.setStretchFactor(1, 0)
        self.splitter.setSizes([1, 0])

        # Initialize UI state
        self.on_transfer_type_changed()
        self.on_parts_type_changed()

        self._refresh_inline_editors()
        self.on_csv_reset()
        self.finalize_initial_size(extra_width=120)
        self._update_side_panel_button()

    def on_transfer_type_changed(self):
        """Called when transfer type radio buttons change"""
        self._update_cost_group_visibility()

    def on_parts_type_changed(self):
        """Called when parts type radio buttons change"""
        is_lpn_transfer = self.lpn_transfer_radio.isChecked()
        
        # Show/hide appropriate containers
        self.lpn_container.setVisible(is_lpn_transfer)
        self.loose_parts_container.setVisible(not is_lpn_transfer)

        # Show/hide LPN-related buttons
        if hasattr(self, 'btn_enter_lpns'):
            self.btn_enter_lpns.setVisible(is_lpn_transfer)
        if hasattr(self, 'btn_enter_locations'):
            # Only show locations button if in LPN mode AND multiple locations mode
            is_multiple_locations = hasattr(self, 'multiple_locations_radio') and self.multiple_locations_radio.isChecked()
            self.btn_enter_locations.setVisible(is_lpn_transfer and is_multiple_locations)

        self._update_cost_group_visibility()
        
        # Update locators editor visibility
        self._refresh_inline_editors()

    def _on_location_mode_changed(self):
        """Called when location mode radio buttons change"""
        is_single_location = self.single_location_radio.isChecked()
        
        # Show/hide appropriate location input containers
        self.single_location_container.setVisible(is_single_location)
        self.multiple_locations_container.setVisible(not is_single_location)
        
        # Show/hide the "Enter Locations" button based on mode
        if hasattr(self, 'btn_enter_locations'):
            self.btn_enter_locations.setVisible(not is_single_location)
        
        # Refresh inline editors to update visibility
        self._refresh_inline_editors()
        
        # If switching to multiple locations mode, automatically open the locations editor
        if not is_single_location:
            self._open_locations_editor()

    def _open_lpn_editor(self):
        """Open the LPN list editor in the side panel"""
        try:
            if not hasattr(self, 'inline_lpn_editor'):
                return
            self._ensure_side_panel_visible()
            editor = self.inline_lpn_editor
            if not editor.container.isVisible():
                editor.container.setVisible(True)
                editor._update_toggle_icon()
            editor.programmatic_update()
            editor.editor.setFocus()
        except Exception:
            pass

    def _open_locations_editor(self):
        """Open the locations list editor in the side panel"""
        try:
            if not hasattr(self, 'inline_locations_editor'):
                return
            self._ensure_side_panel_visible()
            editor = self.inline_locations_editor
            if not editor.container.isVisible():
                editor.container.setVisible(True)
                editor._update_toggle_icon()
            editor.programmatic_update()
            editor.editor.setFocus()
        except Exception:
            pass

    def _handle_locators_click(self):
        # Only open dialog if button is enabled
        if self.btn_locators.isEnabled():
            self.show_locators_dialog()

    def toggle_locators_button(self, state):
        # Only toggle the Locators button availability
        if self.prompt_loc_checkbox.isChecked():
            self.btn_locators.setEnabled(False)
        else:
            self.btn_locators.setEnabled(True)
        self._refresh_inline_editors()

    def clear_inputs(self):
        # Clear all input fields and child part rows
        self.status_label.setText("")
        
        # Clear LPN inputs
        self.lpn_list = []
        self.locations_list = []
        self.to_location_edit.clear()
        self.lpn_cost_group_edit.clear()
        self.loose_cost_group_edit.clear()
        
        # Remove all child part rows
        while self.child_rows_container.count():
            item = self.child_rows_container.takeAt(0)
            if item is not None:
                widget = item.widget() if hasattr(item, 'widget') else None
                if widget:
                    widget.deleteLater()
        self.child_row_count = 0
        # Clear locators list
        self.locators_list = []
        self._refresh_inline_editors()

    def clear_data_fields(self):
        """Alias for clear_inputs - used by MainButtons"""
        self.clear_inputs()
        self._refresh_inline_editors()

    def _update_cost_group_visibility(self):
        """Keep the correct cost group inputs visible."""
        is_cost_group = self.cost_group_radio.isChecked()
        is_lpn_transfer = self.lpn_transfer_radio.isChecked()

        self.lpn_cost_group_container.setVisible(
            is_cost_group and is_lpn_transfer
        )
        self.loose_cost_group_container.setVisible(
            is_cost_group and not is_lpn_transfer
        )

    def _current_transfer_type(self):
        return "cost_group" if self.cost_group_radio.isChecked() else "sub_inventory"

    def _mark_entry_added(self):
        if self.first_transfer_type is None:
            self.first_transfer_type = self._current_transfer_type()
        self._update_switch_transfer_state()

    def _update_switch_transfer_state(self):
        can_switch = self.first_transfer_type is not None and self.row_counter > 1
        self.switch_transfer_button.setEnabled(can_switch)

    def _append_switch_transfer_rows(self, selection_value: str):
        with open(self.temp_csv_file.name, 'a', newline='') as temp_file:
            writer = csv.writer(temp_file)
            writer.writerow([self.row_counter, "F2KEY", "BLANK", ""])
            self.row_counter += 1
            writer.writerow([self.row_counter, "SEND", "Selection", "Y"])
            self.row_counter += 1
            writer.writerow([self.row_counter, "SEND", "Selection", selection_value])
            self.row_counter += 1

    def on_switch_transfer_type(self):
        if self.first_transfer_type is None:
            QMessageBox.warning(self, "Unavailable", "Add transfer data before switching transfer types.")
            return

        switching_to_cost_group = self.first_transfer_type == "sub_inventory"
        selection_value = "3" if switching_to_cost_group else "1"
        if switching_to_cost_group:
            message = (
                "This will add a function that switches you from SubTransfer to CG Transfer screens. "
                "Would you like to continue?"
            )
        else:
            message = (
                "This will add a function that switches you from CG Transfer to SubTransfer screens. "
                "Would you like to continue?"
            )

        reply = QMessageBox.question(
            self,
            "Switch Transfer Type",
            message,
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )
        if reply == QMessageBox.Yes:
            self._append_switch_transfer_rows(selection_value)
            if switching_to_cost_group:
                self.cost_group_radio.setChecked(True)
            else:
                self.sub_inventory_radio.setChecked(True)
            reuse_reply = QMessageBox.question(
                self,
                "Reuse LPNs",
                "Reuse previous LPNs entered?",
                QMessageBox.Yes | QMessageBox.No,
                QMessageBox.No,
            )

            if reuse_reply == QMessageBox.Yes:
                if not self.last_lpn_data or not self.last_lpn_data.get("lpns"):
                    QMessageBox.warning(
                        self,
                        "No LPNs",
                        "No previous LPN list is available to reuse. Add the next transfer manually.",
                    )
                    self.status_label.setText("Switch command added. Enter new transfer details manually.")
                    self.status_label.setStyleSheet("color: orange;")
                    self._update_switch_transfer_state()
                    return

                # Check if last transfer used single or multiple locations
                was_single_location = self.last_lpn_data.get("is_single_location", True)
                lpn_count = len(self.last_lpn_data.get("lpns", []))
                
                if was_single_location:
                    # Previous was single location, ask for new single location
                    default_location = self.last_lpn_data.get("to_locations", [""])[0] if isinstance(self.last_lpn_data.get("to_locations"), list) else self.last_lpn_data.get("to_location", "")
                    new_location, ok = QInputDialog.getText(
                        self,
                        "New Location",
                        "New Location (for all LPNs):",
                        QLineEdit.Normal,
                        default_location,
                    )
                    if not ok or not new_location.strip():
                        QMessageBox.warning(self, "Missing Location", "Location is required to reuse LPNs.")
                        self.status_label.setText("Switch command added. Enter new transfer details manually.")
                        self.status_label.setStyleSheet("color: orange;")
                        self._update_switch_transfer_state()
                        return
                    new_locations = [new_location.strip()] * lpn_count  # Same location for all LPNs
                else:
                    # Previous was multiple locations, ask for new multiple locations
                    old_locations = self.last_lpn_data.get("to_locations", [])
                    default_locations_text = "\n".join(old_locations) if old_locations else ""
                    
                    new_locations_text, ok = QInputDialog.getMultiLineText(
                        self,
                        "New Locations",
                        f"New Locations (one per line, {lpn_count} needed):",
                        default_locations_text,
                    )
                    if not ok or not new_locations_text.strip():
                        QMessageBox.warning(self, "Missing Locations", "Locations are required to reuse LPNs.")
                        self.status_label.setText("Switch command added. Enter new transfer details manually.")
                        self.status_label.setStyleSheet("color: orange;")
                        self._update_switch_transfer_state()
                        return
                    
                    new_locations = [loc.strip() for loc in new_locations_text.strip().splitlines() if loc.strip()]
                    if len(new_locations) != lpn_count:
                        QMessageBox.warning(
                            self, 
                            "Count Mismatch", 
                            f"Number of locations ({len(new_locations)}) must match number of LPNs ({lpn_count})."
                        )
                        self.status_label.setText("Switch command added. Enter new transfer details manually.")
                        self.status_label.setStyleSheet("color: orange;")
                        self._update_switch_transfer_state()
                        return
                new_cost_group = ""
                if switching_to_cost_group:
                    default_cg = self.last_lpn_data.get("to_cost_group", "")
                    cost_group_text, cg_ok = QInputDialog.getText(
                        self,
                        "Cost Group",
                        "Cost Group:",
                        QLineEdit.Normal,
                        default_cg,
                    )
                    if not cg_ok or not cost_group_text.strip():
                        QMessageBox.warning(
                            self,
                            "Missing Cost Group",
                            "Cost group is required when switching to a Cost Group transfer.",
                        )
                        self.status_label.setText("Switch command added. Enter new transfer details manually.")
                        self.status_label.setStyleSheet("color: orange;")
                        self._update_switch_transfer_state()
                        return
                    new_cost_group = cost_group_text.strip()

                try:
                    self.row_counter = self.csv_writer.append_lpn_transfer_to_csv(
                        self.temp_csv_file,
                        self.row_counter,
                        self.last_lpn_data["lpns"],
                        new_locations,
                        new_cost_group,
                    )
                    self.last_lpn_data = {
                        "lpns": list(self.last_lpn_data["lpns"]),
                        "to_locations": new_locations,
                        "to_cost_group": new_cost_group,
                        "is_single_location": was_single_location,
                    }
                    self.last_transfer_mode = "lpn"
                    self._mark_entry_added()
                    if switching_to_cost_group:
                        self.status_label.setText(
                            "Cost Group transfer added using previous LPNs."
                        )
                    else:
                        self.status_label.setText(
                            "Sub Inventory transfer added using previous LPNs."
                        )
                    self.status_label.setStyleSheet("color: blue;")
                except Exception as exc:
                    QMessageBox.critical(self, "Error", f"Failed to add reused LPN transfer: {exc}")
                    self.status_label.setText("Switch command added but transfer failed. Enter data manually.")
                    self.status_label.setStyleSheet("color: red;")
            else:
                self.status_label.setText("Switch command added. Enter new transfer details manually.")
                self.status_label.setStyleSheet("color: orange;")
            self._update_switch_transfer_state()

    def _infer_first_transfer_type_from_file(self):
        try:
            with open(self.temp_csv_file.name, 'r', newline='') as temp_file:
                rows = list(csv.reader(temp_file))
        except Exception:
            return None

        if len(rows) <= 1:
            return None

        for row in rows[1:]:
            if len(row) < 2:
                continue
            prompt = row[1].strip()
            if not prompt:
                continue
            if prompt == "To CG        >":
                return "cost_group"
            if prompt in ("<Done>", "FINISHED", "SUBTRANSFER"):
                break
        return "sub_inventory"

    def on_csv_loaded(self):
        self.first_transfer_type = self._infer_first_transfer_type_from_file()
        self.last_lpn_data = None
        self.last_transfer_mode = None
        self._update_switch_transfer_state()

    def on_csv_reset(self):
        self.first_transfer_type = None
        self.last_lpn_data = None
        self.last_transfer_mode = None
        self._update_switch_transfer_state()

    def on_next_build(self):
        """Called when 'Add to CSV' button is clicked"""
        if self.lpn_transfer_radio.isChecked():
            # LPN Transfer mode
            return self._handle_lpn_transfer()
        else:
            # Loose Parts mode  
            return self._handle_loose_parts_transfer()

    def _handle_lpn_transfer(self):
        """Handle LPN transfer (both Sub Inventory and Cost Group)"""
        # Get LPN list from inline editor
        if not self.lpn_list:
            QMessageBox.warning(self, "No Data", "Please enter LPN numbers using the LPN List editor in the side panel.")
            return

        lpns = self.lpn_list
        if not lpns:
            QMessageBox.warning(self, "No Data", "Please enter valid LPN numbers.")
            return

        # Get location(s) based on mode
        is_single_location = self.single_location_radio.isChecked()
        
        if is_single_location:
            # Single location mode
            to_location = self.to_location_edit.text().strip()
            if not to_location:
                QMessageBox.warning(self, "No Location", "Please enter a destination location.")
                return
            to_locations = [to_location] * len(lpns)  # Same location for all LPNs
        else:
            # Multiple locations mode (1:1 mapping)
            if not self.locations_list:
                QMessageBox.warning(self, "No Locations", "Please enter location numbers using the Locations List editor in the side panel.")
                return
                
            to_locations = self.locations_list
            if not to_locations:
                QMessageBox.warning(self, "No Locations", "Please enter valid location numbers.")
                return
                
            # Validate that number of locations matches number of LPNs
            if len(to_locations) != len(lpns):
                QMessageBox.warning(
                    self, 
                    "Count Mismatch", 
                    f"Number of locations ({len(to_locations)}) must match number of LPNs ({len(lpns)})."
                )
                return

        # Get cost group if needed
        to_cost_group = ""
        if self.cost_group_radio.isChecked():
            to_cost_group = self.lpn_cost_group_edit.text().strip()
            if not to_cost_group:
                QMessageBox.warning(self, "No Cost Group", "Please enter a cost group.")
                return

        try:
            # Add to CSV using updated LPN transfer method that supports multiple locations
            self.row_counter = self.csv_writer.append_lpn_transfer_to_csv(
                self.temp_csv_file, self.row_counter, lpns, to_locations, to_cost_group
            )
            self.last_lpn_data = {
                "lpns": list(lpns),
                "to_locations": to_locations,
                "to_cost_group": to_cost_group,
                "is_single_location": is_single_location,
            }
            self.last_transfer_mode = "lpn"
            self._mark_entry_added()
            # Clear the form after adding to CSV
            self.clear_inputs()
            # Update status
            self.status_label.setText("LPN transfer data added to CSV successfully!")
            self.status_label.setStyleSheet("color: green;")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to add to CSV: {e}")
            self.status_label.setText(f"Error: {str(e)}")

    def _handle_loose_parts_transfer(self):
        """Handle loose parts transfer (both Sub Inventory and Cost Group)"""
        # Gather child part data
        child_parts = []
        for i in range(self.child_rows_container.count()):
            item = self.child_rows_container.itemAt(i)
            if item is not None:
                row_widget = item.widget()
                if row_widget:
                    child_parts.append({
                        'part_number': row_widget.ed_part.text(),
                        'quantity': row_widget.ed_qty.text(),
                        'from_loc': row_widget.ed_loc.text()
                    })
        
        if not child_parts:
            QMessageBox.warning(self, "No Data", "No child parts to add.")
            return

        # If checkbox is checked, bypass all locators checks and warnings
        if self.prompt_loc_checkbox.isChecked():
            locators_to_use = []
        else:
            if not self.locators_list:
                QMessageBox.warning(self, "No Locators", "No locators set. Please add locators.")
                return
            locators_to_use = self.locators_list

        # Get cost group if needed
        to_cost_group = ""
        if self.cost_group_radio.isChecked():
            # For loose parts cost group transfer, we need a cost group
            to_cost_group = self.loose_cost_group_edit.text().strip()
            if not to_cost_group:
                QMessageBox.warning(self, "No Cost Group", "Please enter a cost group for Cost Group transfers.")
                return

        try:
            # Determine which append method to use
            if self.cost_group_radio.isChecked():
                # Cost Group Transfer - Loose Parts
                self.row_counter = self.csv_writer.append_loose_parts_cg_to_csv(
                    self.temp_csv_file, self.row_counter, child_parts, locators_to_use, to_cost_group
                )
            else:
                # Sub Inventory Transfer - Loose Parts (original functionality)
                self.row_counter = self.csv_writer.append_to_csv(
                    self.temp_csv_file, self.row_counter, child_parts, locators_to_use
                )
            self.last_transfer_mode = "loose"
            self.last_lpn_data = None
            self._mark_entry_added()
            
            # Clear the form after adding to CSV
            self.clear_inputs()
            # Update status
            self.status_label.setText("Transfer data added to CSV successfully!")
            self.status_label.setStyleSheet("color: green;")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to add to CSV: {e}")
            self.status_label.setText(f"Error: {str(e)}")

    def create_csv(self):
        """Legacy method - now handled by MainButtons"""
        pass

    def on_finish_csv(self):
        """Called when 'Save CSV' button is clicked - finalize and save the CSV"""
        from PyQt5.QtWidgets import QFileDialog, QMessageBox
        import os
        
        try:
            # Check if there's any data in the CSV
            with open(self.temp_csv_file.name, 'r') as file:
                lines = file.readlines()
                
            # If only headers exist, check if there's data in the form to auto-generate CSV
            if len(lines) <= 1:
                if self.lpn_transfer_radio.isChecked():
                    # Auto-generate from LPN form data
                    self._handle_lpn_transfer()
                else:
                    # Auto-generate from loose parts form data
                    self._handle_loose_parts_transfer()
                    
                # Re-read the file to check if data was added
                with open(self.temp_csv_file.name, 'r') as file:
                    lines = file.readlines()
                
                if len(lines) <= 1:
                    QMessageBox.warning(self, "No Data", "No data to save. Please fill out the form or add data via 'Add to CSV'.")
                    return

            # Add FINISHED row at the end
            self.csv_writer.append_finished(self.temp_csv_file, self.row_counter)
            self.row_counter += 1

            # Get save location
            root_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
            csv_dir = os.path.join(root_dir, "CSV Files")
            file_path, _ = QFileDialog.getSaveFileName(self, "Save Transfer CSV", csv_dir, "CSV Files (*.csv)")

            if file_path:
                # Pass checkbox state to CSV writer
                screen_indicator = "SUBTRANSFER"
                if self.first_transfer_type == "cost_group":
                    screen_indicator = "CGTRANSFER"
                self.csv_writer.save_csv(
                    file_path,
                    self.temp_csv_file,
                    self.csv_headers,
                    add_promptloc=self.prompt_loc_checkbox.isChecked(),
                    screen_indicator=screen_indicator,
                )
                QMessageBox.information(self, "Success", f"CSV saved to {file_path}")
                self.status_label.setText("CSV saved successfully!")
                self.status_label.setStyleSheet("color: green;")
            else:
                # User cancelled, remove the FINISHED row we just added
                with open(self.temp_csv_file.name, 'r') as file:
                    lines = file.readlines()
                with open(self.temp_csv_file.name, 'w') as file:
                    file.writelines(lines[:-1])  # Remove last line
                self.row_counter -= 1
                
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to save CSV: {e}")
            self.status_label.setText(f"Error: {str(e)}")
            self.status_label.setStyleSheet("color: red;")

    def add_child_part(self, part_number="", qty=1, from_loc=""):
        self.child_row_count += 1
        # Ensure part_number is always a string
        safe_part_number = str(part_number) if not isinstance(part_number, bool) else ""
        row = ChildPartRow(self.child_row_count, safe_part_number, qty, from_loc)
        self.child_rows_container.addWidget(row)

    def remove_child_part(self):
        if self.child_row_count > 0:
            item_index = self.child_rows_container.count() - 1
            if item_index >= 0:
                item = self.child_rows_container.takeAt(item_index)
                if item is not None:
                    w = item.widget()
                    if w is not None:
                        w.deleteLater()
                self.child_row_count -= 1

    def paste_multi_parts(self):
        dlg = QDialog(self)
        dlg.setWindowTitle("Paste Multiple Values")
        dlg.resize(500, 400)
        
        main_layout = QVBoxLayout(dlg)
        
        # Create tab widget
        tab_widget = QTabWidget()
        
        # Part Numbers Tab
        part_tab = QWidget()
        part_layout = QVBoxLayout(part_tab)
        part_layout.addWidget(QLabel("Paste part numbers, one per line:"))
        self.part_text = QTextEdit()
        part_layout.addWidget(self.part_text)
        tab_widget.addTab(part_tab, "Part Numbers")
        
        # From Locations Tab
        location_tab = QWidget()
        location_layout = QVBoxLayout(location_tab)
        location_layout.addWidget(QLabel("Paste from locations, one per line:"))
        self.location_text = QTextEdit()
        location_layout.addWidget(self.location_text)
        tab_widget.addTab(location_tab, "From Locations")
        
        # Quantities Tab
        qty_tab = QWidget()
        qty_layout = QVBoxLayout(qty_tab)
        qty_layout.addWidget(QLabel("Paste quantities, one per line (numbers only):"))
        self.qty_text = QTextEdit()
        qty_layout.addWidget(self.qty_text)
        tab_widget.addTab(qty_tab, "Quantities")
        
        main_layout.addWidget(tab_widget)
        
        # Add information label
        info_label = QLabel("Tip: Fill out data in each tab, then click OK to apply all data at once.")
        info_label.setStyleSheet("color: #888; font-style: italic;")
        main_layout.addWidget(info_label)
        
        # Buttons
        btns = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        main_layout.addWidget(btns)
        
        btns.accepted.connect(lambda: self._apply_tabbed_paste(dlg))
        btns.rejected.connect(dlg.reject)
        
        dlg.exec_()

    def _apply_tabbed_paste(self, dialog: QDialog):
        """Apply data from all tabs of the paste dialog"""
        # Get data from all tabs
        part_lines = [line.strip() for line in self.part_text.toPlainText().splitlines() if line.strip()]
        location_lines = [line.strip() for line in self.location_text.toPlainText().splitlines() if line.strip()]
        qty_lines = [line.strip() for line in self.qty_text.toPlainText().splitlines() if line.strip()]
        
        # Determine the maximum number of rows needed
        max_rows = max(len(part_lines), len(location_lines), len(qty_lines))

        if max_rows == 0:
            dialog.accept()
            return

        # Clear existing rows and add new ones
        while self.child_row_count > 0:
            self.remove_child_part()

        # Add rows for each line of data
        for i in range(max_rows):
            part_number = part_lines[i] if i < len(part_lines) else ""
            quantity = int(qty_lines[i]) if i < len(qty_lines) and qty_lines[i].isdigit() else 1
            from_loc = location_lines[i] if i < len(location_lines) else ""
            self.add_child_part(part_number, quantity, from_loc)

        dialog.accept()

    def load_parts(self):
        from PyQt5.QtWidgets import QFileDialog, QMessageBox
        import pandas as pd
        import os
        root_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        templates_dir = os.path.join(root_dir, "Build Templates")
        file_path, _ = QFileDialog.getOpenFileName(self, "Select Excel File", templates_dir, "Excel Files (*.xlsx *.xls)")
        if not file_path:
            return
        try:
            df = pd.read_excel(file_path)
        except Exception as e:
            QMessageBox.warning(self, "Error", f"Failed to read Excel file: {e}")
            return
        # Expect columns: Part#, Location, QTY
        required_cols = ["Part#", "Location", "QTY"]
        if not all(col in df.columns for col in required_cols):
            QMessageBox.warning(self, "Error", f"Excel file must have columns: {', '.join(required_cols)}")
            return
        # Remove any existing child part rows
        while self.child_row_count > 0:
            self.remove_child_part()
        # Add a row for each entry in the Excel file
        for _, row in df.iterrows():
            part = str(row["Part#"]) if not pd.isna(row["Part#"]) else ""
            qty = int(row["QTY"]) if not pd.isna(row["QTY"]) else 1
            loc = str(row["Location"]) if not pd.isna(row["Location"]) else ""
            self.add_child_part(part, qty, loc)

    def show_locators_dialog(self):
        self.open_locators_inline()

    def open_locators_inline(self):
        try:
            if not hasattr(self, 'inline_locators_editor'):
                return
            self._ensure_side_panel_visible()
            editor = self.inline_locators_editor
            if not editor.container.isVisible():
                editor.container.setVisible(True)
                editor._update_toggle_icon()
            editor.programmatic_update()
            editor.editor.setFocus()
        except Exception:
            pass

    def _update_side_panel_button(self) -> None:
        try:
            sizes = self.splitter.sizes() if hasattr(self, 'splitter') else []
            if sizes and len(sizes) >= 2 and sizes[1] > 0:
                self.toggle_side_panel_button.setText('Lists ◀')
            else:
                self.toggle_side_panel_button.setText('Lists ▶')
        except Exception:
            pass

    def _open_side_panel(self) -> None:
        if not hasattr(self, 'splitter'):
            return
        sizes = self.splitter.sizes()
        if len(sizes) < 2:
            return
        left_width = max(sizes[0], self._min_left_width)
        desired_right = max(self._min_side_panel_width, self._side_panel_width)
        self._left_before_side_panel = left_width
        self.resize(self.width() + desired_right, self.height())
        self.splitter.setSizes([left_width, desired_right])

    def _collapse_side_panel(self) -> None:
        if not hasattr(self, 'splitter'):
            return
        sizes = self.splitter.sizes()
        if len(sizes) < 2:
            return
        right_width = sizes[1]
        if right_width <= 0:
            return
        target_width = max(self.minimumWidth(), self.width() - right_width)
        self.resize(target_width, self.height())
        left_target = (
            self._left_before_side_panel
            if self._left_before_side_panel is not None
            else sizes[0]
        )
        left_target = max(self._min_left_width, min(left_target, target_width))
        self.splitter.setSizes([left_target, 0])
        self._left_before_side_panel = None

    def toggle_side_panel(self) -> None:
        try:
            if not hasattr(self, 'splitter'):
                return
            sizes = self.splitter.sizes()
            if len(sizes) < 2:
                return
            if sizes[1] == 0:
                self._open_side_panel()
            else:
                self._collapse_side_panel()
            self._update_side_panel_button()
        except Exception:
            pass

    def _ensure_side_panel_visible(self) -> None:
        try:
            sizes = self.splitter.sizes()
            if len(sizes) < 2:
                return
            if sizes[1] == 0:
                self._open_side_panel()
                self._update_side_panel_button()
        except Exception:
            pass

    def _refresh_inline_editors(self) -> None:
        if hasattr(self, 'inline_locators_editor'):
            self.inline_locators_editor.programmatic_update()
        if hasattr(self, 'inline_lpn_editor'):
            self.inline_lpn_editor.programmatic_update()
        if hasattr(self, 'inline_locations_editor'):
            self.inline_locations_editor.programmatic_update()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    # Apply qdarkstyle theme (support both v3 and v2 function names)
    try:
        app.setStyleSheet(qdarkstyle.load_stylesheet(qt_api='pyqt5'))
    except Exception:
        try:
            app.setStyleSheet(qdarkstyle.load_stylesheet_pyqt5())
        except Exception:
            pass
    w = SubTransferGUI()
    w.show()
    sys.exit(app.exec_())