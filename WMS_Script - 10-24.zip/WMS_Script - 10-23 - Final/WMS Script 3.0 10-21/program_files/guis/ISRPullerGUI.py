"""GUI for extracting ISR logs and generating WIP automation files."""

from __future__ import annotations

import os
import re
from typing import List, Tuple

from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont
from PyQt5.QtWidgets import (
    QApplication,
    QFileDialog,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QScrollArea,
    QCheckBox,
    QSplitter,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

from .BaseGUI import BaseDialog
from ..csv_writers import CSV_Writer_ISRWIP
from ..utils.file_paths import get_default_save_path_for_csv_writer


_LOG_FILE_PATTERN = re.compile(r"^.*\.txt$", re.IGNORECASE)


def extract_serials_from_log(log_content: str) -> List[str]:
    """Return [chassis, nim1, nim2, ...] serials extracted from a show inventory log."""

    chassis_sn = "Missing"
    lines = log_content.splitlines()
    for index, line in enumerate(lines):
        if '"Chassis"' in line and index + 1 < len(lines):
            next_line = lines[index + 1]
            if 'PID: ISR4351/K9' in next_line:
                match = re.search(r'SN:\s*(\S+)', next_line)
                if match and match.group(1).strip():
                    chassis_sn = match.group(1).strip()
                break

    nim_sns: List[str] = []
    for index, line in enumerate(lines):
        if 'NIM subslot' in line and index + 1 < len(lines):
            next_line = lines[index + 1]
            if 'PID: NIM-24A' in next_line:
                match = re.search(r'SN:\s*(\S*)', next_line)
                serial = match.group(1).strip() if match else ""
                nim_sns.append(serial or "Missing")

    while len(nim_sns) < len(CSV_Writer_ISRWIP.SERIAL_HEADER) - 1:
        nim_sns.append("Missing")

    return [chassis_sn] + nim_sns[: len(CSV_Writer_ISRWIP.SERIAL_HEADER) - 1]


class ISRPullerGUI(BaseDialog):
    """Dialog for building ISR WIP exports with inline summary side panel."""

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.folder_path: str = ""
        self.extracted_devices: List[List[str]] = []
        self._last_errors: List[str] = []

        self._side_panel_width = 320
        self._min_side_panel_width = 240
        self._min_left_width = 360
        self._left_before_side_panel: int | None = None

        self._init_ui()
        self.finalize_initial_size(extra_width=60)

    def _init_ui(self) -> None:
        self.setWindowTitle("ISR4351 Data Extraction")

        self.main_layout = QVBoxLayout(self)
        self.splitter = QSplitter(Qt.Horizontal, self)  # type: ignore[attr-defined]
        self.splitter.setHandleWidth(1)
        self.main_layout.addWidget(self.splitter)

        self.left_container = QWidget(self.splitter)
        self.left_layout = QVBoxLayout(self.left_container)
        self.left_layout.setContentsMargins(0, 0, 0, 0)
        self.left_layout.setSpacing(6)

        top_bar = QWidget(self.left_container)
        top_layout = QHBoxLayout(top_bar)
        top_layout.setContentsMargins(0, 0, 0, 0)
        self.status_label = QLabel("Ready", top_bar)
        self.status_label.setStyleSheet("color: #CCCCCC;")
        top_layout.addWidget(self.status_label)
        self.toggle_side_panel_button = QPushButton("Summary ▶", top_bar)
        self.toggle_side_panel_button.setToolTip("Show or hide the summary panel")
        self.toggle_side_panel_button.clicked.connect(self.toggle_side_panel)
        top_layout.addWidget(self.toggle_side_panel_button)
        self.left_layout.addWidget(top_bar)

        scroll_area = QScrollArea(self.left_container)
        scroll_area.setWidgetResizable(True)
        form_widget = QWidget(scroll_area)
        scroll_area.setWidget(form_widget)
        form_layout = QVBoxLayout(form_widget)
        form_layout.setContentsMargins(6, 6, 6, 6)
        form_layout.setSpacing(10)

        title = QLabel("ISR4351 Data Extraction", form_widget)
        title.setFont(QFont("Arial", 18, weight=QFont.Bold))
        title.setStyleSheet("color: #CCCCCC;")
        alignment_center = getattr(getattr(Qt, "AlignmentFlag", Qt), "AlignCenter")
        title.setAlignment(alignment_center)  # type: ignore[arg-type]
        form_layout.addWidget(title)

        self.lpn_checkbox = QCheckBox("Enable LPN Entry", form_widget)
        self.lpn_checkbox.stateChanged.connect(self.toggle_lpn_editing)
        form_layout.addWidget(self.lpn_checkbox)

        lpn_row = QHBoxLayout()
        lpn_label = QLabel("LPN:", form_widget)
        self.lpn_edit = QLineEdit(form_widget)
        self.lpn_edit.setPlaceholderText("Check the box to enter WIP LPN manually")
        self.lpn_edit.setReadOnly(True)
        self.lpn_edit.setStyleSheet("color: gray;")
        lpn_row.addWidget(lpn_label)
        lpn_row.addWidget(self.lpn_edit)
        form_layout.addLayout(lpn_row)

        job_row = QHBoxLayout()
        job_label = QLabel("Job#:", form_widget)
        self.job_edit = QLineEdit(form_widget)
        self.job_edit.setPlaceholderText("Enter job number")
        job_row.addWidget(job_label)
        job_row.addWidget(self.job_edit)
        form_layout.addLayout(job_row)

        folder_label = QLabel("Select folder containing log files:", form_widget)
        form_layout.addWidget(folder_label)

        folder_row = QHBoxLayout()
        self.folder_edit = QLineEdit(form_widget)
        self.folder_edit.setReadOnly(True)
        browse_button = QPushButton("Browse", form_widget)
        browse_button.clicked.connect(self.browse_folder)
        refresh_button = QPushButton("Refresh", form_widget)
        refresh_button.clicked.connect(self.refresh_folder)
        folder_row.addWidget(self.folder_edit)
        folder_row.addWidget(browse_button)
        folder_row.addWidget(refresh_button)
        form_layout.addLayout(folder_row)

        action_row = QHBoxLayout()
        export_xlsx_button = QPushButton("Export XLSX Report", form_widget)
        export_xlsx_button.clicked.connect(self.export_xlsx_report)
        export_csv_button = QPushButton("Export Script CSV", form_widget)
        export_csv_button.clicked.connect(self.export_script_csv)
        action_row.addWidget(export_xlsx_button)
        action_row.addWidget(export_csv_button)
        form_layout.addLayout(action_row)

        form_layout.addStretch()
        self.left_layout.addWidget(scroll_area)

        self.side_panel = QWidget(self.splitter)
        self.side_layout = QVBoxLayout(self.side_panel)
        self.side_layout.setContentsMargins(8, 8, 8, 8)
        self.side_layout.setSpacing(8)

        summary_title = QLabel("Extracted Devices", self.side_panel)
        summary_title.setFont(QFont("Arial", 14, weight=QFont.Bold))
        summary_title.setStyleSheet("color: #CCCCCC;")
        self.side_layout.addWidget(summary_title)

        self.summary_edit = QTextEdit(self.side_panel)
        self.summary_edit.setReadOnly(True)
        self.summary_edit.setLineWrapMode(QTextEdit.NoWrap)
        self.side_layout.addWidget(self.summary_edit)

        self.error_label = QLabel("", self.side_panel)
        self.error_label.setWordWrap(True)
        self.error_label.setStyleSheet("color: #F5A623;")
        self.side_layout.addWidget(self.error_label)
        self.side_layout.addStretch()

        self.side_panel.hide()
        self.splitter.setSizes([self._min_left_width, 0])
        self._update_side_panel_button()

    # ------------------------------------------------------------------
    # UI helpers
    def toggle_lpn_editing(self, state: int) -> None:
        checked_state = getattr(getattr(Qt, "CheckState", Qt), "Checked")
        if state == checked_state:
            self.lpn_edit.setReadOnly(False)
            self.lpn_edit.setStyleSheet("color: white;")
            self.lpn_edit.setFocus()
        else:
            self.lpn_edit.clear()
            self.lpn_edit.setPlaceholderText("Check the box to enter WIP LPN manually")
            self.lpn_edit.setReadOnly(True)
            self.lpn_edit.setStyleSheet("color: gray;")

    def toggle_side_panel(self) -> None:
        try:
            sizes = self.splitter.sizes()
            if len(sizes) < 2:
                return
            if sizes[1] == 0:
                self._open_side_panel()
            else:
                self._collapse_side_panel()
            self._update_side_panel_button()
        except Exception:
            pass

    def _open_side_panel(self) -> None:
        sizes = self.splitter.sizes()
        if len(sizes) < 2:
            return
        left_width = max(sizes[0], self._min_left_width)
        desired_right = max(self._min_side_panel_width, self._side_panel_width)
        self._left_before_side_panel = left_width
        self.side_panel.show()
        self.resize(self.width() + desired_right, self.height())
        self.splitter.setSizes([left_width, desired_right])

    def _collapse_side_panel(self) -> None:
        sizes = self.splitter.sizes()
        if len(sizes) < 2:
            return
        right_width = sizes[1]
        if right_width <= 0:
            return
        target_width = max(self.minimumWidth(), self.width() - right_width)
        self.resize(target_width, self.height())
        left_target = self._left_before_side_panel if self._left_before_side_panel is not None else sizes[0]
        left_target = max(self._min_left_width, min(left_target, target_width))
        self.splitter.setSizes([left_target, 0])
        self.side_panel.hide()
        self._left_before_side_panel = None

    def _ensure_side_panel_visible(self) -> None:
        sizes = self.splitter.sizes()
        if len(sizes) < 2:
            return
        if sizes[1] == 0:
            self._open_side_panel()
            self._update_side_panel_button()

    def _update_side_panel_button(self) -> None:
        sizes = self.splitter.sizes()
        if sizes and len(sizes) >= 2 and sizes[1] > 0:
            self.toggle_side_panel_button.setText("Summary ◀")
        else:
            self.toggle_side_panel_button.setText("Summary ▶")

    def _set_status(self, message: str, level: str = "info") -> None:
        colors = {
            "info": "#CCCCCC",
            "success": "#44C767",
            "warn": "#EFD469",
            "error": "#FF6B6B",
        }
        color = colors.get(level, "#CCCCCC")
        self.status_label.setText(f"<span style='color:{color};'>{message}</span>")

    # ------------------------------------------------------------------
    # Folder handling
    def browse_folder(self) -> None:
        folder = QFileDialog.getExistingDirectory(self, "Select Folder", self.folder_path or os.getcwd())
        if folder:
            self.folder_edit.setText(folder)
            self.folder_path = folder
            self.refresh_folder()

    def refresh_folder(self) -> None:
        folder = self.folder_edit.text().strip()
        if not folder:
            self._set_status("Select a folder to scan", "warn")
            self.extracted_devices = []
            self._update_summary_panel()
            return
        if not os.path.isdir(folder):
            self._set_status("Folder does not exist", "error")
            self.extracted_devices = []
            self._update_summary_panel()
            return

        devices, errors = self._load_devices_from_folder(folder)
        self.extracted_devices = devices
        self._last_errors = errors
        if devices:
            self._set_status(f"Loaded {len(devices)} log file(s)", "success")
            self._ensure_side_panel_visible()
        else:
            self._set_status("No serials found in folder", "warn")
        self._update_summary_panel()

    def _load_devices_from_folder(self, folder: str) -> Tuple[List[List[str]], List[str]]:
        txt_files = sorted(
            [name for name in os.listdir(folder) if _LOG_FILE_PATTERN.match(name)],
            key=str.lower,
        )
        extracted: List[List[str]] = []
        errors: List[str] = []
        for filename in txt_files:
            path = os.path.join(folder, filename)
            try:
                with open(path, "r", encoding="utf-8", errors="ignore") as handle:
                    content = handle.read()
                serials = extract_serials_from_log(content)
                extracted.append(serials)
            except Exception:
                errors.append(filename)
        return extracted, errors

    def _update_summary_panel(self) -> None:
        if not self.extracted_devices:
            self.summary_edit.setPlainText("No logs processed yet.")
        else:
            lines: List[str] = []
            for idx, serials in enumerate(self.extracted_devices, start=1):
                normalized = CSV_Writer_ISRWIP.normalize_serial_set(serials)
                chassis = normalized[0] or "Missing"
                lines.append(f"{idx:02d}. Chassis: {chassis}")
                nim_entries = [value for value in normalized[1:] if value and value.lower() != "missing"]
                if nim_entries:
                    for nim_idx, nim in enumerate(nim_entries, start=1):
                        lines.append(f"    NIM {nim_idx}: {nim}")
                else:
                    lines.append("    No NIM-24A serials detected")
            self.summary_edit.setPlainText("\n".join(lines))

        if self._last_errors:
            truncated = ", ".join(self._last_errors[:5])
            suffix = "" if len(self._last_errors) <= 5 else " ..."
            self.error_label.setText(
                f"Skipped {len(self._last_errors)} file(s): {truncated}{suffix}"
            )
        else:
            self.error_label.clear()

    # ------------------------------------------------------------------
    # Export actions
    def _ensure_devices_loaded(self) -> bool:
        if self.extracted_devices:
            return True
        self.refresh_folder()
        return bool(self.extracted_devices)

    def export_xlsx_report(self) -> None:
        if not self._ensure_devices_loaded():
            QMessageBox.warning(self, "No Data", "Load logs before exporting.")
            return

        default_folder = self.folder_path or os.getcwd()
        default_name = os.path.join(default_folder, "ISR_WIPREPORT.xlsx")
        save_path, _ = QFileDialog.getSaveFileName(
            self,
            "Save XLSX Report",
            default_name,
            "Excel Files (*.xlsx);;All Files (*)",
        )
        if not save_path:
            return
        if not save_path.lower().endswith(".xlsx"):
            save_path += ".xlsx"

        if CSV_Writer_ISRWIP.save_wip_csv_xlsx(save_path, self.extracted_devices):
            QMessageBox.information(self, "Success", f"XLSX report saved to:\n{save_path}")
        else:
            QMessageBox.critical(self, "Error", "Failed to save XLSX report. See console for details.")

    def export_script_csv(self) -> None:
        if not self._ensure_devices_loaded():
            QMessageBox.warning(self, "No Data", "Load logs before exporting.")
            return

        job_value = self.job_edit.text().strip()
        if not job_value:
            QMessageBox.warning(self, "Missing Job#", "Enter a job number before exporting.")
            return

        lpn_value = self.lpn_edit.text().strip() if not self.lpn_edit.isReadOnly() else ""

        default_dir = get_default_save_path_for_csv_writer("WIP_ISR.csv")
        save_path, _ = QFileDialog.getSaveFileName(
            self,
            "Save Script CSV",
            default_dir,
            "CSV Files (*.csv);;All Files (*)",
        )
        if not save_path:
            return
        if not save_path.lower().endswith(".csv"):
            save_path += ".csv"

        if CSV_Writer_ISRWIP.save_wip_csv(save_path, self.extracted_devices, lpn_value, job_value):
            QMessageBox.information(self, "Success", f"Script CSV saved to:\n{save_path}")
        else:
            QMessageBox.critical(self, "Error", "Failed to save script CSV. See console for details.")


def main() -> None:
    import sys

    app = QApplication.instance() or QApplication(sys.argv)
    dialog = ISRPullerGUI()
    dialog.setWindowFlags(Qt.WindowType.Window)
    dialog.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
