# Create a local virtual environment (.venv) at the repository root and install requirements
# Run this script from the dev-tools folder: .\setup_env.ps1

$scriptDir = $PSScriptRoot
$repoRoot = Split-Path -Parent $scriptDir

$venvPath = Join-Path $repoRoot ".venv"
if (-Not (Test-Path $venvPath)) {
    Write-Output "Creating virtual environment at $venvPath..."
    python -m venv $venvPath
} else {
    Write-Output "Virtual environment already exists at $venvPath"
}

$activate = Join-Path $venvPath "Scripts\Activate.ps1"
if (-Not (Test-Path $activate)) {
    Write-Error "Activation script not found at $activate. Ensure Python is installed and 'python -m venv' works."
    exit 1
}

$requirements = Join-Path $scriptDir "requirements.txt"

Write-Output "Activating virtual environment and installing requirements from $requirements..."
# Run in a child PowerShell process so the caller's shell state isn't permanently affected
$command = "& `"$activate`"; python -m pip install --upgrade pip; pip install -r `"$requirements`""
powershell -NoProfile -ExecutionPolicy Bypass -Command $command

Write-Output "Setup complete. To run the launcher from the repo root, run: .\run_launcher.ps1"
