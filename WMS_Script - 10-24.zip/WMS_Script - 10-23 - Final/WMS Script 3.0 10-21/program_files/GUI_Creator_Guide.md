# GUI Creator User Guide (Beginner Edition)

> **Welcome!** This guide will walk you through every step of building a custom WMS automation GUI, with clear explanations and practical examples for every option. No prior experience required!

---

## Table of Contents
1. Introduction
2. Quick Start (Step-by-Step)
3. Field Types & Examples
4. Field Options & Outcomes
5. Designing Your Form
6. Defining CSV Output
7. Advanced Features
8. Troubleshooting & FAQ
9. Example Scenarios
10. Reference: JSON & Templates

---

## 1. Introduction
The GUI Creator lets you build custom forms for WMS tasks, then automatically generates the CSV files your SecureCRT script needs. You can:
- Add any fields you want (text, numbers, lists, dropdowns, checkboxes, tables)
- Control which fields are required, visible, or conditional
- Preview and test your automation before saving
- Save and reuse your GUIs for future tasks

---

## 2. Quick Start (Step-by-Step)
1. **Open GUI Creator** from the main menu.
2. **Name your GUI** (e.g., "Asset Transfer").
3. **Describe your workflow** (e.g., "Moves assets from one location to another").
4. **Add Form Fields**:
   - Click "Add Field"
   - Choose a field type (see below)
   - Fill in label, key, and options
5. **Define CSV Output**:
   - Go to "CSV Template"
   - Add rows for each prompt
   - Link each row to a field or value
6. **Test & Save**:
   - Click "Preview CSV" to check output
   - Save your GUI for future use

---

## 3. Field Types & Examples

| Type      | Description                | Example Use                | Example Value |
|-----------|----------------------------|----------------------------|---------------|
| Text      | Free text input            | Location, part number      | "A123"        |
| Number    | Numeric input              | Quantity, build count      | 10            |
| Checkbox  | True/false toggle          | "Create Label?"            | Checked/Unchecked |
| Dropdown  | Select from options        | "Part Type"                | "Widget"      |
| List      | Multiple items             | LPNs, serials, locations   | ["LPN1", "LPN2"] |
| Table     | Rows with columns          | Asset details, transfers   | See below     |

**Table Example:**
| Serial | Location | Condition |
|--------|----------|-----------|
| S123   | A1       | Good      |
| S124   | B2       | Bad       |

---

## 4. Field Options & Outcomes

Every field has options that control its behavior:

- **Label**: What users see ("From Location:")
- **Key**: Internal name ("from_location")
- **Default Value**: Pre-filled value (optional)
- **Required**: Must be filled before saving
- **Tooltip**: Help text shown on hover
- **Visible When**: Show field only if condition is met (e.g., `field:need_label=true`)
- **Required When**: Only required if condition is met

**Possible Outcomes:**
- If a field is required and left blank, you cannot save.
- If "Visible When" is false, the field is hidden (but keeps its value if re-shown).
- If "Required When" is true, the field must be filled only in that case.

**Example:**
| Field         | Option         | Outcome                                  |
|---------------|---------------|------------------------------------------|
| Label Text    | Required      | Must enter text                          |
| Serial List   | Visible When  | Only shows if "Add Serials" is checked   |
| Quantity      | Default Value | Starts at 1                              |

---

## 5. Designing Your Form

1. **Add each field** you need for your workflow.
2. **Set options** for each field (see above).
3. **Use tooltips** to help users understand what to enter.
4. **Use conditions** to show/hide fields based on other inputs.
5. **Preview your form** to check layout and logic.

**Best Practice:**
- Use clear labels ("From Location" not "Loc")
- Mark essential fields as required
- Group related fields together

---

## 6. Defining CSV Output

1. **Go to CSV Template tab**
2. **Add a row for each prompt** (e.g., "From Location:")
3. **Set Data Source**:
   - `field:[key]` (from a form field)
   - `literal:[value]` (fixed value)
   - `blank` (empty)
4. **Set Condition** (optional): Only include row if condition is true (e.g., `field:create_label=true`).
   - **Now dummy proof!** Just select from a dropdown of available fields and conditions—no coding needed.
5. **Special Commands**: You can insert special WMS_Script commands as a row key using the "Special Command" dropdown:
   - `F4KEY`: triggers F4 key in WMS
   - `F2KEY`: triggers F2 key in WMS
   - `CLEAR`: clears the current screen
   - `DOWNARROW`: moves cursor down
   - `REPRINTS`: triggers reprint action
   - Select a command to insert it as a row key; see tooltips for details.

**CSV Row Example:**
| Prompt           | Data Source         | Condition                | Special Command |
|------------------|--------------------|--------------------------|-----------------|
| From Location:   | field:from_location|                          |                 |
| To Location:     | field:to_location  |                          |                 |
| Create Label:    | literal:Y          | field:create_label=true  |                 |
| Label Text:      | field:label_text   | field:create_label=true  |                 |
| F4KEY            | blank              |                          | F4KEY           |

**Advanced:**
- Use lists/tables to generate multiple rows (e.g., for each LPN)
- Reference number fields for repeated builds

---

## 7. Advanced Features

- **Multiple Builds**: Use a number field ("Number of Builds") and reference it in your CSV template to repeat patterns.
- **Dynamic Dropdowns**: Populate dropdowns from files or lists.
- **Conditional Workflows**: Use checkboxes to drive which fields/rows appear.
- **Lists & Tables**: Allow users to enter multiple items or structured data.
- **Visibility/Required Logic**: Use "Visible When" and "Required When" for complex forms.

---

## 8. Troubleshooting & FAQ

**Common Issues:**
1. *Field validation errors*: Make sure all required fields are filled.
2. *CSV generation fails*: Check that all data sources match field keys exactly.
3. *Conditional rows not appearing*: Verify condition syntax (case-insensitive, must match value).

**FAQ:**
- *How do I preview my CSV?* Use the "Preview CSV" button before saving.
- *Where are example GUIs?* See the `CSV Files/Examples` folder.
- *Can I reuse a GUI?* Yes, use "Load" to open saved GUIs.
- *What if I need a new field type?* Contact your admin or developer.

---

## 9. Example Scenarios

### Scenario 1: Simple Transfer
**Goal:** Move items from one location to another.

**Form Fields:**
- From Location (text, required)
- To Location (text, required)
- Part Number (text, required)
- Quantity (number, required)

**CSV Output:**
| Prompt         | Data Source         |
|----------------|--------------------|
| From Location: | field:from_location|
| To Location:   | field:to_location  |
| Part Number:   | field:part_number  |
| Quantity:      | field:quantity     |
| <Done>         | blank              |

### Scenario 2: Conditional Label Creation
**Goal:** Only create a label if requested.

**Form Fields:**
- Create Label (checkbox)
- Label Text (text)

**CSV Output:**
| Prompt         | Data Source         | Condition                |
|----------------|--------------------|--------------------------|
| Create Label:  | literal:Y          | field:create_label=true  |
| Label Text:    | field:label_text   | field:create_label=true  |

### Scenario 3: Multiple LPNs to Locations
**Goal:** Map each LPN to a location (1:1 mapping).

**Form Fields:**
- LPNs (list, required)
- Locations (list, required)

**CSV Output:**
| Prompt         | Data Source         |
|----------------|--------------------|
| LPN:           | field:LPNs[i]      |
| Location:      | field:Locations[i] |
| <Done>         | blank              |

*(Rows repeat for each LPN/location pair)*

---

## 10. Reference: JSON & Templates

**Sample .gui.json:**
```json
{
  "name": "Simple Transfer",
  "description": "Moves items from one location to another.",
  "fields": [
    {"type": "text", "label": "From Location", "key": "from_location", "required": true},
    {"type": "text", "label": "To Location", "key": "to_location", "required": true},
    {"type": "text", "label": "Part Number", "key": "part_number", "required": true},
    {"type": "number", "label": "Quantity", "key": "quantity", "required": true}
  ],
  "csv_template": [
    {"prompt": "From Location:", "data_source": "field:from_location"},
    {"prompt": "To Location:", "data_source": "field:to_location"},
    {"prompt": "Part Number:", "data_source": "field:part_number"},
    {"prompt": "Quantity:", "data_source": "field:quantity"},
    {"prompt": "<Done>", "data_source": "blank"}
  ]
}
```

---

**Congratulations!** You now have a complete reference for building custom WMS GUIs. For more help, see the example files or ask your admin/developer.