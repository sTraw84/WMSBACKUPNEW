#!/usr/bin/env python3
"""
Test script for Dustin GUI modifications
"""

import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), 'program_files'))

from csv_writers.CSV_Writer_DustinSpares import calculate_transfers

def test_dynamic_parts():
    """Test the dynamic part number functionality"""
    
    # Test data with 3 parts
    test_rows = [
        {"lpn": "C40-1", "start1": 10, "end1": 5, "start2": 8, "end2": 12, "start3": 6, "end3": 3},
        {"lpn": "C40-2", "start1": 2, "end1": 7, "start2": 15, "end2": 10, "start3": 1, "end3": 4},
    ]
    
    # Test with 3 parts
    part_columns = [
        ("start1", "end1", "Custom_Part_A"),
        ("start2", "end2", "Custom_Part_B"), 
        ("start3", "end3", "Custom_Part_C")
    ]
    
    try:
        transfers, leftovers = calculate_transfers(test_rows, part_columns)
        
        print("✓ Dynamic part calculation successful!")
        print(f"Number of transfers: {len(transfers)}")
        print(f"Leftovers: {leftovers}")
        
        # Verify part names are used correctly
        for transfer in transfers:
            part_name = transfer.get('part', '')
            if part_name.startswith('Custom_Part_'):
                print(f"✓ Custom part name found: {part_name}")
            else:
                print(f"✗ Unexpected part name: {part_name}")
        
        return True
        
    except Exception as e:
        print(f"✗ Error in dynamic part calculation: {e}")
        return False

def test_default_compatibility():
    """Test that default 2-part behavior still works"""
    
    # Test data with default 2 parts
    test_rows = [
        {"lpn": "C40-1", "start1": 10, "end1": 5, "start2": 8, "end2": 12},
        {"lpn": "C40-2", "start1": 2, "end1": 7, "start2": 15, "end2": 10},
    ]
    
    try:
        # Test with default part columns (None)
        transfers, leftovers = calculate_transfers(test_rows, None)
        
        print("✓ Default compatibility successful!")
        print(f"Number of transfers: {len(transfers)}")
        print(f"Leftovers: {leftovers}")
        
        # Verify default part names are used
        for transfer in transfers:
            part_name = transfer.get('part', '')
            if part_name in ['Linecard1', 'Linecard2']:
                print(f"✓ Default part name found: {part_name}")
            else:
                print(f"✗ Unexpected part name: {part_name}")
        
        return True
        
    except Exception as e:
        print(f"✗ Error in default compatibility: {e}")
        return False

if __name__ == "__main__":
    print("Testing Dustin GUI modifications...\n")
    
    success1 = test_dynamic_parts()
    print()
    success2 = test_default_compatibility()
    
    if success1 and success2:
        print("\n🎉 All tests passed! The modifications are working correctly.")
    else:
        print("\n❌ Some tests failed. Please check the implementation.")