import csv
import time
import os
import re

history, file_path, valid_prompts, rows = [], "", [], []
special_commands = {
    "UPARROW": "\033OA",
    "DOWNARROW": "\033OB",
    "ENTER": '\r',
    "BLANK": '\r',
    "SEND": None,
    "FINISHED": None,
    "NOTHING": None,
    "F4KEY": chr(27) + "OS",
    "CLEAR": chr(3),
    "UPARROW2": "\033OA\033OA",  # Send up arrow key twice
    "ITEMMATCH": None
}

class ScriptStoppedException(Exception):
    pass

def send_command(data):
    crt.Screen.Send(data + '\r')
    crt.Screen.WaitForCursor()

def get_screen_content():
    """
    Retrieve the current screen content once to avoid multiple calls.
    """
    crt.Screen.WaitForCursor(1)
    return crt.Screen.Get(crt.Screen.CurrentRow, 1, crt.Screen.CurrentRow, crt.Screen.Columns).strip()

def send_special_command(command, next_prompt=None, final_prompt=None):
    if command.startswith("WAIT"):
        time.sleep(float(command[4:]))
    elif command == "FINISHED":
        crt.Dialog.MessageBox("The Script has completed!")
        crt.Screen.Synchronous = False
        raise ScriptStoppedException("Script completed successfully")
    elif command != "SEND" and command != "NOTHING":
        # Support DOWNARROW#
        if command.startswith("DOWNARROW") and command[9:].isdigit():
            count = int(command[9:])
            for _ in range(count):
                crt.Screen.Send(special_commands.get("DOWNARROW", "\033OB"))
                crt.Screen.WaitForCursor()
        elif command == "UPARROW2":
            crt.Screen.Send("\033OA")  # First up arrow
            crt.Screen.WaitForCursor()
            crt.Screen.Send("\033OA")  # Second up arrow
        else:
            crt.Screen.Send(special_commands.get(command, ''))
        crt.Screen.WaitForCursor()
        return False

def record_history(prompt, data):
    global history
    history.append('Prompt: {}, Data: {}'.format(prompt, data))
    if len(history) > 6:
        history.pop(0)

def clear_inner_lpn_data():
    """Clear any data after Inner LPN prompt"""
    try:
        attempts = 0
        max_attempts = 3
        
        while attempts < max_attempts:
            attempts += 1
            
            # Get current screen state
            current_content = get_screen_content()
            
            # If there's data, clear it
            if len(current_content) > len("Inner LPN >"):
                # Send Ctrl+C to clear the line
                crt.Screen.Send(chr(3))
                crt.Screen.WaitForCursor(1)
                
                # Check if data was cleared
                after_clear = get_screen_content()
                
                # If data is still there, try again
                if len(after_clear) > len("Inner LPN >"):
                    continue
            
            # If we get here, either there was no data or it was cleared
            # Send Enter to move past the prompt
            crt.Screen.Send("\r")
            crt.Screen.WaitForCursor(1)
            
            # Verify we're not still at Inner LPN
            current_state = get_screen_content()
            if not current_state.startswith("Inner LPN >"):
                return True
                
            # If we're still at Inner LPN, try again
            time.sleep(0.2)
            
        # If we get here, we've exhausted all attempts
        return False
        
    except Exception as e:
        return False

def handle_inner_lpn_prompt():
    """Handle the Inner LPN prompt and ensure we move past it"""
    # First check if we're actually at an Inner LPN prompt
    screen_content = get_screen_content()
    
    if not screen_content.startswith("Inner LPN >"):
        return False
        
    # If there's data, clear it
    if len(screen_content) > len("Inner LPN >"):
        crt.Screen.Send(chr(3))  # Send Ctrl+C
        crt.Screen.WaitForCursor()
        time.sleep(0.2)
        
    # Send Enter to skip the prompt
    crt.Screen.Send("\r")
    crt.Screen.WaitForCursor()
    time.sleep(0.2)
    
    # Verify we've moved past the prompt
    new_screen_content = get_screen_content()
    
    # If we're still at Inner LPN, try one more time
    if new_screen_content.startswith("Inner LPN >"):
        crt.Screen.Send("\r")
        crt.Screen.WaitForCursor()
        time.sleep(0.2)
    
    return True

def skip_inner_lpn_prompt():
    """Skip the Inner LPN prompt by sending Enter"""
    crt.Screen.Send("\r")
    crt.Screen.WaitForCursor()
    return True

def is_please_wait_screen(content):
    """
    Detects if the current prompt is a 'Please Wait...' spinner.
    Spinner can be: /, \, -, |
    """
    # The spinner is always at the end, may have trailing spaces
    return bool(re.match(r"^Please Wait... [/\|\\-]\s*$", content.strip()))

def wait_for_prompt_and_send_data(expected_prompt, data, current_index=None):
    global valid_prompts, rows

    # --- Handle other special commands first ---
    if expected_prompt in special_commands or expected_prompt.startswith("WAIT"):
        if expected_prompt == "SEND":
            send_command(data)
            record_history(expected_prompt, data)
            return True
        elif expected_prompt != "NOTHING":
            # --- UPARROW2 SPECIAL HANDLING ---
            if expected_prompt == "UPARROW2":
                screen_content = get_screen_content()
                # If we're already at From LPN, skip UPARROW2 and continue
                if screen_content.startswith("From LPN"):
                    record_history("UPARROW2", "Skipped - already at From LPN prompt after reset")
                    return True
                # Otherwise, send UPARROW2 as usual
                crt.Screen.Send("\033OA")
                crt.Screen.WaitForCursor()
                crt.Screen.Send("\033OA")
                crt.Screen.WaitForCursor()
                record_history("UPARROW2", "Sent UPARROW2")
                return True
            # --- END UPARROW2 SPECIAL HANDLING ---
            send_special_command(expected_prompt)
            record_history(expected_prompt, data)
            
            # After UPARROW command, check if we're at Cfg SO Line
            if expected_prompt == "UPARROW":
                time.sleep(0.5)  # Give time for the screen to update
                screen_content = get_screen_content()
                if screen_content.startswith("Cfg SO Line:"):
                    # If Cfg SO Line appears after UPARROW, send another UPARROW
                    send_special_command("UPARROW")
                    record_history("Cfg SO Line:", "UPARROW")
                    return True
            
            # Handle UPARROW2 specially when screen is already at "From LPN"
            if expected_prompt == "UPARROW2":
                # Wait a bit for the screen to update fully
                time.sleep(0.5)
                screen_content = get_screen_content()
                
                # If we're already at the From LPN prompt, we need to handle this special case
                # This can happen in Case #2 where the screen reverts directly to From LPN
                if screen_content.startswith("From LPN"):
                    # Check if the next command (after UPARROW2) is From LPN
                    if current_index is not None and current_index + 1 < len(rows):
                        next_row = rows[current_index + 1]
                        if next_row['PROMPT'].strip().startswith("From LPN"):
                            # Since we're already at From LPN prompt, we'll skip this UPARROW2
                            # and let the script continue to process the From LPN command
                            record_history("UPARROW2", "Skipped - already at From LPN prompt")
                            return True
            
            # After Save/Next, only check for From LPN if next command is UPARROW2
            if expected_prompt == "BLANK":  # Save/Next command
                if current_index is not None and current_index + 1 < len(rows):
                    next_row = rows[current_index + 1]
                    if next_row['PROMPT'].strip() == "UPARROW2":
                        time.sleep(0.5)  # Give time for the screen to update
                        
                        # Check if we're already at the From LPN prompt
                        screen_content = get_screen_content()
                        if screen_content.startswith("From LPN"):
                            # Force a screen refresh and verify again
                            crt.Screen.WaitForCursor(1)
                            time.sleep(0.2)
                            screen_content = get_screen_content()
                            if screen_content.startswith("From LPN"):
                                return True  # Skip the UPARROW2 command since we're already at From LPN
            
            return True
        record_history(expected_prompt, data)
        return True

    start_time = time.time()
    while True:
        screen_content = get_screen_content()

        # NEW: Wait until spinner prompt is gone before proceeding
        if is_please_wait_screen(screen_content):
            time.sleep(0.1)  # Wait briefly, then check again
            continue

        # Check for Inner LPN prompt first (highest priority)
        if screen_content.startswith("Inner LPN >"):
            # ...existing code for Inner LPN...
            is_expected = False
            for row in rows:
                if row['PROMPT'].strip() == "Inner LPN >":
                    is_expected = True
                    break
            if not is_expected:
                if len(screen_content) > len("Inner LPN >"):
                    if clear_inner_lpn_data():
                        continue
                else:
                    crt.Screen.Send("\r")
                    crt.Screen.WaitForCursor(1)
                    time.sleep(0.2)
                    continue

        # Special handling for 'To Mtrl Desgn>' prompt
        if screen_content.startswith("To Mtrl Desgn>"):
            # If there's data, clear it first
            if len(screen_content) > len("To Mtrl Desgn>"):
                crt.Screen.Send(chr(3))  # Ctrl+C to clear
                crt.Screen.WaitForCursor(1)
                time.sleep(0.2)
            # Send Enter to skip the prompt
            crt.Screen.Send("\r")
            crt.Screen.WaitForCursor(1)
            time.sleep(0.2)
            continue  # Continue checking for the expected prompt
        
        # Check for Cfg SO Line prompt
        if screen_content.startswith("Cfg SO Line:"):
            message = "Please enter the Cfg SO Line from WWT's ConfigIT(PACMAN) page.\n\nNOTE: It will be shown to the left of the master part under Ln#. If it says 13.1, you would only enter 13."
            cfg_so_line = crt.Dialog.Prompt(message, "Cfg SO Line Entry")
            if cfg_so_line is not None:
                send_command(cfg_so_line)
                record_history("Cfg SO Line:", cfg_so_line)
            # Continue waiting for the expected prompt
            continue
        
        # Check if screen content starts with the expected prompt or matches any valid prompt
        if screen_content.startswith(expected_prompt) or screen_content in valid_prompts:
            if screen_content.startswith(expected_prompt):
                # Special handling for SN prompt with comma-separated values
                if expected_prompt in ("SN         >", "SN       >") and "," in data:
                    # Split the data by commas and send each value individually
                    sn_values = [sn.strip() for sn in data.split(",")]
                    for sn in sn_values:
                        send_command(sn)
                        record_history(expected_prompt, sn)
                        # Wait for the prompt to appear again before sending the next value
                        time.sleep(0.5)  # Small delay to ensure the screen has updated
                        crt.Screen.WaitForCursor(1)
                else:
                    send_command(data)
                    record_history(expected_prompt, data)
                
                # After sending data, check if Inner LPN appears
                screen_content = get_screen_content()
                
                if screen_content.startswith("Inner LPN >"):
                    # Check if this is an expected prompt in the CSV
                    is_expected = False
                    for row in rows:
                        if row['PROMPT'].strip() == "Inner LPN >":
                            is_expected = True
                            break
                    
                    if not is_expected:
                        # If there's data, clear it first
                        if len(screen_content) > len("Inner LPN >"):
                            if clear_inner_lpn_data():
                                return True
                        else:
                            # If no data, just send Enter to skip
                            crt.Screen.Send("\r")
                            crt.Screen.WaitForCursor(1)
                            return True
                    # If it is expected, let the normal flow handle it
                
                return True
            else:
                handle_unknown_prompt(screen_content, expected_prompt, data, current_index)
                return False
                
        # Check if the current prompt is a serial prompt and matches the expected pattern
        elif expected_prompt == "Serial # of #:" and screen_content and is_serial_prompt(screen_content):
            # Split the data by commas and send each value individually
            sn_values = [sn.strip() for sn in data.split(",")]
            for sn in sn_values:
                send_command(sn)
                record_history(expected_prompt, sn)
                # Wait for serial prompt to reappear
                if not crt.Screen.WaitForString("Serial # of #:", 1):
                    break
            return True
        
        if time.time() - start_time > 10:
            handle_unknown_prompt(screen_content, expected_prompt, data, current_index)
            return False
        time.sleep(0.05)


def read_csv(file_path):
    try:
        with open(file_path, 'rb') as file:
            reader = csv.DictReader(file)
            required_columns = {'NUMBER', 'PROMPT', 'KEY', 'DATA'}
            if not required_columns.issubset(set(reader.fieldnames)):
                crt.Dialog.MessageBox("CSV file must contain 'NUMBER', 'PROMPT', 'KEY', and 'DATA' columns.")
                return None
            return list(reader)
    except IOError as e:
        crt.Dialog.MessageBox("Error opening or reading the CSV file: {0}".format(str(e)))
        return None

def write_csv(file_path, rows):
    try:
        with open(file_path, 'wb') as file:
            writer = csv.DictWriter(file, fieldnames=['NUMBER', 'PROMPT', 'KEY', 'DATA'])
            writer.writeheader()
            writer.writerows(rows)
    except IOError as e:
        crt.Dialog.MessageBox("Error writing to the CSV file: {0}".format(str(e)))

def verify_screen_type(csv_file_path):
    """Verify that the current screen matches the expected type from the last row in the PROMPT column."""
    try:
        with open(csv_file_path, 'rb') as file:
            reader = csv.DictReader(file)
            screen_type = None
            
            # Read through all rows to find the last occurrence of the sentinel prompts
            for row in reader:
                if row['PROMPT'].strip() in ['SPLIT', 'REPACK', 'CONSOLIDATE', 'WIP', 'ASSETLABELS', 'SUBTRANSFER']:
                    screen_type = row['PROMPT'].strip()
            
            if not screen_type:  # If no valid screen type found, proceed
                return True
                
            # Read the top header line from the screen buffer
            screen_lines = crt.Screen.Get(1, 1, 1, crt.Screen.Columns)
            top_header = screen_lines.strip()
            
            # Check screen type and corresponding header text
            if screen_type == "SPLIT":
                if "Split(40)" not in top_header:
                    crt.Dialog.MessageBox("Wrong Screen! Please open WMS to the SPLIT screen and try again.", "Screen Type Mismatch", 48)
                    return False
                return True
            elif screen_type == "REPACK":
                if "LPN Repack(40)" not in top_header:
                    crt.Dialog.MessageBox("Wrong Screen! Please open WMS to the REPACK screen and try again.", "Screen Type Mismatch", 48)
                    return False
                return True
            elif screen_type == "CONSOLIDATE":
                if "Consolidate(40)" not in top_header:
                    crt.Dialog.MessageBox("Wrong Screen! Please open WMS to the CONSOLIDATE screen and try again.", "Screen Type Mismatch", 48)
                    return False
                return True
            elif screen_type == "WIP":
                if "Complete Assy(40)" not in top_header:
                    crt.Dialog.MessageBox("Wrong Screen! Please open WMS to the WIP Complete Assy screen and try again.", "Screen Type Mismatch", 48)
                    return False
                return True
            elif screen_type == "ASSETLABELS":
                if "Serial Attributes" not in top_header:
                    crt.Dialog.MessageBox("Wrong Screen! Please open WMS to the Serial Attributes screen and try again.", "Screen Type Mismatch", 48)
                    return False
                return True
            elif screen_type == "SUBTRANSFER":
                if "Sub Transfer (40)" not in top_header:
                    crt.Dialog.MessageBox("Wrong Screen! Please open WMS to the Sub Transfer (40) screen and try again.", "Screen Type Mismatch", 48)
                    return False
                return True
            return True
            
    except Exception as e:
        crt.Dialog.MessageBox("Error: %s" % str(e), "Error", 16)
        return False

def main():
    try:
        crt.Screen.Synchronous = True  # Ensures the script processes all screen data correctly
        global file_path, rows, valid_prompts, prompt_prefixes, prompt_exact
        
        # Get the directory where the script is located
        script_dir = os.path.dirname(os.path.abspath(__file__))
        csv_folder = os.path.join(script_dir, "CSV Files")
        
        # Create CSV Files directory if it doesn't exist
        if not os.path.exists(csv_folder):
            os.makedirs(csv_folder)
            crt.Dialog.MessageBox("Created CSV Files directory at: {0}".format(csv_folder))
        
        csv_files = [f for f in os.listdir(csv_folder) if f.lower().endswith('.csv')]
        if not csv_files:
            crt.Dialog.MessageBox("No CSV files found in the folder: {0}\nPlease add CSV files to the CSV Files directory.".format(csv_folder))
            return
            
        file_options = "\n".join(["{0}. {1}".format(i + 1, file) for i, file in enumerate(csv_files)])
        selected_option = crt.Dialog.Prompt("Select a CSV file:\n{0}".format(file_options), "Select CSV File", "1")
        try:
            selected_index = int(selected_option) - 1
            if selected_index < 0 or selected_index >= len(csv_files):
                raise ValueError
            file_path = os.path.join(csv_folder, csv_files[selected_index])
        except (ValueError, IndexError):
            crt.Dialog.MessageBox("Invalid selection. Exiting script.")
            return
            
        # Step 1: Verify screen type
        if not verify_screen_type(file_path):
            crt.Screen.Synchronous = False
            return
            

        # Step 2: Load CSV
        if not os.path.isfile(file_path):
            crt.Dialog.MessageBox("CSV file not found: {0}".format(file_path))
            return

        rows = read_csv(file_path)
        if rows is None:
            return

        # Check for PROMPTLOC at the bottom of the PROMPT column

        if rows and rows[-1]['PROMPT'].strip() == 'PROMPTLOC':
            # Prompt for number of locations
            num_locs_str = crt.Dialog.Prompt("How many Locations would you like to transfer to?", "Location Count", "1")
            try:
                num_locs = int(num_locs_str)
            except Exception:
                crt.Dialog.MessageBox("Invalid number of locations.")
                return
            if num_locs < 1:
                crt.Dialog.MessageBox("Number of locations must be at least 1.")
                return
            locations = []
            for i in range(num_locs):
                prev_locs_msg = "".join(["Location {}: {}\n".format(j+1, locations[j]) for j in range(i)])
                prompt_msg = prev_locs_msg + "Enter location #{}:".format(i+1)
                loc = crt.Dialog.Prompt(prompt_msg, "Location Entry")
                if not loc:
                    crt.Dialog.MessageBox("Location cannot be empty.")
                    return
                locations.append(loc)
            # Remove PROMPTLOC row from processing
            template_rows = rows[:-1]
            # For each location, process the CSV with To Loc overridden
            for idx, loc in enumerate(locations):
                # Deep copy template_rows for each location
                loc_rows = []
                for r in template_rows:
                    new_row = dict(r)
                    if new_row['PROMPT'].strip() == 'To Loc       >':
                        new_row['DATA'] = loc
                    # Ignore FINISHED except for last location
                    if new_row['PROMPT'].strip() == 'FINISHED' and idx != len(locations)-1:
                        continue
                    loc_rows.append(new_row)
                # Validate number column
                try:
                    number_column = [int(row['NUMBER']) for row in loc_rows]
                except (ValueError, KeyError) as e:
                    crt.Dialog.MessageBox("Error with NUMBER column: {0}".format(str(e)))
                    return
                if number_column != sorted(number_column):
                    crt.Dialog.MessageBox("Please sort NUMBER column in numerical order.")
                    return
                # Set up prompt matching
                valid_prompts = [row['PROMPT'].strip() for row in loc_rows]
                prompt_prefixes = set([prompt.split(':')[0] + ':' for prompt in valid_prompts if ':' in prompt])
                prompt_exact = set([prompt for prompt in valid_prompts if ':' not in prompt])
                # Start processing data for this location
                rows = loc_rows
                main_loop(0)
            return

        # Start processing from the beginning
        start_index = 0

        # Step 4: Validate number column
        try:
            number_column = [int(row['NUMBER']) for row in rows]
        except (ValueError, KeyError) as e:
            crt.Dialog.MessageBox("Error with NUMBER column: {0}".format(str(e)))
            return
        if number_column != sorted(number_column):
            crt.Dialog.MessageBox("Please sort NUMBER column in numerical order.")
            return

        # Step 5: Set up prompt matching
        valid_prompts = [row['PROMPT'].strip() for row in rows]
        prompt_prefixes = set([prompt.split(':')[0] + ':' for prompt in valid_prompts if ':' in prompt])
        prompt_exact = set([prompt for prompt in valid_prompts if ':' not in prompt])

        # Step 6: Start processing data
        main_loop(start_index)
        
    except ScriptStoppedException as e:
        # Only show message if it was manually stopped, not if it completed successfully
        if "Script stopped by user" in str(e):
            crt.Dialog.MessageBox("Script stopped by user.")
    finally:
        crt.Screen.Synchronous = False  # Reset synchronous mode

def main_loop(start_index):
    global rows
    try:
        for index, row in enumerate(rows[start_index:], start=start_index):
            prompt, data = row['PROMPT'].strip(), row['DATA']
            # Skip SUBTRANSFER prompt during processing
            if prompt == 'SUBTRANSFER':
                continue
            if not prompt:
                # Only show empty prompt message if we haven't encountered FINISHED
                if not any(row['PROMPT'].strip() == "FINISHED" for row in rows):
                    crt.Dialog.MessageBox("Encountered empty prompt. Stopping script.")
                break
            try:
                if wait_for_prompt_and_send_data(prompt, data, index):
                    continue
            except ScriptStoppedException:
                # User manually stopped the script or script completed successfully
                raise
            except Exception as e:
                # Unexpected error occurred
                handle_unknown_prompt(prompt, data, e, index)
                break
    except ScriptStoppedException:
        # Re-raise the exception to be caught by the main function
        raise
    finally:
        crt.Screen.Synchronous = False

def is_serial_prompt(prompt):
    """Check if the prompt matches the Serial # of #: pattern."""
    # This pattern will match "Serial" followed by any number, "of", any number, and ":"
    pattern = r"Serial \d+ of \d+:"
    return bool(re.match(pattern, prompt))

def handle_clear_prompt():
    """Handle clearing the current prompt and return True if successful"""
    try:
        # Send Ctrl+C to clear the line
        crt.Screen.Send(chr(3))
        crt.Screen.WaitForCursor(1)
        return True
    except Exception as e:
        crt.Dialog.MessageBox("Error clearing prompt: {0}".format(str(e)))
        return False

def handle_unknown_prompt(active_prompt, expected_prompt, data, current_index):
    # First check if it's a known "skip" prompt
    if active_prompt.strip().startswith("Inner LPN >"):
        # Check if this prompt is expected in the CSV
        is_expected = False
        for row in rows:
            if row['PROMPT'].strip() == "Inner LPN >":
                is_expected = True
                break
                
        # If not expected, handle it automatically
        if not is_expected:
            # Check if there's data next to the prompt
            if len(active_prompt.strip()) > len("Inner LPN >"):  # If there's data after the prompt
                # Send Enter key directly
                skip_inner_lpn_prompt()
                # Return True to advance to next line in CSV
                return True
    
    # Check for Cfg SO Line prompt
    if active_prompt.strip().startswith("Cfg SO Line:"):
        # Check if there's any data after the prompt
        if len(active_prompt.strip()) > len("Cfg SO Line:"):
            # If there's data, send uparrow
            send_special_command("UPARROW")
            record_history("Cfg SO Line:", "UPARROW")
        else:
            # If no data, show the custom dialog
            message = "Please enter the Cfg SO Line from WWT's ConfigIT(PACMAN) page.\n\nNOTE: It will be shown to the left of the master part under Ln#. If it says 13.1, you would only enter 13."
            cfg_so_line = crt.Dialog.Prompt(message, "Cfg SO Line Entry")
            if cfg_so_line is not None:
                send_command(cfg_so_line)
                record_history("Cfg SO Line:", cfg_so_line)
        return True
        
    # Check if it's a serial prompt (any numbers)
    if is_serial_prompt(active_prompt):
        # The existing data splitting and sending logic will handle this
        return True
        
    # Format the message with better organization
    message = (
        "Unexpected prompt encountered!\n\n"
        "Prompt Details:\n"
        "------------\n"
        "On-Screen Prompt: {}\n"
        "Expected Prompt: {}\n"
        "------------\n\n"
        "Choose an action:\n"
        "1. Send Enter Key\n"
        "2. Send Up Arrow\n"
        "3. Send Down Arrow\n"
        "4. Send F4 Key\n"
        "5. Clear Prompt\n"
        "6. Enter Data Manually\n"
        "7. Show CSV Lines (Continue Script)\n"
        "8. Stop Script"
    ).format(active_prompt, expected_prompt)
               
    user_option = crt.Dialog.Prompt(message, "[Prompt Options]", "1")
    
    if user_option == "1":
        send_special_command("ENTER")
        record_history(expected_prompt, "ENTER")
        handle_unknown_prompt(active_prompt, expected_prompt, data, current_index)
    elif user_option == "2":
        send_special_command("UPARROW")
        record_history(expected_prompt, "UPARROW")
        handle_unknown_prompt(active_prompt, expected_prompt, data, current_index)
    elif user_option == "3":
        send_special_command("DOWNARROW")
        record_history(expected_prompt, "DOWNARROW")
        handle_unknown_prompt(active_prompt, expected_prompt, data, current_index)
    elif user_option == "4":
        send_special_command("F4KEY")
        record_history(expected_prompt, "F4KEY")
        handle_unknown_prompt(active_prompt, expected_prompt, data, current_index)
    elif user_option == "5":
        if handle_clear_prompt():
            handle_unknown_prompt(active_prompt, expected_prompt, data, current_index)
    elif user_option == "6":
        manual_data = crt.Dialog.Prompt("Enter Data:", "Manual Data Entry")
        if manual_data is not None:
            send_command(manual_data)
            record_history(expected_prompt, manual_data)
            handle_unknown_prompt(active_prompt, expected_prompt, data, current_index)
        else:
            handle_unknown_prompt(active_prompt, expected_prompt, data, current_index)
    elif user_option == "7":
        show_csv_lines_menu(current_index)
    elif user_option == "8":
        # User manually stopped the script
        raise ScriptStoppedException("Script stopped by user.")

def show_csv_lines_menu(current_index):
    global rows
    
    # Build the menu message
    message = "Select from below or choose a number from the NUMBER column in the CSV to continue from:\n\n"
    
    # Add lines before the current unprocessed line
    for i in range(max(0, current_index - 10), current_index):
        row = rows[i]
        prompt = row['PROMPT'].strip()
        data = row['DATA'].strip()
        
        # Clean up the prompt by removing extra spaces
        if '>' in prompt:
            prompt = prompt.split('>')[0].strip() + '>'
        elif ':' in prompt:
            prompt = prompt.split(':')[0].strip() + ':'
            
        # Truncate long item data
        if prompt == "Item>" and data and "ACTUAL" in data:
            data = data.split("ACTUAL")[0].rstrip(".") + "..."
            
        # Only show data if it exists
        if data:
            message += "{0}\t{1} {2}\n".format(row['NUMBER'], prompt, data)
        else:
            message += "{0}\t{1}\n".format(row['NUMBER'], prompt)
    
    # Add separator before current unprocessed line
    message += "------------------------------\n"
    
    # Add the current unprocessed line
    row = rows[current_index]
    prompt = row['PROMPT'].strip()
    data = row['DATA'].strip()
    if '>' in prompt:
        prompt = prompt.split('>')[0].strip() + '>'
    elif ':' in prompt:
        prompt = prompt.split(':')[0].strip() + ':'
        
    # Truncate long item data
    if prompt == "Item>" and data and "ACTUAL" in data:
        data = data.split("ACTUAL")[0].rstrip(".") + "..."
        
    if data:
        message += "{0}\t{1} {2}\n".format(row['NUMBER'], prompt, data)
    else:
        message += "{0}\t{1}\n".format(row['NUMBER'], prompt)
    
    # Add separator after current unprocessed line
    message += "------------------------------\n"
    
    # Add lines after the current unprocessed line
    for i in range(current_index + 1, min(len(rows), current_index + 11)):
        row = rows[i]
        prompt = row['PROMPT'].strip()
        data = row['DATA'].strip()
        
        if '>' in prompt:
            prompt = prompt.split('>')[0].strip() + '>'
        elif ':' in prompt:
            prompt = prompt.split(':')[0].strip() + ':'
            
        # Truncate long item data
        if prompt == "Item>" and data and "ACTUAL" in data:
            data = data.split("ACTUAL")[0].rstrip(".") + "..."
            
        if data:
            message += "{0}\t{1} {2}\n".format(row['NUMBER'], prompt, data)
        else:
            message += "{0}\t{1}\n".format(row['NUMBER'], prompt)
    
    # Add main menu option
    message += "\n0. Main Menu\n\n"
    message += "Choose a selection above or enter a number from the NUMBER column of the CSV to continue from:"
    
    user_option = crt.Dialog.Prompt(message, "CSV Line Selection", "0")
    
    if user_option == "0":
        # Return to Prompt Options menu
        crt.Screen.WaitForCursor(1)
        screen_content = crt.Screen.Get(crt.Screen.CurrentRow, 1, crt.Screen.CurrentRow, crt.Screen.Columns).strip()
        handle_unknown_prompt(screen_content, rows[current_index]['PROMPT'].strip(), rows[current_index]['DATA'], current_index)
        return
    
    try:
        selected_number = int(user_option)
        # Find the row with the selected number
        for i, row in enumerate(rows):
            if int(row['NUMBER']) == selected_number:
                if row['PROMPT'].strip():  # Check if there's a prompt
                    wait_for_prompt_and_send_data(row['PROMPT'].strip(), row['DATA'], i)
                    main_loop(start_index=i + 1)
                    return
                else:
                    crt.Dialog.MessageBox("Invalid selection - no prompt found for this line number.")
                    show_csv_lines_menu(current_index)
                    return
        crt.Dialog.MessageBox("Invalid selection - line number not found in CSV.")
        show_csv_lines_menu(current_index)
    except ValueError:
        crt.Dialog.MessageBox("Invalid selection - please enter a valid number.")
        show_csv_lines_menu(current_index)
        
main()