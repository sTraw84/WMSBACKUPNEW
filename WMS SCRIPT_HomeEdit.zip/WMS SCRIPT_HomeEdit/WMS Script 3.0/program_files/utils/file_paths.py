"""
Utility module for handling default directory paths in the WMS application.
Provides consistent default paths for file save dialogs.
"""
import os
from pathlib import Path
from typing import Optional


def get_project_root() -> Path:
    """Get the root directory of the project."""
    # Go up two levels from the utils module to reach the project root
    return Path(__file__).resolve().parents[2]


def get_csv_files_directory() -> Path:
    """Get the path to the CSV Files directory."""
    return get_project_root() / "CSV Files"


def get_mes_tracker_files_directory() -> Path:
    """Get the path to the MES Tracker Files directory."""
    return get_project_root() / "MES Tracker Files"


def ensure_directory_exists(directory_path: Path) -> None:
    """Ensure that a directory exists, creating it if necessary."""
    directory_path.mkdir(parents=True, exist_ok=True)


def get_default_csv_save_path(filename: str = "") -> str:
    """
    Get the default path for saving CSV files.
    
    Args:
        filename: Optional filename to append to the path
        
    Returns:
        String path to use as default in QFileDialog.getSaveFileName
    """
    csv_dir = get_csv_files_directory()
    ensure_directory_exists(csv_dir)
    
    if filename:
        return str(csv_dir / filename)
    return str(csv_dir)


def get_default_mes_tracker_save_path(filename: str = "") -> str:
    """
    Get the default path for saving MES Tracker files.
    
    Args:
        filename: Optional filename to append to the path
        
    Returns:
        String path to use as default in QFileDialog.getSaveFileName
    """
    tracker_dir = get_mes_tracker_files_directory()
    ensure_directory_exists(tracker_dir)
    
    if filename:
        return str(tracker_dir / filename)
    return str(tracker_dir)


def get_default_save_path_for_csv_writer(filename: str = "") -> str:
    """
    Get the default save path for CSV writer operations.
    This defaults to the CSV Files directory.
    
    Args:
        filename: Optional filename to append to the path
        
    Returns:
        String path to use as default in QFileDialog.getSaveFileName
    """
    return get_default_csv_save_path(filename)


def get_default_save_path_for_mes_extractor(filename: str = "MES_Orders.xlsx") -> str:
    """
    Get the default save path for MES Extractor operations.
    This defaults to the MES Tracker Files directory.
    
    Args:
        filename: Default filename for MES extractor files
        
    Returns:
        String path to use as default in QFileDialog.getSaveFileName
    """
    return get_default_mes_tracker_save_path(filename)