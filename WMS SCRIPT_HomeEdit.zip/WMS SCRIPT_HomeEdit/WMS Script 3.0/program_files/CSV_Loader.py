import csv
import tempfile

def load_and_verify_csv(file_path, mode="split"):
    try:
        rows = []
        with open(file_path, 'r') as file:
            reader = csv.DictReader(file)
            headers = reader.fieldnames

            required_headers = ["NUMBER", "PROMPT", "KEY", "DATA"]
            if not all(header in headers for header in required_headers):
                raise ValueError(f"CSV does not have the required headers. Found: {headers}")

            processed_rows = []
            for row in reader:
                if row["PROMPT"] == "SN         >" and "," in row["DATA"]:
                    sn_values = [sn.strip() for sn in row["DATA"].split(",")]
                    for sn in sn_values:
                        new_row = {k: v for k, v in row.items() if k in required_headers}
                        new_row["DATA"] = sn
                        processed_rows.append(new_row)
                else:
                    processed_rows.append({k: v for k, v in row.items() if k in required_headers})

            rows = processed_rows

            numbers = [int(row["NUMBER"]) for row in rows]
            if numbers != sorted(numbers):
                raise ValueError("NUMBER column is not in numerical order.")

            if rows:
                last_row = rows[-1]
                if last_row["PROMPT"] == "FINISHED":
                    rows.pop()
                    last_row = rows[-1] if rows else None
                if mode == "split" and last_row and last_row["PROMPT"] != "UPARROW":
                    rows.append({"NUMBER": str(numbers[-1] + 1), "PROMPT": "UPARROW", "KEY": "UPARROW", "DATA": ""})

        temp_csv_file = tempfile.NamedTemporaryFile(delete=False, mode='w', newline='')
        with open(temp_csv_file.name, 'w', newline='') as file:
            writer = csv.DictWriter(file, fieldnames=required_headers)
            writer.writeheader()
            writer.writerows(rows)

        return temp_csv_file
    except Exception as e:
        print(f"Error loading and verifying CSV: {e}")
        raise
