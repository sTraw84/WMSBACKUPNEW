import os
import sys
import traceback
import json
from typing import List, Dict, Any, Optional

import pandas as pd
import requests
from PyQt5.QtWidgets import (
    QApplication,
    QWidget,
    QVBoxLayout,
    QPushButton,
    QFileDialog,
    QLabel,
    QMessageBox,
    QTextEdit,
    QCheckBox,
    QComboBox,
    QHBoxLayout,
)
import qdarkstyle

# Import default path utilities
from ..utils.file_paths import get_default_save_path_for_mes_extractor


class MESExtractor(QWidget):
    def read_filter_payload(self, filename: str = "MES_Filters.json") -> Optional[dict]:
        """Read and parse the filter payload from the specified JSON file in the json files folder."""
        json_folder = os.path.join(os.path.dirname(__file__), "json files")
        filter_path = os.path.join(json_folder, filename)
        try:
            with open(filter_path, "r", encoding="utf-8") as f:
                payload = json.load(f)
            return payload
        except Exception as e:
            self.log(f"Failed to read/parse {filename}: {e}")
            return None
    """GUI tool to export MES orders using session cookies - no configuration needed."""

    def __init__(self, parent: Optional[QWidget] = None) -> None:
        super().__init__(parent)
        self.setWindowTitle("MES Order Extractor")
        self.resize(500, 400)

        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(12, 12, 12, 12)
        main_layout.setSpacing(8)
        info_label = QLabel(
            "One-click MES order extraction using your browser's session cookies.\n"
            "Make sure you're logged into MES in Chrome/Edge and have your filters applied.\n"
            "If automatic extraction fails, paste your cookie string below (from DevTools > Network > Headers)."
        )
        info_label.setWordWrap(True)
        main_layout.addWidget(info_label)

        # Prepare log output early so populate_filter_files can log if needed
        self.log_output = QTextEdit()
        self.log_output.setReadOnly(True)
        self.log_output.setMinimumHeight(160)

        # Filter file selection
        filter_layout = QHBoxLayout()
        filter_layout.addWidget(QLabel("Filter File:"))
        self.filter_combo = QComboBox()
        self.populate_filter_files()
        filter_layout.addWidget(self.filter_combo)
        
        # Add refresh button for filter files
        refresh_btn = QPushButton("Refresh")
        refresh_btn.setMaximumWidth(80)
        refresh_btn.clicked.connect(self.refresh_filter_files)
        filter_layout.addWidget(refresh_btn)
        
        main_layout.addLayout(filter_layout)

        main_layout.addWidget(QLabel("Paste Cookie String (required):"))
        self.cookie_input = QTextEdit()
        self.cookie_input.setPlaceholderText("Paste cookie string here from DevTools > Network > Headers...")
        self.cookie_input.setMinimumHeight(60)
        self.cookie_input.setMaximumHeight(80)
        main_layout.addWidget(self.cookie_input)

        self.export_btn = QPushButton("Export My MES Orders to Excel")
        self.export_btn.clicked.connect(self.export_orders)
        main_layout.addWidget(self.export_btn)

        # Optional post-processing: autorun Smartsheets Extractor to add SO# and Program(SS) links
        self.autorun_ss_checkbox = QCheckBox("Autorun Smartsheets Extractor (add links to SO# and Program(SS))")
        self.autorun_ss_checkbox.setChecked(False)
        main_layout.addWidget(self.autorun_ss_checkbox)

        main_layout.addWidget(QLabel("Log:"))
        main_layout.addWidget(self.log_output)

        # Ensure a decent minimum window size and center on screen when shown
        self.setMinimumSize(520, 480)

    def showEvent(self, event):
        super().showEvent(event)
        try:
            # Center the window on the primary screen
            screen = QApplication.primaryScreen()
            if screen:
                geo = self.frameGeometry()
                center_point = screen.availableGeometry().center()
                geo.moveCenter(center_point)
                self.move(geo.topLeft())
        except Exception:
            pass

    def populate_filter_files(self) -> None:
        """Populate the filter dropdown with available JSON files."""
        json_folder = os.path.join(os.path.dirname(__file__), "json files")
        self.filter_combo.clear()

        try:
            if not os.path.isdir(json_folder):
                self.filter_combo.addItem("<json files folder missing>")
                self.log("json files folder not found alongside MES_Extractor.")
                return

            json_files = sorted([f for f in os.listdir(json_folder) if f.lower().endswith(".json")])
            if not json_files:
                self.filter_combo.addItem("<no json filters>")
                self.log("No JSON filter files found in json files folder.")
                return

            self.filter_combo.addItems(json_files)

            # Prefer MES_Filters.json when present
            default_name = "MES_Filters.json"
            if default_name in json_files:
                self.filter_combo.setCurrentText(default_name)

        except Exception as exc:
            self.filter_combo.addItem("<error loading>")
            self.log(f"Error loading filter files: {exc}")

    def refresh_filter_files(self) -> None:
        """Refresh the dropdown, keeping the previous choice when possible."""
        previous = self.filter_combo.currentText()
        self.populate_filter_files()

        index = self.filter_combo.findText(previous)
        if index >= 0:
            self.filter_combo.setCurrentIndex(index)

        self.log("Filter file list refreshed.")

    # ------------------------------------------------------------------
    # UI helpers
    # ------------------------------------------------------------------
    def log(self, message: str) -> None:
        self.log_output.append(message)

    def get_browser_cookies(self, domain: str) -> Dict[str, str]:
        """Extract cookies from browser for the given domain."""
        try:
            import browser_cookie3
        except Exception as e:
            self.log(f"Failed to import browser_cookie3: {e}")
            return {}
            
        cookies = {}
        # Try Chrome first
        try:
            chrome_cookies = browser_cookie3.chrome(domain_name=domain)
            for cookie in chrome_cookies:
                cookies[cookie.name] = cookie.value
            if cookies:
                self.log(f"Loaded {len(cookies)} cookies from Chrome")
                return cookies
        except Exception as e:
            self.log(f"Chrome cookie extraction failed: {e}")

        # Try Edge if Chrome fails
        try:
            edge_cookies = browser_cookie3.edge(domain_name=domain)
            for cookie in edge_cookies:
                cookies[cookie.name] = cookie.value
            if cookies:
                self.log(f"Loaded {len(cookies)} cookies from Edge")
                return cookies
        except Exception as e:
            self.log(f"Edge cookie extraction failed: {e}")

        return cookies

    def parse_cookie_string(self, cookie_string: str) -> Dict[str, str]:
        """Parse a raw cookie string into a dict."""
        cookies = {}
        for part in cookie_string.split(';'):
            if '=' in part:
                name, value = part.split('=', 1)
                cookies[name.strip()] = value.strip()
        return cookies


    def extract_order_data(self, data: Any) -> List[Dict[str, Any]]:
        """Extract order records from API response."""
        orders = []
        
        if isinstance(data, list):
            orders = data
        elif isinstance(data, dict):
            # Try common keys that might contain order data
            for key in ['orders', 'workorders', 'data', 'results', 'items']:
                if key in data and isinstance(data[key], list):
                    orders = data[key]
                    break
            else:
                # If it's a single order object, wrap it in a list
                if any(field in data for field in ['id', 'orderNumber', 'workOrder', 'status']):
                    orders = [data]
        
        return orders

    # ------------------------------------------------------------------
    # Core extraction logic
    # ------------------------------------------------------------------
    def export_orders(self) -> None:
        self.export_btn.setDisabled(True)
        self.log_output.clear()

        try:
            # Get output file path
            output_path, _ = QFileDialog.getSaveFileName(
                self,
                "Save Excel File",
                get_default_save_path_for_mes_extractor("MES_Orders.xlsx"),
                "Excel Files (*.xlsx)"
            )
            if not output_path:
                self.log("Export cancelled by user.")
                return

            # Require manual cookie string
            cookie_string = self.cookie_input.toPlainText().strip()
            if not cookie_string:
                raise RuntimeError("You must paste your cookie string above (from DevTools > Network > Headers).")
            self.log("Using manually entered cookie string.")
            cookies = self.parse_cookie_string(cookie_string)

            # Create session with cookies
            session = requests.Session()
            session.cookies.update(cookies)

            # Add common headers to mimic browser requests
            session.headers.update({
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                'Accept': 'application/json, text/plain, */*',
                'Accept-Language': 'en-US,en;q=0.9',
                'Referer': 'https://mes.wwt.com/'
            })


            # Use fixed MES API endpoint
            endpoint = "https://apirouter.apps.wwt.com/api/forward/mes-api/workOrders"
            self.log(f"Using MES API endpoint: {endpoint}")

            # Read filter payload from selected JSON file
            selected_filter = self.filter_combo.currentText()
            invalid_tokens = {"<json files folder missing>", "<no json filters>", "<error loading>"}
            if selected_filter in invalid_tokens or not selected_filter:
                raise RuntimeError(f"Invalid filter file selection: {selected_filter}")

            payload = self.read_filter_payload(selected_filter)
            if not payload:
                raise RuntimeError(f"Could not read or parse {selected_filter}. Please check the file format.")

            # Fetch the data using POST with filters
            self.log("Fetching filtered order data...")
            resp = session.post(endpoint, json=payload, timeout=30)
            resp.raise_for_status()

            data = resp.json()
            orders = self.extract_order_data(data)

            if not orders:
                raise RuntimeError("No order data found in the response.")


            # Convert to DataFrame
            df = pd.DataFrame(orders)

            # Clean up the data - flatten nested objects if any
            for col in df.columns:
                if df[col].dtype == 'object':
                    df[col] = df[col].apply(lambda x: str(x) if isinstance(x, (dict, list)) else x)

            # Column mapping from original to output
            col_map = {
                'A': 'documentNumber',
                'B': 'soNumber',
                'C': 'serviceTemplateDesc',
                'D': 'scheduledComplDate',
                'E': 'location',
                'F': 'orderManager',
                'G': 'expediteFlag',
                'H': 'assemblyQty',
                'J': 'gicTicket',
                'K': 'currentService'
            }

            # Select and reorder columns
            output_cols = [
                'documentNumber',    # A: WO# (with hyperlink)
                'soNumber',          # B: SO#
                'serviceTemplateDesc', # C: Program(SS) (cleaned)
                'scheduledComplDate', # D: LED (date format)
                'location',          # E: Lab Loc
                'orderManager',      # F: OM
                'expediteFlag',      # G: Expedite
                'assemblyQty',       # H: Devices
                'gicTicket',         # J: GIC#
                'currentService'     # K: Status
            ]

            # Build new DataFrame with blank columns for Tech (I) and Notes/Handoff (L)
            new_df = pd.DataFrame()
            # A: WO# (display text is documentNumber, hyperlink will use jobHeaderId)
            new_df['WO#'] = df['documentNumber'] if 'documentNumber' in df.columns else ''
            # B: SO#
            new_df['SO#'] = df['soNumber'] if 'soNumber' in df.columns else ''
            # C: Program(SS) (cleaned)
            import re

            removal_patterns = [
                r'Microsoft',
                r'GICLAB\d+',
                r'L3\s*-\s*MSFT\s+Reuse\s*-',
                r'MSFT\s+Reuse\s*-',
            ]

            def clean_program(val):
                if pd.isnull(val):
                    return ''
                text = str(val)
                for pattern in removal_patterns:
                    text = re.sub(pattern, '', text, flags=re.IGNORECASE)
                text = re.sub(r'\s+', ' ', text)
                return text.strip(" -_")

            location_patterns = [
                r'\.LAB\.WPC\.\.',
                r'\.LAB\.NA1\.\.',
            ]

            def clean_location(val):
                if pd.isnull(val):
                    return ''
                text = str(val)
                for pattern in location_patterns:
                    text = re.sub(pattern, '', text, flags=re.IGNORECASE)
                text = re.sub(r'\s+', ' ', text)
                return text.strip()

            new_df['Program(SS)'] = (
                df['serviceTemplateDesc'].apply(clean_program)
                if 'serviceTemplateDesc' in df.columns else ''
            )
            # D: LED (date format)
            new_df['LED'] = pd.to_datetime(df['scheduledComplDate'], errors='coerce').dt.strftime('%m/%d/%Y') if 'scheduledComplDate' in df.columns else ''
            # E: Lab Loc
            new_df['Lab Loc'] = (
                df['location'].apply(clean_location)
                if 'location' in df.columns else ''
            )
            # F: OM
            new_df['OM'] = df['orderManager'] if 'orderManager' in df.columns else ''
            # G: Expedite
            new_df['Expedite'] = df['expediteFlag'] if 'expediteFlag' in df.columns else ''
            # H: Devices
            new_df['Devices'] = df['assemblyQty'] if 'assemblyQty' in df.columns else ''
            # I: Tech (blank)
            new_df['Tech'] = ''
            # J: GIC#
            new_df['GIC#'] = df['gicTicket'] if 'gicTicket' in df.columns else ''
            # K: Status
            new_df['Status'] = df['currentService'] if 'currentService' in df.columns else ''
            # L: Notes/Handoff (blank)
            new_df['Notes/Handoff'] = ''


            # Save to Excel
            new_df.to_excel(output_path, index=False)

            # Make WO# column a clickable hyperlink with display text as documentNumber and link to jobHeaderId
            try:
                from openpyxl import load_workbook
                wb = load_workbook(output_path)
                if wb.worksheets:
                    ws = wb.worksheets[0]
                    from openpyxl.cell.cell import Cell
                    # Get jobHeaderId and documentNumber columns from original df
                    job_ids = df['jobHeaderId'].tolist() if 'jobHeaderId' in df.columns else []
                    doc_nums = df['documentNumber'].tolist() if 'documentNumber' in df.columns else []
                    from openpyxl.worksheet.hyperlink import Hyperlink
                    for row in range(2, ws.max_row + 1):
                        cell = ws.cell(row=row, column=1)
                        if not isinstance(cell, Cell):
                            continue
                        idx = row - 2  # index into original df
                        if idx < len(job_ids) and idx < len(doc_nums):
                            job_id = str(job_ids[idx])
                            doc_num = str(doc_nums[idx])
                            url = f'https://mes.apps.wwt.com/orders/{job_id}'
                            cell.value = doc_num
                            # Use Hyperlink object for static type friendliness
                            cell.hyperlink = Hyperlink(ref=cell.coordinate, target=url, display=doc_num)
                            cell.style = 'Hyperlink'
                    wb.save(output_path)
            except Exception as e:
                self.log(f"Could not set hyperlinks: {e}")

            self.log(f"Successfully exported {len(new_df)} filtered orders to {output_path}")
            # If requested, augment the saved workbook with SO# and Program(SS) hyperlinks
            if self.autorun_ss_checkbox.isChecked():
                try:
                    self.log("Autorun enabled: adding Smartsheet/ConfigIT links to SO# and Program(SS)...")
                    self.apply_smartsheet_links(output_path)
                    self.log("Added SO# and Program(SS) hyperlinks.")
                except Exception as e:
                    self.log(f"Autorun Smartsheets step failed: {e}")
            QMessageBox.information(self, "Success", f"Exported {len(new_df)} filtered orders to {output_path}")

        except Exception as exc:
            self.log("Extraction failed.")
            self.log(traceback.format_exc())
            QMessageBox.critical(self, "Error", str(exc))
        finally:
            self.export_btn.setDisabled(False)

    # ------------------------------------------------------------------
    # Post-processing: add SO# (ConfigIT) and Program(SS) (Smartsheet) hyperlinks
    # ------------------------------------------------------------------
    def _normalize_so(self, value: Any) -> str:
        try:
            return str(int(float(value)))
        except Exception:
            return str(value).strip() if value is not None else ""

    def _extract_work_order_link(self, wo_val: Any) -> str:
        if wo_val is None:
            return ""
        import re
        m = re.search(r"(\d+)", str(wo_val))
        return f"https://configit.apps.wwt.com/work-order/{m.group(1)}" if m else ""

    def _get_smartsheet_lookup(self, api_token: str, sheet_id: str) -> Dict[str, Any]:
        """Return dict mapping normalized SO Number -> Smartsheet rowId."""
        try:
            import smartsheet
        except Exception as e:
            raise RuntimeError(f"smartsheet SDK not installed: {e}")
        ss = smartsheet.Smartsheet(api_token)
        sheet = ss.Sheets.get_sheet(sheet_id)
        so_col_id = None
        for col in sheet.columns:
            if str(col.title).strip().lower() == 'so number':
                so_col_id = col.id
                break
        if not so_col_id:
            raise RuntimeError("Could not find 'SO Number' column in Smartsheet sheet")
        lookup: Dict[str, Any] = {}
        for row in sheet.rows:
            for cell in row.cells:
                if cell.column_id == so_col_id and cell.value is not None:
                    key = self._normalize_so(cell.value)
                    lookup[key] = row.id
        return lookup

    def _get_smartsheet_token(self) -> Optional[str]:
        # Prefer environment variable
        token = os.environ.get('SS_API_TOKEN')
        if token:
            return token
        # Fallback to keyring if available
        try:
            import keyring
            kr = keyring.get_password("WWT_WMS_SSLinkCreator", "ss_api_token")
            if kr:
                return kr
        except Exception:
            pass
        return None

    def apply_smartsheet_links(self, excel_path: str) -> None:
        """Open the saved workbook, and add hyperlinks to SO# and Program(SS) columns.
        - SO#: ConfigIT link derived from WO# value
        - Program(SS): Smartsheet row link found via SO# (if API token available)
        Existing links/formatting are preserved.
        """
        try:
            from openpyxl import load_workbook
            from openpyxl.styles import Font
        except Exception as e:
            raise RuntimeError(f"openpyxl required: {e}")

        # Load workbook to preserve existing links
        wb = load_workbook(excel_path)
        ws = wb.active if wb.worksheets else None
        if ws is None:
            raise RuntimeError("Could not open worksheet for hyperlinking")

        # Identify column indexes by header
        header_cells = next(ws.iter_rows(min_row=1, max_row=1))
        headers = [c.value for c in header_cells]
        try:
            wo_idx = headers.index('WO#') + 1
        except ValueError:
            wo_idx = None
        try:
            so_idx = headers.index('SO#') + 1
        except ValueError:
            so_idx = None
        try:
            prog_idx = headers.index('Program(SS)') + 1
        except ValueError:
            prog_idx = None

        # Prepare Smartsheet lookup (optional)
        prog_lookup: Dict[str, Any] = {}
        sheet_id = None
        api_token = self._get_smartsheet_token()
        if api_token:
            try:
                # Reuse SHEET_ID from SSLinkCreator if available
                try:
                    from program_files.guis.SSLinkCreator import SSLinkCreator as _SSLC
                    sheet_id = getattr(_SSLC, 'SHEET_ID', None)
                except Exception:
                    sheet_id = None
                if not sheet_id:
                    # Fallback to known sheet id if not importable
                    sheet_id = "9xwh2FwVR9WMgxpJ483m3wVxvCx6PJf8HqHc2q81"
                prog_lookup = self._get_smartsheet_lookup(api_token, sheet_id)
                self.log(f"Smartsheet lookup loaded: {len(prog_lookup)} SO rows")
            except Exception as e:
                self.log(f"Smartsheet lookup skipped: {e}")

        max_rows = ws.max_row
        from openpyxl.worksheet.hyperlink import Hyperlink
        for row in range(2, max_rows + 1):
            # SO# link (ConfigIT derived from WO#)
            if so_idx and wo_idx:
                wo_val = ws.cell(row=row, column=wo_idx).value
                so_cell = ws.cell(row=row, column=so_idx)
                so_link = self._extract_work_order_link(wo_val)
                if so_link:
                    so_cell.hyperlink = Hyperlink(ref=so_cell.coordinate, target=so_link, display=str(so_cell.value))
                    so_cell.font = Font(color='0000FF', underline='single')
            # Program(SS) link (Smartsheet row)
            if prog_idx and so_idx and prog_lookup:
                so_val = ws.cell(row=row, column=so_idx).value
                so_key = self._normalize_so(so_val)
                row_id = prog_lookup.get(so_key)
                if row_id:
                    prog_cell = ws.cell(row=row, column=prog_idx)
                    prog_url = f"https://app.smartsheet.com/sheets/{sheet_id}?rowId={row_id}"
                    prog_cell.hyperlink = Hyperlink(ref=prog_cell.coordinate, target=prog_url, display=str(prog_cell.value))
                    prog_cell.font = Font(color='0000FF', underline='single')

        wb.save(excel_path)
if __name__ == "__main__":
    app = QApplication(sys.argv)
    app.setStyleSheet(qdarkstyle.load_stylesheet_pyqt5())
    gui = MESExtractor()
    gui.show()
    sys.exit(app.exec_())
