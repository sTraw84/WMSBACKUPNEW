if __name__ == "__main__":
    import sys
    import os
    # Ensure the workspace root is in sys.path for package imports
    workspace_root = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
    if workspace_root not in sys.path:
        sys.path.insert(0, workspace_root)
    from PyQt5.QtWidgets import QApplication
    from program_files.guis.RepackGUI import RepackGUI
    app = QApplication.instance() or QApplication(sys.argv)
    dlg = RepackGUI()
    dlg.exec_()
if __name__ == "__main__":
    import sys
    import os
    # Ensure the workspace root is in sys.path for package imports
    workspace_root = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
    if workspace_root not in sys.path:
        sys.path.insert(0, workspace_root)
    from PyQt5.QtWidgets import QApplication
    app = QApplication.instance() or QApplication(sys.argv)
    dlg = RepackGUI()
    dlg.exec_()
import tempfile
from PyQt5.QtWidgets import (
    QDialog, QVBoxLayout, QLabel, QScrollArea, QWidget, QHBoxLayout, QLineEdit,
    QCheckBox, QPushButton, QMessageBox, QFileDialog, QSpacerItem, QSizePolicy,
    QTableWidget, QTableWidgetItem, QInputDialog, QTextEdit, QTabWidget,
    QDialogButtonBox, QSplitter
)
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QIntValidator
from program_files.csv_writers import CSV_Writer_Repack
from .MainButtons import MainButtons
from .BaseGUI import BaseDialog
from .InlineEditors import CollapsibleListEditor, ChildSNsTabbedEditor
from ..utils.file_paths import get_default_save_path_for_csv_writer
import csv
from typing import List, Optional

class NumericLineEdit(QLineEdit):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setValidator(QIntValidator(0, 999999, self))
class RepackGUI(BaseDialog):
    def __init__(self):
        super().__init__()
        self.list_dialogs = {}
        self.mode = "repack"
        self.csv_writer = CSV_Writer_Repack

        # CSV
        self.temp_csv_file = tempfile.NamedTemporaryFile(delete=False, mode='w', newline='')
        self.row_counter = 1
        self.csv_writer.write_csv_headers(self.temp_csv_file)
        # Match header contract used across writers
        self.csv_headers: List[str] = ["NUMBER", "PROMPT", "KEY", "DATA"]

        # State
        self.total_builds = 0
        self.child_part_counter = 0
        self.c40_list: List[str] = []
        self.master_sn_list: List[str] = []
        # Each entry is either None (no SNs tracked for that child row) or a list of SN strings
        self.child_sn_list: List[Optional[List[str]]] = []
        self.lpn_changed = False
        self._sn_popouts = {}
        self._left_before_side_panel: Optional[int] = None

        self.initUI()

    def initUI(self):
        self.setWindowTitle('Repack Questions')
        self.resize(640, 560)
        self.setMinimumSize(640, 520)
        self.main_layout = QVBoxLayout(self)
        self._side_panel_width = 320
        self._min_left_width = 320
        self._min_side_panel_width = 220

        # Top bar
        self.top_layout = QHBoxLayout()
        self.status_label = QLabel(self)
        self.top_layout.addWidget(self.status_label)
        self.counter_label = QLabel('Total Builds: 0', self)
        self.counter_label.setAlignment(Qt.AlignRight)  # type: ignore[attr-defined]
        self.top_layout.addWidget(self.counter_label)
        self.toggle_side_panel_button = QPushButton('LPN and SN List ▶', self)
        self.toggle_side_panel_button.setToolTip('Show/Hide inline editors panel')
        self.toggle_side_panel_button.setMinimumWidth(self.toggle_side_panel_button.sizeHint().width())
        self.toggle_side_panel_button.clicked.connect(self.toggle_side_panel)
        self.top_layout.addWidget(self.toggle_side_panel_button)
        self.main_layout.addLayout(self.top_layout)

        # Splitter
        self.splitter = QSplitter(Qt.Horizontal, self)  # type: ignore[attr-defined]
        self.splitter.setHandleWidth(1)

        # Left: scroll area + main buttons
        self.left_container = QWidget(self.splitter)
        self.left_layout = QVBoxLayout(self.left_container)
        self.left_layout.setContentsMargins(0, 0, 0, 0)
        self.left_layout.setSpacing(5)

        self.scroll_area = QScrollArea(self.left_container)
        self.scroll_area.setWidgetResizable(True)
        self.scroll_content = QWidget(self.scroll_area)
        self.scroll_layout = QVBoxLayout(self.scroll_content)
        self.scroll_area.setWidget(self.scroll_content)
        self.left_layout.addWidget(self.scroll_area)

        # Warning
        warning_label = QLabel('WARNING! Master parts must be unpacked and loose in location before repacking.', self)
        warning_label.setStyleSheet('color: yellow;')
        warning_label.setAlignment(Qt.AlignCenter)  # type: ignore[attr-defined]
        self.scroll_layout.addWidget(warning_label)

        # Q1
        question1_layout = QHBoxLayout()
        question1_label = QLabel('Do you need master parts repacked onto a C40?', self)
        self.question1_checkbox = QCheckBox(self)
        self.question1_checkbox.stateChanged.connect(self.toggle_part_number)
        question1_layout.addWidget(question1_label)
        question1_layout.addWidget(self.question1_checkbox)
        self.scroll_layout.addLayout(question1_layout)

        # Locator
        self.locator_layout = QHBoxLayout()
        self.locator_label = QLabel('Locator:', self)
        self.locator_textbox = QLineEdit(self)
        self.locator_layout.addWidget(self.locator_label)
        self.locator_layout.addWidget(self.locator_textbox)
        self.locator_label.hide()
        self.locator_textbox.hide()
        self.scroll_layout.addLayout(self.locator_layout)

        # Master part row
        self.master_part_layout = QHBoxLayout()
        self.master_part_label = QLabel('Master Part:', self)
        self.master_part_textbox = QLineEdit(self)
        self.master_sn_list_button = QPushButton('Master SN List', self)
        self.master_sn_list_button.setFixedWidth(self.master_sn_list_button.sizeHint().width())
        self.master_sn_list_button.clicked.connect(self.open_master_sn_list_dialog)
        self.master_part_layout.addWidget(self.master_part_label)
        self.master_part_layout.addWidget(self.master_part_textbox)
        self.master_part_layout.addWidget(self.master_sn_list_button)
        self.master_part_label.hide()
        self.master_part_textbox.hide()
        self.master_sn_list_button.hide()
        self.scroll_layout.addLayout(self.master_part_layout)

        # From LPN row
        self.from_lpn_layout = QHBoxLayout()
        self.from_lpn_label = QLabel('From LPN (Child Parts):', self)
        self.from_lpn_textbox = QLineEdit(self)
        self.from_lpn_textbox.setPlaceholderText('Check the box if repacking from a locator')
        self.from_lpn_textbox.setStyleSheet('color: #00FF00;')
        self.from_lpn_textbox.textChanged.connect(lambda text: (self.validate_from_lpn(text), None)[1])
        self.repack_from_locator_checkbox = QCheckBox(self)
        self.repack_from_locator_checkbox.stateChanged.connect(self.toggle_from_lpn_editing)
        self.from_lpn_layout.addWidget(self.from_lpn_label)
        self.from_lpn_layout.addWidget(self.from_lpn_textbox)
        self.from_lpn_layout.addWidget(self.repack_from_locator_checkbox)
        self.scroll_layout.addLayout(self.from_lpn_layout)

        # Q2
        question2_layout = QHBoxLayout()
        question2_label = QLabel('How many child parts per C40?', self)
        paste_multiple_button = QPushButton('Paste Multi.', self)
        paste_multiple_button.setFixedWidth(paste_multiple_button.sizeHint().width())
        paste_multiple_button.clicked.connect(self.open_paste_multiple_dialog)
        load_template_button = QPushButton('Load Template', self)
        load_template_button.setFixedWidth(load_template_button.sizeHint().width())
        load_template_button.setToolTip('Load Part#/QTY from an Excel template (expects columns: Part#, QTY)')
        load_template_button.clicked.connect(self.load_template_parts)
        add_button = QPushButton('+', self)
        remove_button = QPushButton('-', self)
        add_button.setFixedWidth(20)
        remove_button.setFixedWidth(20)
        add_button.clicked.connect(self.add_child_part)
        remove_button.clicked.connect(self.remove_child_part)
        add_child_sns_button = QPushButton("Add Child SN's", self)
        add_child_sns_button.setFixedWidth(add_child_sns_button.sizeHint().width())
        add_child_sns_button.clicked.connect(self.prompt_child_sns)
        question2_layout.addWidget(question2_label)
        question2_layout.addWidget(paste_multiple_button)
        question2_layout.addWidget(load_template_button)
        question2_layout.addWidget(add_button)
        question2_layout.addWidget(remove_button)
        question2_layout.addWidget(add_child_sns_button)
        self.scroll_layout.addLayout(question2_layout)

        # Child parts list
        self.child_parts_layout = QVBoxLayout()
        self.scroll_layout.addLayout(self.child_parts_layout)

        # Q3
        question3_layout = QHBoxLayout()
        question3_label = QLabel("How many C40's are built this way?", self)
        self.question3_textbox = NumericLineEdit(self)
        self.add_c40_list_button = QPushButton('C40 List', self)
        self.add_c40_list_button.clicked.connect(self.open_c40_list_dialog)
        question3_layout.addWidget(question3_label)
        question3_layout.addWidget(self.question3_textbox)
        question3_layout.addWidget(self.add_c40_list_button)
        self.scroll_layout.addLayout(question3_layout)

        # Spacer and counters
        self.scroll_layout.addItem(QSpacerItem(20, 20, QSizePolicy.Minimum, QSizePolicy.Expanding))
        self.question3_textbox.textChanged.connect(lambda _: self._refresh_sn_badges())

        # Main buttons under left pane
        self.main_buttons = MainButtons(self)
        self.left_layout.addLayout(self.main_buttons.get_layout())

        # Right side panel: inline editors
        self.side_panel = QWidget(self.splitter)
        self.side_layout = QVBoxLayout(self.side_panel)
        self.side_layout.setContentsMargins(6, 6, 6, 6)
        self.side_layout.setSpacing(8)
        self.inline_c40_editor = CollapsibleListEditor(
            self,
            title='C40 List (Inline)',
            attr_name='c40_list',
            get_expected=lambda: int(self.question3_textbox.text()) if self.question3_textbox.text().strip().isdigit() else None,
        )
        self.inline_master_sn_editor = CollapsibleListEditor(
            self,
            title='Master SN List (Inline)',
            attr_name='master_sn_list',
            get_expected=lambda: int(self.question3_textbox.text()) if (self.question3_textbox.text().strip().isdigit() and self.question1_checkbox.isChecked()) else None,
            is_active=lambda: self.question1_checkbox.isChecked(),
        )
        self.inline_child_sn_tabs = ChildSNsTabbedEditor(self, title='Child SNs (Inline Tabs)')
        self.side_layout.addWidget(self.inline_c40_editor)
        self.side_layout.addWidget(self.inline_master_sn_editor)
        self.side_layout.addWidget(self.inline_child_sn_tabs)
        self.side_layout.addStretch()

        # Add panes
        self.splitter.addWidget(self.left_container)
        self.splitter.addWidget(self.side_panel)
        self.splitter.setStretchFactor(0, 4)
        self.splitter.setStretchFactor(1, 0)
        self.splitter.setSizes([1, 0])
        self.main_layout.addWidget(self.splitter)

        # Initial state
        self.inline_c40_editor.programmatic_update()
        self.inline_master_sn_editor.programmatic_update()
        self.inline_child_sn_tabs.programmatic_update()
        self.scroll_layout.setSpacing(5)
        self.scroll_layout.setContentsMargins(5, 5, 5, 5)
        self.finalize_initial_size(extra_width=120)
        # Ensure toggle label matches current visibility
        self._update_side_panel_button()

    def _update_side_panel_button(self):
        try:
            sizes = self.splitter.sizes() if hasattr(self, 'splitter') else []
            if sizes and len(sizes) >= 2 and sizes[1] > 0:
                self.toggle_side_panel_button.setText('LPN and SN List ◀')
            else:
                self.toggle_side_panel_button.setText('LPN and SN List ▶')
        except Exception:
            pass

    def _open_side_panel(self) -> None:
        if not hasattr(self, 'splitter'):
            return
        sizes = self.splitter.sizes()
        if len(sizes) < 2:
            return
        left = max(sizes[0], self._min_left_width)
        desired_right = max(self._min_side_panel_width, self._side_panel_width)
        self._left_before_side_panel = left
        self.resize(self.width() + desired_right, self.height())
        self.splitter.setSizes([left, desired_right])

    def _collapse_side_panel(self) -> None:
        if not hasattr(self, 'splitter'):
            return
        sizes = self.splitter.sizes()
        if len(sizes) < 2:
            return
        right = sizes[1]
        if right <= 0:
            return
        target_width = max(self.minimumWidth(), self.width() - right)
        self.resize(target_width, self.height())
        left_target = self._left_before_side_panel if self._left_before_side_panel is not None else sizes[0]
        left_target = max(self._min_left_width, min(left_target, target_width))
        self.splitter.setSizes([left_target, 0])
        self._left_before_side_panel = None

    def toggle_side_panel(self):
        try:
            if not hasattr(self, 'splitter'):
                return
            sizes = self.splitter.sizes()
            if len(sizes) < 2:
                return
            if sizes[1] == 0:
                self._open_side_panel()
            else:
                self._collapse_side_panel()
            self._update_side_panel_button()
        except Exception:
            pass

    def _ensure_side_panel_visible(self):
        try:
            sizes = self.splitter.sizes()
            if len(sizes) < 2:
                return
            if sizes[1] == 0:
                self._open_side_panel()
                self._update_side_panel_button()
        except Exception:
            pass

    def open_c40_list_dialog(self):
        """Redirect to inline C40 editor: expand and focus its editor."""
        try:
            if hasattr(self, 'inline_c40_editor'):
                # Ensure side panel is visible
                self._ensure_side_panel_visible()
                # Ensure visible/expanded
                if not self.inline_c40_editor.container.isVisible():
                    self.inline_c40_editor.container.setVisible(True)
                    self.inline_c40_editor._update_toggle_icon()
                self.inline_c40_editor.programmatic_update()
                # Focus text editor
                self.inline_c40_editor.editor.setFocus()
        except Exception:
            pass

    def open_master_sn_list_dialog(self):
        """Redirect to inline Master SN editor: expand and focus its editor."""
        try:
            if hasattr(self, 'inline_master_sn_editor'):
                # Ensure side panel is visible
                self._ensure_side_panel_visible()
                if not self.inline_master_sn_editor.container.isVisible():
                    self.inline_master_sn_editor.container.setVisible(True)
                    self.inline_master_sn_editor._update_toggle_icon()
                self.inline_master_sn_editor.programmatic_update()
                self.inline_master_sn_editor.editor.setFocus()
        except Exception:
            pass

    def prompt_child_sns(self):
        if self.child_part_counter == 0:
            QMessageBox.warning(self, 'No Child Parts', "Add at least one child part before adding child SNs.")
            return
        num_sns, ok = QInputDialog.getInt(self, 'Input', 'How many child parts lines have SNs?')
        if ok:
            self.add_child_sns(num_sns)

    def add_child_sns(self, num_sns):
        if self.child_part_counter == 0:
            QMessageBox.warning(self, 'No Child Parts', "Add at least one child part before adding child SNs.")
            return
        for i in range(self.child_parts_layout.count()):
            item = self.child_parts_layout.itemAt(i)
            child_part_layout = item.layout() if item is not None else None
            if not child_part_layout:
                continue
            for j in reversed(range(child_part_layout.count())):
                it = child_part_layout.itemAt(j)
                widget = it.widget() if it is not None else None
                if isinstance(widget, QPushButton) and widget.text() == 'SNs':
                    widget.deleteLater()
                elif isinstance(widget, QLabel) and widget.property('sn_badge'):
                    widget.deleteLater()
        # Close any active SN pop-outs when rebuilding the SN slots
        for idx, pop_pair in list(self._sn_popouts.items()):
            dlg, _ = pop_pair
            try:
                dlg.close()
            except Exception:
                pass
            self._sn_popouts.pop(idx, None)
        if num_sns > self.child_part_counter:
            QMessageBox.information(self, 'Limited Child Parts', f'Only {self.child_part_counter} child part rows are available. SN entries created for that many rows.')
        desired_rows = min(max(num_sns, 0), self.child_part_counter)
        self.child_sn_list = [None] * self.child_part_counter
        for i in range(desired_rows):
            self.child_sn_list[i] = []
            item = self.child_parts_layout.itemAt(i)
            child_part_layout = item.layout() if item is not None else None
            if child_part_layout:
                sn_button = QPushButton('SNs', self)
                # Redirect to inline tabs for the corresponding child row
                sn_button.clicked.connect(lambda _, idx=i: self.open_child_sn_inline(idx))
                child_part_layout.addWidget(sn_button)
            # Add or update the X/Y badge next to the SN button
            self._create_or_get_sn_badge(i)
            self.update_sn_badge(i)
        for i in range(desired_rows, self.child_part_counter):
            self.update_sn_badge(i)
        # Update inline editors in case counts matter
        self.inline_c40_editor.programmatic_update()
        self.inline_master_sn_editor.programmatic_update()
        try:
            self.inline_child_sn_tabs.programmatic_update()
        except Exception:
            pass
        self._refresh_sn_badges()

    def open_child_sn_list_popout(self, index, anchor_widget):
        from PyQt5.QtWidgets import QDialog, QVBoxLayout, QTextEdit, QHBoxLayout, QPushButton
        from PyQt5.QtCore import Qt
        # Use a tool window so it doesn't auto-close when clicking the main window (unlike Qt.Popup)
        pop = QDialog(self, flags=Qt.Tool | Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint)  # type: ignore[attr-defined]
        pop.setModal(False)
        v = QVBoxLayout(pop)
        v.setContentsMargins(8,8,8,8)
        # Header label showing context
        header = QLabel(f"Child Part {index+1} SNs:")
        v.addWidget(header)
        edit = QTextEdit(pop)
        existing = self.child_sn_list[index] or []
        edit.setPlainText("\n".join(existing))
        v.addWidget(edit)
        h = QHBoxLayout()
        apply_btn = QPushButton('Apply', pop)
        close_btn = QPushButton('Close', pop)
        h.addWidget(apply_btn)
        h.addWidget(close_btn)
        v.addLayout(h)

        def apply_and_close():
            lines = [line.strip() for line in edit.toPlainText().splitlines() if line.strip()]
            self.update_child_sn_list(index, lines)
            self.update_sn_badge(index)
            try:
                self.inline_child_sn_tabs.programmatic_update()
            except Exception:
                pass
            pop.close()

        def do_close():
            pop.close()
        apply_btn.clicked.connect(apply_and_close)
        close_btn.clicked.connect(do_close)

        # Position next to the anchor button
        global_pos = anchor_widget.mapToGlobal(anchor_widget.rect().bottomLeft())
        pop.move(global_pos)

        # Track and maintain position on parent moves
        self._sn_popouts[index] = (pop, anchor_widget)
        def on_closed():
            self._sn_popouts.pop(index, None)
        pop.finished.connect(lambda _: on_closed())
        try:
            anchor_widget.destroyed.connect(lambda _: pop.close())
        except Exception:
            pass

        pop.show()

    def open_child_sn_inline(self, index: int):
        """Show the inline tabs and select the tab for the given child row index."""
        try:
            # Ensure inline editor is visible
            if hasattr(self, 'inline_child_sn_tabs'):
                # Ensure side panel is visible
                self._ensure_side_panel_visible()
                if not self.inline_child_sn_tabs.container.isVisible():
                    self.inline_child_sn_tabs.container.setVisible(True)
                    # Update the caret icon
                    self.inline_child_sn_tabs._update_toggle_icon()
                # Rebuild tabs from current child_sn_list and select desired tab
                self.inline_child_sn_tabs.rebuild_tabs()
                label = f"ChildSN{index + 1}"
                for t in range(self.inline_child_sn_tabs.tabs.count()):
                    if self.inline_child_sn_tabs.tabs.tabText(t) == label:
                        self.inline_child_sn_tabs.tabs.setCurrentIndex(t)
                        # Focus the text editor if available
                        ed = self.inline_child_sn_tabs._tab_editors.get(index)
                        if ed is not None:
                            ed.setFocus()
                        break
        except Exception:
            pass

    def load_template_parts(self):
        """Load child part numbers and quantities from an Excel template (columns: Part#, QTY)."""
        from PyQt5.QtWidgets import QFileDialog, QMessageBox
        import os
        try:
            import pandas as pd
        except ImportError:
            QMessageBox.warning(self, 'Missing Dependency', 'pandas is required to load templates.')
            return
        # Build default templates directory path (same pattern as TransferGUI)
        root_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        templates_dir = os.path.join(root_dir, 'Build Templates')
        file_path, _ = QFileDialog.getOpenFileName(self, 'Select Excel File', templates_dir, 'Excel Files (*.xlsx *.xls)')
        if not file_path:
            return
        try:
            df = pd.read_excel(file_path)
        except Exception as e:
            QMessageBox.warning(self, 'Error', f'Failed to read Excel file: {e}')
            return
        required_cols = ['Part#', 'QTY']
        if not all(col in df.columns for col in required_cols):
            QMessageBox.warning(self, 'Error', 'Excel file must have columns: Part#, QTY')
            return
        # Clear existing child parts
        while self.child_part_counter > 0:
            self.remove_child_part()
        # Populate rows
        for _, row in df.iterrows():
            part = str(row['Part#']) if 'Part#' in row and not pd.isna(row['Part#']) else ''
            qty_val = row['QTY'] if 'QTY' in row else 1
            try:
                qty = int(qty_val) if not pd.isna(qty_val) else 1
            except Exception:
                qty = 1
            self.add_child_part()
            last_index = self.child_parts_layout.count() - 1
            if last_index >= 0:
                last_item = self.child_parts_layout.itemAt(last_index)
                if last_item:
                    lay = last_item.layout()
                    if lay:
                        it1 = lay.itemAt(1)
                        it3 = lay.itemAt(3)
                        part_widget = it1.widget() if it1 is not None else None
                        qty_widget = it3.widget() if it3 is not None else None
                        if part_widget:
                            part_widget.setText(part)
                        if qty_widget:
                            qty_widget.setText(str(qty))
        self.status_label.setText('<span style="color: green;">Template loaded successfully.</span>')
        # Refresh inline editors (expected counts change with question3 value later, but list length updated)
        self.inline_c40_editor.programmatic_update()
        self.inline_master_sn_editor.programmatic_update()
        try:
            self.inline_child_sn_tabs.programmatic_update()
        except Exception:
            pass
        try:
            self.inline_child_sn_tabs.programmatic_update()
        except Exception:
            pass

    def update_child_sn_list(self, index, data):
        self.child_sn_list[index] = data
        self.update_sn_badge(index)
        try:
            self.inline_child_sn_tabs.programmatic_update()
        except Exception:
            pass

    def toggle_part_number(self, state):
        visible = state == Qt.Checked  # type: ignore[attr-defined]
        self.locator_label.setVisible(visible)
        self.locator_textbox.setVisible(visible)
        self.master_part_label.setVisible(visible)
        self.master_part_textbox.setVisible(visible)
        self.master_sn_list_button.setVisible(visible)
        self.inline_master_sn_editor.programmatic_update()
        
        # Disconnect any existing text change validation
        try:
            self.master_part_textbox.textChanged.disconnect()
        except Exception:
            pass
            
        # Add text change validation for Master Part only when visible
        if visible:
            self.master_part_textbox.textChanged.connect(lambda text: (self.validate_master_part_text(text), None)[1])

    def validate_master_part_text(self, text):
        """Validate master part text to ensure it doesn't start with forbidden prefixes"""
        if text and any(text.startswith(prefix) for prefix in ['C40-', 'L40-', 'RC40-', 'BTS40-']):
            self.status_label.setText('<span style="color: red;">Master part numbers cannot start with C40-, L40-, RC40-, or BTS40-</span>')
            self.master_part_textbox.setStyleSheet("color: red;")
            self.master_part_label.setStyleSheet("color: red;")
            return False
        else:
            self.master_part_textbox.setStyleSheet("")
            self.master_part_label.setStyleSheet("")
            if not text:
                self.status_label.clear()
            return True

    # Non-returning wrapper for textChanged to satisfy PyQt slot signature
    def _on_master_part_changed(self, text: str):
        self.validate_master_part_text(text)

    # Non-returning wrappers for child part and qty textChanged signals
    def _on_child_part_changed(self, text: str, textbox: QLineEdit):
        self.validate_child_part_text(text, textbox)

    def _on_quantity_changed(self, text: str, qty_label: QLabel):
        self.validate_quantity(text, qty_label)

    def add_child_part(self):
        self.child_part_counter += 1
        self.child_sn_list.append(None)
        child_part_layout = QHBoxLayout()
        child_part_label = QLabel(f'Child Part {self.child_part_counter}:', self)
        child_part_textbox = QLineEdit(self)
        # Add text change validation
        child_part_textbox.textChanged.connect(lambda text, tb=child_part_textbox: self._on_child_part_changed(text, tb))
        qty_label = QLabel('QTY:', self)
        qty_textbox = NumericLineEdit(self)
        qty_textbox.setFixedWidth(50)
        # Add quantity validation
        qty_textbox.textChanged.connect(lambda text, ql=qty_label: self._on_quantity_changed(text, ql))
        child_part_layout.addWidget(child_part_label)
        child_part_layout.addWidget(child_part_textbox)
        child_part_layout.addWidget(qty_label)
        child_part_layout.addWidget(qty_textbox)
        self.child_parts_layout.addLayout(child_part_layout)
        self.inline_c40_editor.programmatic_update()
        self.inline_master_sn_editor.programmatic_update()
        try:
            self.inline_child_sn_tabs.programmatic_update()
        except Exception:
            pass
        self._refresh_sn_badges()

    def validate_child_part_text(self, text, textbox, qty_label=None):
        """Validate child part text to ensure it doesn't start with forbidden prefixes and check for duplicates"""
        # Check for forbidden prefixes
        if text and any(text.startswith(prefix) for prefix in ['C40-', 'L40-', 'RC40-', 'BTS40-']):
            self.status_label.setText('<span style="color: red;">Child part numbers cannot start with C40-, L40-, RC40-, or BTS40-</span>')
            textbox.setStyleSheet("color: red;")
            return False

        # Check for duplicates
        if text:
            for i in range(self.child_parts_layout.count()):
                item = self.child_parts_layout.itemAt(i)
                child_part_layout = item.layout() if item is not None else None
                if not child_part_layout:
                    continue
                it = child_part_layout.itemAt(1)
                other_textbox = it.widget() if it is not None else None
                if other_textbox and other_textbox != textbox and other_textbox.text().strip() == text.strip():
                    self.status_label.setText(f'<span style="color: red;">Duplicate child part number found: {text}</span>')
                    textbox.setStyleSheet("color: red;")
                    return False

        textbox.setStyleSheet("")
        if not text:
            self.status_label.clear()
        return True

    def validate_quantity(self, text, qty_label):
        """Validate quantity field and highlight label if empty"""
        if not text.strip():
            qty_label.setStyleSheet("color: red;")
            return False
        qty_label.setStyleSheet("")
        # Update badge for the row that owns this qty label
        try:
            idx = self._get_row_index_for_widget(qty_label)
            if idx is not None:
                self.update_sn_badge(idx)
        except Exception:
            pass
        return True

    def remove_child_part(self):
        if self.child_part_counter > 0:
            # Close any popout for the last row if open
            if (self.child_part_counter - 1) in self._sn_popouts:
                dlg, _ = self._sn_popouts.pop(self.child_part_counter - 1)
                try:
                    dlg.close()
                except Exception:
                    pass
            if self.child_sn_list:
                self.child_sn_list.pop()
            item = self.child_parts_layout.takeAt(self.child_part_counter - 1)
            if item:
                lay = item.layout()
                while lay and lay.count():
                    it = lay.takeAt(0)
                    widget = it.widget() if it is not None else None
                    if widget:
                        widget.deleteLater()
                self.child_part_counter -= 1
        self.inline_c40_editor.programmatic_update()
        self.inline_master_sn_editor.programmatic_update()
        try:
            self.inline_child_sn_tabs.programmatic_update()
        except Exception:
            pass
        self._refresh_sn_badges()

    def moveEvent(self, event):
        try:
            self._reposition_sn_popouts()
        except Exception:
            pass
        super().moveEvent(event)

    def resizeEvent(self, event):
        try:
            self._reposition_sn_popouts()
        except Exception:
            pass
        super().resizeEvent(event)

    def _reposition_sn_popouts(self):
        # Reposition all open SN pop-outs relative to their anchor widgets
        remove_keys = []
        for idx, tup in self._sn_popouts.items():
            pop, anchor = tup
            if pop is None or anchor is None:
                remove_keys.append(idx)
                continue
            if not pop.isVisible():
                remove_keys.append(idx)
                continue
            try:
                pos = anchor.mapToGlobal(anchor.rect().bottomLeft())
                pop.move(pos)
            except Exception:
                remove_keys.append(idx)
        for k in remove_keys:
            self._sn_popouts.pop(k, None)

    def enable_lpn_editing(self):
        self.lpn_changed = True  # Set flag to indicate LPN has been changed
        self.from_lpn_textbox.setReadOnly(False)
        self.from_lpn_textbox.setFocus()

    def on_next_build(self):
        try:
            # Check if number of C40s is entered
            if not self.question3_textbox.text().strip():
                self.status_label.setText('<span style="color: red;">Please enter the number of C40s to build.</span>')
                self.question3_textbox.setStyleSheet("color: red;")
                return
            else:
                self.question3_textbox.setStyleSheet("")
                
            num_builds = int(self.question3_textbox.text())
            
            # Check if From LPN is entered (unless repacking from locator)
            if not self.from_lpn_textbox.text().strip() and not self.repack_from_locator_checkbox.isChecked():
                self.status_label.setText('<span style="color: red;">Please enter the From LPN.</span>')
                self.from_lpn_textbox.setStyleSheet("color: red;")
                self.from_lpn_label.setStyleSheet("color: red;")
                return
            elif not self.validate_from_lpn(self.from_lpn_textbox.text().strip()):
                return
                
            # Check if there is either a master part or child part
            has_master_part = self.question1_checkbox.isChecked() and self.master_part_textbox.text().strip()
            has_child_parts = self.child_parts_layout.count() > 0
            
            if not (has_master_part or has_child_parts):
                self.status_label.setText('<span style="color: red;">Add either a master or child part.</span>')
                return
                
            # Check if Master Part is entered when checkbox is checked
            if self.question1_checkbox.isChecked():
                if not self.master_part_textbox.text().strip():
                    self.status_label.setText('<span style="color: red;">Please enter the Master Part number.</span>')
                    self.master_part_textbox.setStyleSheet("color: red;")
                    self.master_part_label.setStyleSheet("color: red;")
                    return
                elif not self.validate_master_part_text(self.master_part_textbox.text().strip()):
                    return
            else:
                self.master_part_textbox.setStyleSheet("")
                self.master_part_label.setStyleSheet("")
                
            # Check C40 list count matches number of builds
            if len(self.c40_list) != num_builds:
                self.status_label.setText(f'<span style="color: red;">C40 List requires exactly {num_builds} entries. Current count: {len(self.c40_list)}</span>')
                return
                
            # Check Master SN list count matches number of builds when checkbox is checked
            if self.question1_checkbox.isChecked() and len(self.master_sn_list) != num_builds:
                self.status_label.setText(f'<span style="color: red;">Master SN List requires exactly {num_builds} entries. Current count: {len(self.master_sn_list)}</span>')
                return
            # Update inline editors before writing to reflect final expected counts
            self.inline_c40_editor.programmatic_update()
            self.inline_master_sn_editor.programmatic_update()
            self._refresh_sn_badges()
                
            # Check each child part for required information and validate
            for i in range(self.child_parts_layout.count()):
                item = self.child_parts_layout.itemAt(i)
                child_part_layout = item.layout() if item is not None else None
                if not child_part_layout:
                    continue
                pw_it = child_part_layout.itemAt(1)
                qw_it = child_part_layout.itemAt(3)
                qty_lbl_it = child_part_layout.itemAt(2)
                part_widget = pw_it.widget() if pw_it is not None else None
                qty_widget = qw_it.widget() if qw_it is not None else None
                qty_label = qty_lbl_it.widget() if qty_lbl_it is not None else None
                part_number = part_widget.text().strip() if part_widget else ''
                quantity = qty_widget.text().strip() if qty_widget else ''
                
                # Check if part number is entered
                if not part_number:
                    self.status_label.setText(f'<span style="color: red;">Missing part number for Child Part {i+1}.</span>')
                    it1 = child_part_layout.itemAt(1) if child_part_layout else None
                    part_w = it1.widget() if it1 is not None else None
                    if part_w:
                        part_w.setStyleSheet("color: red;")
                    return
                    
                # Check if quantity is entered
                if not quantity:
                    self.status_label.setText(f'<span style="color: red;">Missing quantity for Child Part {i+1}.</span>')
                    if qty_label:
                        qty_label.setStyleSheet("color: red;")
                    return
                    
                # Check if quantity is a valid number
                try:
                    qty = int(quantity)
                except ValueError:
                    self.status_label.setText(f'<span style="color: red;">Invalid quantity for Child Part {i+1}. Please enter a number.</span>')
                    if qty_label:
                        qty_label.setStyleSheet("color: red;")
                    return
                    
                # Check SN list count matches expected quantity
                if i < len(self.child_sn_list) and self.child_sn_list[i] is not None:
                    expected_sns_count = qty * num_builds
                    current_list = self.child_sn_list[i] or []
                    if len(current_list) != expected_sns_count:
                        self.status_label.setText(f'<span style="color: red;">Child Part {i+1} requires exactly {expected_sns_count} SNs. Current count: {len(current_list)}</span>')
                        return

                # Validate child part text (including duplicate check)
                if not self.validate_child_part_text(part_number, part_widget):
                    return

            # All checks passed, proceed with adding to CSV
            # Clear any existing error messages
            self.status_label.clear()
            
            # Add to CSV and update status
            self.row_counter = CSV_Writer_Repack.append_to_csv(self.temp_csv_file, self.row_counter, self.c40_list, self.master_sn_list, self.child_sn_list, self.from_lpn_textbox, self.master_part_textbox, self.question1_checkbox, self.child_parts_layout, num_builds, self.repack_from_locator_checkbox)
            self.total_builds += num_builds
            
            # Set success message and ensure it's not overwritten
            success_message = f'<span style="color: green;">{num_builds} New builds added to CSV.</span>'
            self.status_label.setText(success_message)
            self.counter_label.setText('Total Builds: {}'.format(self.total_builds))
            
            # Clear all fields except LPN and status
            self.question1_checkbox.setChecked(False)
            self.master_part_textbox.clear()
            self.question3_textbox.clear()
            self.c40_list = []
            self.master_sn_list = []
            self.child_sn_list = []
            self.locator_textbox.clear()
            
            # Clear child parts
            while self.child_parts_layout.count():
                item = self.child_parts_layout.takeAt(0)
                lay = item.layout() if item is not None else None
                if lay:
                    while lay.count():
                        it = lay.takeAt(0)
                        widget = it.widget() if it is not None else None
                        if widget:
                            widget.deleteLater()
            self.child_part_counter = 0
            self._refresh_sn_badges()
            try:
                self.inline_child_sn_tabs.programmatic_update()
            except Exception:
                pass
            
            # Hide master part fields
            self.master_part_label.hide()
            self.master_part_textbox.hide()
            self.master_sn_list_button.hide()
            self.locator_label.hide()
            self.locator_textbox.hide()

        except ValueError:
            self.status_label.setText('<span style="color: red;">Invalid number entered for C40 quantity.</span>')
        except Exception as e:
            self.status_label.setText(f'<span style="color: red;">An unexpected error occurred: {str(e)}</span>')

    def show_change_button(self):
        try:
            if hasattr(self, 'change_lpn_button'):
                self.change_lpn_button.setParent(None)
            self.change_lpn_button = QPushButton('Change', self)
            self.change_lpn_button.clicked.connect(self.enable_lpn_editing)
            self.from_lpn_layout.addWidget(self.change_lpn_button)
        except Exception as e:
            print(f"Error showing change button: {e}")

    def clear_layout(self, layout):
        try:
            while layout.count():
                child = layout.takeAt(0)
                if child.widget():
                    child.widget().deleteLater()
        except Exception as e:
            print(f"Error clearing layout: {e}")

    def clear_data_fields(self):
        # Clear all input fields
        self.question1_checkbox.setChecked(False)
        self.master_part_textbox.clear()
        self.question3_textbox.clear()
        self.from_lpn_textbox.clear()
        self.from_lpn_textbox.setReadOnly(False)
        self.locator_textbox.clear()
        
        # Clear all lists
        self.c40_list = []
        self.master_sn_list = []
        self.child_sn_list = []
        
        # Clear child parts
        while self.child_parts_layout.count():
            item = self.child_parts_layout.takeAt(0)
            lay = item.layout() if item is not None else None
            if lay:
                while lay.count():
                    it = lay.takeAt(0)
                    w = it.widget() if it is not None else None
                    if w:
                        w.deleteLater()
        self.child_part_counter = 0
        self._refresh_sn_badges()
        try:
            self.inline_child_sn_tabs.programmatic_update()
        except Exception:
            pass
        
        # Hide master part fields
        self.master_part_label.hide()
        self.master_part_textbox.hide()
        self.master_sn_list_button.hide()
        self.locator_label.hide()
        self.locator_textbox.hide()
        
        # Clear status message
        self.status_label.clear()
        
        # Reset counter
        self.total_builds = 0
        self.counter_label.setText('Total Builds: 0')
        
        # Remove change button if it exists
        if hasattr(self, 'change_lpn_button'):
            self.change_lpn_button.setParent(None)

    def start_over(self):
        try:
            reply = QMessageBox.question(self, 'Warning', 'This will delete all unsaved CSV data and will start over. Do you want to proceed?',
                                         QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
            if reply == QMessageBox.Yes:
                self.clear_data_fields()
                self.close()
                new_dialog = RepackGUI()
                new_dialog.exec_()
        except Exception as e:
            print(f"Error starting over: {e}")

    def preview_csv(self):
        try:
            csv_data = CSV_Writer_Repack.read_csv(self.temp_csv_file)
            dialog = QDialog(self)
            dialog.setWindowTitle('Preview CSV')
            dialog.setFixedSize(600, 400)
            layout = QVBoxLayout(dialog)
            table = QTableWidget(dialog)
            table.setRowCount(len(csv_data))
            table.setColumnCount(3)
            table.setHorizontalHeaderLabels(["PROMPT", "KEY", "DATA"])
            for row_idx, row_data in enumerate(csv_data): # Start from row 0 to include headers
                for col_idx, col_data in enumerate(row_data[1:4]):
                    table.setItem(row_idx, col_idx, QTableWidgetItem(col_data))
            layout.addWidget(table)
            ok_button = QPushButton('OK', dialog)
            ok_button.clicked.connect(dialog.accept)
            layout.addWidget(ok_button)
            dialog.exec_()
        except Exception as e:
            print(f"Error previewing CSV: {e}")

    def on_finish_csv(self):
        try:
            # Check if the CSV is empty (only has headers)
            with open(self.temp_csv_file.name, 'r') as file:
                csv_data = list(csv.reader(file))
                # If CSV only has the header row, show warning message and return
                if len(csv_data) <= 1:  # Only header row exists
                    QMessageBox.warning(self, "CSV is Empty", 
                                     "CSV is currently blank. Fill out the information and add it via 'Add to CSV' and then 'Save As'.")
                    return
            
            # Check if the last row has "UPARROW" in the PROMPT column
            if len(csv_data) > 1 and csv_data[-1][1].strip() == "UPARROW":
                # Remove the last row and rewrite the CSV
                csv_data.pop()
                with open(self.temp_csv_file.name, 'w', newline='') as rewrite_file:
                    csv_writer = csv.writer(rewrite_file)
                    for row in csv_data:
                        csv_writer.writerow(row)
                # Adjust row counter since we removed a row
                self.row_counter -= 1
        
            CSV_Writer_Repack.append_finished(self.temp_csv_file, self.row_counter)
            self.row_counter += 1
            options = QFileDialog.Options()
            options |= QFileDialog.DontUseNativeDialog
            file_name, _ = QFileDialog.getSaveFileName(self, "Save CSV As", get_default_save_path_for_csv_writer(""), "CSV (MS-DOS) (*.csv);;All Files (*)", options=options)
            if file_name:
                if not file_name.endswith('.csv'):
                    file_name += '.csv'
                CSV_Writer_Repack.save_csv(file_name, self.temp_csv_file, self.csv_headers)
                
                # Prompt the user with the dialog after saving
                msg_box = QMessageBox()
                msg_box.setWindowTitle('CSV Saved')
                msg_box.setText('Would you like to start a new CSV or continue adding to the existing one?')
                new_csv_button = msg_box.addButton('New CSV', QMessageBox.ActionRole)
                continue_button = msg_box.addButton('Continue', QMessageBox.ActionRole)
                msg_box.exec_()
                
                if msg_box.clickedButton() == new_csv_button:
                    self.clear_data_fields()
                    self.close()
                    new_dialog = RepackGUI()
                    new_dialog.exec_()
                elif msg_box.clickedButton() == continue_button:
                    # Remove the "FINISHED" row
                    with open(self.temp_csv_file.name, 'r') as file:
                        lines = file.readlines()
                    with open(self.temp_csv_file.name, 'w') as file:
                        for line in lines:
                            if "FINISHED" not in line:
                                file.write(line)
        except Exception as e:
            print(f"Error finishing CSV: {e}")

    def handle_text_change(self):
        if self.from_lpn_textbox.text():
            self.from_lpn_textbox.setStyleSheet("color: white;")
        else:
            self.from_lpn_textbox.setStyleSheet("color: #00FF00;")  # Brighter green

    def toggle_from_lpn_editing(self, state):
        if state == Qt.Checked:  # type: ignore[attr-defined]
            self.from_lpn_textbox.setReadOnly(True)
            self.from_lpn_textbox.setStyleSheet("color: grey;")
            self.from_lpn_textbox.clear()
        else:
            self.from_lpn_textbox.setReadOnly(False)
            if self.from_lpn_textbox.text():
                self.from_lpn_textbox.setStyleSheet("color: white;")
            else:
                self.from_lpn_textbox.setStyleSheet("color: #00FF00;")  # Brighter green
            self.from_lpn_textbox.setPlaceholderText("Check the box if repacking from a locator")

    def open_paste_multiple_dialog(self):
        dialog = QDialog(self)
        dialog.setWindowTitle("Paste Multiple Child Parts")
        dialog.setModal(True)

        layout = QVBoxLayout(dialog)

        # Create tab widget with Part Numbers and Quantities tabs
        tab_widget = QTabWidget()

        # Part Numbers tab
        part_tab = QWidget()
        part_layout = QVBoxLayout(part_tab)
        part_layout.addWidget(QLabel("Paste child part numbers below (one per line):"))
        self.part_text = QTextEdit()
        self.part_text.setPlaceholderText("Paste child part numbers here...")
        part_layout.addWidget(self.part_text)
        tab_widget.addTab(part_tab, "Part Numbers")

        # Quantities tab
        qty_tab = QWidget()
        qty_layout = QVBoxLayout(qty_tab)
        qty_layout.addWidget(QLabel("Paste quantities below (one per line, numbers only):"))
        self.qty_text = QTextEdit()
        self.qty_text.setPlaceholderText("Paste quantities here...")
        qty_layout.addWidget(self.qty_text)
        tab_widget.addTab(qty_tab, "Quantities")

        layout.addWidget(tab_widget)

        # Dialog buttons
        btns = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        layout.addWidget(btns)

        btns.accepted.connect(lambda: self._apply_tabbed_paste(dialog))
        btns.rejected.connect(dialog.reject)

        dialog.exec_()

    def _apply_tabbed_paste(self, dialog: QDialog):
        """Apply data from both tabs to the child parts list."""
        # Gather lines
        part_lines = [line.strip() for line in self.part_text.toPlainText().splitlines() if line.strip()]
        qty_lines = [line.strip() for line in self.qty_text.toPlainText().splitlines() if line.strip()]

        if not part_lines and not qty_lines:
            QMessageBox.warning(self, "Warning", "No data pasted!")
            return

        # Validate part prefixes
        invalid_parts = [p for p in part_lines if any(p.startswith(prefix) for prefix in ['C40-', 'L40-', 'RC40-', 'BTS40-'])]
        if invalid_parts:
            QMessageBox.warning(self, "Warning", f"The following parts are invalid (cannot start with C40-, L40-, RC40-, or BTS40-):\n\n{', '.join(invalid_parts)}")
            return

        # Check for duplicates within pasted parts
        seen = set()
        duplicates = []
        for p in part_lines:
            if p in seen:
                duplicates.append(p)
            else:
                seen.add(p)
        if duplicates:
            QMessageBox.warning(self, "Warning", f"Duplicate child part numbers found in pasted text: {', '.join(sorted(set(duplicates)))}")
            return

        # Check duplicates against existing parts
        existing_parts = []
        for i in range(self.child_parts_layout.count()):
            item_i = self.child_parts_layout.itemAt(i)
            row_layout = item_i.layout() if item_i is not None else None
            if row_layout and row_layout.itemAt(1):
                it1 = row_layout.itemAt(1)
                part_widget = it1.widget() if it1 is not None else None
                if part_widget:
                    existing = part_widget.text().strip()
                    if existing:
                        existing_parts.append(existing)
        dup_against_existing = [p for p in part_lines if p in existing_parts]
        if dup_against_existing:
            QMessageBox.warning(self, "Warning", f"The following parts already exist in the list: {', '.join(sorted(set(dup_against_existing)))}")
            return

        # Add parts as new rows
        for part in part_lines:
            self.add_child_part()
            last_index = self.child_parts_layout.count() - 1
            if last_index >= 0:
                last_item = self.child_parts_layout.itemAt(last_index)
                if last_item is not None:
                    last_layout = last_item.layout()
                    if last_layout is not None:
                        part_item = last_layout.itemAt(1)
                        if part_item is not None:
                            part_widget = part_item.widget()
                            if part_widget is not None:
                                part_widget.setText(part)

        # Apply quantities (add rows if needed)
        for i, qty_text in enumerate(qty_lines):
            try:
                qty = int(qty_text)
                if qty < 0:
                    continue
            except ValueError:
                continue
            if i >= self.child_parts_layout.count():
                self.add_child_part()
            row_item = self.child_parts_layout.itemAt(i)
            if row_item is not None:
                row_layout = row_item.layout()
                if row_layout is not None:
                    qty_item = row_layout.itemAt(3)
                    if qty_item is not None:
                        qty_field = qty_item.widget()
                        if qty_field is not None:
                            qty_field.setText(str(qty))

        dialog.accept()

    # ---------- Helpers for SN pop-outs and badges ----------
    def _get_row_index_for_widget(self, widget) -> Optional[int]:
        for i in range(self.child_parts_layout.count()):
            item_i = self.child_parts_layout.itemAt(i)
            lay = item_i.layout() if item_i is not None else None
            if not lay:
                continue
            # Check if widget is in this row layout
            for j in range(lay.count()):
                it = lay.itemAt(j)
                if it and it.widget() is widget:
                    return i
        return None

    def _create_or_get_sn_badge(self, idx: int) -> Optional[QLabel]:
        item_idx = self.child_parts_layout.itemAt(idx)
        if item_idx is None:
            return None
        lay = item_idx.layout()
        if not lay:
            return None
        # Find existing badge after SNs button
        for j in range(lay.count()):
            item_j = lay.itemAt(j)
            w = item_j.widget() if item_j is not None else None
            if isinstance(w, QPushButton) and w.text() == 'SNs':
                # Next position might be the badge
                if j + 1 < lay.count():
                    nxt_item = lay.itemAt(j + 1)
                    nxt = nxt_item.widget() if nxt_item is not None else None
                    if isinstance(nxt, QLabel):
                        return nxt
                # Create badge label
                badge = QLabel('')
                badge.setProperty('sn_badge', True)
                badge.setStyleSheet('color: lightgray;')
                try:
                    lay.insertWidget(j + 1, badge)  # type: ignore[attr-defined]
                except Exception:
                    lay.addWidget(badge)
                return badge
        return None

    def _compute_expected_sns_for_row(self, idx: int):
        try:
            builds_txt = self.question3_textbox.text().strip()
            builds = int(builds_txt) if builds_txt.isdigit() else None
            item_idx = self.child_parts_layout.itemAt(idx)
            lay = item_idx.layout() if item_idx is not None else None
            if not lay:
                return None
            it = lay.itemAt(3)
            qty_widget = it.widget() if it is not None else None
            qty_txt = qty_widget.text().strip() if qty_widget else ''
            qty = int(qty_txt) if qty_txt.isdigit() else None
            if builds is None or qty is None:
                return None
            return builds * qty
        except Exception:
            return None

    def update_sn_badge(self, idx: int):
        badge = self._create_or_get_sn_badge(idx)
        if badge is None:
            return
        # Only show badge for rows that have SNs list (not None)
        if idx >= len(self.child_sn_list) or self.child_sn_list[idx] is None:
            badge.setText('')
            badge.setStyleSheet('color: lightgray;')
            return
        current = len(self.child_sn_list[idx] or [])
        expected = self._compute_expected_sns_for_row(idx)
        if expected is None:
            badge.setText(f'SNs {current}')
            badge.setStyleSheet('color: lightgray;')
        else:
            badge.setText(f'SNs {current}/{expected}')
            if current == expected:
                badge.setStyleSheet('color: #00ff00;')
            else:
                badge.setStyleSheet('color: #ffd700;')

    def _refresh_sn_badges(self):
        try:
            for i in range(self.child_parts_layout.count()):
                self.update_sn_badge(i)
        except Exception:
            pass
        
    def process_pasted_parts(self, pasted_text, dialog, text_edit):
        """Process the pasted text and add child parts"""
        text = pasted_text
        if not text.strip():
            QMessageBox.warning(self, "Warning", "No data pasted!")
            return
            
        # Split text into lines and remove empty lines
        parts = [line.strip() for line in text.split('\n') if line.strip()]
        
        if not parts:
            QMessageBox.warning(self, "Warning", "No valid parts found in pasted text!")
            return

        # Check for duplicates in pasted text
        seen = set()
        duplicates = []
        duplicate_indices = []  # Store indices of duplicate lines
        first_occurrences = set()  # Store the first occurrence of each part
        parts_with_duplicates = set()  # Store parts that have duplicates
        
        # First pass: identify duplicates and their first occurrences
        for i, part in enumerate(parts):
            if part in seen:
                duplicates.append(part)
                duplicate_indices.append(i)
                parts_with_duplicates.add(part)
            else:
                seen.add(part)
                first_occurrences.add(i)

        if duplicates:
            # Create formatted text with first occurrences in green (only if they have duplicates) and duplicates in red
            formatted_text = ""
            for i, part in enumerate(parts):
                if i in duplicate_indices:
                    formatted_text += f'<span style="color: red;">{part}</span><br>'
                elif i in first_occurrences and part in parts_with_duplicates:
                    formatted_text += f'<span style="color: green;">{part}</span><br>'
                else:
                    formatted_text += f'{part}<br>'
            
            text_edit.setHtml(formatted_text)
            QMessageBox.warning(self, "Warning", f"Duplicate child part numbers found in pasted text: {', '.join(duplicates)}")
            return

        # Validate parts before adding them
        invalid_parts = [part for part in parts if any(part.startswith(prefix) for prefix in ['C40-', 'L40-', 'RC40-', 'BTS40-'])]
        if invalid_parts:
            # Create formatted text with invalid parts in red
            formatted_text = ""
            for part in parts:
                if any(part.startswith(prefix) for prefix in ['C40-', 'L40-', 'RC40-', 'BTS40-']):
                    formatted_text += f'<span style="color: red;">{part}</span><br>'
                else:
                    formatted_text += f'{part}<br>'
            
            text_edit.setHtml(formatted_text)
            QMessageBox.warning(self, "Warning", f"The following parts are invalid (cannot start with C40-, L40-, RC40-, or BTS40-):\n\n{', '.join(invalid_parts)}")
            return
            
        # Check for duplicates with existing parts
        existing_parts = []
        for i in range(self.child_parts_layout.count()):
            item_i = self.child_parts_layout.itemAt(i)
            child_part_layout = item_i.layout() if item_i is not None else None
            part_number = ''
            if child_part_layout:
                it1 = child_part_layout.itemAt(1)
                w1 = it1.widget() if it1 is not None else None
                if w1:
                    part_number = w1.text().strip()
            if part_number:
                existing_parts.append(part_number)

        duplicates = []
        duplicate_indices = []
        for i, part in enumerate(parts):
            if part in existing_parts:
                duplicates.append(part)
                duplicate_indices.append(i)

        if duplicates:
            # Create formatted text with duplicates in red
            formatted_text = ""
            for i, part in enumerate(parts):
                if i in duplicate_indices:
                    formatted_text += f'<span style="color: red;">{part}</span><br>'
                else:
                    formatted_text += f'{part}<br>'
            
            text_edit.setHtml(formatted_text)
            QMessageBox.warning(self, "Warning", f"The following parts already exist in the list: {', '.join(duplicates)}")
            return
            
        # If we get here, the input is valid
        # Add new child parts without clearing existing ones
        for part in parts:
            self.add_child_part()
            # Get the last added child part layout
            last_item = self.child_parts_layout.itemAt(self.child_parts_layout.count() - 1)
            last_layout = last_item.layout() if last_item is not None else None
            # Set the part number
            if last_layout:
                it1 = last_layout.itemAt(1)
                w1 = it1.widget() if it1 is not None else None
                if w1:
                    w1.setText(part)
            
        dialog.accept()

    def validate_from_lpn(self, text):
        """Validate From LPN format and highlight if invalid"""
        if not self.repack_from_locator_checkbox.isChecked():
            if text and not any(text.startswith(prefix) for prefix in ['C40-', 'L40-', 'RC40-', 'BTS40-']):
                self.status_label.setText('<span style="color: red;">From LPN must start with C40-, L40-, RC40-, or BTS40-</span>')
                self.from_lpn_textbox.setStyleSheet("color: red;")
                self.from_lpn_label.setStyleSheet("color: red;")
                return False
            else:
                self.from_lpn_textbox.setStyleSheet("")
                self.from_lpn_label.setStyleSheet("")
                self.status_label.clear()  # Clear the error message when valid
        return True

    def closeEvent(self, event):
        """Handle the window close event"""
        # Close all list dialogs
        for dialog in self.list_dialogs.values():
            if dialog and dialog.isVisible():
                dialog.close()
        event.accept()