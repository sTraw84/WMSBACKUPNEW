from PyQt5.QtWidgets import (
    QDialog,
    QVBoxLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QMessageBox,
    QFileDialog,
    QSplitter,
    QWidget,
)
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont, QIntValidator
from .BaseGUI import BaseDialog
from .InlineEditors import CollapsibleListEditor
from program_files.csv_writers import CSV_Writer_AttributeLabels
from ..utils.file_paths import get_default_save_path_for_csv_writer

def is_full_four_segment(part_text: str) -> bool:
    return part_text.count('.') == 3 and all(seg.strip() for seg in part_text.split('.'))


def first_segment(part_text: str) -> str:
    return part_text.split('.')[0].strip() if part_text else ''


class AttributeLabelsGUI(BaseDialog):
    def __init__(self):
        super().__init__()
        self.sn_list = []
        self._side_panel_width = 260
        self._min_left_width = 320
        self._min_side_panel_width = 200
        self._left_before_side_panel = None
        self.init_ui()

    def init_ui(self):
        self.setWindowTitle('Attribute Labels')
        self.resize(540, 320)
        self.setMinimumSize(500, 300)

        self.main_layout = QVBoxLayout(self)

        self.splitter = QSplitter(Qt.Horizontal, self)  # type: ignore[attr-defined]
        self.splitter.setHandleWidth(1)
        self.main_layout.addWidget(self.splitter)

        self.left_container = QWidget(self.splitter)
        self.left_layout = QVBoxLayout(self.left_container)
        self.left_layout.setContentsMargins(0, 0, 0, 0)
        self.left_layout.setSpacing(6)

        top_bar = QWidget(self.left_container)
        self.top_layout = QHBoxLayout(top_bar)
        self.top_layout.setContentsMargins(0, 0, 0, 0)
        self.status_label = QLabel('', top_bar)
        self.top_layout.addWidget(self.status_label)
        self.toggle_side_panel_button = QPushButton('Inline Lists ▶', top_bar)
        self.toggle_side_panel_button.setToolTip('Show or hide the inline list panel')
        self.toggle_side_panel_button.setMinimumWidth(
            self.toggle_side_panel_button.sizeHint().width()
        )
        self.toggle_side_panel_button.clicked.connect(self.toggle_side_panel)
        self.top_layout.addWidget(self.toggle_side_panel_button)
        self.left_layout.addWidget(top_bar)

        title = QLabel('Attribute Labels')
        title.setFont(QFont('Arial', 18, weight=QFont.Bold))
        title.setStyleSheet('color: #CCCCCC;')
        title.setAlignment(Qt.AlignCenter)
        self.left_layout.addWidget(title)
        part_row = QHBoxLayout()
        part_label = QLabel('Part#:', self)
        self.part_edit = QLineEdit(self)
        self.part_edit.setPlaceholderText('Enter full 4-segment part# or single segment (e.g., DCS-7800R3A-36DM2-LC or DCS-7800R3A-36DM2-LC.ACTUAL.26129.MSN/CSCO)')
        part_row.addWidget(part_label)
        part_row.addWidget(self.part_edit)
        self.left_layout.addLayout(part_row)
        select_row = QHBoxLayout()
        select_label = QLabel('Part# Selection:', self)
        self.select_edit = QLineEdit(self)
        self.select_edit.setValidator(QIntValidator(0, 9999, self))
        self.select_edit.setPlaceholderText('Enter selection number (Insert 0 if no selection is required)')
        select_row.addWidget(select_label)
        select_row.addWidget(self.select_edit)
        info_btn = QPushButton("?")
        info_btn.setFixedWidth(28)
        info_btn.setToolTip("What is Part# Selection?")
        info_btn.clicked.connect(self.show_selection_info)
        select_row.addWidget(info_btn)
        self.left_layout.addLayout(select_row)
        sn_row = QHBoxLayout()
        self.sn_button = QPushButton('SN List', self)
        self.sn_button.clicked.connect(self.open_sn_list)
        sn_row.addWidget(self.sn_button)
        self.left_layout.addLayout(sn_row)
        action_row = QHBoxLayout()
        export_btn = QPushButton('Generate CSV', self)
        export_btn.clicked.connect(self.generate_csv)
        cancel_btn = QPushButton('Cancel', self)
        cancel_btn.clicked.connect(self.close)
        action_row.addWidget(export_btn)
        action_row.addWidget(cancel_btn)
        self.left_layout.addLayout(action_row)
        self.left_layout.addStretch()

        self.side_panel = QWidget(self.splitter)
        self.side_layout = QVBoxLayout(self.side_panel)
        self.side_layout.setContentsMargins(6, 6, 6, 6)
        self.side_layout.setSpacing(8)

        self.inline_sn_editor = CollapsibleListEditor(
            self,
            title='SN List (Inline)',
            attr_name='sn_list',
        )
        self.side_layout.addWidget(self.inline_sn_editor)
        self.inline_sn_editor.apply_button.clicked.connect(self._refresh_inline_editors)
        self.side_layout.addStretch()

        self.splitter.addWidget(self.left_container)
        self.splitter.addWidget(self.side_panel)
        self.splitter.setStretchFactor(0, 1)
        self.splitter.setStretchFactor(1, 0)
        self.splitter.setSizes([1, 0])

        self._refresh_inline_editors()
        self.finalize_initial_size(extra_width=120)
        self._update_side_panel_button()

    def show_selection_info(self):
        info_text = (
            "When a part number is entered and WMS presents a menu to select the full 4-segment part, "
            "the Part# Selection box is for entering the number corresponding to the correct part from that menu. "
            "If no selection is required, enter 0.\n\n"
            "Example menu:\n"
            "  Action                                    \n"
            "1<DCS-7500R2-36CQ-LC.ACTUAL.26129.MSN/CSCO >                \n"
            "2<DCS-7500R2-36CQ-LC.ACTUAL.26129.CITI     >\n"
            "3<DCS-7500R2-36CQ-LC.ACTUAL.26129.FISV     >\n"
            "4<DCS-7500R2-36CQ-LC.ACTUAL.26129.AMZN     >\n"
            "5<DCS-7500R2-36CQ-LC.NC.26129.MSN/CSCO     >\n"
            "6<DCS-7500R2-36CQ-LC.ACTUAL.1886569.UBS    >\n"
            "7<DCS-7500R2-36CQ-LC.ACTUAL.26129.FCBK     >\n"
            "8<DCS-7500R2-36CQ-LC.ACTUAL.26129.WEBSRVRTL>\n"
            "9<DCS-7500R2-36CQ-LC.ACTUAL.26129.MSN/MSIT >"
        )
        QMessageBox.information(self, "Part# Selection Help", info_text)

    def open_sn_list(self):
        self.open_sn_list_inline()

    def open_sn_list_inline(self):
        try:
            if not hasattr(self, 'inline_sn_editor'):
                return
            self._ensure_side_panel_visible()
            editor = self.inline_sn_editor
            if not editor.container.isVisible():
                editor.container.setVisible(True)
                editor._update_toggle_icon()
            editor.programmatic_update()
            editor.editor.setFocus()
        except Exception:
            pass

    def _update_side_panel_button(self) -> None:
        try:
            sizes = self.splitter.sizes() if hasattr(self, 'splitter') else []
            if sizes and len(sizes) >= 2 and sizes[1] > 0:
                self.toggle_side_panel_button.setText('Inline Lists ◀')
            else:
                self.toggle_side_panel_button.setText('Inline Lists ▶')
        except Exception:
            pass

    def _open_side_panel(self) -> None:
        if not hasattr(self, 'splitter'):
            return
        sizes = self.splitter.sizes()
        if len(sizes) < 2:
            return
        left_width = max(sizes[0], self._min_left_width)
        desired_right = max(self._min_side_panel_width, self._side_panel_width)
        self._left_before_side_panel = left_width
        self.resize(self.width() + desired_right, self.height())
        self.splitter.setSizes([left_width, desired_right])

    def _collapse_side_panel(self) -> None:
        if not hasattr(self, 'splitter'):
            return
        sizes = self.splitter.sizes()
        if len(sizes) < 2:
            return
        right_width = sizes[1]
        if right_width <= 0:
            return
        target_width = max(self.minimumWidth(), self.width() - right_width)
        self.resize(target_width, self.height())
        left_target = (
            self._left_before_side_panel
            if self._left_before_side_panel is not None
            else sizes[0]
        )
        left_target = max(self._min_left_width, min(left_target, target_width))
        self.splitter.setSizes([left_target, 0])
        self._left_before_side_panel = None

    def toggle_side_panel(self) -> None:
        try:
            if not hasattr(self, 'splitter'):
                return
            sizes = self.splitter.sizes()
            if len(sizes) < 2:
                return
            if sizes[1] == 0:
                self._open_side_panel()
            else:
                self._collapse_side_panel()
            self._update_side_panel_button()
        except Exception:
            pass

    def _ensure_side_panel_visible(self) -> None:
        try:
            sizes = self.splitter.sizes()
            if len(sizes) < 2:
                return
            if sizes[1] == 0:
                self._open_side_panel()
                self._update_side_panel_button()
        except Exception:
            pass

    def _refresh_inline_editors(self) -> None:
        if hasattr(self, 'inline_sn_editor'):
            self.inline_sn_editor.programmatic_update()
        if hasattr(self, 'sn_button'):
            count = len(self.sn_list)
            self.sn_button.setText('SN List' if count == 0 else f'SN List ({count})')

    def generate_csv(self):
        part_input = self.part_edit.text().strip()
        selection_num = self.select_edit.text().strip()
        if not part_input:
            QMessageBox.warning(self, 'Invalid Part#', 'Please enter a part number (single-segment or full 4-segment).')
            return
        # Normalize trailing dots (allow users to enter a single segment with a trailing dot)
        part_full = part_input.rstrip('.')
        # Accept either a full 4-segment part or a single-segment part (no dots)
        if not (is_full_four_segment(part_full) or (part_full.count('.') == 0 and part_full.strip())):
            QMessageBox.warning(self, 'Invalid Part#', 'Please enter either a full 4-segment part# (e.g., ISR4351/K9.ACTUAL.324.MSN/CSCO) or a single-segment part# (e.g., DCS-7800R3A-36DM2-LC).')
            return
        if not selection_num or not selection_num.isdigit():
            QMessageBox.warning(self, 'Invalid Selection',
                'Please enter a valid number for Part# Selection. Insert 0 if no selection is required.')
            return
        if not self.sn_list:
            QMessageBox.warning(self, 'No SNs', 'Please add at least one serial number via SN List before proceeding.')
            return
        item_value = first_segment(part_full)
        send_value = selection_num
        file_path, _ = QFileDialog.getSaveFileName(self, 'Save CSV', get_default_save_path_for_csv_writer('Asset_Label.csv'), 'CSV files (*.csv)')
        if not file_path:
            return
        if not file_path.lower().endswith('.csv'):
            file_path += '.csv'
        try:
            CSV_Writer_AttributeLabels.save_attribute_csv(file_path, item_value, part_full, self.sn_list, send_value)
            QMessageBox.information(self, 'Success', f'CSV saved: {file_path}')
            self.close()
        except Exception as e:
            QMessageBox.critical(self, 'Error', f'Failed to save CSV: {str(e)}')
