# MES Order Extractor

A PyQt5 utility that attaches to your already-authenticated MES browser session (via Playwright) and exports the currently filtered orders into an Excel workbook.

## Prerequisites

1. **Python dependencies**
   ```bash
   pip install -r dev-tools/requirements.txt
   playwright install
   ```

2. **Start your browser with remote debugging enabled**
   - **Google Chrome**
     ```bash
     "C:\Program Files\Google\Chrome\Application\chrome.exe" --remote-debugging-port=9222
     ```
   - **Microsoft Edge**
     ```bash
     "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe" --remote-debugging-port=9222
     ```

   Make sure all existing instances of the browser are closed before launching it with the command above. After launch, sign in to the MES portal manually and filter the orders as needed.

## Usage

1. Run the extractor GUI:
   ```bash
   python -m program_files.guis.MES_Extractor
   ```
2. Adjust the connection settings if you are using a different port, tab title, or custom CSS selectors.
3. Click **Export Orders to Excel**, choose a destination `.xlsx` file, and wait for the log to report success.

## Tips

- The **Tab title contains** field is matched case-insensitively. Keep the keyword short (e.g., `MES`).
- If your order table requires different selectors, update the **Row selector** (rows to capture) or **Cell selector** (cells within each row).
- Leave **Treat first row as header** enabled when the first row contains column names.
- If no data is captured, check the log pane for detailed error messages and adjust the selectors accordingly.
