import csv

def write_csv_headers(file):
    headers = ["NUMBER", "PROMPT", "KEY", "DATA"]
    writer = csv.writer(file, delimiter=',')
    writer.writerow(headers)


def append_to_csv(temp_csv_file, row_counter, c40_list, master_sn_list, child_sn_list, from_lpn_textbox, master_part_textbox, question1_checkbox, child_parts_layout, num_builds):
    from_lpn = from_lpn_textbox.text().strip() if not from_lpn_textbox.isReadOnly() else None
    master_part = master_part_textbox.text().strip() if master_part_textbox.isVisible() else None
    with open(temp_csv_file.name, 'a', newline='') as file:
        writer = csv.writer(file, delimiter=',')
        for i in range(num_builds):
            if from_lpn:
                writer.writerow([row_counter, "From LPN   :", "FromLPN", from_lpn])
                row_counter += 1
                from_lpn = None
            writer.writerow([row_counter, "To LPN     :", "C40", c40_list[i % len(c40_list)] if c40_list else f"C40-{7812765 + i}"])
            row_counter += 1
            if question1_checkbox.isChecked() and master_part:
                writer.writerow([row_counter, "Item       >", f"MasterPart1", master_part])
                row_counter += 1
                writer.writerow([row_counter, "Qty        :", "QuantityM1", 1])
                row_counter += 1
                writer.writerow([row_counter, "SN         >", "SerialM1", str(master_sn_list[i % len(master_sn_list)]) if master_sn_list else f"0F36XMQ24423K{i+3}"])
                row_counter += 1
                writer.writerow([row_counter, "<Save/Next>", "BLANK", ""])
                row_counter += 1
            for j in range(child_parts_layout.count()):
                child_part_layout = child_parts_layout.itemAt(j).layout()
                writer.writerow([row_counter, "Item       >", f"ChildPart{j+1}:", child_part_layout.itemAt(1).widget().text().strip()])
                row_counter += 1
                writer.writerow([row_counter, "Qty        :", f"QuantityP{j+1}:", child_part_layout.itemAt(3).widget().text().strip()])
                row_counter += 1
                if child_sn_list[j]:
                    sn_count = int(child_part_layout.itemAt(3).widget().text().strip())
                    sn_list = child_sn_list[j][i*sn_count:(i+1)*sn_count]
                    writer.writerow([row_counter, "SN         >", f"SerialP{j+1}:", ", ".join(map(str, sn_list))])
                    row_counter += 1
                writer.writerow([row_counter, "<Save/Next>", "BLANK", ""])
                row_counter += 1
            writer.writerow([row_counter, "UPARROW", "UPARROW", ""])
            row_counter += 1
    return row_counter


def read_csv(temp_csv_file):
    with open(temp_csv_file.name, 'r') as file:
        reader = csv.reader(file)
        return list(reader)


def append_finished(temp_csv_file, row_counter):
    with open(temp_csv_file.name, 'a', newline='') as file:
        writer = csv.writer(file, delimiter=',')
        writer.writerow([row_counter, "FINISHED", "", ""])


def save_csv(file_name, temp_file):
    try:
        rows = []
        with open(temp_file.name, 'r') as temp_file_r:
            reader = csv.reader(temp_file_r)
            rows = list(reader)
        if rows:
            last_row_number = int(rows[-1][0]) if rows[-1][0] else 0
            rows.append([str(last_row_number + 1), "SPLIT", "", ""])
        with open(file_name, 'w', newline='') as file:
            writer = csv.writer(file, delimiter=',')
            for row in rows:
                writer.writerow(row)
        return True
    except Exception as e:
        print(f"Error saving CSV: {e}")
        return False
