import csv

def write_csv_headers(file):
    headers = ['NUMBER', 'PROMPT', 'KEY', 'DATA']
    writer = csv.writer(file)
    writer.writerow(headers)


def append_to_csv(
    temp_csv_file,
    row_counter,
    c40_list,
    master_sn_list,
    child_sn_list,
    from_lpn_textbox,
    master_part_textbox,
    question1_checkbox,
    child_parts_layout,
    num_builds,
    repack_from_locator_checkbox,
):
    """Append repack rows to the temporary CSV file.

    Mirrors the legacy implementation while working with the refactored module
    layout. Handles both master-part (Yes path) and child-part (No path)
    workflows, including optional locator handling and serial numbers.
    """

    with open(temp_csv_file.name, 'a', newline='') as file:
        writer = csv.writer(file, delimiter=',')

        def safe_child_sn(child_index):
            if not child_sn_list or child_index >= len(child_sn_list):
                return []
            return child_sn_list[child_index] or []

        def child_layout(index):
            item = child_parts_layout.itemAt(index)
            return item.layout() if item else None

        def get_child_part(layout):
            return layout.itemAt(1).widget().text().strip()

        def get_child_qty(layout):
            return int(layout.itemAt(3).widget().text().strip())

        def child_lpn_value():
            if repack_from_locator_checkbox.isChecked():
                return ""
            return from_lpn_textbox.text().strip()

        def next_c40_name(idx):
            if c40_list and idx < len(c40_list):
                return c40_list[idx]
            return f"C40-{idx + 1}"

        # Handle "Yes" menu data (master part included)
        if question1_checkbox.isChecked():
            master_part = master_part_textbox.text().strip()

            for build_index in range(num_builds):
                c40_name = next_c40_name(build_index)

                writer.writerow([row_counter, "From LPN  :", "BLANK", ""])
                row_counter += 1
                writer.writerow([row_counter, "To LPN    :", "C40", c40_name])
                row_counter += 1
                writer.writerow([row_counter, "Locator   :", "BLANK", ""])
                row_counter += 1
                writer.writerow([row_counter, "Item      :", "MasterPart", master_part])
                row_counter += 1
                writer.writerow([row_counter, "Quantity  :", "MasterQty", "1"])
                row_counter += 1

                if master_sn_list and build_index < len(master_sn_list):
                    writer.writerow([
                        row_counter,
                        "Serial # of #:",
                        "MasterSN",
                        master_sn_list[build_index],
                    ])
                    row_counter += 1

                writer.writerow([row_counter, "<Done>", "BLANK", ""])
                row_counter += 1

                # Child parts for this C40 build
                for child_index in range(child_parts_layout.count()):
                    layout = child_layout(child_index)
                    if layout is None:
                        continue

                    part_number = get_child_part(layout)
                    quantity = get_child_qty(layout)
                    child_lpn = child_lpn_value()

                    sns_for_child = safe_child_sn(child_index)
                    sns_per_c40 = quantity
                    start = build_index * sns_per_c40
                    end = start + sns_per_c40
                    current_sns = sns_for_child[start:end]

                    writer.writerow([row_counter, "From LPN  :", "ChildLPN", child_lpn])
                    row_counter += 1
                    writer.writerow([row_counter, "To LPN    :", "C40", c40_name])
                    row_counter += 1
                    writer.writerow([row_counter, "Locator   :", "BLANK", ""])
                    row_counter += 1
                    writer.writerow([row_counter, "Item      :", "ChildPart", part_number])
                    row_counter += 1
                    writer.writerow([
                        row_counter,
                        "Quantity  :",
                        "ChildQty",
                        str(quantity),
                    ])
                    row_counter += 1

                    if current_sns:
                        writer.writerow([
                            row_counter,
                            "Serial # of #:",
                            "ChildSN",
                            ", ".join(current_sns),
                        ])
                        row_counter += 1

                    writer.writerow([row_counter, "<Done>", "BLANK", ""])
                    row_counter += 1

        # Handle "No" menu data (child parts only)
        else:
            child_lpn = child_lpn_value()

            for build_index in range(num_builds):
                c40_name = next_c40_name(build_index)

                for child_index in range(child_parts_layout.count()):
                    layout = child_layout(child_index)
                    if layout is None:
                        continue

                    part_number = get_child_part(layout)
                    quantity = get_child_qty(layout)
                    sns_for_child = safe_child_sn(child_index)
                    sns_per_c40 = quantity
                    start = build_index * sns_per_c40
                    end = start + sns_per_c40
                    current_sns = sns_for_child[start:end]

                    writer.writerow([row_counter, "From LPN  :", "ChildLPN", child_lpn])
                    row_counter += 1
                    writer.writerow([row_counter, "To LPN    :", "C40", c40_name])
                    row_counter += 1
                    writer.writerow([row_counter, "Locator   :", "BLANK", ""])
                    row_counter += 1
                    writer.writerow([row_counter, "Item      :", "ChildPart", part_number])
                    row_counter += 1
                    writer.writerow([
                        row_counter,
                        "Quantity  :",
                        "ChildQty",
                        str(quantity),
                    ])
                    row_counter += 1

                    if current_sns:
                        writer.writerow([
                            row_counter,
                            "Serial # of #:",
                            "ChildSN",
                            ", ".join(current_sns),
                        ])
                        row_counter += 1

                    writer.writerow([row_counter, "<Done>", "BLANK", ""])
                    row_counter += 1

    return row_counter


def read_csv(temp_csv_file):
    with open(temp_csv_file.name, 'r') as file:
        reader = csv.reader(file)
        return list(reader)


def append_finished(temp_csv_file, row_counter):
    with open(temp_csv_file.name, 'a', newline='') as file:
        writer = csv.writer(file)
        writer.writerow([row_counter, 'FINISHED', '', ''])


def save_csv(file_name, temp_file, csv_headers=None):
    try:
        rows = []
        with open(temp_file.name, 'r') as temp_file_r:
            reader = csv.reader(temp_file_r)
            rows = list(reader)
        if rows:
            last_row_number = int(rows[-1][0]) if rows[-1][0] else 0
            rows.append([str(last_row_number + 1), "REPACK", "", ""])
        with open(file_name, 'w', newline='') as file:
            writer = csv.writer(file)
            writer.writerows(rows)
        return True
    except Exception as e:
        print('Error saving re-pack CSV:', e)
        return False
