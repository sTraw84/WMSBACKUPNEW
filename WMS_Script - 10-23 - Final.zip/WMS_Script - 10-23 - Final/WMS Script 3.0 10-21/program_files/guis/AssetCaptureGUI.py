import sys
from PyQt5.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QTabWidget, QLineEdit, QDialog, QDialogButtonBox, QTextEdit
)
from PyQt5.QtCore import Qt
import qdarkstyle

class AssetTab(QWidget):
    def __init__(self, index, asset_type="Asset"):
        super().__init__()
        layout = QVBoxLayout(self)
        layout.addWidget(QLabel(f"{asset_type} #{index}"))
        self.asset_type = asset_type
        self.fields = {}
        if asset_type == "Rack":
            self.fields['part'] = QLineEdit(); self.fields['part'].setPlaceholderText("Rack Part Number"); self.fields['part']; layout.addWidget(self.fields['part'])
            self.fields['serial'] = QLineEdit(); self.fields['serial'].setPlaceholderText("Rack Serial Number"); self.fields['serial']; layout.addWidget(self.fields['serial'])
            self.fields['asset'] = QLineEdit(); self.fields['asset'].setPlaceholderText("Rack Asset Number"); self.fields['asset']; layout.addWidget(self.fields['asset'])
            self.fields['msf_part'] = QLineEdit(); self.fields['msf_part'].setPlaceholderText("Rack MSF Part"); self.fields['msf_part']; layout.addWidget(self.fields['msf_part'])
            self.fields['msf_asset'] = QLineEdit(); self.fields['msf_asset'].setPlaceholderText("Rack MSF Asset"); self.fields['msf_asset']; layout.addWidget(self.fields['msf_asset'])
            self.fields['ru'] = QLineEdit(); self.fields['ru'].setPlaceholderText("Device Rack Unit"); layout.addWidget(self.fields['ru'])
        elif asset_type == "Device":
            self.fields['part'] = QLineEdit(); self.fields['part'].setPlaceholderText("Device Part Number"); layout.addWidget(self.fields['part'])
            self.fields['serial'] = QLineEdit(); self.fields['serial'].setPlaceholderText("Device Serial Number"); layout.addWidget(self.fields['serial'])
            self.fields['asset'] = QLineEdit(); self.fields['asset'].setPlaceholderText("Device Asset Number"); layout.addWidget(self.fields['asset'])
            self.fields['msf_part'] = QLineEdit(); self.fields['msf_part'].setPlaceholderText("Device MSF Part"); layout.addWidget(self.fields['msf_part'])
            self.fields['ru'] = QLineEdit(); self.fields['ru'].setPlaceholderText("Device Rack Unit"); layout.addWidget(self.fields['ru'])
        elif asset_type == "PDU":
            self.fields['part'] = QLineEdit(); self.fields['part'].setPlaceholderText("PDU Part Number"); layout.addWidget(self.fields['part'])
            self.fields['serial'] = QLineEdit(); self.fields['serial'].setPlaceholderText("PDU Serial Number"); layout.addWidget(self.fields['serial'])
            self.fields['asset'] = QLineEdit(); self.fields['asset'].setPlaceholderText("PDU Asset"); layout.addWidget(self.fields['asset'])
            self.fields['ru'] = QLineEdit(); self.fields['ru'].setPlaceholderText("PDU Rack Unit"); layout.addWidget(self.fields['ru'])
        elif asset_type == "LinkDevice":
            self.fields['part'] = QLineEdit(); self.fields['part'].setPlaceholderText("Link Device Part Number"); layout.addWidget(self.fields['part'])
            self.fields['serial'] = QLineEdit(); self.fields['serial'].setPlaceholderText("Link Device Serial Number"); layout.addWidget(self.fields['serial'])
            self.fields['asset'] = QLineEdit(); self.fields['asset'].setPlaceholderText("Link Device Asset Number"); layout.addWidget(self.fields['asset'])
        elif asset_type == "LinkNode":
            self.fields['part'] = QLineEdit(); self.fields['part'].setPlaceholderText("Link Device Part Number"); layout.addWidget(self.fields['part'])
            self.fields['serial'] = QLineEdit(); self.fields['serial'].setPlaceholderText("Link Device Serial Number"); layout.addWidget(self.fields['serial'])
            self.fields['asset'] = QLineEdit(); self.fields['asset'].setPlaceholderText("Link Device Asset Number"); layout.addWidget(self.fields['asset'])
        else:
            self.fields['part'] = QLineEdit(); self.fields['part'].setPlaceholderText("Part Number"); layout.addWidget(self.fields['part'])
            self.fields['serial'] = QLineEdit(); self.fields['serial'].setPlaceholderText("Serial Number"); layout.addWidget(self.fields['serial'])
            self.fields['ru'] = QLineEdit(); self.fields['ru'].setPlaceholderText("RU Location"); layout.addWidget(self.fields['ru'])
            self.fields['asset'] = QLineEdit(); self.fields['asset'].setPlaceholderText("Asset Name"); layout.addWidget(self.fields['asset'])
        self.setLayout(layout)

class AssetCaptureGUI(QWidget):
    DEFAULT_PART_NUMBER_TYPE = {
        "MSFTMORPD06.ACTUAL.24739.MSN/CSCO": "Rack",
        "920-9B36F-00RX-8S0.ACTUAL.14956.MSN/CSCO": "Device",
        "920-9N52F-09RB-7S0.ACTUAL.14956.MSN/CSCO": "Device",
        "DCS-7060X6-64PE-B-EHW-F": "Device",
        "MQM9700-NS2R.ACTUAL.21484.MSN/CSCO": "Device",
        "I24A6-AMD-123.ACTUAL.MNMFDJ.LINKEDIN": "LinkDevice",
        "AS -F1114S-RNTR-3M-LC019.ACTUAL.18071.LINKEDIN": "LinkDevice",
        "NS3160A6NODEINSDENSE123-T": "LinkNode",
        "NODEASF1114SRNTR3M-T": "LinkNode",
        "US30008L.ACTUAL.5309.MSN/CSCO": "PDU",
    }
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Asset Capture")
        self.resize(600, 400)
        self.tab_count = 0
        self.tab_types = []  # Track asset type for each tab
        main = QVBoxLayout(self)
        self.tabs = QTabWidget(self)
        main.addWidget(self.tabs)
        btns = QHBoxLayout()
        self.btn_add_rack = QPushButton("+ Rack")
        self.btn_add_rack.setToolTip("Add rack tab")
        self.btn_add_rack.clicked.connect(lambda: self.add_tab(asset_type="Rack"))
        btns.addWidget(self.btn_add_rack)
        self.btn_add_device = QPushButton("+ Device")
        self.btn_add_device.setToolTip("Add device tab")
        self.btn_add_device.clicked.connect(lambda: self.add_tab(asset_type="Device"))
        btns.addWidget(self.btn_add_device)
        self.btn_add_pdu = QPushButton("+ PDU")
        self.btn_add_pdu.setToolTip("Add PDU tab")
        self.btn_add_pdu.clicked.connect(lambda: self.add_tab(asset_type="PDU"))
        btns.addWidget(self.btn_add_pdu)
        self.btn_remove = QPushButton("-")
        self.btn_remove.setToolTip("Remove last asset tab")
        self.btn_remove.clicked.connect(self.remove_tab)
        btns.addWidget(self.btn_remove)
        # LinkDevice / LinkNode buttons
        self.btn_add_linkdevice = QPushButton("+ LinkDevice")
        self.btn_add_linkdevice.setToolTip("Add LinkDevice tab")
        self.btn_add_linkdevice.clicked.connect(lambda: self.add_tab(asset_type="LinkDevice"))
        btns.addWidget(self.btn_add_linkdevice)
        self.btn_add_linknode = QPushButton("+ LinkNode")
        self.btn_add_linknode.setToolTip("Add LinkNode tab")
        self.btn_add_linknode.clicked.connect(lambda: self.add_tab(asset_type="LinkNode"))
        btns.addWidget(self.btn_add_linknode)
        main.addLayout(btns)

        # Paste buttons row
        paste_btns = QHBoxLayout()
        self.btn_paste_part = QPushButton("Paste Part Numbers")
        self.btn_paste_part.clicked.connect(lambda: self.paste_to_field('part'))
        paste_btns.addWidget(self.btn_paste_part)
        self.btn_paste_serial = QPushButton("Paste Serials")
        self.btn_paste_serial.clicked.connect(lambda: self.paste_to_field('serial'))
        paste_btns.addWidget(self.btn_paste_serial)
        self.btn_paste_ru = QPushButton("Paste RU Locations")
        self.btn_paste_ru.clicked.connect(lambda: self.paste_to_field('ru'))
        paste_btns.addWidget(self.btn_paste_ru)
        self.btn_paste_asset = QPushButton("Paste Asset Names")
        self.btn_paste_asset.clicked.connect(lambda: self.paste_to_field('asset'))
        paste_btns.addWidget(self.btn_paste_asset)
        self.btn_paste_msf_part = QPushButton("Paste MSF Part")
        self.btn_paste_msf_part.clicked.connect(lambda: self.paste_to_field('msf_part'))
        paste_btns.addWidget(self.btn_paste_msf_part)
        main.addLayout(paste_btns)

        # Create CSV button
        csv_btns = QHBoxLayout()
        self.btn_create_csv = QPushButton("Create CSV")
        self.btn_create_csv.setStyleSheet("font-weight: bold; background-color: #2d8cf0; color: white;")
        self.btn_create_csv.clicked.connect(self.create_csv)
        csv_btns.addWidget(self.btn_create_csv)
        main.addLayout(csv_btns)

        self.add_tab()

    def create_csv(self):
        from PyQt5.QtWidgets import QFileDialog, QMessageBox
        import os
        from program_files.csv_writers.CSV_Writer_AssetCapture import write_asset_capture_csv
        # Gather and sort all tab data
        pdus = []
        racks = []
        devices = []
        others = []
        
        for i in range(self.tabs.count()):
            tab = self.tabs.widget(i)
            asset = {'Type': tab.asset_type}
            for key, field in tab.fields.items():
                asset[key] = field.text()
            
            # Sort into appropriate list
            if tab.asset_type == "PDU":
                pdus.append(asset)
            elif tab.asset_type == "Rack":
                racks.append(asset)
            elif tab.asset_type == "Device":
                devices.append(asset)
            elif tab.asset_type == "LinkNode":
                devices.append(asset)
            elif tab.asset_type == "LinkDevice":
                devices.append(asset)
            else:
                others.append(asset)
        
        # Combine in desired order: PDUs, Racks, Devices, others
        assets = pdus + racks + devices + others
        
        if not assets:
            QMessageBox.warning(self, "No Data", "No asset data to write.")
            return
            
        root_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        csv_dir = os.path.join(root_dir, "CSV Files")
        file_path, _ = QFileDialog.getSaveFileName(self, "Save Asset CSV", csv_dir, "CSV Files (*.csv)")
        if not file_path:
            return
        try:
            write_asset_capture_csv(file_path, assets)
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to write CSV: {e}")
            return
        QMessageBox.information(self, "Success", f"CSV saved to {file_path}")

    def paste_to_field(self, field):
        dlg = QDialog(self)
        dlg.setWindowTitle(f"Paste {field.title()}s")
        v = QVBoxLayout(dlg)
        v.addWidget(QLabel(f"Paste {field.title()}s, one per line:"))
        txt = QLineEdit() if field == 'asset' else QTextEdit()
        v.addWidget(txt)
        btns = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        v.addWidget(btns)
        def accept():
            lines = txt.text().splitlines() if field == 'asset' else txt.toPlainText().splitlines()
            lines = [l.strip() for l in lines if l.strip()]
            if field == 'part':
                self.tabs.clear()
                self.tab_count = 0
                self.tab_types = []
                for pn in lines:
                    asset_type = self.DEFAULT_PART_NUMBER_TYPE.get(pn, "Rack" if pn == lines[0] else "Asset")
                    self.add_tab(asset_type=asset_type)
                    tab = self.tabs.widget(self.tabs.count()-1)
                    tab.fields['part'].setText(pn)
            else:
                for i, value in enumerate(lines):
                    if i < self.tabs.count():
                        tab = self.tabs.widget(i)
                        if field == 'serial':
                            tab.fields['serial'].setText(value)
                        elif field == 'ru':
                            # Only set 'ru' if it exists for this tab type
                            if 'ru' in tab.fields:
                                tab.fields['ru'].setText(value)
                        elif field == 'asset':
                            tab.fields['asset'].setText(value)
                        elif field == 'msf_part':
                            if 'msf_part' in tab.fields:
                                tab.fields['msf_part'].setText(value)
            dlg.accept()
        btns.accepted.connect(accept)
        btns.rejected.connect(dlg.reject)
        dlg.exec_()

    def add_tab(self, asset_type="Asset"):
        self.tab_count += 1
        tab = AssetTab(self.tab_count, asset_type)
        self.tabs.addTab(tab, f"{asset_type} {self.tab_count}")
        self.tab_types.append(asset_type)

    def remove_tab(self):
        if self.tab_count > 1:
            self.tabs.removeTab(self.tab_count - 1)
            self.tab_count -= 1
            self.tab_types.pop()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    try:
        app.setStyleSheet(qdarkstyle.load_stylesheet(qt_api='pyqt5'))
    except Exception:
        try:
            app.setStyleSheet(qdarkstyle.load_stylesheet_pyqt5())
        except Exception:
            pass
    w = AssetCaptureGUI()
    w.show()
    sys.exit(app.exec_())
