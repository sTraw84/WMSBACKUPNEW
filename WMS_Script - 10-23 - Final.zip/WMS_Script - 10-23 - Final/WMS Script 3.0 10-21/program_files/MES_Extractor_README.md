# MES Extractor Quick Reference

This guide covers the controls you see when launching the MES Extractor from the main Home GUI.

## Main Window Controls

- **Filter File**: JSON payloads stored in `program_files/guis/json files`. The selected file is sent to the MES API to define which work orders are returned. Use **Refresh** after adding new JSONs.
- **Layout**: JSON layout definitions located in `program_files/guis/json files/layouts`. Layouts decide which columns appear in the export, how values are transformed, and which columns get hyperlinks. Use **Refresh** to rescan; **Edit Layout...** opens the layout editor.
- **Paste Cookie String**: Paste the `Cookie` header captured from MES (Chrome/Edge DevTools → Network → Headers). The extractor reuses this session when calling the API.
- **Export My MES Orders to Excel**: Runs the extraction, applies the selected layout (unless base report is checked), and saves an `.xlsx` file to the path you choose.
- **Run base report with all columns**: Ignores the layout selection and exports every column returned by MES for troubleshooting or ad hoc analysis.
- **Autorun Smartsheets Extractor**: When enabled, the saved workbook is post-processed to append ConfigIT work-order hyperlinks and Smartsheet row links. Requires a Smartsheet API token via environment variable or OS keyring entry.
- **Log panel**: Shows progress messages, errors, and post-processing notes so you can troubleshoot cookies, missing columns, or failed link injections.

## Layout Editor Overview

Use **Edit Layout...** to customize how data is exported.

- **Columns list**: Displays each column in export order. Use **Add**, **Remove**, **Up**, **Down** to adjust the list.
- **Header**: Text used as the Excel column title.
- **Source Field**: (Optional) MES field name to pull from. Leave empty if you only want a default value or hyperlink column.
- **Default Value**: Fallback text used when the source field is blank or absent.
- **Transform**:
  - `raw`: pass data through unchanged.
  - `clean_program`: strip common prefixes/spaces from service template descriptions.
  - `clean_location`: normalize lab location strings.
  - `date`: parse and render as `MM/DD/YYYY`.
  - `blank`: ignore the source and fill with `Default Value`.
  - `hyperlink`: use the link metadata fields below (id/template) to build Excel hyperlinks.
- **Link ID Field** / **Link URL Template**: Only enabled for `hyperlink`. `id_source` should be a field from the MES payload. Place `{value}` in the template to inject the ID per row.
- **SS Link / MES Link / Configit Link**: Select at most one checkbox per column.
  - **SS Link**: adds Smartsheet row hyperlinks based on SO numbers.
  - **MES Link**: adds ConfigIT work-order links.
  - **Configit Link**: also uses document numbers but targets the ConfigIT site specifically.
- **Rules**: IF/THEN overrides run after columns are built (e.g., set “Line of Business” when GIC# matches a value).
- **Save** overwrites the current layout file; **Save As...** creates a new layout JSON.

## Example Column Configurations

- **Program column**
  - Header: `Program(SS)`
  - Source Field: `serviceTemplateDesc`
  - Transform: `clean_program`
  - SS Link: checked

- **Static technician column**
  - Header: `Tech`
  - Transform: `blank`
  - Default Value: `Unassigned`

- **MES work-order hyperlink**
  - Header: `WO#`
  - Source Field: `documentNumber`
  - Transform: `raw`
  - Link ID Field: `jobHeaderId`
  - Link URL Template: `https://mes.apps.wwt.com/orders/{value}`
  - MES Link: checked
