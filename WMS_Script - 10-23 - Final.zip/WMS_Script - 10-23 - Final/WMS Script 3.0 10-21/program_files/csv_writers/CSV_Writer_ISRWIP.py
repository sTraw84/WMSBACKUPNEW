"""Helpers for generating ISR WIP CSV and XLSX outputs."""

from __future__ import annotations

import csv
from typing import Iterable, List, Sequence

import openpyxl
from openpyxl.worksheet.worksheet import Worksheet

SERIAL_HEADER: List[str] = [
    "ISR4351/K9",
    "NIM-24A 1",
    "NIM-24A 2",
    "NIM-24A 3",
    "NIM-24A 4",
    "NIM-24A 5",
]


def normalize_serial_set(serials: Sequence[str] | None) -> List[str]:
    """Pad or trim a serial list to match the expected header length."""

    normalized = [value.strip() if isinstance(value, str) else "" for value in (serials or [])]
    if len(normalized) < len(SERIAL_HEADER):
        normalized.extend(["Missing"] * (len(SERIAL_HEADER) - len(normalized)))
    return normalized[: len(SERIAL_HEADER)]


def save_wip_csv_xlsx(output_path: str, serial_sets: Iterable[Sequence[str] | None]) -> bool:
    """Persist the serial matrix to an Excel workbook."""

    try:
        workbook = openpyxl.Workbook()
        sheet: Worksheet | None = workbook.active
        if sheet is None:
            raise ValueError("Unable to access workbook worksheet")
        sheet.append(SERIAL_HEADER)
        for serial_row in serial_sets:
            sheet.append(normalize_serial_set(serial_row))
        workbook.save(output_path)
        return True
    except Exception as exc:  # pragma: no cover - surfaced via GUI feedback
        print("Error saving ISR WIP XLSX:", exc)
        return False


def build_wip_prompt_rows(
    serial_sets: Iterable[Sequence[str] | None],
    lpn_value: str = "",
    job_value: str = "",
) -> List[List[str]]:
    """Create NUMBER/PROMPT/KEY/DATA rows for the automation script."""

    rows: List[List[str]] = [["NUMBER", "PROMPT", "KEY", "DATA"]]
    row_num = 1

    rows.append([str(row_num), "LPN      >", "BLANK", lpn_value.strip()])
    row_num += 1

    rows.append([str(row_num), "Job      >", "Job", job_value.strip()])
    row_num += 1

    for serial_row in serial_sets:
        normalized = normalize_serial_set(serial_row)
        chassis_sn = normalized[0] if normalized else ""
        rows.append([str(row_num), "SN       >", "SN1", chassis_sn])
        row_num += 1

        rows.append([str(row_num), "<Components>", "BLANK", ""])
        row_num += 1

        nim_values = [value for value in normalized[1:] if value and value.lower() != "missing"]
        if nim_values:
            for nim_sn in nim_values:
                rows.append([str(row_num), "SN       >", "SN2", nim_sn])
                row_num += 1
                rows.append([str(row_num), "<Next Assm>", "BLANK", ""])
                row_num += 1
        else:
            rows.append([str(row_num), "<Next Assm>", "BLANK", ""])
            row_num += 1

    rows.append([str(row_num), "FINISHED", "", ""])
    return rows


def save_wip_csv(
    output_path: str,
    serial_sets: Iterable[Sequence[str] | None],
    lpn_value: str = "",
    job_value: str = "",
) -> bool:
    """Write the ISR WIP CSV to disk."""

    try:
        rows = build_wip_prompt_rows(serial_sets, lpn_value, job_value)
        with open(output_path, "w", newline="") as handle:
            writer = csv.writer(handle)
            writer.writerows(rows)
        return True
    except Exception as exc:  # pragma: no cover - surfaced via GUI feedback
        print("Error saving ISR WIP CSV:", exc)
        return False
