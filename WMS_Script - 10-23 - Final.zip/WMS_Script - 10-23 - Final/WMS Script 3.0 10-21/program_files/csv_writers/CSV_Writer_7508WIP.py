"""Helpers for generating Arista 7508 WIP automation CSV outputs."""

from __future__ import annotations

import csv
from collections import defaultdict
from typing import Iterable, List, Sequence, Tuple

from openpyxl import load_workbook

SERIAL_HEADER: List[str] = [
    "Chassis",
    "Supervisor",
    "Fabric Module 1",
    "Fabric Module 2",
    "Fabric Module 3",
    "Fabric Module 4",
    "Fabric Module 5",
    "Fabric Module 6",
]

_ITEM_MASTER = "BND"
_ITEM_SUP = "SUP"
_ITEM_FM = "FM#"

_PROMPT_HEADER = ["NUMBER", "PROMPT", "KEY", "DATA"]


class Workbook7508Error(RuntimeError):
    """Raised when the 7508 workbook structure does not meet expectations."""


def _group_rows_by_lpn(rows: Iterable[Sequence[str | None]]) -> List[Tuple[str, List[str]]]:
    grouped: defaultdict[str, List[Tuple[str, str]]] = defaultdict(list)
    for item_number, lpn_number, serial_number in rows:
        if not lpn_number:
            raise Workbook7508Error("Encountered row without LPN number")
        grouped[lpn_number].append(((item_number or ""), (serial_number or "")))

    ordered_sets: List[Tuple[str, List[str]]] = []
    for lpn in sorted(grouped):
        entries = grouped[lpn]
        master_sn = next((serial for item, serial in entries if _ITEM_MASTER in item), "")
        sup_sn = next((serial for item, serial in entries if _ITEM_SUP in item), "")
        fm_serials = [serial for item, serial in entries if _ITEM_FM in item]
        normalized = [master_sn, sup_sn]
        normalized.extend(fm_serials[: len(SERIAL_HEADER) - 2])
        while len(normalized) < len(SERIAL_HEADER):
            normalized.append("")
        ordered_sets.append((lpn, normalized))
    return ordered_sets


def load_serial_sets_from_workbook(path: str) -> List[Tuple[str, List[str]]]:
    """Load serial groupings from the provided Excel workbook path."""

    workbook = load_workbook(path, data_only=True)
    worksheet = workbook.active
    if worksheet is None:
        raise Workbook7508Error("Workbook does not contain an active worksheet")

    rows: List[Tuple[str | None, str | None, str | None]] = []
    for row in worksheet.iter_rows(min_row=2, values_only=True):
        if not isinstance(row, (tuple, list)):
            continue
        item = row[0] if len(row) > 0 else None
        lpn = row[1] if len(row) > 1 else None
        serial = row[2] if len(row) > 2 else None
        item_text = str(item) if item is not None else None
        lpn_text = str(lpn) if lpn is not None else None
        serial_text = str(serial) if serial is not None else None
        rows.append((item_text, lpn_text, serial_text))
    if not rows:
        return []
    return _group_rows_by_lpn(rows)


def serial_sets_only(grouped_sets: Iterable[Tuple[str, Sequence[str]]]) -> List[List[str]]:
    """Drop LPN from grouped results for writer utilities that only need serials."""

    return [list(serials) for _, serials in grouped_sets]


def build_wip_prompt_rows(
    serial_sets: Iterable[Sequence[str]],
    lpn_value: str = "",
    job_value: str = "",
) -> List[List[str]]:
    serial_sets_list = list(serial_sets)
    rows: List[List[str]] = [_PROMPT_HEADER]
    idx = 1

    rows.append([str(idx), "LPN      >", "BLANK-L40", lpn_value.strip()])
    idx += 1

    rows.append([str(idx), "Job      >", "JOB", job_value.strip()])
    idx += 1

    for set_index, serial_set in enumerate(serial_sets_list):
        normalized = [(value or "").strip() for value in serial_set]
        chassis_sn = normalized[0] if normalized else ""
        sup_sn = normalized[1] if len(normalized) > 1 else ""
        fm_values = [value for value in normalized[2:] if value]

        rows.append([str(idx), "SN       >", "MasterSN", chassis_sn])
        idx += 1
        rows.append([str(idx), "<Components> ", "BLANK", ""])
        idx += 1

        rows.append([str(idx), "SN       >", "SupSN", sup_sn])
        idx += 1
        rows.append([str(idx), "<Next Component>", "", ""])
        idx += 1

        rows.append([str(idx), "SN       >", "MasterSN", chassis_sn])
        idx += 1
        rows.append([str(idx), "<Next Component>", "BLANK", ""])
        idx += 1

        rows.append([
            str(idx),
            "SN       >",
            "FMSN",
            ", ".join(fm_values),
        ])
        idx += 1
        if set_index != len(serial_sets_list) - 1:
            rows.append([str(idx), "<Next Assm>", "BLANK", ""])
            idx += 1

    rows.append([str(idx), "FINISHED", "", ""])
    idx += 1
    rows.append([str(idx), "WIP", "", ""])

    return rows


def save_wip_csv(
    output_path: str,
    serial_sets: Iterable[Sequence[str]],
    lpn_value: str = "",
    job_value: str = "",
) -> bool:
    try:
        rows = build_wip_prompt_rows(serial_sets, lpn_value, job_value)
        with open(output_path, "w", newline="", encoding="utf-8") as handle:
            writer = csv.writer(handle)
            writer.writerows(rows)
        return True
    except Exception as exc:  # pragma: no cover
        print("Error saving 7508 WIP CSV:", exc)
        return False