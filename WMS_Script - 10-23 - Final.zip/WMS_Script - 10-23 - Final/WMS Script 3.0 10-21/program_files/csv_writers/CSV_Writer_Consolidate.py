import csv

def write_csv_headers(file):
    headers = ["NUMBER", "PROMPT", "KEY", "DATA"]
    with open(file.name, 'w', newline='') as csv_file:
        writer = csv.writer(csv_file, delimiter=',')
        writer.writerow(headers)


def append_to_csv(file, row_counter, c40_list, parent_lpn_textbox):
    with open(file.name, 'a', newline='') as csv_file:
        writer = csv.writer(csv_file, delimiter=',')
        writer.writerow([row_counter, "ParentLPN>", "ParentLPN", parent_lpn_textbox.text(), ""])
        row_counter += 1
        for c40 in c40_list:
            writer.writerow([row_counter, "Next LPN >", "C40", c40, ""])
            row_counter += 1
            writer.writerow([row_counter, "<More>", "BLANK", "", ""])
            row_counter += 1
    return row_counter


def append_finished(file, row_counter):
    with open(file.name, 'a', newline='') as csv_file:
        writer = csv.writer(csv_file, delimiter=',')
        writer.writerow([row_counter, "FINISHED", "FINISHED", "", ""])


def save_csv(file_name, temp_file, headers=None, screen_indicator="CONSOLIDATE", **_):
    try:
        headers = headers or ["NUMBER", "PROMPT", "KEY", "DATA"]

        with open(temp_file.name, 'r', newline='') as temp_file_r:
            reader = csv.reader(temp_file_r)
            rows = list(reader)

        if not rows:
            rows = [headers]
        else:
            first_row = rows[0] if rows[0] else []
            normalized_first = [col.strip() for col in first_row]
            if normalized_first != headers:
                rows.insert(0, headers)

        last_row_number = 0
        for row in rows[1:]:
            if not row:
                continue
            try:
                last_row_number = max(last_row_number, int(row[0]))
            except (ValueError, IndexError):
                continue

        rows.append([str(last_row_number + 1), screen_indicator, "", "", ""])

        with open(file_name, 'w', newline='') as file:
            writer = csv.writer(file, delimiter=',')
            writer.writerows(rows)
        return True
    except Exception as e:
        print(f"Error saving CSV: {e}")
        return False


def read_csv(temp_file):
    with open(temp_file.name, 'r') as file:
        reader = csv.reader(file)
        return list(reader)
