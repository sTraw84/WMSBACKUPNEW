import tempfile
from collections import defaultdict
from pathlib import Path
from typing import Any, Dict, List, Mapping, Optional, Sequence, cast

from PyQt5.QtCore import Qt
from PyQt5.QtGui import QIntValidator
from PyQt5.QtWidgets import (
    QFileDialog,
    QGridLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QRadioButton,
    QSizePolicy,
    QVBoxLayout,
    QWidget,
)

from program_files.csv_writers import CSV_Writer_DustinSpares
from program_files.utils.file_paths import get_default_save_path_for_csv_writer

from .BaseGUI import BaseDialog
from .MainButtons import MainButtons


class IntLineEdit(QLineEdit):
    def __init__(self, parent: Optional[QWidget] = None) -> None:
        super().__init__(parent)
        self.setValidator(QIntValidator(0, 999999, self))


class DustinSparesGUI(BaseDialog):
    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle("Dustin Spare Balancer")
        self.screen_indicator = "REPACK"
        self.csv_writer = CSV_Writer_DustinSpares

        self.temp_csv_file = tempfile.NamedTemporaryFile(
            delete=False,
            mode="w",
            newline="",
        )
        self.csv_writer.write_csv_headers(self.temp_csv_file)
        self.temp_csv_file.flush()
        self.row_counter = 1
        self.csv_headers = ["NUMBER", "PROMPT", "KEY", "DATA"]

        self.starting_sheet_path: Optional[Path] = None
        self.spare_mode: Optional[str] = None
        self.plan_consumed = False
        self.row_entries: List[Dict[str, QWidget]] = []
        self._suppress_row_change = False

        self._build_ui()
        self._add_lpn_row(mark_dirty=False)
        self.finalize_initial_size(extra_width=80)
        self._update_add_button_state()

    def _build_ui(self) -> None:
        layout = QVBoxLayout(self)
        layout.setSpacing(10)

        title = QLabel("Balance Dustin Spares")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title.setStyleSheet("font-size: 18px; font-weight: bold;")
        layout.addWidget(title)

        upload_box = QHBoxLayout()
        self.upload_button = QPushButton("Upload Spreadsheet")
        self.upload_button.clicked.connect(self.upload_spreadsheet)
        upload_box.addWidget(self.upload_button)

        self.file_label = QLabel("No file selected")
        self.file_label.setSizePolicy(
            QSizePolicy.Expanding,
            QSizePolicy.Preferred,
        )
        upload_box.addWidget(self.file_label)
        layout.addLayout(upload_box)

        source_group = QGroupBox("Where are the spares coming from?")
        source_layout = QGridLayout()
        self.location_radio = QRadioButton("Location")
        self.location_radio.toggled.connect(
            lambda checked: checked and self._set_spare_mode("location")
        )
        source_layout.addWidget(self.location_radio, 0, 0)

        self.lpn_radio = QRadioButton("LPN")
        self.lpn_radio.toggled.connect(
            lambda checked: checked and self._set_spare_mode("lpn")
        )
        source_layout.addWidget(self.lpn_radio, 0, 1)
        source_group.setLayout(source_layout)
        layout.addWidget(source_group)

        self.spare_lpn_container = QWidget()
        spare_lpn_layout = QHBoxLayout(self.spare_lpn_container)
        spare_lpn_layout.setContentsMargins(0, 0, 0, 0)
        spare_lpn_layout.setSpacing(6)
        spare_label = QLabel("Spare LPN:")
        spare_lpn_layout.addWidget(spare_label)
        self.spare_lpn_edit = QLineEdit()
        self.spare_lpn_edit.textChanged.connect(self._on_rows_changed)
        spare_lpn_layout.addWidget(self.spare_lpn_edit)
        self.spare_lpn_container.hide()
        layout.addWidget(self.spare_lpn_container)

        rows_group = QGroupBox("C40 Balancing Lines")
        rows_group_layout = QVBoxLayout(rows_group)
        rows_group_layout.setContentsMargins(8, 8, 8, 8)
        rows_group_layout.setSpacing(6)

        header_widget = QWidget()
        header_layout = QGridLayout(header_widget)
        header_layout.setContentsMargins(0, 0, 0, 0)
        header_layout.setHorizontalSpacing(10)
        header_layout.addWidget(QLabel("#"), 0, 0)
        header_layout.addWidget(QLabel("LPN"), 0, 1)
        header_layout.addWidget(QLabel("Start1"), 0, 2)
        header_layout.addWidget(QLabel("End1"), 0, 3)
        header_layout.addWidget(QLabel("Start2"), 0, 4)
        header_layout.addWidget(QLabel("End2"), 0, 5)
        header_layout.addWidget(QLabel(""), 0, 6)
        rows_group_layout.addWidget(header_widget)

        self.rows_layout = QVBoxLayout()
        self.rows_layout.setSpacing(4)
        rows_group_layout.addLayout(self.rows_layout)

        controls_layout = QHBoxLayout()
        self.add_row_button = QPushButton("Add C40 Row")
        self.add_row_button.clicked.connect(lambda: self._add_lpn_row())
        controls_layout.addWidget(self.add_row_button)

        self.clear_rows_button = QPushButton("Clear Rows")
        self.clear_rows_button.clicked.connect(self._clear_lpn_rows)
        controls_layout.addWidget(self.clear_rows_button)
        controls_layout.addStretch()
        rows_group_layout.addLayout(controls_layout)

        layout.addWidget(rows_group)

        self.status_label = QLabel()
        layout.addWidget(self.status_label)

        self.main_buttons = MainButtons(self)
        layout.addLayout(self.main_buttons.get_layout())

    def upload_spreadsheet(self) -> None:
        options = QFileDialog.Options()
        options |= QFileDialog.DontUseNativeDialog
        start_dir = get_default_save_path_for_csv_writer("")
        file_name, _ = QFileDialog.getOpenFileName(
            self,
            "Select Dustin Starting Sheet",
            start_dir,
            "Excel Files (*.xlsx *.xlsm);;CSV Files (*.csv);;All Files (*)",
            options=options,
        )
        if not file_name:
            return
        try:
            rows = self.csv_writer.load_starting_sheet(file_name)
        except Exception as exc:
            QMessageBox.critical(
                self,
                "Error",
                f"Failed to load spreadsheet: {exc}",
            )
            return
        self.starting_sheet_path = Path(file_name)
        self.file_label.setText(self.starting_sheet_path.name)
        self._populate_rows(rows)
        loaded_msg = (
            f"Loaded {len(rows)} LPN rows from "
            f"{self.starting_sheet_path.name}."
        )
        self._set_status(loaded_msg, success=True)

    def _populate_rows(
        self,
        rows: Sequence[Mapping[str, Any]],
    ) -> None:
        self._suppress_row_change = True
        self._clear_lpn_rows(add_blank=False, mark_dirty=False)
        for row in rows:
            self._add_lpn_row(row, mark_dirty=False)
        if not rows:
            self._add_lpn_row(mark_dirty=False)
        self._suppress_row_change = False
        self.plan_consumed = False
        self._set_status("")
        self._update_add_button_state()

    def _set_spare_mode(self, mode: str) -> None:
        if self.spare_mode == mode:
            return
        self.spare_mode = mode
        if mode == "lpn":
            self.spare_lpn_container.show()
            self.spare_lpn_edit.setFocus()
        else:
            self.spare_lpn_edit.clear()
            self.spare_lpn_container.hide()
        self.plan_consumed = False
        self._update_add_button_state()

    def _rows_complete(self) -> bool:
        if not self.row_entries:
            return False
        for entry in self.row_entries:
            if not entry["lpn"].text().strip():
                return False
            for key in ("start1", "end1", "start2", "end2"):
                if not entry[key].text().strip():
                    return False
        return True

    def _update_add_button_state(self) -> None:
        enabled = (
            not self.plan_consumed
            and self.spare_mode is not None
            and (
                self.spare_mode != "lpn"
                or bool(self.spare_lpn_edit.text().strip())
            )
            and self._rows_complete()
        )
        self.main_buttons.add_button.setEnabled(enabled)

    def _set_status(self, message: str, success: bool = False) -> None:
        if not message:
            self.status_label.clear()
            return
        color = "green" if success else "#ff5555"
        rich_text = f"<span style='color: {color};'>{message}</span>"
        self.status_label.setText(rich_text)

    def _collect_rows(self) -> List[Dict[str, object]]:
        if not self.row_entries:
            raise ValueError(
                "Add at least one C40 line before creating the CSV."
            )
        rows: List[Dict[str, object]] = []
        for idx, entry in enumerate(self.row_entries, start=1):
            lpn = entry["lpn"].text().strip()
            if not lpn:
                raise ValueError(f"Row {idx}: LPN is required.")
            values: Dict[str, object] = {"lpn": lpn}
            for field_key, label in (
                ("start1", "Start1"),
                ("end1", "End1"),
                ("start2", "Start2"),
                ("end2", "End2"),
            ):
                text = entry[field_key].text().strip()
                if not text:
                    raise ValueError(f"Row {idx}: {label} is required.")
                try:
                    values[field_key] = int(text)
                except ValueError as exc:
                    raise ValueError(
                        f"Row {idx}: {label} must be a whole number."
                    ) from exc
            rows.append(values)
        return rows

    def on_next_build(self) -> None:
        try:
            rows = self._collect_rows()
        except ValueError as exc:
            self._set_status(str(exc))
            return
        if self.plan_consumed:
            self._set_status(
                "Plan already added. Start over or adjust the lines first."
            )
            return
        if self.spare_mode is None:
            self._set_status("Select where the spares are coming from.")
            return
        spare_value = (
            self.spare_lpn_edit.text().strip()
            if self.spare_mode == "lpn"
            else None
        )
        if self.spare_mode == "lpn" and not spare_value:
            self._set_status("Enter the spare LPN before adding to CSV.")
            return
        try:
            rows_for_writer = cast(List[Dict[str, int]], rows)
            transfers = self.csv_writer.calculate_transfers(rows_for_writer)
            if not transfers:
                self._set_status(
                    "No transfers needed; everything is already balanced."
                )
                return
            self.row_counter = self.csv_writer.append_to_csv(
                self.temp_csv_file,
                self.row_counter,
                spare_mode=self.spare_mode,
                spare_value=spare_value,
                transfers=transfers,
                rows=rows_for_writer,
            )
        except ValueError as exc:
            self._set_status(str(exc))
            return
        except Exception as exc:
            QMessageBox.critical(
                self,
                "Error",
                f"Failed to append to CSV: {exc}",
            )
            return

        summary: Dict[str, int] = defaultdict(int)
        spare_summary: Dict[str, int] = defaultdict(int)
        for move in transfers:
            part = str(move["part"])
            qty_value = move.get("qty")
            if isinstance(qty_value, (int, float)):
                qty = int(qty_value)
            elif isinstance(qty_value, str):
                try:
                    qty = int(qty_value.strip()) if qty_value.strip() else 0
                except ValueError:
                    qty = 0
            else:
                qty = 0
            summary[part] += qty
            if move["from_spare"]:
                spare_summary[part] += qty

        parts_text = ", ".join(
            f"{part}: {qty}" for part, qty in summary.items()
        )
        spare_text = ""
        if any(spare_summary.values()):
            spare_details = ", ".join(
                f"{part}: {qty}" for part, qty in spare_summary.items() if qty
            )
            spare_text = f" | Spares supplied: {spare_details}"

        summary_msg = (
            f"Added {len(transfers)} move instructions | "
            f"{parts_text}{spare_text}"
        )
        self._set_status(summary_msg, success=True)
        self.plan_consumed = True
        self._update_add_button_state()

    def _add_lpn_row(
        self,
        data: Optional[Mapping[str, Any]] = None,
        *,
        mark_dirty: bool = True,
    ) -> None:
        row_widget = QWidget()
        layout = QGridLayout(row_widget)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setHorizontalSpacing(10)

        index_label = QLabel("1.")
        layout.addWidget(index_label, 0, 0)

        lpn_edit = QLineEdit()
        lpn_edit.setPlaceholderText("C40-#")
        lpn_edit.textChanged.connect(self._on_rows_changed)
        layout.addWidget(lpn_edit, 0, 1)

        start1_edit = IntLineEdit()
        start1_edit.textChanged.connect(self._on_rows_changed)
        layout.addWidget(start1_edit, 0, 2)

        end1_edit = IntLineEdit()
        end1_edit.textChanged.connect(self._on_rows_changed)
        layout.addWidget(end1_edit, 0, 3)

        start2_edit = IntLineEdit()
        start2_edit.textChanged.connect(self._on_rows_changed)
        layout.addWidget(start2_edit, 0, 4)

        end2_edit = IntLineEdit()
        end2_edit.textChanged.connect(self._on_rows_changed)
        layout.addWidget(end2_edit, 0, 5)

        remove_button = QPushButton("Remove")
        layout.addWidget(remove_button, 0, 6)

        entry = {
            "widget": row_widget,
            "index": index_label,
            "lpn": lpn_edit,
            "start1": start1_edit,
            "end1": end1_edit,
            "start2": start2_edit,
            "end2": end2_edit,
            "remove": remove_button,
        }
        remove_button.clicked.connect(lambda _, e=entry: self._remove_row(e))

        self.row_entries.append(entry)
        self.rows_layout.addWidget(row_widget)

        if data is not None:
            self._suppress_row_change = True
            lpn_edit.setText(str(data.get("lpn", "")))
            start1_edit.setText(str(data.get("start1", "")))
            end1_edit.setText(str(data.get("end1", "")))
            start2_edit.setText(str(data.get("start2", "")))
            end2_edit.setText(str(data.get("end2", "")))
            self._suppress_row_change = False

        self._refresh_row_numbers()
        if mark_dirty:
            self._on_rows_changed()
        else:
            self._update_add_button_state()

    def _remove_row(self, entry: Dict[str, QWidget]) -> None:
        if entry not in self.row_entries:
            return
        self.row_entries.remove(entry)
        widget = entry.get("widget")
        if widget is not None:
            widget.deleteLater()
        if not self.row_entries:
            self._add_lpn_row(mark_dirty=False)
        self._refresh_row_numbers()
        self._on_rows_changed()

    def _clear_lpn_rows(
        self,
        add_blank: bool = True,
        mark_dirty: bool = True,
    ) -> None:
        self._suppress_row_change = True
        while self.row_entries:
            entry = self.row_entries.pop()
            widget = entry.get("widget")
            if widget is not None:
                widget.deleteLater()
        self._suppress_row_change = False
        if add_blank:
            self._add_lpn_row(mark_dirty=False)
        self._refresh_row_numbers()
        if mark_dirty:
            self._on_rows_changed()
        else:
            self._update_add_button_state()

    def _refresh_row_numbers(self) -> None:
        for idx, entry in enumerate(self.row_entries, start=1):
            entry["index"].setText(f"{idx}.")

    def _on_rows_changed(self) -> None:
        if self._suppress_row_change:
            return
        self.plan_consumed = False
        self._set_status("")
        self._update_add_button_state()

    def clear_data_fields(self) -> None:
        self.starting_sheet_path = None
        self.file_label.setText("No file selected")
        self._clear_lpn_rows(add_blank=True, mark_dirty=False)
        self.plan_consumed = False
        self.spare_mode = None
        self.location_radio.blockSignals(True)
        self.lpn_radio.blockSignals(True)
        self.location_radio.setChecked(False)
        self.lpn_radio.setChecked(False)
        self.location_radio.blockSignals(False)
        self.lpn_radio.blockSignals(False)
        self.spare_lpn_edit.clear()
        self.spare_lpn_container.hide()
        self._set_status("")
        self._update_add_button_state()

    def on_csv_reset(self) -> None:
        self.plan_consumed = False
        try:
            self.temp_csv_file.flush()
        except Exception:
            pass
        self._update_add_button_state()

    def on_csv_loaded(self) -> None:
        self.plan_consumed = False
        self._update_add_button_state()
