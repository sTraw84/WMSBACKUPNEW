Project layout

This repository was reorganized so the root contains only the launcher, the WMS script, CSV data, program files package, and backups.

Top-level layout

- CSV Files/         # CSV data files used by the app (kept as-is)
- Program Files/     # Archive folder + helper (contains Program Files/Other)
- program_files/     # Active Python package used by the launcher (guis, csv_writers, CSV_Loader)
- __pycache__/       # Python bytecode cache
- HomeGUI.pyw        # Launcher: starts the PyQt application using `program_files.guis.HomeGUI`
- WMS_Script_1.5.2.py

Backups

Original flat modules were archived to `Program Files/Other/`. If you need to restore a file to the root or to the package, use the copies there as the source.

How to run

1) Create a Python environment with the required packages (see `requirements.txt`).

2) From the project root run (PowerShell):

```powershell
python .\HomeGUI.pyw
```

or use the convenience script:

```powershell
./run_launcher.ps1
```

Developer notes

- The active code imports from the package `program_files` (e.g. `program_files.guis.HomeGUI`).
- If you prefer to use the old flat layout, either restore files from `Program Files/Other/` or change imports accordingly. The package approach is more robust for packaging and IDE support.

If you want, I can:
- Add a small test harness to exercise CSV writers (non-interactive).
- Convert the archived copies to import from `program_files` so the `Program Files/` tree can be used as the active codebase.
- Remove backups once you're satisfied.

Token storage / Keyring
-----------------------
This project supports secure storage of the Smartsheet API token using the OS keyring via `keyring`. See `dev-tools/KEYRING_README.md` for setup, usage, and recommendations. The SS Link Creator UI also provides a "Set API Token" button and will offer to save the token to the OS keyring for future runs.
