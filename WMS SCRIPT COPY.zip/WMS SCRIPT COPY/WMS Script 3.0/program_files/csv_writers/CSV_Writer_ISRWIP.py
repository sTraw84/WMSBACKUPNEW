import csv
import openpyxl

def write_csv_headers(file):
    headers = ['NUMBER', 'PROMPT', 'KEY', 'DATA']
    writer = csv.writer(file)
    writer.writerow(headers)


def save_wip_csv_xlsx(output_path, rows):
    wb = openpyxl.Workbook()
    ws = wb.active
    for r in rows:
        ws.append(r)
    wb.save(output_path)


def read_csv(temp_csv_file):
    with open(temp_csv_file.name, 'r', newline='') as file:
        reader = csv.reader(file)
        return list(reader)


def append_finished(temp_csv_file, row_counter):
    with open(temp_csv_file.name, 'a', newline='') as file:
        writer = csv.writer(file)
        writer.writerow([row_counter, 'FINISHED', '', ''])


def save_csv(file_name, temp_file, as_xlsx=False):
    rows = read_csv(temp_file)
    if as_xlsx:
        save_wip_csv_xlsx(file_name, rows)
        return True
    try:
        with open(file_name, 'w', newline='') as file:
            writer = csv.writer(file)
            writer.writerows(rows)
        return True
    except Exception as e:
        print('Error saving ISR WIP CSV:', e)
        return False
