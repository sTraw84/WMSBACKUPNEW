from PyQt5.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QLabel, QTextEdit
from PyQt5.QtCore import Qt

class CollapsibleListEditor(QWidget):
    """Generic collapsible list editor that binds to a list attribute on a parent dialog.

    Args:
        parent: The dialog that owns the backing list attribute.
        title: Header title to display.
        attr_name: Name of the attribute on parent that stores the python list.
        get_expected: Optional callable returning an int (expected count) or None.
        is_active: Optional callable returning bool indicating if requirement applies (e.g. master part checkbox checked).
    """
    def __init__(self, parent, title: str, attr_name: str, get_expected=None, is_active=None):
        super().__init__(parent)
        self._parent = parent
        self._attr = attr_name
        self._title = title
        self._get_expected = get_expected
        self._is_active = is_active
        self._building = False

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0,0,0,0)
        outer.setSpacing(2)

        header_layout = QHBoxLayout()
        header_layout.setContentsMargins(0,0,0,0)
        header_layout.setSpacing(6)
        self.toggle_button = QPushButton('\u25B6')  # triangle right
        self.toggle_button.setFixedWidth(24)
        self.toggle_button.setFlat(True)
        self.toggle_button.clicked.connect(self.toggle)
        self.title_label = QLabel(self._title)
        self.count_label = QLabel("")
        header_layout.addWidget(self.toggle_button)
        header_layout.addWidget(self.title_label)
        header_layout.addStretch()
        header_layout.addWidget(self.count_label)
        outer.addLayout(header_layout)

        self.container = QWidget(self)
        self.container.setVisible(False)
        cont_layout = QVBoxLayout(self.container)
        cont_layout.setContentsMargins(24,0,0,0)
        cont_layout.setSpacing(4)
        self.editor = QTextEdit(self.container)
        self.editor.setPlaceholderText("One entry per line")
        self.apply_button = QPushButton("Apply", self.container)
        self.apply_button.clicked.connect(self.apply_changes)
        cont_layout.addWidget(self.editor)
        cont_layout.addWidget(self.apply_button, alignment=Qt.AlignLeft)  # type: ignore[attr-defined]

        outer.addWidget(self.container)

    def toggle(self):
        self.container.setVisible(not self.container.isVisible())
        self._update_toggle_icon()
        if self.container.isVisible():
            self.load_from_attr()
            self.refresh_count()

    def _update_toggle_icon(self):
        self.toggle_button.setText('\u25BC' if self.container.isVisible() else '\u25B6')  # down / right

    def load_from_attr(self):
        try:
            current = getattr(self._parent, self._attr, []) or []
            self.editor.setPlainText("\n".join(current))
        except Exception:
            pass

    def apply_changes(self):
        raw_lines = self.editor.toPlainText().splitlines()
        cleaned = [line.strip() for line in raw_lines if line.strip()]
        setattr(self._parent, self._attr, cleaned)
        self.refresh_count()
        if hasattr(self._parent, 'status_label'):
            self._parent.status_label.setText(f'<span style="color: green;">Updated {self._title} ({len(cleaned)})</span>')

    def refresh_count(self):
        expected = None
        try:
            if self._get_expected:
                expected = self._get_expected()
        except Exception:
            expected = None
        active = True
        if self._is_active:
            try:
                active = self._is_active()
            except Exception:
                active = True
        current = getattr(self._parent, self._attr, []) or []
        # Gray out/disable when inactive
        self.setEnabled(bool(active))
        if not active:
            self.count_label.setText("")
            return
        if expected is not None and expected > 0:
            color = 'green' if len(current) == expected else 'yellow'
            self.count_label.setText(f'<span style="color: {color};">{len(current)}/{expected}</span>')
        else:
            self.count_label.setText(f'<span style="color: lightgray;">{len(current)}</span>')

    def programmatic_update(self):
        # call when external value may have changed
        if self.container.isVisible():
            self.load_from_attr()
        self.refresh_count()


class ChildSNsTabbedEditor(QWidget):
    """Collapsible inline editor showing tabs per child part that has SNs.

    Tabs are labeled by child row number (1-based). Each tab contains a QTextEdit
    and an Apply button that writes back to parent.child_sn_list[idx].
    """
    def __init__(self, parent, title: str = "Child SNs (Inline)"):
        super().__init__(parent)
        self._parent = parent
        self._title = title
        self._tab_editors = {}  # idx -> QTextEdit

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0,0,0,0)
        outer.setSpacing(2)

        header_layout = QHBoxLayout()
        header_layout.setContentsMargins(0,0,0,0)
        header_layout.setSpacing(6)
        self.toggle_button = QPushButton('\u25B6')
        self.toggle_button.setFixedWidth(24)
        self.toggle_button.setFlat(True)
        self.toggle_button.clicked.connect(self.toggle)
        self.toggle_button.setEnabled(False)
        self.title_label = QLabel(self._title)
        self.count_label = QLabel("")
        header_layout.addWidget(self.toggle_button)
        header_layout.addWidget(self.title_label)
        header_layout.addStretch()
        header_layout.addWidget(self.count_label)
        outer.addLayout(header_layout)

        # Container and tabs
        self.container = QWidget(self)
        self.container.setVisible(False)
        cont_layout = QVBoxLayout(self.container)
        cont_layout.setContentsMargins(24,0,0,0)
        cont_layout.setSpacing(6)

        from PyQt5.QtWidgets import QTabWidget
        self.tabs = QTabWidget(self.container)
        cont_layout.addWidget(self.tabs)
        outer.addWidget(self.container)

    def toggle(self):
        child_sn, indices = self._collect_indices()
        if not self._set_toggle_state(indices):
            return
        self.container.setVisible(not self.container.isVisible())
        self._update_toggle_icon()
        if self.container.isVisible():
            self.rebuild_tabs()

    def _update_toggle_icon(self):
        self.toggle_button.setText('\u25BC' if self.container.isVisible() else '\u25B6')

    def _collect_indices(self):
        child_sn = getattr(self._parent, 'child_sn_list', []) or []
        indices = [i for i, value in enumerate(child_sn) if value is not None]
        return child_sn, indices

    def _set_toggle_state(self, indices):
        has_any = bool(indices)
        self.toggle_button.setEnabled(has_any)
        if not has_any:
            self.tabs.clear()
            self._tab_editors = {}
            if self.container.isVisible():
                self.container.setVisible(False)
                self._update_toggle_icon()
            self.count_label.setText("<span style='color: lightgray;'>sets: 0</span>")
        return has_any

    def rebuild_tabs(self):
        from PyQt5.QtWidgets import QWidget as QW, QVBoxLayout as QVL, QPushButton
        child_sn, indices = self._collect_indices()
        if not self._set_toggle_state(indices):
            return
        # Compute desired labels and remove any tabs not in desired
        desired_labels = set([f"ChildSN{(i+1)}" for i in indices])
        # Remove tabs no longer needed
        for i in reversed(range(self.tabs.count())):
            label = self.tabs.tabText(i)
            if label not in desired_labels:
                self.tabs.removeTab(i)
        # Rebuild editors map
        self._tab_editors = {}
        # Ensure tabs exist in order
        for idx in indices:
            label = f"ChildSN{(idx+1)}"
            # Find existing tab index by label
            tab_index = None
            for t in range(self.tabs.count()):
                if self.tabs.tabText(t) == label:
                    tab_index = t
                    break
            if tab_index is None:
                # Create a new tab page
                page = QW()
                v = QVL(page)
                v.setContentsMargins(4,4,4,4)
                edit = QTextEdit(page)
                apply_btn = QPushButton('Apply', page)
                v.addWidget(edit)
                v.addWidget(apply_btn, alignment=Qt.AlignLeft)  # type: ignore[attr-defined]
                self.tabs.addTab(page, label)
                tab_index = self.tabs.count()-1
                # Wire apply
                def make_apply(i, ed):
                    return lambda: self._apply_for_index(i, ed)
                apply_btn.clicked.connect(make_apply(idx, edit))
                self._tab_editors[idx] = edit
            else:
                # Replace editor reference for existing page
                page = self.tabs.widget(tab_index)
                # Find the QTextEdit inside
                if page is not None:
                    layout = page.layout()
                    if layout is not None:
                        for j in range(layout.count()):
                            item = layout.itemAt(j)
                            w = item.widget() if item is not None else None
                            if isinstance(w, QTextEdit):
                                self._tab_editors[idx] = w
                                break
        # Populate editors
        for idx in indices:
            ed = self._tab_editors.get(idx)
            if ed is not None:
                try:
                    current = child_sn[idx] or []
                    ed.setPlainText("\n".join(current))
                except Exception:
                    pass
        # Update header count
        self.count_label.setText(f"<span style='color: lightgray;'>sets: {len(indices)}</span>")

    def _apply_for_index(self, idx: int, editor: QTextEdit):
        lines = [line.strip() for line in editor.toPlainText().splitlines() if line.strip()]
        try:
            while len(getattr(self._parent, 'child_sn_list')) <= idx:
                getattr(self._parent, 'child_sn_list').append(None)
            getattr(self._parent, 'child_sn_list')[idx] = lines
        except Exception:
            pass
        # If parent has a badge updater, refresh it
        try:
            if hasattr(self._parent, 'update_sn_badge'):
                self._parent.update_sn_badge(idx)
        except Exception:
            pass

    def programmatic_update(self):
        child_sn, indices = self._collect_indices()
        if not self._set_toggle_state(indices):
            return
        if self.container.isVisible():
            self.rebuild_tabs()
        else:
            self.count_label.setText(f"<span style='color: lightgray;'>sets: {len(indices)}</span>")
