import sys
import os
from PyQt5.QtWidgets import QApplication, QWidget, QVBoxLayout, QPushButton, QLabel, QMessageBox, QTextEdit, QHBoxLayout, QStackedLayout
from PyQt5.QtGui import QFont, QIcon
from PyQt5.QtCore import Qt
import qdarkstyle
from .BaseGUI import BaseWidget, BaseDialog
## Removed unused import: ListDialog
from .AttributeLabelsGUI import AttributeLabelsGUI
## Removed unused import: MainButtons

from program_files.guis.SingleDevicesGUI import SingleDevicesGUI  # will be moved later
## Removed unused import: WIPJobsGUI
## Removed unused import: CSV_Writer_Consolidate

# Import MES/Tracker tools
try:
    from .MES_Extractor import MESExtractor
    MES_EXTRACTOR_AVAILABLE = True
except ImportError as e:
    print(f"MES_Extractor not available: {e}")
    MES_EXTRACTOR_AVAILABLE = False

try:
    from .SSLinkCreator import SSLinkCreator
    SS_LINK_CREATOR_AVAILABLE = True
except ImportError:
    SS_LINK_CREATOR_AVAILABLE = False


def get_instructions_text():
    try:
        with open(os.path.join(os.path.dirname(__file__), '..', '..', 'Instructions.txt'), 'r') as file:
            return file.read()
    except Exception:
        return "Instructions file not found."


class InstructionsDialog(BaseDialog):
    def __init__(self, text, parent=None):
        super().__init__()
        self.setWindowTitle("Instructions")
        self.setWindowFlags(Qt.WindowType.Window)
        self.setWindowIcon(QIcon('bolt.ico'))
        layout = QVBoxLayout(self)
        self.text_edit = QTextEdit()
        self.text_edit.setReadOnly(True)
        self.text_edit.setLineWrapMode(QTextEdit.NoWrap)
        processed_text = text.replace('\n', '<br>')
        self.text_edit.setHtml(processed_text)
        layout.addWidget(self.text_edit)
        button_layout = QHBoxLayout()
        close_button = QPushButton("Close")
        close_button.clicked.connect(lambda: (self.close(), None)[1])
        button_layout.addStretch()
        button_layout.addWidget(close_button)
        layout.addLayout(button_layout)
        self.update_size()

    def update_size(self):
        doc = self.text_edit.document()
        doc_size = None
        try:
            if doc is not None and hasattr(doc, 'size'):
                doc_size = doc.size()
        except Exception:
            doc_size = None
        width = int(doc_size.width()) + 40 if doc_size is not None else 400
        height = int(doc_size.height()) + 80 if doc_size is not None else 300
        self.setMinimumSize(width, height)
        screen = QApplication.primaryScreen()
        if screen:
            geometry = screen.geometry() if hasattr(screen, 'geometry') else None
            if geometry is not None:
                max_width = int(geometry.width() * 0.8)
                max_height = int(geometry.height() * 0.8)
                self.setMaximumSize(max_width, max_height)
        self.resize(width, height)


class HomeGUI(BaseWidget):
    def __init__(self):
        super().__init__()
        self.dialogs = {}
        self.setWindowIcon(QIcon('bolt.ico'))
        self.initUI()

    def initUI(self):
        self.stacked = QStackedLayout()

        # Main home page
        self.home_widget = QWidget()
        home_layout = QVBoxLayout(self.home_widget)
        self.title_label = QLabel("WMS Script")
        # Slightly smaller title so the window stays compact
        self.title_label.setFont(QFont("Arial", 18, weight=QFont.Bold))
        self.title_label.setStyleSheet("color: #CCCCCC;")
        self.title_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        home_layout.addWidget(self.title_label)

        self.instructions_button = QPushButton("Instructions")
        self.instructions_button.clicked.connect(self.show_instructions)
        home_layout.addWidget(self.instructions_button)

        split_button = QPushButton('Create Split CSV', self)
        split_button.clicked.connect(self.open_split_dialog)
        home_layout.addWidget(split_button)

        self.create_repack_button = QPushButton("Create Repack CSV")
        self.create_repack_button.clicked.connect(self.show_repack_message)
        home_layout.addWidget(self.create_repack_button)

        # Add Transfer CSV button
        transfer_button = QPushButton('Create Transfer CSV', self)
        transfer_button.clicked.connect(self.open_transfer_dialog)
        home_layout.addWidget(transfer_button)

        consolidate_button = QPushButton('Create Consolidate CSV', self)
        consolidate_button.clicked.connect(self.open_consolidate_dialog)
        home_layout.addWidget(consolidate_button)

        attribute_button = QPushButton('Attribute Labels', self)
        attribute_button.clicked.connect(self.open_attribute_labels)
        home_layout.addWidget(attribute_button)

        wip_jobs_button = QPushButton('WIP Jobs', self)
        wip_jobs_button.clicked.connect(self.show_wip_view)
        home_layout.addWidget(wip_jobs_button)

        mes_tracker_button = QPushButton('MES/Tracker Tools', self)
        mes_tracker_button.clicked.connect(self.show_mes_tracker_view)
        home_layout.addWidget(mes_tracker_button)


        # WIP Options page
        self.wip_widget = QWidget()
        wip_layout = QVBoxLayout(self.wip_widget)
        wip_title = QLabel("WIP Options")
        wip_title.setFont(QFont("Arial", 18, weight=QFont.Bold))
        wip_title.setStyleSheet("color: #CCCCCC;")
        wip_title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        wip_layout.addWidget(wip_title)

        wip_single_button = QPushButton("Single Devices", self)
        wip_single_button.clicked.connect(self.open_single_devices)
        wip_layout.addWidget(wip_single_button)

        wip_isr_button = QPushButton("ISR4351 Devices", self)
        wip_isr_button.clicked.connect(self.launch_isr_puller)
        wip_layout.addWidget(wip_isr_button)

        wip_manual_button = QPushButton("Manual WIP", self)
        wip_manual_button.clicked.connect(lambda: (QMessageBox.information(self, "Manual WIP", "Manual WIP functionality will be implemented in the future."), None)[1])
        wip_layout.addWidget(wip_manual_button)

        wip_return_button = QPushButton("Return to Main GUI", self)
        wip_return_button.clicked.connect(self.show_home_view)
        wip_layout.addWidget(wip_return_button)

        # MES/Tracker Tools page
        self.mes_tracker_widget = QWidget()
        mes_tracker_layout = QVBoxLayout(self.mes_tracker_widget)
        mes_tracker_title = QLabel("MES/Tracker Tools")
        mes_tracker_title.setFont(QFont("Arial", 18, weight=QFont.Bold))
        mes_tracker_title.setStyleSheet("color: #CCCCCC;")
        mes_tracker_title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        mes_tracker_layout.addWidget(mes_tracker_title)

        mes_extractor_button = QPushButton("MES Order Extractor", self)
        mes_extractor_button.clicked.connect(self.open_mes_extractor)
        mes_tracker_layout.addWidget(mes_extractor_button)

        ss_link_creator_button = QPushButton("Smartsheets Link Creator", self)
        ss_link_creator_button.clicked.connect(self.open_ss_link_creator)
        mes_tracker_layout.addWidget(ss_link_creator_button)

        mes_tracker_return_button = QPushButton("Return to Main GUI", self)
        mes_tracker_return_button.clicked.connect(self.show_home_view)
        mes_tracker_layout.addWidget(mes_tracker_return_button)

        # Assemble stacked layout
        self.stacked.addWidget(self.home_widget)
        self.stacked.addWidget(self.wip_widget)
        self.stacked.addWidget(self.mes_tracker_widget)

        root = QVBoxLayout(self)
        root.addLayout(self.stacked)
        self.setLayout(root)

        self.setWindowTitle("Home GUI")
        # Keep window compact
        self.setMinimumWidth(360)
        self.adjustSize()

    def show_home_view(self):
        self.stacked.setCurrentIndex(0)

    def show_wip_view(self):
        self.stacked.setCurrentIndex(1)

    def show_mes_tracker_view(self):
        self.stacked.setCurrentIndex(2)


    def show_instructions(self):
        instructions_text = get_instructions_text()
        if 'instructions' in self.dialogs and self.dialogs['instructions'].isVisible():
            self.dialogs['instructions'].raise_()
            self.dialogs['instructions'].activateWindow()
        else:
            self.dialogs['instructions'] = InstructionsDialog(instructions_text, self)
            self.dialogs['instructions'].show()

    def show_repack_message(self):
        if 'repack' in self.dialogs and self.dialogs['repack'].isVisible():
            self.dialogs['repack'].raise_()
            self.dialogs['repack'].activateWindow()
        else:
            try:
                from program_files.guis.RepackGUI import RepackGUI
                self.dialogs['repack'] = RepackGUI()
                self.dialogs['repack'].setWindowFlags(Qt.WindowType.Window)
                self.dialogs['repack'].show()
            except Exception:
                QMessageBox.information(self, "Repack", "Repack GUI not available yet.")

    def open_split_dialog(self):
        try:
            from program_files.guis.SplitGUI import SplitGUI
            self.dialogs['split'] = SplitGUI()
            self.dialogs['split'].setWindowFlags(Qt.WindowType.Window)
            self.dialogs['split'].show()
        except Exception:
            QMessageBox.information(self, "Split", "Split GUI not available yet.")

    def open_consolidate_dialog(self):
        try:
            from program_files.guis.ConsolidateGUI import ConsolidateGUI
            self.dialogs['consolidate'] = ConsolidateGUI()
            self.dialogs['consolidate'].setWindowFlags(Qt.WindowType.Window)
            self.dialogs['consolidate'].show()
        except Exception:
            QMessageBox.information(self, "Consolidate", "Consolidate GUI not available yet.")

    def open_single_devices(self):
        try:
            dialog = SingleDevicesGUI("", "")
            dialog.exec_()
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to open Single Devices: {str(e)}")

    def launch_isr_puller(self):
        try:
            script_path = os.path.join(os.getcwd(), "ISR_SN-Puller.pyw")
            if os.path.exists(script_path):
                import subprocess
                subprocess.Popen([sys.executable, script_path])
            else:
                QMessageBox.critical(self, "Error", "ISR_SN-Puller.pyw not found in the current directory.")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to launch ISR_SN-Puller: {str(e)}")

    def open_attribute_labels(self):
        try:
            dialog = AttributeLabelsGUI()
            dialog.exec_()
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to open Attribute Labels: {str(e)}")


    def open_transfer_dialog(self):
        try:
            from program_files.guis.TransferGUI import TransferGUI
            self.dialogs['transfer'] = TransferGUI()
            self.dialogs['transfer'].setWindowFlags(Qt.WindowType.Window)
            self.dialogs['transfer'].show()
        except Exception as e:
            QMessageBox.information(self, "Transfer", f"Transfer GUI not available yet.\n{str(e)}")

    def open_mes_extractor(self):
        try:
            if not MES_EXTRACTOR_AVAILABLE:
                QMessageBox.critical(self, "Error", "MES Extractor is not available. Please check your installation.")
                return
                
            if 'mes_extractor' in self.dialogs and self.dialogs['mes_extractor'].isVisible():
                self.dialogs['mes_extractor'].raise_()
                self.dialogs['mes_extractor'].activateWindow()
            else:
                self.dialogs['mes_extractor'] = MESExtractor()
                self.dialogs['mes_extractor'].setWindowFlags(Qt.WindowType.Window)
                self.dialogs['mes_extractor'].show()
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to open MES Order Extractor: {str(e)}")

    def open_ss_link_creator(self):
        try:
            if not SS_LINK_CREATOR_AVAILABLE:
                QMessageBox.critical(self, "Error", "Smartsheets Link Creator is not available. Please check your installation.")
                return
                
            if 'ss_link_creator' in self.dialogs and self.dialogs['ss_link_creator'].isVisible():
                self.dialogs['ss_link_creator'].raise_()
                self.dialogs['ss_link_creator'].activateWindow()
            else:
                self.dialogs['ss_link_creator'] = SSLinkCreator()
                self.dialogs['ss_link_creator'].setWindowFlags(Qt.WindowType.Window)
                self.dialogs['ss_link_creator'].show()
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to open Smartsheets Link Creator: {str(e)}")

if __name__ == "__main__":
    app = QApplication(sys.argv)
    app.setStyleSheet(qdarkstyle.load_stylesheet_pyqt5())
    app.setWindowIcon(QIcon('bolt.ico'))
    ex = HomeGUI()
    ex.show()
    ret = app.exec_()
    sys.exit(ret)
