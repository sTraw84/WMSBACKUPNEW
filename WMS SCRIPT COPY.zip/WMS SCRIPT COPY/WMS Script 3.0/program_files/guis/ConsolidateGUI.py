import sys
import os
from PyQt5.QtWidgets import (QApplication, QDialog, QVBoxLayout, QHBoxLayout, 
                            QLabel, QLineEdit, QPushButton, QListWidget, QMessageBox, QScrollArea, QWidget, QSpacerItem, QSizePolicy, QTableWidget, QTableWidgetItem, QInputDialog, QFileDialog)
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QIntValidator
import tempfile
from program_files.csv_writers import CSV_Writer_Consolidate
from program_files import CSV_Loader
from .Dialogs import ListDialog
from .MainButtons import MainButtons
from .BaseGUI import BaseDialog
from ..utils.file_paths import get_default_save_path_for_csv_writer
import csv

class NumericLineEdit(QLineEdit):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setValidator(QIntValidator(0, 999999, self))

class ConsolidateGUI(BaseDialog):
    def __init__(self):
        super().__init__()
        self.list_dialogs = {}  # Dictionary to store references to list dialogs
        self.mode = "consolidate"  # Set the mode for CSV loading
        self.csv_writer = CSV_Writer_Consolidate  # Set the CSV writer
        self.init_ui()
        self.temp_csv_file = tempfile.NamedTemporaryFile(delete=False, mode='w', newline='')
        self.row_counter = 1
        self.total_builds = 0  # Initialize total builds counter
        CSV_Writer_Consolidate.write_csv_headers(self.temp_csv_file)
        self.c40_list = []
        self.lpn_changed = False  # Track if the LPN has been changed

    def init_ui(self):
        self.setWindowTitle('Consolidate Questions')
        self.setFixedSize(496, 250)  # Half the height of other dialogs
        self.main_layout = QVBoxLayout(self)

        # Create horizontal layout for error box and counter box
        self.top_layout = QHBoxLayout()
        self.status_label = QLabel(self)
        self.top_layout.addWidget(self.status_label)

        # Add counter label
        self.counter_label = QLabel('# of C40s to Consolidate: 0', self)
        self.counter_label.setAlignment(Qt.AlignRight)
        self.top_layout.addWidget(self.counter_label)

        # Add the top layout to the main layout
        self.main_layout.addLayout(self.top_layout)

        self.scroll_area = QScrollArea(self)
        self.scroll_area.setWidgetResizable(True)
        self.scroll_content = QWidget(self.scroll_area)
        self.scroll_layout = QVBoxLayout(self.scroll_content)
        self.scroll_area.setWidget(self.scroll_content)
        self.main_layout.addWidget(self.scroll_area)

        self.parent_lpn_layout = QHBoxLayout()
        self.parent_lpn_label = QLabel('Parent LPN:', self)
        self.parent_lpn_textbox = QLineEdit(self)
        self.parent_lpn_layout.addWidget(self.parent_lpn_label)
        self.parent_lpn_layout.addWidget(self.parent_lpn_textbox)
        self.scroll_layout.addLayout(self.parent_lpn_layout)

        self.c40_list_layout = QHBoxLayout()
        self.c40_list_label = QLabel('C40 List:', self)
        self.add_c40_list_button = QPushButton('C40 List', self)
        self.add_c40_list_button.clicked.connect(self.open_c40_list_dialog)
        self.c40_list_layout.addWidget(self.c40_list_label)
        self.c40_list_layout.addWidget(self.add_c40_list_button)
        self.scroll_layout.addLayout(self.c40_list_layout)

        self.scroll_layout.addItem(QSpacerItem(20, 20, QSizePolicy.Minimum, QSizePolicy.Expanding))

        # Initialize and add main buttons
        self.main_buttons = MainButtons(self)
        self.main_layout.addLayout(self.main_buttons.get_layout())

        self.scroll_layout.setSpacing(5)
        self.scroll_layout.setContentsMargins(5, 5, 5, 5)

    def open_c40_list_dialog(self):
        dialog = ListDialog("C40 List", existing_list=self.c40_list, 
                          update_callback=lambda data: setattr(self, 'c40_list', data),
                          parent=self)
        self.list_dialogs['c40'] = dialog  # Store reference
        dialog.show()

    def validate_inputs(self):
        # Validate Parent LPN format
        parent_lpn = self.parent_lpn_textbox.text().strip()
        if parent_lpn and not any(parent_lpn.startswith(prefix) for prefix in ['C40-', 'L40-', 'RC40-', 'BTS40-']):
            self.status_label.setText('<span style="color: red;">Parent LPN must start with C40-, L40-, RC40-, or BTS40-</span>')
            self.parent_lpn_textbox.setStyleSheet("color: red;")
            self.parent_lpn_label.setStyleSheet("color: red;")
            return False
        else:
            self.parent_lpn_textbox.setStyleSheet("")
            self.parent_lpn_label.setStyleSheet("")

        # Validate C40 List entries
        for i, c40 in enumerate(self.c40_list):
            if not c40.startswith('C40-'):
                self.status_label.setText(f'<span style="color: red;">C40 List entry {i+1} must start with C40-</span>')
                return False

        return True

    def on_next_build(self):
        try:
            # Check if Parent LPN is entered
            if not self.parent_lpn_textbox.text().strip():
                self.status_label.setText('<span style="color: red;">Please enter the Parent LPN.</span>')
                return
                
            # Check if C40 list is not empty
            if not self.c40_list:
                self.status_label.setText('<span style="color: red;">Please add at least one C40 to the list.</span>')
                return

            # Validate inputs
            if not self.validate_inputs():
                return

            # All checks passed, proceed with adding to CSV
            if self.lpn_changed:
                self.append_uparrow()
                self.lpn_changed = False

            self.row_counter = CSV_Writer_Consolidate.append_to_csv(self.temp_csv_file, self.row_counter, self.c40_list, self.parent_lpn_textbox)
            self.total_builds += len(self.c40_list)
            self.status_label.setText(f'<span style="color: green;">{len(self.c40_list)} C40s added to CSV.</span>')
            self.counter_label.setText(f'# of C40s to Consolidate: {self.total_builds}')
            self.parent_lpn_textbox.setReadOnly(True)
            self.show_change_button()
            
            # Clear all fields except LPN and status
            self.c40_list = []
            self.c40_list_label.setText('C40 List:')

        except Exception as e:
            self.status_label.setText(f'<span style="color: red;">An unexpected error occurred: {str(e)}</span>')

    def append_uparrow(self):
        with open(self.temp_csv_file.name, 'a', newline='') as file:
            writer = csv.writer(file, delimiter=',')
            writer.writerow([self.row_counter, "UPARROW", "UPARROW", "", ""])
            self.row_counter += 1

    def clear_data_fields_except_lpn_and_status(self):
        try:
            self.c40_list = []
        except Exception as e:
            print(f"Error clearing data fields except LPN and status: {e}")

    def show_change_button(self):
        try:
            if hasattr(self, 'change_lpn_button'):
                self.change_lpn_button.setParent(None)
            self.change_lpn_button = QPushButton('Change', self)
            self.change_lpn_button.clicked.connect(self.enable_lpn_editing)
            self.parent_lpn_layout.addWidget(self.change_lpn_button)
        except Exception as e:
            print(f"Error showing change button: {e}")

    def enable_lpn_editing(self):
        self.lpn_changed = True  # Set flag to indicate LPN has been changed
        self.parent_lpn_textbox.setReadOnly(False)
        self.parent_lpn_textbox.setFocus()

    def clear_data_fields(self):
        # Clear all input fields
        self.parent_lpn_textbox.clear()
        self.parent_lpn_textbox.setReadOnly(False)
        
        # Clear all lists
        self.c40_list = []
        
        # Clear status message
        self.status_label.clear()
        
        # Reset counter
        self.total_builds = 0
        self.counter_label.setText('# of C40s to Consolidate: 0')
        
        # Remove change button if it exists
        if hasattr(self, 'change_lpn_button'):
            self.change_lpn_button.setParent(None)

    def start_over(self):
        try:
            reply = QMessageBox.question(self, 'Warning', 'This will delete all unsaved CSV data and will start over. Do you want to proceed?',
                                         QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
            if reply == QMessageBox.Yes:
                self.clear_data_fields()
                self.close()
                new_dialog = ConsolidateGUI()
                new_dialog.exec_()
        except Exception as e:
            print(f"Error starting over: {e}")

    def preview_csv(self):
        try:
            csv_data = CSV_Writer_Consolidate.read_csv(self.temp_csv_file)
            dialog = QDialog(self)
            dialog.setWindowTitle('Preview CSV')
            dialog.setFixedSize(600, 400)
            layout = QVBoxLayout(dialog)
            table = QTableWidget(dialog)
            table.setRowCount(len(csv_data))
            table.setColumnCount(3)
            table.setHorizontalHeaderLabels(["PROMPT", "KEY", "DATA"])
            for row_idx, row_data in enumerate(csv_data):
                for col_idx, col_data in enumerate(row_data[1:4]):
                    table.setItem(row_idx, col_idx, QTableWidgetItem(col_data))
            layout.addWidget(table)
            ok_button = QPushButton('OK', dialog)
            ok_button.clicked.connect(dialog.accept)
            layout.addWidget(ok_button)
            dialog.exec_()
        except Exception as e:
            print(f"Error previewing CSV: {e}")

    def on_finish_csv(self):
        try:
            # Check if the CSV is empty (only has headers)
            with open(self.temp_csv_file.name, 'r') as file:
                csv_data = list(csv.reader(file))
                # If CSV only has the header row, show warning message and return
                if len(csv_data) <= 1:  # Only header row exists
                    QMessageBox.warning(self, "CSV is Empty", 
                                     "CSV is currently blank. Fill out the information and add it via 'Add to CSV' and then 'Save As'.")
                    return
            
            # Check if the last row has "UPARROW" in the PROMPT column
            if len(csv_data) > 1 and csv_data[-1][1].strip() == "UPARROW":
                # Remove the last row and rewrite the CSV
                csv_data.pop()
                with open(self.temp_csv_file.name, 'w', newline='') as rewrite_file:
                    csv_writer = csv.writer(rewrite_file)
                    for row in csv_data:
                        csv_writer.writerow(row)
                # Adjust row counter since we removed a row
                self.row_counter -= 1
        
            CSV_Writer_Consolidate.append_finished(self.temp_csv_file, self.row_counter)
            self.row_counter += 1
            options = QMessageBox.Options()
            options |= QMessageBox.DontUseNativeDialog
            file_name, _ = QFileDialog.getSaveFileName(self, "Save CSV As", get_default_save_path_for_csv_writer(""), "CSV (MS-DOS) (*.csv);;All Files (*)", options=options)
            if file_name:
                if not file_name.endswith('.csv'):
                    file_name += '.csv'
                CSV_Writer_Consolidate.save_csv(file_name, self.temp_csv_file)
                
                # Prompt the user with the dialog after saving
                msg_box = QMessageBox()
                msg_box.setWindowTitle('CSV Saved')
                msg_box.setText('Would you like to start a new CSV or continue adding to the existing one?')
                new_csv_button = msg_box.addButton('New CSV', QMessageBox.ActionRole)
                continue_button = msg_box.addButton('Continue', QMessageBox.ActionRole)
                msg_box.exec_()
                
                if msg_box.clickedButton() == new_csv_button:
                    self.clear_data_fields()
                    self.close()
                    new_dialog = ConsolidateGUI()
                    new_dialog.exec_()
                elif msg_box.clickedButton() == continue_button:
                    # Remove the "FINISHED" row
                    with open(self.temp_csv_file.name, 'r') as file:
                        lines = file.readlines()
                    with open(self.temp_csv_file.name, 'w') as file:
                        for line in lines:
                            if "FINISHED" not in line:
                                file.write(line)
        except Exception as e:
            print(f"Error finishing CSV: {e}") 