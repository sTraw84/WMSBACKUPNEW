import os
from PyQt5.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit,
                            QPushButton, QCheckBox, QMessageBox, QScrollArea, QWidget,
                            QSpacerItem, QSizePolicy, QFileDialog)
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont
from .BaseGUI import BaseDialog
from .Dialogs import ListDialog
from program_files.csv_writers import CSV_Writer_SingleWIP
from ..utils.file_paths import get_default_save_path_for_csv_writer

class SingleDevicesGUI(BaseDialog):
    def __init__(self, lpn_value="", job_value=""):
        super().__init__()
        self.lpn_value = lpn_value
        self.job_value = job_value
        self.initUI()

    def initUI(self):
        self.setWindowTitle('Single Devices')
        self.setFixedSize(500, 400)
        self.main_layout = QVBoxLayout(self)
        title_label = QLabel("Single Devices")
        title_label.setFont(QFont("Arial", 18, weight=QFont.Bold))
        title_label.setStyleSheet("color: #CCCCCC;")
        title_label.setAlignment(Qt.AlignCenter)
        self.main_layout.addWidget(title_label)
        self.scroll_area = QScrollArea(self)
        self.scroll_area.setWidgetResizable(True)
        self.scroll_content = QWidget(self.scroll_area)
        self.scroll_layout = QVBoxLayout(self.scroll_content)
        self.scroll_area.setWidget(self.scroll_content)
        self.main_layout.addWidget(self.scroll_area)
        lpn_layout = QHBoxLayout()
        self.lpn_checkbox = QCheckBox("Enable LPN Entry", self)
        self.lpn_checkbox.stateChanged.connect(self.toggle_lpn_editing)
        lpn_layout.addWidget(self.lpn_checkbox)
        self.scroll_layout.addLayout(lpn_layout)
        lpn_text_layout = QHBoxLayout()
        lpn_label = QLabel("LPN:", self)
        self.lpn_input = QLineEdit(self)
        self.lpn_input.setPlaceholderText("Check the box to enter WIP LPN manually")
        self.lpn_input.setReadOnly(True)
        self.lpn_input.setStyleSheet("color: grey;")
        lpn_text_layout.addWidget(lpn_label)
        lpn_text_layout.addWidget(self.lpn_input)
        self.scroll_layout.addLayout(lpn_text_layout)
        job_layout = QHBoxLayout()
        job_label = QLabel("Job#:", self)
        self.job_input = QLineEdit(self)
        self.job_input.setPlaceholderText("Enter WIP Job# here")
        job_layout.addWidget(job_label)
        job_layout.addWidget(self.job_input)
        self.scroll_layout.addLayout(job_layout)
        if self.lpn_value:
            self.lpn_layout = QHBoxLayout()
            self.lpn_label = QLabel("LPN:", self)
            self.lpn_display = QLineEdit(self)
            self.lpn_display.setText(self.lpn_value)
            self.lpn_display.setReadOnly(True)
            self.lpn_display.setStyleSheet("color: grey;")
            self.lpn_layout.addWidget(self.lpn_label)
            self.lpn_layout.addWidget(self.lpn_display)
            self.scroll_layout.addLayout(self.lpn_layout)
        if self.job_value:
            self.job_layout = QHBoxLayout()
            self.job_label = QLabel("Job#:", self)
            self.job_display = QLineEdit(self)
            self.job_display.setText(self.job_value)
            self.job_display.setReadOnly(True)
            self.job_display.setStyleSheet("color: grey;")
            self.job_layout.addWidget(self.job_label)
            self.job_layout.addWidget(self.job_display)
            self.scroll_layout.addLayout(self.job_layout)
        sn_button_layout = QHBoxLayout()
        self.sn_list = []
        self.sn_list_button = QPushButton('SN List', self)
        self.sn_list_button.clicked.connect(self.open_sn_list_dialog)
        sn_button_layout.addWidget(self.sn_list_button)
        self.scroll_layout.addLayout(sn_button_layout)
        self.scroll_layout.addItem(QSpacerItem(20, 20, QSizePolicy.Minimum, QSizePolicy.Expanding))
        self.action_buttons_layout = QHBoxLayout()
        self.generate_csv_button = QPushButton("Generate CSV", self)
        self.generate_csv_button.clicked.connect(self.generate_csv)
        self.cancel_button = QPushButton("Cancel", self)
        self.cancel_button.clicked.connect(self.close)
        self.action_buttons_layout.addWidget(self.generate_csv_button)
        self.action_buttons_layout.addWidget(self.cancel_button)
        self.scroll_layout.addLayout(self.action_buttons_layout)

    def toggle_lpn_editing(self, state):
        if state == Qt.Checked:
            self.lpn_input.setReadOnly(False)
            self.lpn_input.setStyleSheet("color: white;")
            self.lpn_input.clear()
            self.lpn_input.setPlaceholderText("Enter WIP LPN...")
        else:
            self.lpn_input.setReadOnly(True)
            self.lpn_input.setStyleSheet("color: grey;")
            self.lpn_input.clear()
            self.lpn_input.setPlaceholderText("Check the box to enter WIP LPN manually")

    def open_sn_list_dialog(self):
        dialog = ListDialog("SN List", existing_list=self.sn_list,
                          update_callback=lambda data: setattr(self, 'sn_list', [sn.strip() for sn in data if sn.strip()]),
                          parent=self)
        dialog.exec_()

    def generate_csv(self):
        try:
            job_value = self.job_input.text().strip()
            if not job_value:
                QMessageBox.warning(self, "Missing Job#", "Please enter WIP Job# before proceeding.")
                return
            if not self.sn_list:
                QMessageBox.warning(self, "No SNs", "Please enter at least one serial number via SN List.")
                return
            file_path, _ = QFileDialog.getSaveFileName(self, "Save WIP CSV File", get_default_save_path_for_csv_writer("WIP_Single.csv"), "CSV files (*.csv);;All files (*)")
            if not file_path:
                return
            if not file_path.lower().endswith('.csv'):
                file_path += '.csv'
            lpn_value = self.lpn_input.text().strip() if self.lpn_checkbox.isChecked() else ""
            success = CSV_Writer_SingleWIP.save_wip_single_csv(file_path, self.sn_list, lpn_value, job_value)
            if success:
                QMessageBox.information(self, "Success", f"WIP CSV file saved successfully:\n{file_path}")
                self.close()
            else:
                QMessageBox.critical(self, "Error", "Failed to save CSV file.")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"An error occurred: {str(e)}")

    def closeEvent(self, event):
        event.accept()
