"""GUI Creator - design custom automation workflows for WMS."""

import json
import os
from typing import Any, Dict, List, Optional

from PyQt5.QtGui import QFont
from PyQt5.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QFileDialog,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QListWidget,
    QMessageBox,
    QPushButton,
    QScrollArea,
    QSpinBox,
    QTextEdit,
    QTableWidget,
    QTableWidgetItem,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)

from .BaseGUI import BaseDialog
from ..utils.file_paths import get_default_save_path_for_csv_writer


class FieldDefinition:
    """Represents a single input field in the GUI."""

    def __init__(self) -> None:
        self.field_type: str = "text"  # text, number, checkbox, dropdown, list, table
        self.label: str = ""
        self.key: str = ""
        self.default_value: str = ""
        self.options: List[str] = []  # Dropdown choices
        self.columns: List[str] = []  # Table column headers
        self.required: bool = True
        self.tooltip: str = ""
        self.visible_when: str = ""
        self.required_when: str = ""


class CsvRowDefinition:
    """Represents a single row in the CSV output template."""

    def __init__(self) -> None:
        self.prompt: str = ""
        self.key: str = ""
        self.data_source: str = ""
        self.condition: str = ""
        self.repeat_field: str = ""  # Field key to iterate on (list/table)
        self.segment: str = "main"  # main or footer


class GuiDefinition:
    """Complete definition of a custom GUI."""

    def __init__(self) -> None:
        self.name: str = ""
        self.description: str = ""
        self.include_finished: bool = True
        self.fields: List[FieldDefinition] = []
        self.csv_rows: List[CsvRowDefinition] = []


class FieldEditor(QDialog):
    """Dialog for editing a single field definition."""

    def __init__(self, field_def: Optional[FieldDefinition] = None, parent: Optional[QWidget] = None) -> None:
        super().__init__(parent)
        self.field_def = field_def or FieldDefinition()
        self.setWindowTitle("Edit Field")
        self.setModal(True)
        self.resize(420, 360)
        self._init_ui()
        self._load_field()

    def _init_ui(self) -> None:
        layout = QVBoxLayout(self)

        type_row = QHBoxLayout()
        type_row.addWidget(QLabel("Field Type:"))
        self.type_combo = QComboBox()
        self.type_combo.addItems(["text", "number", "checkbox", "dropdown", "list", "table"])
        self.type_combo.currentTextChanged.connect(self._on_type_changed)
        type_row.addWidget(self.type_combo)
        layout.addLayout(type_row)

        form = QFormLayout()
        self.label_edit = QLineEdit()
        self.key_edit = QLineEdit()
        self.default_edit = QLineEdit()
        self.tooltip_edit = QLineEdit()
        self.required_check = QCheckBox()
        self.visible_when_edit = QLineEdit()
        self.required_when_edit = QLineEdit()

        form.addRow("Label:", self.label_edit)
        form.addRow("Key (variable name):", self.key_edit)
        form.addRow("Default Value:", self.default_edit)
        form.addRow("Tooltip:", self.tooltip_edit)
        form.addRow("Required:", self.required_check)
        self.visible_when_edit.setPlaceholderText("field:OtherField=true")
        self.required_when_edit.setPlaceholderText("field:OtherField=true")
        form.addRow("Visible When:", self.visible_when_edit)
        form.addRow("Required When:", self.required_when_edit)
        layout.addLayout(form)

        condition_help = QLabel(
            "Conditions use the format field:OtherKey=value and compare case-insensitively. "
            "Leave blank to always show or require the field."
        )
        condition_help.setWordWrap(True)
        condition_help.setStyleSheet("color: gray; font-size: 10px;")
        layout.addWidget(condition_help)

        self.dropdown_group = QGroupBox("Dropdown Options")
        dropdown_layout = QVBoxLayout(self.dropdown_group)
        dropdown_layout.addWidget(QLabel("Options (one per line):"))
        self.options_edit = QTextEdit()
        self.options_edit.setMaximumHeight(110)
        dropdown_layout.addWidget(self.options_edit)
        layout.addWidget(self.dropdown_group)

        self.table_group = QGroupBox("Table Columns")
        table_layout = QVBoxLayout(self.table_group)
        table_layout.addWidget(QLabel("Columns (one per line):"))
        self.columns_edit = QTextEdit()
        self.columns_edit.setPlaceholderText("e.g. Part Number\nQuantity\nFrom Locator")
        self.columns_edit.setMaximumHeight(110)
        table_layout.addWidget(self.columns_edit)
        layout.addWidget(self.table_group)

        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

        self._on_type_changed()

    def _on_type_changed(self) -> None:
        field_type = self.type_combo.currentText()
        self.dropdown_group.setVisible(field_type == "dropdown")
        self.table_group.setVisible(field_type == "table")
        self.default_edit.setEnabled(field_type != "table")

    def _load_field(self) -> None:
        self.type_combo.setCurrentText(self.field_def.field_type)
        self.label_edit.setText(self.field_def.label)
        self.key_edit.setText(self.field_def.key)
        self.default_edit.setText(self.field_def.default_value)
        self.tooltip_edit.setText(self.field_def.tooltip)
        self.required_check.setChecked(self.field_def.required)
        self.visible_when_edit.setText(self.field_def.visible_when)
        self.required_when_edit.setText(self.field_def.required_when)
        self.options_edit.setPlainText("\n".join(self.field_def.options))
        self.columns_edit.setPlainText("\n".join(self.field_def.columns))

    def accept(self) -> None:
        self.field_def.field_type = self.type_combo.currentText()
        self.field_def.label = self.label_edit.text().strip()
        self.field_def.key = self.key_edit.text().strip()
        self.field_def.default_value = self.default_edit.text()
        self.field_def.tooltip = self.tooltip_edit.text()
        self.field_def.required = self.required_check.isChecked()
        self.field_def.visible_when = self.visible_when_edit.text().strip()
        self.field_def.required_when = self.required_when_edit.text().strip()

        if self.field_def.field_type == "dropdown":
            self.field_def.options = [line.strip() for line in self.options_edit.toPlainText().splitlines() if line.strip()]
        else:
            self.field_def.options = []

        if self.field_def.field_type == "table":
            self.field_def.columns = [line.strip() for line in self.columns_edit.toPlainText().splitlines() if line.strip()]
        else:
            self.field_def.columns = []

        super().accept()


class CsvRowEditor(QDialog):
    """Dialog for editing a single CSV row definition."""

    BASE_DATA_TYPES: List[tuple[str, str]] = [
        ("Field Value", "field"),
        ("Literal", "literal"),
        ("Blank", "blank"),
    ]

    def __init__(
        self,
        row_def: Optional[CsvRowDefinition] = None,
        available_fields: Optional[List[str]] = None,
        field_metadata: Optional[Dict[str, FieldDefinition]] = None,
        parent: Optional[QWidget] = None,
    ) -> None:
        super().__init__(parent)
        self.row_def = row_def or CsvRowDefinition()
        self.available_fields = available_fields or []
        self.field_metadata = field_metadata or {}
        self.setWindowTitle("Edit CSV Row")
        self.setModal(True)
        self.resize(520, 320)
        self._init_ui()
        self._load_row()

    def _init_ui(self) -> None:
        layout = QVBoxLayout(self)

        form = QFormLayout()
        self.prompt_edit = QLineEdit()
        self.key_edit = QLineEdit()

        self.data_type_combo = QComboBox()
        self.data_type_combo.currentIndexChanged.connect(self._on_data_type_changed)
        self.data_value_combo = QComboBox()
        self.data_value_combo.setEditable(True)

        self.table_column_combo = QComboBox()
        self.table_column_combo.setVisible(False)

        data_widget = QWidget()
        data_widget_layout = QVBoxLayout(data_widget)
        data_widget_layout.setContentsMargins(0, 0, 0, 0)
        type_row = QHBoxLayout()
        type_row.setContentsMargins(0, 0, 0, 0)
        type_row.addWidget(self.data_type_combo)
        type_row.addWidget(self.data_value_combo)
        data_widget_layout.addLayout(type_row)
        data_widget_layout.addWidget(self.table_column_combo)

        self.condition_edit = QLineEdit()

        self.repeat_combo = QComboBox()
        self.repeat_combo.addItem("None", "")
        for field in self.field_metadata.values():
            if field.key and field.field_type in {"list", "table"}:
                display = f"{field.label or field.key} ({field.field_type})"
                self.repeat_combo.addItem(display, field.key)
        self.repeat_combo.currentIndexChanged.connect(self._on_repeat_changed)

        self.segment_combo = QComboBox()
        self.segment_combo.addItem("Main Rows", "main")
        self.segment_combo.addItem("Footer Rows", "footer")

        form.addRow("Prompt Text:", self.prompt_edit)
        form.addRow("Key:", self.key_edit)
        form.addRow("Data Source:", data_widget)
        form.addRow("Condition:", self.condition_edit)
        form.addRow("Repeat Field:", self.repeat_combo)
        form.addRow("Segment:", self.segment_combo)

        layout.addLayout(form)

        help_text = QLabel(
            "Data Sources:\n"
            "• Field Value – use a value from another field\n"
            "• Literal – fixed text\n"
            "• Blank – empty string\n"
            "• List Item Value – current value from a list repeat\n"
            "• Table Column Value – value from the current table row"
        )
        help_text.setWordWrap(True)
        help_text.setStyleSheet("color: gray; font-size: 10px;")
        layout.addWidget(help_text)

        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

        self._update_data_type_options()

    def _current_repeat_field(self) -> Optional[FieldDefinition]:
        key = self.repeat_combo.currentData()
        if key:
            return self.field_metadata.get(key)
        return None

    def _update_data_type_options(self) -> None:
        current_data = self.data_type_combo.currentData()
        self.data_type_combo.blockSignals(True)
        self.data_type_combo.clear()
        for text, value in self.BASE_DATA_TYPES:
            self.data_type_combo.addItem(text, value)

        repeat_field = self._current_repeat_field()
        if repeat_field and repeat_field.field_type == "list":
            self.data_type_combo.addItem("List Item Value", "repeat_value")
        if repeat_field and repeat_field.field_type == "table":
            self.data_type_combo.addItem("Table Column Value", "repeat_column")

        index = self.data_type_combo.findData(current_data)
        if index == -1:
            index = 0
        self.data_type_combo.setCurrentIndex(index)
        self.data_type_combo.blockSignals(False)
        self._on_data_type_changed()

    def _on_repeat_changed(self) -> None:
        self._update_data_type_options()

    def _on_data_type_changed(self) -> None:
        data_type = self.data_type_combo.currentData()
        self.table_column_combo.setVisible(data_type == "repeat_column")

        if data_type == "field":
            self.data_value_combo.setEnabled(True)
            self.data_value_combo.setEditable(False)
            self.data_value_combo.clear()
            self.data_value_combo.addItems(self.available_fields)
        elif data_type == "literal":
            self.data_value_combo.setEnabled(True)
            self.data_value_combo.setEditable(True)
            if self.data_value_combo.count() == 0:
                self.data_value_combo.addItem("")
            self.data_value_combo.setCurrentIndex(0)
        elif data_type == "blank":
            self.data_value_combo.clear()
            self.data_value_combo.setEnabled(False)
        elif data_type == "repeat_value":
            self.data_value_combo.clear()
            self.data_value_combo.setEnabled(False)
        elif data_type == "repeat_column":
            self.data_value_combo.clear()
            self.data_value_combo.setEnabled(False)
            self._populate_table_columns()

    def _populate_table_columns(self, selected: str = "") -> None:
        repeat_field = self._current_repeat_field()
        self.table_column_combo.blockSignals(True)
        self.table_column_combo.clear()
        if repeat_field and repeat_field.columns:
            self.table_column_combo.addItems(repeat_field.columns)
            if selected:
                index = self.table_column_combo.findText(selected)
                if index != -1:
                    self.table_column_combo.setCurrentIndex(index)
        self.table_column_combo.blockSignals(False)

    def _load_row(self) -> None:
        self.prompt_edit.setText(self.row_def.prompt)
        self.key_edit.setText(self.row_def.key)
        self.condition_edit.setText(self.row_def.condition)

        repeat_index = self.repeat_combo.findData(self.row_def.repeat_field or "")
        if repeat_index != -1:
            self.repeat_combo.setCurrentIndex(repeat_index)
        self.segment_combo.setCurrentIndex(self.segment_combo.findData(self.row_def.segment or "main"))

        self._update_data_type_options()

        source = self.row_def.data_source or ""
        if source.startswith("field:"):
            data_type = "field"
            value = source[len("field:"):]
            if self.data_value_combo.findText(value) == -1 and value:
                self.data_value_combo.addItem(value)
            self.data_value_combo.setCurrentText(value)
        elif source.startswith("literal:"):
            data_type = "literal"
            value = source[len("literal:"):]
            if self.data_value_combo.count() == 0:
                self.data_value_combo.addItem(value)
            self.data_value_combo.setEditText(value)
        elif source == "repeat_value":
            data_type = "repeat_value"
        elif source.startswith("repeat_column:"):
            data_type = "repeat_column"
            column = source[len("repeat_column:"):]
            self._populate_table_columns(column)
        else:
            data_type = "blank"

        type_index = self.data_type_combo.findData(data_type)
        if type_index != -1:
            self.data_type_combo.setCurrentIndex(type_index)
            self._on_data_type_changed()
            if data_type == "field":
                self.data_value_combo.setCurrentText(value)
            elif data_type == "literal":
                self.data_value_combo.setEditText(value)
            elif data_type == "repeat_column":
                self._populate_table_columns(column)

    def accept(self) -> None:
        data_type = self.data_type_combo.currentData()
        repeat_field_key = self.repeat_combo.currentData()

        if data_type in {"repeat_value", "repeat_column"} and not repeat_field_key:
            QMessageBox.warning(self, "Invalid Row", "Select a repeat field before using repeat data sources.")
            return

        if data_type == "field":
            field_value = self.data_value_combo.currentText().strip()
            if not field_value:
                QMessageBox.warning(self, "Invalid Row", "Select a field to source the data from.")
                return
            self.row_def.data_source = f"field:{field_value}"
        elif data_type == "literal":
            literal_value = self.data_value_combo.currentText()
            self.row_def.data_source = f"literal:{literal_value}"
        elif data_type == "blank":
            self.row_def.data_source = "blank"
        elif data_type == "repeat_value":
            self.row_def.data_source = "repeat_value"
        elif data_type == "repeat_column":
            column = self.table_column_combo.currentText().strip()
            if not column:
                QMessageBox.warning(self, "Invalid Row", "Select a table column to use for this row.")
                return
            self.row_def.data_source = f"repeat_column:{column}"
        else:
            self.row_def.data_source = "blank"

        self.row_def.prompt = self.prompt_edit.text()
        self.row_def.key = self.key_edit.text()
        self.row_def.condition = self.condition_edit.text()
        self.row_def.repeat_field = repeat_field_key or ""
        self.row_def.segment = self.segment_combo.currentData() or "main"
        super().accept()


class GuiCreatorGUI(BaseDialog):
    """Main GUI Creator interface."""

    def __init__(self) -> None:
        super().__init__()
        self.gui_def = GuiDefinition()
        self.setWindowTitle("GUI Creator")
        self.resize(1024, 720)
        self.setMinimumSize(860, 600)
        self._init_ui()

    def _init_ui(self) -> None:
        main_layout = QVBoxLayout(self)

        header_layout = QHBoxLayout()
        title = QLabel("GUI Creator")
        title.setFont(QFont("Arial", 16, QFont.Bold))
        title.setStyleSheet("color: #CCCCCC;")
        header_layout.addWidget(title)
        header_layout.addStretch()

        new_btn = QPushButton("New")
        new_btn.clicked.connect(self.new_gui)
        load_btn = QPushButton("Load")
        load_btn.clicked.connect(self.load_gui)
        save_btn = QPushButton("Save")
        save_btn.clicked.connect(self.save_gui)
        generate_btn = QPushButton("Generate & Test")
        generate_btn.clicked.connect(self.generate_test_gui)

        header_layout.addWidget(new_btn)
        header_layout.addWidget(load_btn)
        header_layout.addWidget(save_btn)
        header_layout.addWidget(generate_btn)
        main_layout.addLayout(header_layout)

        self.tabs = QTabWidget()
        main_layout.addWidget(self.tabs)

        self._setup_basic_info_tab()
        self._setup_fields_tab()
        self._setup_csv_template_tab()

        close_btn = QPushButton("Close")
        close_btn.clicked.connect(self.reject)
        main_layout.addWidget(close_btn)

    def _setup_basic_info_tab(self) -> None:
        tab = QWidget()
        layout = QVBoxLayout(tab)

        form = QFormLayout()
        self.name_edit = QLineEdit()
        self.description_edit = QTextEdit()
        self.description_edit.setMaximumHeight(120)

        form.addRow("GUI Name:", self.name_edit)
        form.addRow("Description:", self.description_edit)
        layout.addLayout(form)

        self.include_finished_checkbox = QCheckBox("Automatically append FINISHED row")
        self.include_finished_checkbox.setChecked(True)
        layout.addWidget(self.include_finished_checkbox)
        layout.addStretch()
        self.tabs.addTab(tab, "Basic Info")

    def _setup_fields_tab(self) -> None:
        tab = QWidget()
        layout = QHBoxLayout(tab)

        left_layout = QVBoxLayout()
        left_layout.addWidget(QLabel("Form Fields:"))
        self.fields_list = QListWidget()
        left_layout.addWidget(self.fields_list)

        buttons_layout = QHBoxLayout()
        add_field_btn = QPushButton("Add Field")
        add_field_btn.clicked.connect(self.add_field)
        edit_field_btn = QPushButton("Edit Field")
        edit_field_btn.clicked.connect(self.edit_field)
        remove_field_btn = QPushButton("Remove Field")
        remove_field_btn.clicked.connect(self.remove_field)
        buttons_layout.addWidget(add_field_btn)
        buttons_layout.addWidget(edit_field_btn)
        buttons_layout.addWidget(remove_field_btn)
        left_layout.addLayout(buttons_layout)

        right_layout = QVBoxLayout()
        right_layout.addWidget(QLabel("Preview:"))
        self.preview_scroll = QScrollArea()
        self.preview_scroll.setWidgetResizable(True)
        self.preview_widget = QWidget()
        self.preview_layout = QVBoxLayout(self.preview_widget)
        self.preview_scroll.setWidget(self.preview_widget)
        right_layout.addWidget(self.preview_scroll)

        layout.addLayout(left_layout, 1)
        layout.addLayout(right_layout, 1)
        self.tabs.addTab(tab, "Form Fields")

    def _setup_csv_template_tab(self) -> None:
        tab = QWidget()
        layout = QVBoxLayout(tab)
        layout.addWidget(QLabel("CSV Output Template:"))

        self.csv_table = QTableWidget()
        self.csv_table.setColumnCount(6)
        self.csv_table.setHorizontalHeaderLabels([
            "Prompt",
            "Key",
            "Data Source",
            "Condition",
            "Repeat Field",
            "Segment",
        ])
        layout.addWidget(self.csv_table)

        csv_buttons = QHBoxLayout()
        add_btn = QPushButton("Add Row")
        add_btn.clicked.connect(self.add_csv_row)
        edit_btn = QPushButton("Edit Row")
        edit_btn.clicked.connect(self.edit_csv_row)
        remove_btn = QPushButton("Remove Row")
        remove_btn.clicked.connect(self.remove_csv_row)
        up_btn = QPushButton("Move Up")
        up_btn.clicked.connect(self.move_csv_row_up)
        down_btn = QPushButton("Move Down")
        down_btn.clicked.connect(self.move_csv_row_down)

        csv_buttons.addWidget(add_btn)
        csv_buttons.addWidget(edit_btn)
        csv_buttons.addWidget(remove_btn)
        csv_buttons.addWidget(up_btn)
        csv_buttons.addWidget(down_btn)
        layout.addLayout(csv_buttons)

        self.tabs.addTab(tab, "CSV Template")

    # Field management -------------------------------------------------

    def add_field(self) -> None:
        editor = FieldEditor(parent=self)
        if editor.exec_() == QDialog.Accepted:
            self.gui_def.fields.append(editor.field_def)
            self.refresh_fields_display()

    def edit_field(self) -> None:
        row = self.fields_list.currentRow()
        if 0 <= row < len(self.gui_def.fields):
            editor = FieldEditor(self.gui_def.fields[row], parent=self)
            if editor.exec_() == QDialog.Accepted:
                self.refresh_fields_display()

    def remove_field(self) -> None:
        row = self.fields_list.currentRow()
        if 0 <= row < len(self.gui_def.fields):
            del self.gui_def.fields[row]
            self.refresh_fields_display()

    def refresh_fields_display(self) -> None:
        self.fields_list.clear()
        for field in self.gui_def.fields:
            descriptor = field.label or field.key or "(unnamed)"
            self.fields_list.addItem(f"{descriptor} ({field.field_type})")

        while self.preview_layout.count():
            item = self.preview_layout.takeAt(0)
            widget = item.widget() if item else None
            if widget:
                widget.deleteLater()

        for field in self.gui_def.fields:
            self.preview_layout.addWidget(self._create_preview_widget(field))
        self.preview_layout.addStretch()

    def _create_preview_widget(self, field: FieldDefinition) -> QWidget:
        container = QWidget()
        container_layout = QVBoxLayout(container)
        container_layout.setContentsMargins(5, 2, 5, 2)
        layout = QHBoxLayout()
        label = QLabel(f"{field.label or field.key}:" if (field.label or field.key) else "Field:")
        layout.addWidget(label)

        if field.field_type == "text":
            widget = QLineEdit()
            widget.setPlaceholderText(field.default_value)
        elif field.field_type == "number":
            widget = QSpinBox()
            try:
                widget.setValue(int(field.default_value))
            except ValueError:
                widget.setValue(0)
        elif field.field_type == "checkbox":
            widget = QCheckBox()
            widget.setChecked(field.default_value.lower() == "true")
        elif field.field_type == "dropdown":
            widget = QComboBox()
            widget.addItems(field.options)
        elif field.field_type == "list":
            widget = QLineEdit()
            widget.setPlaceholderText("List editor")
        elif field.field_type == "table":
            widget = QLineEdit()
            widget.setPlaceholderText("Table editor")
        else:
            widget = QLineEdit()

        widget.setEnabled(False)
        layout.addWidget(widget)
        container_layout.addLayout(layout)

        info_bits: List[str] = []
        if field.visible_when:
            info_bits.append(f"Visible when {field.visible_when}")
        if field.required_when:
            info_bits.append(f"Required when {field.required_when}")
        if info_bits:
            info_label = QLabel("; ".join(info_bits))
            info_label.setStyleSheet("color: gray; font-size: 10px;")
            container_layout.addWidget(info_label)
        return container

    # CSV row management -----------------------------------------------

    def _build_field_metadata(self) -> Dict[str, FieldDefinition]:
        return {field.key: field for field in self.gui_def.fields if field.key}

    def _available_value_fields(self) -> List[str]:
        return [
            field.key
            for field in self.gui_def.fields
            if field.key and field.field_type in {"text", "number", "checkbox", "dropdown"}
        ]

    def add_csv_row(self) -> None:
        editor = CsvRowEditor(
            available_fields=self._available_value_fields(),
            field_metadata=self._build_field_metadata(),
            parent=self,
        )
        if editor.exec_() == QDialog.Accepted:
            self.gui_def.csv_rows.append(editor.row_def)
            self.refresh_csv_display()

    def edit_csv_row(self) -> None:
        row = self.csv_table.currentRow()
        if 0 <= row < len(self.gui_def.csv_rows):
            editor = CsvRowEditor(
                row_def=self.gui_def.csv_rows[row],
                available_fields=self._available_value_fields(),
                field_metadata=self._build_field_metadata(),
                parent=self,
            )
            if editor.exec_() == QDialog.Accepted:
                self.refresh_csv_display()

    def remove_csv_row(self) -> None:
        row = self.csv_table.currentRow()
        if 0 <= row < len(self.gui_def.csv_rows):
            del self.gui_def.csv_rows[row]
            self.refresh_csv_display()

    def move_csv_row_up(self) -> None:
        row = self.csv_table.currentRow()
        if 0 < row < len(self.gui_def.csv_rows):
            self.gui_def.csv_rows[row - 1], self.gui_def.csv_rows[row] = (
                self.gui_def.csv_rows[row],
                self.gui_def.csv_rows[row - 1],
            )
            self.refresh_csv_display()
            self.csv_table.setCurrentCell(row - 1, 0)

    def move_csv_row_down(self) -> None:
        row = self.csv_table.currentRow()
        if 0 <= row < len(self.gui_def.csv_rows) - 1:
            self.gui_def.csv_rows[row + 1], self.gui_def.csv_rows[row] = (
                self.gui_def.csv_rows[row],
                self.gui_def.csv_rows[row + 1],
            )
            self.refresh_csv_display()
            self.csv_table.setCurrentCell(row + 1, 0)

    def refresh_csv_display(self) -> None:
        self.csv_table.setRowCount(len(self.gui_def.csv_rows))
        metadata = self._build_field_metadata()
        for row_index, row_def in enumerate(self.gui_def.csv_rows):
            self.csv_table.setItem(row_index, 0, QTableWidgetItem(row_def.prompt))
            self.csv_table.setItem(row_index, 1, QTableWidgetItem(row_def.key))
            self.csv_table.setItem(row_index, 2, QTableWidgetItem(row_def.data_source))
            self.csv_table.setItem(row_index, 3, QTableWidgetItem(row_def.condition))
            repeat_display = ""
            if row_def.repeat_field:
                field = metadata.get(row_def.repeat_field)
                repeat_display = field.label or field.key if field else row_def.repeat_field
            self.csv_table.setItem(row_index, 4, QTableWidgetItem(repeat_display))
            segment_display = "Main" if row_def.segment == "main" else "Footer"
            self.csv_table.setItem(row_index, 5, QTableWidgetItem(segment_display))

    # Persistence ------------------------------------------------------

    def new_gui(self) -> None:
        if QMessageBox.question(self, "New GUI", "Start a new GUI definition?", QMessageBox.Yes | QMessageBox.No) == QMessageBox.Yes:
            self.gui_def = GuiDefinition()
            self.name_edit.clear()
            self.description_edit.clear()
            self.include_finished_checkbox.setChecked(True)
            self.refresh_fields_display()
            self.refresh_csv_display()

    def save_gui(self) -> None:
        self.gui_def.name = self.name_edit.text().strip()
        self.gui_def.description = self.description_edit.toPlainText()
        self.gui_def.include_finished = self.include_finished_checkbox.isChecked()

        if not self.gui_def.name:
            QMessageBox.warning(self, "Missing Name", "Please enter a GUI name before saving.")
            return

        default_path = os.path.join(
            get_default_save_path_for_csv_writer(""),
            f"{self.gui_def.name}.gui.json",
        )
        file_path, _ = QFileDialog.getSaveFileName(
            self,
            "Save GUI Definition",
            default_path,
            "GUI Files (*.gui.json);;All Files (*)",
        )
        if not file_path:
            return

        try:
            data = {
                "name": self.gui_def.name,
                "description": self.gui_def.description,
                "include_finished": self.gui_def.include_finished,
                "fields": [self._field_to_dict(field) for field in self.gui_def.fields],
                "csv_rows": [self._csv_row_to_dict(row) for row in self.gui_def.csv_rows],
            }
            with open(file_path, "w", encoding="utf-8") as handle:
                json.dump(data, handle, indent=2)
            QMessageBox.information(self, "Saved", f"GUI definition saved to:\n{file_path}")
        except Exception as exc:
            QMessageBox.critical(self, "Save Failed", f"Unable to save GUI definition:\n{exc}")

    def load_gui(self) -> None:
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "Load GUI Definition",
            get_default_save_path_for_csv_writer(""),
            "GUI Files (*.gui.json);;All Files (*)",
        )
        if not file_path:
            return

        try:
            with open(file_path, "r", encoding="utf-8") as handle:
                data = json.load(handle)

            self.gui_def = GuiDefinition()
            self.gui_def.name = data.get("name", "")
            self.gui_def.description = data.get("description", "")
            self.gui_def.include_finished = data.get("include_finished", True)

            for field_data in data.get("fields", []):
                self.gui_def.fields.append(self._dict_to_field(field_data))

            for row_data in data.get("csv_rows", []):
                self.gui_def.csv_rows.append(self._dict_to_csv_row(row_data))

            self.name_edit.setText(self.gui_def.name)
            self.description_edit.setPlainText(self.gui_def.description)
            self.include_finished_checkbox.setChecked(self.gui_def.include_finished)
            self.refresh_fields_display()
            self.refresh_csv_display()
            QMessageBox.information(self, "Loaded", f"GUI definition loaded from:\n{file_path}")
        except Exception as exc:
            QMessageBox.critical(self, "Load Failed", f"Unable to load GUI definition:\n{exc}")

    # Helpers ---------------------------------------------------------

    def generate_test_gui(self) -> None:
        if not self.gui_def.fields:
            QMessageBox.warning(self, "Incomplete", "Add at least one form field first.")
            return
        if not self.gui_def.csv_rows:
            QMessageBox.warning(self, "Incomplete", "Add at least one CSV template row first.")
            return

        self.gui_def.name = self.name_edit.text().strip() or "Test GUI"
        self.gui_def.description = self.description_edit.toPlainText()
        self.gui_def.include_finished = self.include_finished_checkbox.isChecked()

        try:
            generated_gui = GeneratedGUI(self.gui_def, parent=self)
            generated_gui.exec_()
        except Exception as exc:
            QMessageBox.critical(self, "Generation Failed", f"Unable to generate GUI:\n{exc}")

    def _field_to_dict(self, field: FieldDefinition) -> Dict[str, Any]:
        return {
            "field_type": field.field_type,
            "label": field.label,
            "key": field.key,
            "default_value": field.default_value,
            "options": field.options,
            "columns": field.columns,
            "required": field.required,
            "tooltip": field.tooltip,
            "visible_when": field.visible_when,
            "required_when": field.required_when,
        }

    def _dict_to_field(self, data: Dict[str, Any]) -> FieldDefinition:
        field = FieldDefinition()
        field.field_type = data.get("field_type", "text")
        field.label = data.get("label", "")
        field.key = data.get("key", "")
        field.default_value = data.get("default_value", "")
        field.options = data.get("options", [])
        field.columns = data.get("columns", [])
        field.required = data.get("required", True)
        field.tooltip = data.get("tooltip", "")
        field.visible_when = data.get("visible_when", "")
        field.required_when = data.get("required_when", "")
        return field

    def _csv_row_to_dict(self, row: CsvRowDefinition) -> Dict[str, Any]:
        return {
            "prompt": row.prompt,
            "key": row.key,
            "data_source": row.data_source,
            "condition": row.condition,
            "repeat_field": row.repeat_field,
            "segment": row.segment,
        }

    def _dict_to_csv_row(self, data: Dict[str, Any]) -> CsvRowDefinition:
        row = CsvRowDefinition()
        row.prompt = data.get("prompt", "")
        row.key = data.get("key", "")
        row.data_source = data.get("data_source", "")
        row.condition = data.get("condition", "")
        row.repeat_field = data.get("repeat_field", "")
        row.segment = data.get("segment", "main")
        return row


from .GeneratedGUI import GeneratedGUI  # noqa: E402
