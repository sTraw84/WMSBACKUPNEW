import csv

def write_csv_headers(file):
    headers = ["NUMBER", "PROMPT", "KEY", "DATA"]
    with open(file.name, 'w', newline='') as csv_file:
        writer = csv.writer(csv_file, delimiter=',')
        writer.writerow(headers)


def append_to_csv(file, row_counter, c40_list, parent_lpn_textbox):
    with open(file.name, 'a', newline='') as csv_file:
        writer = csv.writer(csv_file, delimiter=',')
        writer.writerow([row_counter, "ParentLPN>", "ParentLPN", parent_lpn_textbox.text(), ""])
        row_counter += 1
        for c40 in c40_list:
            writer.writerow([row_counter, "Next LPN >", "C40", c40, ""])
            row_counter += 1
            writer.writerow([row_counter, "<More>", "BLANK", "", ""])
            row_counter += 1
    return row_counter


def append_finished(file, row_counter):
    with open(file.name, 'a', newline='') as csv_file:
        writer = csv.writer(csv_file, delimiter=',')
        writer.writerow([row_counter, "FINISHED", "FINISHED", "", ""])


def save_csv(file_name, temp_file):
    try:
        rows = []
        with open(temp_file.name, 'r') as temp_file_r:
            reader = csv.reader(temp_file_r)
            rows = list(reader)
        if rows:
            last_row_number = int(rows[-1][0]) if rows[-1][0] else 0
            rows.append([str(last_row_number + 1), "CONSOLIDATE", "", "", ""])
        with open(file_name, 'w', newline='') as file:
            writer = csv.writer(file, delimiter=',')
            for row in rows:
                writer.writerow(row)
        return True
    except Exception as e:
        print(f"Error saving CSV: {e}")
        return False


def read_csv(temp_file):
    with open(temp_file.name, 'r') as file:
        reader = csv.reader(file)
        return list(reader)
