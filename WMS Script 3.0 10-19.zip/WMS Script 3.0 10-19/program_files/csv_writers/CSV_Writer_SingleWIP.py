import csv
import os

def write_csv_headers(file):
    headers = ['NUMBER', 'PROMPT', 'KEY', 'DATA']
    writer = csv.writer(file, delimiter=',')
    writer.writerow(headers)

def build_rows_from_sn_list(sn_list, lpn_value, job_value):
    rows = []
    row_number = 1
    rows.append([row_number, 'LPN      >', 'BLANK', lpn_value])
    row_number += 1
    rows.append([row_number, 'Job      >', 'Job', job_value])
    row_number += 1
    last_index = len(sn_list) - 1
    for idx, sn in enumerate(sn_list):
        rows.append([row_number, 'SN       >', 'SN1', sn])
        row_number += 1
        rows.append([row_number, '<Components>', 'BLANK', ''])
        row_number += 1
        rows.append([row_number, 'SN       >', 'SN2', sn])
        row_number += 1
        if idx != last_index:
            rows.append([row_number, '<Next Assm>', 'BLANK', ''])
            row_number += 1
    rows.append([row_number, 'FINISHED', '', ''])
    row_number += 1
    rows.append([row_number, 'WIP', '', ''])
    return rows

def save_wip_single_csv(file_path, sn_list, lpn_value, job_value):
    os.makedirs(os.path.dirname(file_path) or '.', exist_ok=True)
    with open(file_path, 'w', newline='', encoding='utf-8') as f:
        write_csv_headers(f)
        writer = csv.writer(f, delimiter=',')
        for row in build_rows_from_sn_list(sn_list, lpn_value, job_value):
            writer.writerow(row)
    return True
