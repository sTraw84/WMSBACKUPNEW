#!/usr/bin/env python3
"""
Test script for SubTransferGUI CSV writer functionality
Tests all four combinations:
1. Sub Inventory Transfer + Loose Parts
2. Sub Inventory Transfer + LPN Transfer  
3. Cost Group Transfer + Loose Parts
4. Cost Group Transfer + LPN Transfer
"""

import tempfile
import os
import sys

# Add the parent directory to path so we can import program_files
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from program_files.csv_writers import CSV_Writer_SubTransfer

def test_sub_inventory_loose_parts():
    """Test Sub Inventory Transfer + Loose Parts (original functionality)"""
    print("Testing Sub Inventory Transfer + Loose Parts...")
    
    # Create temporary file
    temp_file = tempfile.NamedTemporaryFile(delete=False, mode='w', newline='')
    CSV_Writer_SubTransfer.write_csv_headers(temp_file)
    temp_file.close()
    
    # Test data
    child_parts = [
        {'part_number': '1415-A-048-RED.ACTUAL.2380032.MSN/CSCO', 'quantity': '5', 'from_loc': 'ZL4PCSTCK01'},
        {'part_number': '1415-A-048-BLU.ACTUAL.2380032.MSN/CSCO', 'quantity': '5', 'from_loc': 'ZL4PCSTCK02'}
    ]
    locators = ['ZL4ASSET01']
    
    # Append to CSV
    row_counter = CSV_Writer_SubTransfer.append_to_csv(temp_file, 1, child_parts, locators)
    CSV_Writer_SubTransfer.append_finished(temp_file, row_counter)
    
    # Read and print result
    with open(temp_file.name, 'r') as f:
        content = f.read()
        print("Result:")
        print(content)
        print("=" * 50)
    
    # Cleanup
    os.unlink(temp_file.name)

def test_sub_inventory_lpn():
    """Test Sub Inventory Transfer + LPN Transfer"""
    print("Testing Sub Inventory Transfer + LPN Transfer...")
    
    # Create temporary file
    temp_file = tempfile.NamedTemporaryFile(delete=False, mode='w', newline='')
    CSV_Writer_SubTransfer.write_csv_headers(temp_file)
    temp_file.close()
    
    # Test data
    lpns = [
        'L40-MO154386964-001-7830',
        'L40-MO154386964-003-7830',
        'L40-MO154386964-004-7830'
    ]
    to_location = 'MSFWIP'
    
    # Append to CSV
    row_counter = CSV_Writer_SubTransfer.append_lpn_transfer_to_csv(temp_file, 1, lpns, to_location)
    CSV_Writer_SubTransfer.append_finished(temp_file, row_counter)
    
    # Read and print result
    with open(temp_file.name, 'r') as f:
        content = f.read()
        print("Result:")
        print(content)
        print("=" * 50)
    
    # Cleanup
    os.unlink(temp_file.name)

def test_cost_group_lpn():
    """Test Cost Group Transfer + LPN Transfer"""
    print("Testing Cost Group Transfer + LPN Transfer...")
    
    # Create temporary file
    temp_file = tempfile.NamedTemporaryFile(delete=False, mode='w', newline='')
    CSV_Writer_SubTransfer.write_csv_headers(temp_file)
    temp_file.close()
    
    # Test data
    lpns = [
        'L40-MO154386964-002-7830',
        'L40-MO154386964-003-7830',
        'L40-MO154386964-004-7830'
    ]
    to_location = 'ZL3RU01'
    to_cost_group = 'MCIO_RUS-C'
    
    # Append to CSV
    row_counter = CSV_Writer_SubTransfer.append_lpn_transfer_to_csv(temp_file, 1, lpns, to_location, to_cost_group)
    CSV_Writer_SubTransfer.append_finished(temp_file, row_counter)
    
    # Read and print result
    with open(temp_file.name, 'r') as f:
        content = f.read()
        print("Result:")
        print(content)
        print("=" * 50)
    
    # Cleanup
    os.unlink(temp_file.name)

def test_cost_group_loose_parts():
    """Test Cost Group Transfer + Loose Parts"""
    print("Testing Cost Group Transfer + Loose Parts...")
    
    # Create temporary file
    temp_file = tempfile.NamedTemporaryFile(delete=False, mode='w', newline='')
    CSV_Writer_SubTransfer.write_csv_headers(temp_file)
    temp_file.close()
    
    # Test data
    child_parts = [
        {'part_number': '1415-A-048-RED.ACTUAL.2380032.MSN/CSCO', 'quantity': '5', 'from_loc': 'ZL4PCSTCK01'},
        {'part_number': '1415-A-048-BLU.ACTUAL.2380032.MSN/CSCO', 'quantity': '5', 'from_loc': 'ZL4PCSTCK02'}
    ]
    locators = ['ZL3RU01']
    to_cost_group = 'MCIO_RUS-C'
    
    # Append to CSV
    row_counter = CSV_Writer_SubTransfer.append_loose_parts_cg_to_csv(temp_file, 1, child_parts, locators, to_cost_group)
    CSV_Writer_SubTransfer.append_finished(temp_file, row_counter)
    
    # Read and print result
    with open(temp_file.name, 'r') as f:
        content = f.read()
        print("Result:")
        print(content)
        print("=" * 50)
    
    # Cleanup
    os.unlink(temp_file.name)

if __name__ == "__main__":
    print("Running SubTransferGUI CSV Writer Tests")
    print("=" * 50)
    
    test_sub_inventory_loose_parts()
    test_sub_inventory_lpn()
    test_cost_group_lpn()
    test_cost_group_loose_parts()
    
    print("All tests completed!")