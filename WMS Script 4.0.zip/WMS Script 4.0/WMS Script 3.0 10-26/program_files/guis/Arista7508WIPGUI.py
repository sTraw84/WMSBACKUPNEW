"""Inline-enabled GUI for building Arista 7508 WIP automation files."""

from __future__ import annotations

import os
from typing import List, Tuple

from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont
from PyQt5.QtWidgets import (
    QApplication,
    QFileDialog,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QScrollArea,
    QSplitter,
    QTextEdit,
    QVBoxLayout,
    QWidget,
    QCheckBox,
)

from .BaseGUI import BaseDialog
from ..csv_writers import CSV_Writer_7508WIP
from ..utils.file_paths import get_csv_files_directory, ensure_directory_exists


class Arista7508WIPGUI(BaseDialog):
    """Dialog for loading a 7508 BOM workbook and generating a WIP CSV."""

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.excel_path: str = ""
        self.grouped_serials: List[Tuple[str, List[str]]] = []

        self._side_panel_width = 320
        self._min_side_panel_width = 240
        self._min_left_width = 360
        self._left_before_side_panel: int | None = None

        self._init_ui()
        self.finalize_initial_size(extra_width=80)

    # ------------------------------------------------------------------
    # UI construction
    def _init_ui(self) -> None:
        self.setWindowTitle("Arista 7508 WIP Builder")

        self.main_layout = QVBoxLayout(self)
        self.splitter = QSplitter(Qt.Horizontal, self)  # type: ignore[attr-defined]
        self.splitter.setHandleWidth(1)
        self.main_layout.addWidget(self.splitter)

        self.left_container = QWidget(self.splitter)
        self.left_layout = QVBoxLayout(self.left_container)
        self.left_layout.setContentsMargins(0, 0, 0, 0)
        self.left_layout.setSpacing(6)

        top_bar = QWidget(self.left_container)
        top_layout = QHBoxLayout(top_bar)
        top_layout.setContentsMargins(0, 0, 0, 0)
        self.status_label = QLabel("Select workbook", top_bar)
        self.status_label.setStyleSheet("color: #CCCCCC;")
        top_layout.addWidget(self.status_label)
        self.toggle_side_panel_button = QPushButton("Summary ▶", top_bar)
        self.toggle_side_panel_button.setToolTip("Show or hide the summary panel")
        self.toggle_side_panel_button.clicked.connect(self.toggle_side_panel)
        top_layout.addWidget(self.toggle_side_panel_button)
        self.left_layout.addWidget(top_bar)

        scroll_area = QScrollArea(self.left_container)
        scroll_area.setWidgetResizable(True)
        form_widget = QWidget(scroll_area)
        scroll_area.setWidget(form_widget)
        form_layout = QVBoxLayout(form_widget)
        form_layout.setContentsMargins(6, 6, 6, 6)
        form_layout.setSpacing(10)

        title = QLabel("Arista 7508 WIP Builder", form_widget)
        title.setFont(QFont("Arial", 18, weight=QFont.Bold))
        title.setStyleSheet("color: #CCCCCC;")
        alignment_center = getattr(getattr(Qt, "AlignmentFlag", Qt), "AlignCenter")
        title.setAlignment(alignment_center)  # type: ignore[arg-type]
        form_layout.addWidget(title)

        self.lpn_checkbox = QCheckBox("Enable LPN Entry", form_widget)
        self.lpn_checkbox.stateChanged.connect(self.toggle_lpn_editing)
        form_layout.addWidget(self.lpn_checkbox)

        lpn_row = QHBoxLayout()
        lpn_label = QLabel("LPN:", form_widget)
        self.lpn_edit = QLineEdit(form_widget)
        self.lpn_edit.setPlaceholderText("Enable LPN entry to provide a default value")
        self.lpn_edit.setReadOnly(True)
        self.lpn_edit.setStyleSheet("color: gray;")
        lpn_row.addWidget(lpn_label)
        lpn_row.addWidget(self.lpn_edit)
        form_layout.addLayout(lpn_row)

        job_row = QHBoxLayout()
        job_label = QLabel("Job#:", form_widget)
        self.job_edit = QLineEdit(form_widget)
        self.job_edit.setPlaceholderText("Enter job number, e.g. 3926256")
        job_row.addWidget(job_label)
        job_row.addWidget(self.job_edit)
        form_layout.addLayout(job_row)

        file_label = QLabel("Load workbook (Excel):", form_widget)
        form_layout.addWidget(file_label)

        file_row = QHBoxLayout()
        self.file_edit = QLineEdit(form_widget)
        self.file_edit.setReadOnly(True)
        browse_button = QPushButton("Browse", form_widget)
        browse_button.clicked.connect(self.browse_workbook)
        reload_button = QPushButton("Reload", form_widget)
        reload_button.clicked.connect(self.reload_workbook)
        file_row.addWidget(self.file_edit)
        file_row.addWidget(browse_button)
        file_row.addWidget(reload_button)
        form_layout.addLayout(file_row)

        export_button = QPushButton("Export Script CSV", form_widget)
        export_button.clicked.connect(self.export_script_csv)
        form_layout.addWidget(export_button)

        form_layout.addStretch()
        self.left_layout.addWidget(scroll_area)

        self.side_panel = QWidget(self.splitter)
        self.side_layout = QVBoxLayout(self.side_panel)
        self.side_layout.setContentsMargins(8, 8, 8, 8)
        self.side_layout.setSpacing(8)

        summary_title = QLabel("Workbook Summary", self.side_panel)
        summary_title.setFont(QFont("Arial", 14, weight=QFont.Bold))
        summary_title.setStyleSheet("color: #CCCCCC;")
        self.side_layout.addWidget(summary_title)

        self.summary_edit = QTextEdit(self.side_panel)
        self.summary_edit.setReadOnly(True)
        self.summary_edit.setLineWrapMode(QTextEdit.NoWrap)
        self.side_layout.addWidget(self.summary_edit)

        self.side_panel.hide()
        self.splitter.setSizes([self._min_left_width, 0])
        self._update_side_panel_button()

    # ------------------------------------------------------------------
    # UI helpers
    def toggle_lpn_editing(self, state: int) -> None:
        checked_state = getattr(getattr(Qt, "CheckState", Qt), "Checked")
        if state == checked_state:
            self.lpn_edit.setReadOnly(False)
            self.lpn_edit.setStyleSheet("color: white;")
            self.lpn_edit.setFocus()
        else:
            self.lpn_edit.clear()
            self.lpn_edit.setPlaceholderText("Enable LPN entry to provide a default value")
            self.lpn_edit.setReadOnly(True)
            self.lpn_edit.setStyleSheet("color: gray;")

    def toggle_side_panel(self) -> None:
        sizes = self.splitter.sizes()
        if len(sizes) < 2:
            return
        if sizes[1] == 0:
            self._open_side_panel()
        else:
            self._collapse_side_panel()
        self._update_side_panel_button()

    def _open_side_panel(self) -> None:
        sizes = self.splitter.sizes()
        if len(sizes) < 2:
            return
        left_width = max(sizes[0], self._min_left_width)
        desired_right = max(self._min_side_panel_width, self._side_panel_width)
        self._left_before_side_panel = left_width
        self.side_panel.show()
        self.resize(self.width() + desired_right, self.height())
        self.splitter.setSizes([left_width, desired_right])

    def _collapse_side_panel(self) -> None:
        sizes = self.splitter.sizes()
        if len(sizes) < 2:
            return
        right_width = sizes[1]
        if right_width <= 0:
            return
        target_width = max(self.minimumWidth(), self.width() - right_width)
        self.resize(target_width, self.height())
        left_target = self._left_before_side_panel if self._left_before_side_panel is not None else sizes[0]
        left_target = max(self._min_left_width, min(left_target, target_width))
        self.splitter.setSizes([left_target, 0])
        self.side_panel.hide()
        self._left_before_side_panel = None

    def _ensure_side_panel_visible(self) -> None:
        sizes = self.splitter.sizes()
        if len(sizes) < 2:
            return
        if sizes[1] == 0:
            self._open_side_panel()

    def _update_side_panel_button(self) -> None:
        sizes = self.splitter.sizes()
        if sizes and len(sizes) >= 2 and sizes[1] > 0:
            self.toggle_side_panel_button.setText("Summary ◀")
        else:
            self.toggle_side_panel_button.setText("Summary ▶")

    def _set_status(self, message: str, level: str = "info") -> None:
        colors = {
            "info": "#CCCCCC",
            "success": "#44C767",
            "warn": "#EFD469",
            "error": "#FF6B6B",
        }
        color = colors.get(level, "#CCCCCC")
        self.status_label.setText(f"<span style='color:{color};'>{message}</span>")

    # ------------------------------------------------------------------
    # Workbook handling
    def browse_workbook(self) -> None:
        start_dir = self.excel_path or os.getcwd()
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Select 7508 Workbook",
            start_dir,
            "Excel Files (*.xlsx *.xlsm);;All Files (*)",
        )
        if not path:
            return
        self.file_edit.setText(path)
        self.excel_path = path
        self.reload_workbook()

    def reload_workbook(self) -> None:
        path = self.file_edit.text().strip()
        if not path:
            self._set_status("Select a workbook to parse", "warn")
            self.grouped_serials = []
            self._update_summary_panel()
            return
        if not os.path.isfile(path):
            self._set_status("Workbook not found", "error")
            self.grouped_serials = []
            self._update_summary_panel()
            return

        try:
            grouped = CSV_Writer_7508WIP.load_serial_sets_from_workbook(path)
            self.grouped_serials = grouped
            if grouped:
                self._set_status(f"Loaded {len(grouped)} assemblies", "success")
                self._ensure_side_panel_visible()
            else:
                self._set_status("Workbook contains no data rows", "warn")
            self._update_summary_panel()
        except Exception as exc:
            self.grouped_serials = []
            self._update_summary_panel()
            QMessageBox.critical(self, "Error", f"Failed to parse workbook:\n{exc}")
            self._set_status("Failed to parse workbook", "error")

    def _update_summary_panel(self) -> None:
        if not self.grouped_serials:
            self.summary_edit.setPlainText("No workbook loaded.")
            return

        lines: List[str] = []
        for index, (lpn, serials) in enumerate(self.grouped_serials, start=1):
            chassis = serials[0] if serials else ""
            sup = serials[1] if len(serials) > 1 else ""
            fms = [value for value in serials[2:] if value]
            lines.append(f"{index:02d}. LPN: {lpn}")
            lines.append(f"    MasterSN: {chassis or 'Missing'}")
            lines.append(f"    SupSN: {sup or 'Missing'}")
            if fms:
                lines.append("    FMSN: " + ", ".join(fms))
            else:
                lines.append("    No fabric module serials")
        self.summary_edit.setPlainText("\n".join(lines))

    # ------------------------------------------------------------------
    # Export
    def export_script_csv(self) -> None:
        if not self.grouped_serials:
            self.reload_workbook()
            if not self.grouped_serials:
                QMessageBox.warning(self, "No Data", "Load a workbook before exporting.")
                return

        job_value = self.job_edit.text().strip()
        if not job_value:
            QMessageBox.warning(self, "Missing Job#", "Enter a job number before exporting.")
            return

        lpn_value = self.lpn_edit.text().strip() if not self.lpn_edit.isReadOnly() else ""

        default_dir = get_csv_files_directory()
        ensure_directory_exists(default_dir)

        dialog = QFileDialog(self, "Save 7508 WIP CSV")
        dialog.setAcceptMode(QFileDialog.AcceptSave)
        dialog.setNameFilters(["CSV Files (*.csv)", "All Files (*)"])
        dialog.setDirectory(str(default_dir))
        dialog.selectFile("7508_WIP.csv")

        if dialog.exec_() != QFileDialog.Accepted:
            return

        selected_files = dialog.selectedFiles()
        if not selected_files:
            return
        save_path = selected_files[0]
        if not save_path.lower().endswith(".csv"):
            save_path += ".csv"

        serial_sets = CSV_Writer_7508WIP.serial_sets_only(self.grouped_serials)
        if CSV_Writer_7508WIP.save_wip_csv(save_path, serial_sets, lpn_value, job_value):
            QMessageBox.information(self, "Success", f"Script CSV saved to:\n{save_path}")
        else:
            QMessageBox.critical(self, "Error", "Failed to save script CSV. See console for details.")


def main() -> None:
    import sys

    app = QApplication.instance() or QApplication(sys.argv)
    dialog = Arista7508WIPGUI()
    dialog.setWindowFlags(Qt.WindowType.Window)
    dialog.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
