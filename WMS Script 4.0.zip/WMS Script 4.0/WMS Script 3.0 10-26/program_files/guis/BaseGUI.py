from PyQt5.QtWidgets import QWidget, QDialog, QApplication
from PyQt5.QtGui import QIcon

class BaseWidget(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowIcon(QIcon('bolt.ico'))

    def finalize_initial_size(self, extra_width: int = 0, extra_height: int = 0, max_screen_ratio: float = 0.9):
        """Resize to fit contents (after layout constructed) ensuring buttons aren't clipped."""
        try:
            self.adjustSize()
            hint = self.sizeHint()
            width = hint.width() + extra_width
            height = hint.height() + extra_height
            screen = QApplication.primaryScreen()
            if screen and hasattr(screen, 'availableGeometry'):
                geo = screen.availableGeometry()
                width = min(width, int(geo.width() * max_screen_ratio))
                height = min(height, int(geo.height() * max_screen_ratio))
            self.resize(width, height)
            self.setMinimumSize(width, height)
        except Exception:
            pass

class BaseDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowIcon(QIcon('bolt.ico'))

    def finalize_initial_size(self, extra_width: int = 0, extra_height: int = 0, max_screen_ratio: float = 0.9):
        """Resize dialog to recommended size after layouts are populated."""
        try:
            self.adjustSize()
            hint = self.sizeHint()
            width = hint.width() + extra_width
            height = hint.height() + extra_height
            screen = QApplication.primaryScreen()
            if screen and hasattr(screen, 'availableGeometry'):
                geo = screen.availableGeometry()
                width = min(width, int(geo.width() * max_screen_ratio))
                height = min(height, int(geo.height() * max_screen_ratio))
            # Guarantee a sensible minimum vertical size for scroll areas
            min_height = max(460, height)
            self.resize(width, min_height)
            self.setMinimumSize(width, min_height)
        except Exception:
            pass
