"""GUI Creator - design custom automation workflows for WMS."""

import json
import os
import keyword
from typing import Any, Dict, List, Optional, Sequence, Tuple

from PyQt5.QtCore import QUrl
from PyQt5.QtGui import QDesktopServices, QFont
from PyQt5.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QFileDialog,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QInputDialog,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QMessageBox,
    QPushButton,
    QScrollArea,
    QSpinBox,
    QTextEdit,
    QTableWidget,
    QTableWidgetItem,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)

from .BaseGUI import BaseDialog
from ..utils.file_paths import get_default_save_path_for_csv_writer


class FieldDefinition:
    """Represents a single input field in the GUI."""

    def __init__(self) -> None:
        self.field_type: str = "text"  # text, number, checkbox, dropdown, list, table
        self.label: str = ""
        self.key: str = ""
        self.default_value: str = ""
        self.options: List[str] = []  # Dropdown choices
        self.columns: List[str] = []  # Table column headers
        self.required: bool = True
        self.tooltip: str = ""
        self.visible_when: str = ""
        self.required_when: str = ""


class CsvRowDefinition:
    """Represents a single row in the CSV output template."""

    def __init__(self) -> None:
        self.prompt: str = ""
        self.key: str = ""
        self.data_source: str = ""
        self.condition: str = ""
        self.repeat_field: str = ""  # Field key to iterate on (list/table)
        self.segment: str = "main"  # main or footer


class GuiDefinition:
    """Complete definition of a custom GUI."""

    def __init__(self) -> None:
        self.name: str = ""
        self.description: str = ""
        self.include_finished: bool = True
        self.fields: List[FieldDefinition] = []
        self.csv_rows: List[CsvRowDefinition] = []


CONDITION_OPERATORS: List[Dict[str, Any]] = [
    {"id": "equals", "label": "is exactly", "requires_value": True},
    {"id": "not_equals", "label": "is not", "requires_value": True},
    {"id": "is_filled", "label": "is filled", "requires_value": False},
    {"id": "is_blank", "label": "is blank", "requires_value": False},
    {"id": "contains", "label": "contains", "requires_value": True},
    {"id": "not_contains", "label": "does not contain", "requires_value": True},
]

OPERATOR_LOOKUP: Dict[str, Dict[str, Any]] = {op["id"]: op for op in CONDITION_OPERATORS}


def _safe_literal(value: str) -> str:
    escaped = value.replace("'", "\\'")
    return f"'{escaped}'"


def parse_condition_string(condition: str) -> Tuple[str, List[Dict[str, Any]]]:
    text = (condition or "").strip()
    if not text:
        return "all", []

    if text.startswith("{"):
        try:
            payload = json.loads(text)
        except (TypeError, ValueError):
            payload = {}
        mode = payload.get("mode", "all") if isinstance(payload, dict) else "all"
        raw_rules = payload.get("rules", []) if isinstance(payload, dict) else []
        rules: List[Dict[str, Any]] = []
        for raw in raw_rules:
            if not isinstance(raw, dict):
                continue
            field_key = str(raw.get("field", "")).strip()
            if not field_key:
                continue
            operator = str(raw.get("operator", "equals")).strip() or "equals"
            value_text = str(raw.get("value", "")).strip()
            rule: Dict[str, Any] = {"field": field_key, "operator": operator}
            if value_text:
                rule["value"] = value_text
            rules.append(rule)
        if not rules:
            return "all", []
        if mode not in {"all", "any"}:
            mode = "all"
        return mode, rules

    if text.startswith("field:"):
        clause = text[len("field:"):]
        if "!=" in clause:
            field_key, value_text = clause.split("!=", 1)
            field_key = field_key.strip()
            value_text = value_text.strip()
            if not field_key:
                return "all", []
            if value_text:
                return "all", [{"field": field_key, "operator": "not_equals", "value": value_text}]
            return "all", [{"field": field_key, "operator": "is_filled"}]
        if "=" in clause:
            field_key, value_text = clause.split("=", 1)
            field_key = field_key.strip()
            value_text = value_text.strip()
            if not field_key:
                return "all", []
            if value_text:
                return "all", [{"field": field_key, "operator": "equals", "value": value_text}]
            return "all", [{"field": field_key, "operator": "is_blank"}]

    return "all", []


def condition_to_string(mode: str, rules: List[Dict[str, Any]]) -> str:
    cleaned_rules: List[Dict[str, Any]] = []
    for rule in rules:
        field_key = str(rule.get("field", "")).strip()
        if not field_key:
            continue
        operator = str(rule.get("operator", "equals")).strip() or "equals"
        value_text = str(rule.get("value", "")).strip()
        cleaned: Dict[str, Any] = {"field": field_key, "operator": operator}
        if value_text:
            cleaned["value"] = value_text
        cleaned_rules.append(cleaned)

    if not cleaned_rules:
        return ""

    normalized_mode = "any" if mode == "any" else "all"
    payload = {"mode": normalized_mode, "rules": cleaned_rules}
    return json.dumps(payload, separators=(",", ":"))


def describe_condition_rule(rule: Dict[str, Any], field_map: Dict[str, FieldDefinition]) -> str:
    field_key = rule.get("field", "")
    if not field_key:
        return ""

    field = field_map.get(field_key)
    label = (field.label or field.key) if field else field_key
    operator = rule.get("operator", "equals")
    value_text = str(rule.get("value", "")).strip()
    field_type = field.field_type if field else ""

    if operator == "equals":
        if field_type == "checkbox":
            if value_text.lower() == "true":
                return f"{label} is checked"
            if value_text.lower() == "false":
                return f"{label} is not checked"
        if value_text:
            return f"{label} is {_safe_literal(value_text)}"
        return f"{label} is blank"
    if operator == "not_equals":
        if field_type == "checkbox":
            if value_text.lower() == "true":
                return f"{label} is not checked"
            if value_text.lower() == "false":
                return f"{label} is checked"
        if value_text:
            return f"{label} is not {_safe_literal(value_text)}"
        return f"{label} is not blank"
    if operator == "is_filled":
        return f"{label} is filled"
    if operator == "is_blank":
        return f"{label} is blank"
    if operator == "contains" and value_text:
        return f"{label} contains {_safe_literal(value_text)}"
    if operator == "not_contains" and value_text:
        return f"{label} does not contain {_safe_literal(value_text)}"
    return f"{label} condition"


def summarize_condition(condition: str, fields: Sequence[FieldDefinition]) -> str:
    mode, rules = parse_condition_string(condition)
    if not rules:
        return ""

    field_map = {field.key: field for field in fields if field.key}
    parts = [describe_condition_rule(rule, field_map) for rule in rules]
    parts = [part for part in parts if part]
    if not parts:
        return ""

    if len(parts) == 1:
        return parts[0]

    connector = " AND " if mode == "all" else " OR "
    prefix = "All of: " if mode == "all" else "Any of: "
    return prefix + connector.join(parts)


class ConditionRuleDialog(QDialog):
    """Dialog for configuring a single condition rule."""

    def __init__(
        self,
        fields: Sequence[FieldDefinition],
        rule: Optional[Dict[str, Any]] = None,
        parent: Optional[QWidget] = None,
    ) -> None:
        super().__init__(parent)
        self.fields = [field for field in fields if field.key]
        self.field_map = {field.key: field for field in self.fields}
        self.rule: Dict[str, Any] = {}
        self.setWindowTitle("Condition Rule")
        self.setModal(True)
        self.resize(360, 220)
        self._init_ui()
        if rule:
            self._load_rule(rule)

    def _init_ui(self) -> None:
        layout = QVBoxLayout(self)
        form = QFormLayout()

        self.field_combo = QComboBox()
        for field in self.fields:
            display = field.label or field.key
            self.field_combo.addItem(display, field.key)
        form.addRow("Field:", self.field_combo)

        self.operator_combo = QComboBox()
        for operator in CONDITION_OPERATORS:
            self.operator_combo.addItem(operator["label"], operator["id"])
        form.addRow("Operator:", self.operator_combo)

        self.value_combo = QComboBox()
        self.value_combo.setEditable(True)
        form.addRow("Value:", self.value_combo)

        layout.addLayout(form)

        hint = QLabel("Use the value box when required; comparisons are case-insensitive.")
        hint.setStyleSheet("color: gray; font-size: 10px;")
        hint.setWordWrap(True)
        layout.addWidget(hint)

        self.field_combo.currentIndexChanged.connect(self._on_field_changed)
        self.operator_combo.currentIndexChanged.connect(self._on_operator_changed)

        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

        self._on_field_changed()
        self._on_operator_changed()

    def _current_field(self) -> Optional[FieldDefinition]:
        key = self.field_combo.currentData()
        if key:
            return self.field_map.get(key)
        return None

    def _populate_value_options(self, selected: str = "") -> None:
        field = self._current_field()
        self.value_combo.blockSignals(True)
        self.value_combo.clear()
        choices: List[str] = []
        if field:
            if field.field_type == "checkbox":
                choices = ["true", "false"]
            elif field.field_type == "dropdown":
                choices = list(field.options)
            elif field.field_type == "list":
                choices = list(field.options)
            elif field.field_type == "table":
                choices = list(field.columns)

        for choice in choices:
            self.value_combo.addItem(choice)

        self.value_combo.setEditable(True)
        if selected:
            index = self.value_combo.findText(selected)
            if index == -1:
                self.value_combo.addItem(selected)
                index = self.value_combo.findText(selected)
            self.value_combo.setCurrentIndex(index)
        elif self.value_combo.count():
            self.value_combo.setCurrentIndex(0)
        self.value_combo.blockSignals(False)

    def _on_field_changed(self) -> None:
        self._populate_value_options()

    def _on_operator_changed(self) -> None:
        operator_id = self.operator_combo.currentData()
        info = OPERATOR_LOOKUP.get(operator_id, {})
        needs_value = bool(info.get("requires_value", False))
        self.value_combo.setEnabled(needs_value)
        if not needs_value:
            self.value_combo.setEditText("")

    def _load_rule(self, rule: Dict[str, Any]) -> None:
        field_key = rule.get("field", "")
        if field_key:
            index = self.field_combo.findData(field_key)
            if index != -1:
                self.field_combo.setCurrentIndex(index)
        operator = rule.get("operator", "equals")
        index = self.operator_combo.findData(operator)
        if index != -1:
            self.operator_combo.setCurrentIndex(index)
        value_text = str(rule.get("value", ""))
        self._populate_value_options(value_text)
        self._on_operator_changed()

    def accept(self) -> None:  # type: ignore[override]
        field_key = self.field_combo.currentData()
        if not field_key:
            QMessageBox.warning(self, "Invalid Rule", "Select a field for this condition.")
            return

        operator_id = self.operator_combo.currentData()
        info = OPERATOR_LOOKUP.get(operator_id, {})
        needs_value = bool(info.get("requires_value", False))
        value_text = self.value_combo.currentText().strip()

        if needs_value and not value_text:
            QMessageBox.warning(self, "Invalid Rule", "Enter a comparison value for this operator.")
            return

        self.rule = {"field": field_key, "operator": operator_id}
        if needs_value:
            self.rule["value"] = value_text

        super().accept()


class ConditionBuilderDialog(QDialog):
    """Dialog for assembling complex visibility/requirement conditions."""

    def __init__(
        self,
        fields: Sequence[FieldDefinition],
        initial_condition: str = "",
        parent: Optional[QWidget] = None,
    ) -> None:
        super().__init__(parent)
        self.fields = [field for field in fields if field.key]
        self.field_map = {field.key: field for field in self.fields}
        self.mode, self.rules = parse_condition_string(initial_condition)
        self.setWindowTitle("Build Condition")
        self.setModal(True)
        self.resize(420, 360)
        self._init_ui()
        self._refresh_rules()

    def _init_ui(self) -> None:
        layout = QVBoxLayout(self)

        mode_row = QHBoxLayout()
        mode_row.addWidget(QLabel("Match logic:"))
        self.mode_combo = QComboBox()
        self.mode_combo.addItem("All conditions (AND)", "all")
        self.mode_combo.addItem("Any condition (OR)", "any")
        index = self.mode_combo.findData(self.mode)
        self.mode_combo.setCurrentIndex(index if index != -1 else 0)
        self.mode_combo.currentIndexChanged.connect(self._update_summary)
        mode_row.addWidget(self.mode_combo)
        layout.addLayout(mode_row)

        self.rule_list = QListWidget()
        layout.addWidget(self.rule_list)

        buttons_row = QHBoxLayout()
        self.add_btn = QPushButton("Add")
        self.add_btn.clicked.connect(self._add_rule)
        buttons_row.addWidget(self.add_btn)

        edit_btn = QPushButton("Edit")
        edit_btn.clicked.connect(self._edit_rule)
        buttons_row.addWidget(edit_btn)

        remove_btn = QPushButton("Remove")
        remove_btn.clicked.connect(self._remove_rule)
        buttons_row.addWidget(remove_btn)

        up_btn = QPushButton("Move Up")
        up_btn.clicked.connect(lambda: self._move_rule(-1))
        buttons_row.addWidget(up_btn)

        down_btn = QPushButton("Move Down")
        down_btn.clicked.connect(lambda: self._move_rule(1))
        buttons_row.addWidget(down_btn)

        layout.addLayout(buttons_row)

        self.summary_label = QLabel()
        self.summary_label.setStyleSheet("color: gray; font-size: 10px;")
        self.summary_label.setWordWrap(True)
        layout.addWidget(self.summary_label)

        if not self.fields:
            info = QLabel("Add at least one field with a key before building conditions.")
            info.setStyleSheet("color: gray; font-size: 10px;")
            info.setWordWrap(True)
            layout.addWidget(info)
            self.add_btn.setEnabled(False)

        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def _refresh_rules(self) -> None:
        self.rule_list.clear()
        for rule in self.rules:
            description = describe_condition_rule(rule, self.field_map)
            self.rule_list.addItem(description or "Condition")
        self._update_summary()

    def _update_summary(self) -> None:
        summary = summarize_condition(condition_to_string(self.mode_combo.currentData(), self.rules), self.fields)
        if summary:
            self.summary_label.setText(f"Preview: {summary}")
        else:
            self.summary_label.setText("Preview: Always (no conditions)")

    def _selected_index(self) -> int:
        return self.rule_list.currentRow()

    def _add_rule(self) -> None:
        if not self.fields:
            QMessageBox.information(self, "No Fields", "Define fields with keys before adding conditions.")
            return
        dialog = ConditionRuleDialog(self.fields, parent=self)
        if dialog.exec_() == QDialog.Accepted:
            self.rules.append(dialog.rule)
            self._refresh_rules()
            self.rule_list.setCurrentRow(len(self.rules) - 1)

    def _edit_rule(self) -> None:
        index = self._selected_index()
        if index < 0 or index >= len(self.rules):
            return
        dialog = ConditionRuleDialog(self.fields, self.rules[index], parent=self)
        if dialog.exec_() == QDialog.Accepted:
            self.rules[index] = dialog.rule
            self._refresh_rules()
            self.rule_list.setCurrentRow(index)

    def _remove_rule(self) -> None:
        index = self._selected_index()
        if index < 0 or index >= len(self.rules):
            return
        del self.rules[index]
        self._refresh_rules()
        if self.rules:
            self.rule_list.setCurrentRow(min(index, len(self.rules) - 1))

    def _move_rule(self, step: int) -> None:
        index = self._selected_index()
        new_index = index + step
        if index < 0 or new_index < 0 or new_index >= len(self.rules):
            return
        self.rules[index], self.rules[new_index] = self.rules[new_index], self.rules[index]
        self._refresh_rules()
        self.rule_list.setCurrentRow(new_index)

    def get_condition_string(self) -> str:
        return condition_to_string(self.mode_combo.currentData(), self.rules)

    def get_summary(self) -> str:
        return summarize_condition(self.get_condition_string(), self.fields)


class FieldEditor(QDialog):
    """Dialog for editing a single field definition."""

    FIELD_TYPE_HELP: Dict[str, str] = {
        "text": "Text field: collect freeform input such as operator names or comments.",
        "number": "Number field: enforce numeric input (ideal for counts or quantities).",
        "checkbox": "Checkbox: simple true/false toggle. Set the default value to 'true' or 'false'.",
        "dropdown": "Dropdown: single-choice menu. Add one option per line in the options box below.",
        "list": "List: allow repeatable entries. Each option becomes an item that can be iterated over.",
        "table": "Table: capture structured rows. Define the column headers below (one per line).",
    }

    RESERVED_WORDS = {"true", "false", "none", "null", "and", "or", "not"}

    def __init__(self, field_def: Optional[FieldDefinition] = None, parent: Optional[QWidget] = None) -> None:
        super().__init__(parent)
        self.field_def = field_def or FieldDefinition()
        self._key_overridden: bool = False
        self._updating_key: bool = False
        self.visible_when_condition: str = self.field_def.visible_when or ""
        self.required_when_condition: str = self.field_def.required_when or ""

        self.setWindowTitle("Edit Field")
        self.setModal(True)
        self.resize(440, 420)

        self._init_ui()
        self._load_field()

    def _init_ui(self) -> None:
        layout = QVBoxLayout(self)

        type_row = QHBoxLayout()
        type_row.addWidget(QLabel("Field Type:"))
        self.type_combo = QComboBox()
        self.type_combo.addItems(["text", "number", "checkbox", "dropdown", "list", "table"])
        self.type_combo.currentTextChanged.connect(self._on_type_changed)
        type_row.addWidget(self.type_combo)
        layout.addLayout(type_row)

        form = QFormLayout()

        self.label_edit = QLineEdit()
        self.label_edit.setPlaceholderText("e.g. Serial Number")
        self.label_edit.textChanged.connect(self._auto_generate_key)
        self.label_edit.textChanged.connect(lambda _text: self._refresh_condition_summaries())
        form.addRow("Label:", self.label_edit)

        self.key_edit = QLineEdit()
        self.key_edit.setPlaceholderText("auto-generated from label")
        self.key_edit.textChanged.connect(self._key_manual_override)
        self.key_edit.textChanged.connect(lambda _text: self._refresh_condition_summaries())
        form.addRow("Key (auto-generated, can override):", self.key_edit)

        self.default_edit = QLineEdit()
        self.default_edit.setPlaceholderText("Optional default value")
        form.addRow("Default Value:", self.default_edit)

        self.tooltip_edit = QLineEdit()
        self.tooltip_edit.setPlaceholderText("Explain this field to the builder (optional)")
        form.addRow("Tooltip:", self.tooltip_edit)

        self.required_check = QCheckBox()
        form.addRow("Required:", self.required_check)

        self.visible_when_display = self._create_condition_row(
            form,
            "Visible When:",
            "Always visible",
            "visible",
        )
        self.required_when_display = self._create_condition_row(
            form,
            "Required When:",
            "Always (uses Required checkbox)",
            "required",
        )

        layout.addLayout(form)

        self.help_label = QLabel()
        self.help_label.setWordWrap(True)
        self.help_label.setStyleSheet("color: gray; font-size: 10px;")
        layout.addWidget(self.help_label)

        self.options_group = QGroupBox("Dropdown/List Options")
        options_layout = QVBoxLayout(self.options_group)
        self.options_list = QListWidget()
        self.options_list.itemDoubleClicked.connect(self._edit_option)
        options_layout.addWidget(self.options_list)

        option_buttons = QHBoxLayout()
        add_option_btn = QPushButton("Add")
        add_option_btn.clicked.connect(self._add_option)
        edit_option_btn = QPushButton("Edit")
        edit_option_btn.clicked.connect(self._edit_option)
        remove_option_btn = QPushButton("Remove")
        remove_option_btn.clicked.connect(self._remove_option)
        up_option_btn = QPushButton("Move Up")
        up_option_btn.clicked.connect(lambda: self._move_option(-1))
        down_option_btn = QPushButton("Move Down")
        down_option_btn.clicked.connect(lambda: self._move_option(1))
        option_buttons.addWidget(add_option_btn)
        option_buttons.addWidget(edit_option_btn)
        option_buttons.addWidget(remove_option_btn)
        option_buttons.addWidget(up_option_btn)
        option_buttons.addWidget(down_option_btn)
        options_layout.addLayout(option_buttons)

        self.options_preview_group = QGroupBox("Live Preview")
        options_preview_layout = QVBoxLayout(self.options_preview_group)
        options_preview_layout.addWidget(QLabel("Dropdown Sample:"))
        self.dropdown_preview = QComboBox()
        self.dropdown_preview.setEnabled(False)
        options_preview_layout.addWidget(self.dropdown_preview)
        options_preview_layout.addWidget(QLabel("List Sample:"))
        self.list_preview = QListWidget()
        self.list_preview.setSelectionMode(QListWidget.NoSelection)
        self.list_preview.setMaximumHeight(90)
        options_preview_layout.addWidget(self.list_preview)
        options_layout.addWidget(self.options_preview_group)
        layout.addWidget(self.options_group)

        self.table_group = QGroupBox("Table Columns")
        table_layout = QVBoxLayout(self.table_group)
        self.columns_list = QListWidget()
        self.columns_list.itemDoubleClicked.connect(self._edit_column)
        table_layout.addWidget(self.columns_list)

        column_buttons = QHBoxLayout()
        add_column_btn = QPushButton("Add")
        add_column_btn.clicked.connect(self._add_column)
        edit_column_btn = QPushButton("Edit")
        edit_column_btn.clicked.connect(self._edit_column)
        remove_column_btn = QPushButton("Remove")
        remove_column_btn.clicked.connect(self._remove_column)
        up_column_btn = QPushButton("Move Up")
        up_column_btn.clicked.connect(lambda: self._move_column(-1))
        down_column_btn = QPushButton("Move Down")
        down_column_btn.clicked.connect(lambda: self._move_column(1))
        column_buttons.addWidget(add_column_btn)
        column_buttons.addWidget(edit_column_btn)
        column_buttons.addWidget(remove_column_btn)
        column_buttons.addWidget(up_column_btn)
        column_buttons.addWidget(down_column_btn)
        table_layout.addLayout(column_buttons)

        self.table_preview = QTableWidget()
        self.table_preview.setRowCount(2)
        self.table_preview.setColumnCount(0)
        self.table_preview.setMaximumHeight(120)
        self.table_preview.setEditTriggers(QTableWidget.NoEditTriggers)
        self.table_preview.setSelectionMode(QTableWidget.NoSelection)
        table_layout.addWidget(self.table_preview)
        layout.addWidget(self.table_group)

        self._refresh_option_preview()
        self._refresh_table_preview()

        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

        self._on_type_changed()

    def _create_condition_row(self, form: QFormLayout, label: str, placeholder: str, target: str) -> QLineEdit:
        container = QWidget()
        row_layout = QHBoxLayout(container)
        row_layout.setContentsMargins(0, 0, 0, 0)
        display = QLineEdit()
        display.setReadOnly(True)
        display.setPlaceholderText(placeholder)
        display.setAccessibleName(f"{label.rstrip(':')} summary")
        row_layout.addWidget(display, 1)

        edit_btn = QPushButton("Edit…")
        edit_btn.clicked.connect(lambda _checked=False, t=target: self._open_condition_builder(t))
        row_layout.addWidget(edit_btn)

        clear_btn = QPushButton("Clear")
        clear_btn.clicked.connect(lambda _checked=False, t=target: self._clear_condition(t))
        row_layout.addWidget(clear_btn)

        form.addRow(label, container)
        return display

    def _current_field_snapshot(self) -> Optional[FieldDefinition]:
        key = self.key_edit.text().strip()
        if not key:
            return None
        snapshot = FieldDefinition()
        snapshot.key = key
        snapshot.label = self.label_edit.text().strip() or key
        snapshot.field_type = self.type_combo.currentText()
        snapshot.options = self._collect_items(self.options_list)
        snapshot.columns = self._collect_items(self.columns_list)
        return snapshot

    def _gather_condition_fields(self) -> List[FieldDefinition]:
        fields: List[FieldDefinition] = []
        parent_gui = self.parent()
        gui_def = getattr(parent_gui, "gui_def", None)
        if gui_def and hasattr(gui_def, "fields"):
            for field in gui_def.fields:
                if field.key:
                    fields.append(field)
        snapshot = self._current_field_snapshot()
        if snapshot and snapshot.key and not any(field.key == snapshot.key for field in fields):
            fields.append(snapshot)
        return fields

    def _open_condition_builder(self, target: str) -> None:
        fields = self._gather_condition_fields()
        initial = self.visible_when_condition if target == "visible" else self.required_when_condition
        builder = ConditionBuilderDialog(fields, initial, parent=self)
        if builder.exec_() == QDialog.Accepted:
            self._update_condition_display(target, builder.get_condition_string())

    def _clear_condition(self, target: str) -> None:
        self._update_condition_display(target, "")

    def _update_condition_display(self, target: str, condition: Optional[str] = None) -> None:
        if target == "visible":
            if condition is not None:
                self.visible_when_condition = condition
            current = self.visible_when_condition
            display = self.visible_when_display
            placeholder = "Always visible"
        else:
            if condition is not None:
                self.required_when_condition = condition
            current = self.required_when_condition
            display = self.required_when_display
            placeholder = "Always (uses Required checkbox)"

        summary = summarize_condition(current, self._gather_condition_fields())
        if summary:
            display.setText(summary)
            display.setToolTip(current or placeholder)
        else:
            display.clear()
            display.setPlaceholderText(placeholder)
            display.setToolTip(placeholder)

    def _refresh_condition_summaries(self) -> None:
        self._update_condition_display("visible")
        self._update_condition_display("required")

    def _collect_items(self, list_widget: QListWidget) -> List[str]:
        values: List[str] = []
        for index in range(list_widget.count()):
            item = list_widget.item(index)
            if item is None:
                continue
            text = item.text().strip()
            if text:
                values.append(text)
        return values

    def _is_duplicate_entry(
        self,
        list_widget: QListWidget,
        value: str,
        skip_index: Optional[int] = None,
    ) -> bool:
        target = value.casefold()
        for index in range(list_widget.count()):
            if skip_index is not None and index == skip_index:
                continue
            item = list_widget.item(index)
            if item is None:
                continue
            if item.text().strip().casefold() == target:
                return True
        return False

    def _add_option(self) -> None:
        text, ok = QInputDialog.getText(self, "Add Option", "Option value:")
        if not ok:
            return
        value = text.strip()
        if not value:
            QMessageBox.warning(self, "Invalid Option", "Option cannot be empty.")
            return
        if self._is_duplicate_entry(self.options_list, value):
            QMessageBox.warning(self, "Duplicate Option", f"'{value}' is already listed.")
            return
        self.options_list.addItem(value)
        self.options_list.setCurrentRow(self.options_list.count() - 1)
        self._refresh_option_preview()

    def _edit_option(self, item: Optional[QListWidgetItem] = None) -> None:
        target_item = item or self.options_list.currentItem()
        if target_item is None:
            QMessageBox.information(self, "Select Option", "Select an option to edit.")
            return
        current_row = self.options_list.row(target_item)
        text, ok = QInputDialog.getText(
            self,
            "Edit Option",
            "Option value:",
            text=target_item.text(),
        )
        if not ok:
            return
        value = text.strip()
        if not value:
            QMessageBox.warning(self, "Invalid Option", "Option cannot be empty.")
            return
        if self._is_duplicate_entry(self.options_list, value, skip_index=current_row):
            QMessageBox.warning(self, "Duplicate Option", f"'{value}' is already listed.")
            return
        target_item.setText(value)
        self._refresh_option_preview()

    def _remove_option(self) -> None:
        row = self.options_list.currentRow()
        if row < 0:
            QMessageBox.information(self, "Select Option", "Select an option to remove.")
            return
        self.options_list.takeItem(row)
        self._refresh_option_preview()

    def _move_option(self, step: int) -> None:
        row = self.options_list.currentRow()
        if row < 0:
            return
        new_row = row + step
        if new_row < 0 or new_row >= self.options_list.count():
            return
        item = self.options_list.takeItem(row)
        self.options_list.insertItem(new_row, item)
        self.options_list.setCurrentRow(new_row)
        self._refresh_option_preview()

    def _add_column(self) -> None:
        text, ok = QInputDialog.getText(self, "Add Column", "Column header:")
        if not ok:
            return
        value = text.strip()
        if not value:
            QMessageBox.warning(self, "Invalid Column", "Column header cannot be empty.")
            return
        if self._is_duplicate_entry(self.columns_list, value):
            QMessageBox.warning(self, "Duplicate Column", f"'{value}' is already listed.")
            return
        self.columns_list.addItem(value)
        self.columns_list.setCurrentRow(self.columns_list.count() - 1)
        self._refresh_table_preview()

    def _edit_column(self, item: Optional[QListWidgetItem] = None) -> None:
        target_item = item or self.columns_list.currentItem()
        if target_item is None:
            QMessageBox.information(self, "Select Column", "Select a column to edit.")
            return
        current_row = self.columns_list.row(target_item)
        text, ok = QInputDialog.getText(
            self,
            "Edit Column",
            "Column header:",
            text=target_item.text(),
        )
        if not ok:
            return
        value = text.strip()
        if not value:
            QMessageBox.warning(self, "Invalid Column", "Column header cannot be empty.")
            return
        if self._is_duplicate_entry(self.columns_list, value, skip_index=current_row):
            QMessageBox.warning(self, "Duplicate Column", f"'{value}' is already listed.")
            return
        target_item.setText(value)
        self._refresh_table_preview()

    def _remove_column(self) -> None:
        row = self.columns_list.currentRow()
        if row < 0:
            QMessageBox.information(self, "Select Column", "Select a column to remove.")
            return
        self.columns_list.takeItem(row)
        self._refresh_table_preview()

    def _move_column(self, step: int) -> None:
        row = self.columns_list.currentRow()
        if row < 0:
            return
        new_row = row + step
        if new_row < 0 or new_row >= self.columns_list.count():
            return
        item = self.columns_list.takeItem(row)
        self.columns_list.insertItem(new_row, item)
        self.columns_list.setCurrentRow(new_row)
        self._refresh_table_preview()

    def _refresh_option_preview(self) -> None:
        options = self._collect_items(self.options_list)
        self.dropdown_preview.clear()
        self.list_preview.clear()
        if options:
            self.dropdown_preview.addItems(options)
            self.dropdown_preview.setEnabled(True)
            self.list_preview.addItems(options)
            self.list_preview.setEnabled(True)
        else:
            self.dropdown_preview.addItem("(no options)")
            self.dropdown_preview.setEnabled(False)
            self.list_preview.addItem("(no options)")
            self.list_preview.setEnabled(False)

    def _refresh_table_preview(self) -> None:
        columns = self._collect_items(self.columns_list)
        self.table_preview.clear()
        if columns:
            self.table_preview.setColumnCount(len(columns))
            self.table_preview.setRowCount(2)
            self.table_preview.setHorizontalHeaderLabels(columns)
            for row in range(2):
                for col, header in enumerate(columns):
                    sample_text = f"{header} {row + 1}"
                    self.table_preview.setItem(row, col, QTableWidgetItem(sample_text))
        else:
            self.table_preview.setColumnCount(0)
            self.table_preview.setRowCount(0)

    def _sanitize_key(self, raw: str) -> str:
        cleaned = "".join(ch if ch.isalnum() else "_" for ch in raw.strip().lower())
        while "__" in cleaned:
            cleaned = cleaned.replace("__", "_")
        cleaned = cleaned.strip("_")
        if cleaned and cleaned[0].isdigit():
            cleaned = f"field_{cleaned}"
        return cleaned

    def _update_help_message(self) -> None:
        field_type = self.type_combo.currentText()
        type_help = self.FIELD_TYPE_HELP.get(field_type, "")
        guidance = [type_help] if type_help else []
        guidance.append("Keys auto-generate from the label but can be overridden when needed.")
        guidance.append("Use 'Visible When' and 'Required When' to control logic without scripting.")
        self.help_label.setText("\n\n".join(guidance))

    def _auto_generate_key(self, text: str) -> None:
        if self._key_overridden:
            return
        sanitized = self._sanitize_key(text)
        if sanitized == self.key_edit.text():
            return
        self._updating_key = True
        self.key_edit.setText(sanitized)
        self._updating_key = False

    def _key_manual_override(self, text: str) -> None:
        if self._updating_key:
            return
        sanitized_label = self._sanitize_key(self.label_edit.text())
        if not text:
            self._key_overridden = False
            return
        self._key_overridden = text != sanitized_label

    def _is_reserved_word(self, key: str) -> bool:
        key_lower = key.lower()
        return key_lower in self.RESERVED_WORDS or keyword.iskeyword(key_lower)

    def _is_duplicate_key(self, key: str) -> bool:
        parent_gui = self.parent()
        gui_fields = getattr(parent_gui, "gui_def", None)
        if gui_fields and hasattr(gui_fields, "fields"):
            for field in gui_fields.fields:
                if field is self.field_def:
                    continue
                if field.key and field.key.casefold() == key.casefold():
                    return True
        return False

    def _on_type_changed(self) -> None:
        field_type = self.type_combo.currentText()
        self.options_group.setVisible(field_type in {"dropdown", "list"})
        self.table_group.setVisible(field_type == "table")
        self.default_edit.setEnabled(field_type != "table")
        self._update_help_message()
        self._refresh_condition_summaries()

    def _load_field(self) -> None:
        self.type_combo.setCurrentText(self.field_def.field_type)
        self.label_edit.setText(self.field_def.label)
        self.key_edit.setText(self.field_def.key)
        self.default_edit.setText(self.field_def.default_value)
        self.tooltip_edit.setText(self.field_def.tooltip)
        self.required_check.setChecked(self.field_def.required)

        self.options_list.clear()
        for option in self.field_def.options:
            self.options_list.addItem(option)
        self._refresh_option_preview()

        self.columns_list.clear()
        for column in self.field_def.columns:
            self.columns_list.addItem(column)
        self._refresh_table_preview()

        self.visible_when_condition = self.field_def.visible_when or ""
        self.required_when_condition = self.field_def.required_when or ""
        self._refresh_condition_summaries()

        generated = self._sanitize_key(self.field_def.label)
        current_key = (self.field_def.key or "").strip()
        self._key_overridden = bool(current_key and current_key != generated)

    def accept(self) -> None:
        label = self.label_edit.text().strip()
        raw_key = self.key_edit.text().strip()

        if not label:
            QMessageBox.warning(self, "Missing Label", "Field label is required.")
            return

        key = self._sanitize_key(raw_key)
        if not key:
            QMessageBox.warning(
                self,
                "Invalid Key",
                "Field key is required and may only use letters, numbers, or underscores.",
            )
            return
        if raw_key != key:
            QMessageBox.information(
                self,
                "Adjusted Key",
                f"Keys must be lowercase and use underscores. Updated key to '{key}'.",
            )
            self._updating_key = True
            self.key_edit.setText(key)
            self._updating_key = False

        if self._is_reserved_word(key):
            QMessageBox.warning(self, "Reserved Word", f"'{key}' is a reserved word and cannot be used as a key.")
            return

        if self._is_duplicate_key(key):
            QMessageBox.warning(self, "Duplicate Key", f"'{key}' is already used by another field.")
            return

        self.field_def.field_type = self.type_combo.currentText()
        self.field_def.label = label
        self.field_def.key = key
        self.field_def.default_value = self.default_edit.text().strip()
        self.field_def.tooltip = self.tooltip_edit.text().strip()
        self.field_def.required = self.required_check.isChecked()
        self.field_def.visible_when = self.visible_when_condition
        self.field_def.required_when = self.required_when_condition

        if self.field_def.field_type in {"dropdown", "list"}:
            self.field_def.options = self._collect_items(self.options_list)
        else:
            self.field_def.options = []

        if self.field_def.field_type == "table":
            self.field_def.columns = self._collect_items(self.columns_list)
        else:
            self.field_def.columns = []

        super().accept()


class CsvRowEditor(QDialog):
    """Dialog for editing a single CSV row definition."""

    BASE_DATA_TYPES: List[tuple[str, str]] = [
        ("Field Value", "field"),
        ("Literal", "literal"),
        ("Blank", "blank"),
    ]

    SPECIAL_COMMAND_SUGGESTIONS: List[str] = [
        "BLANK",
        "CLEAR",
        "DOWNARROW",
        "ENTER",
        "F2KEY",
        "F4KEY",
        "FINISHED",
        "ITEMMATCH",
        "NOTHING",
        "SEND",
        "UPARROW",
        "UPARROW2",
        "WAIT",
    ]

    def __init__(
        self,
        row_def: Optional[CsvRowDefinition] = None,
        available_fields: Optional[List[str]] = None,
        field_metadata: Optional[Dict[str, FieldDefinition]] = None,
        parent: Optional[QWidget] = None,
    ) -> None:
        super().__init__(parent)
        self.row_def = row_def or CsvRowDefinition()
        self.available_fields = available_fields or []
        self.field_metadata = field_metadata or {}
        self.condition_string: str = self.row_def.condition or ""
        self.setWindowTitle("Edit CSV Row")
        self.setModal(True)
        self.resize(520, 320)
        self._init_ui()
        self._load_row()

    def _init_ui(self) -> None:
        layout = QVBoxLayout(self)

        form = QFormLayout()
        self.prompt_edit = QLineEdit()
        self.key_edit = QLineEdit()

        self.data_type_combo = QComboBox()
        self.data_type_combo.currentIndexChanged.connect(self._on_data_type_changed)
        self.data_value_combo = QComboBox()
        self.data_value_combo.setEditable(True)

        self.table_column_combo = QComboBox()
        self.table_column_combo.setVisible(False)

        data_widget = QWidget()
        data_widget_layout = QVBoxLayout(data_widget)
        data_widget_layout.setContentsMargins(0, 0, 0, 0)
        type_row = QHBoxLayout()
        type_row.setContentsMargins(0, 0, 0, 0)
        type_row.addWidget(self.data_type_combo)
        type_row.addWidget(self.data_value_combo)
        data_widget_layout.addLayout(type_row)
        data_widget_layout.addWidget(self.table_column_combo)

        # Dummy-proof condition builder for CSV row conditions
        condition_widget = QWidget()
        condition_layout = QHBoxLayout(condition_widget)
        condition_layout.setContentsMargins(0, 0, 0, 0)
        self.condition_display = QLineEdit()
        self.condition_display.setReadOnly(True)
        self.condition_display.setPlaceholderText("Always include row")
        self.condition_display.setAccessibleName("CSV row condition summary")
        condition_layout.addWidget(self.condition_display, 1)
        condition_edit_btn = QPushButton("Edit…")
        condition_edit_btn.clicked.connect(self._edit_condition)
        condition_layout.addWidget(condition_edit_btn)
        condition_clear_btn = QPushButton("Clear")
        condition_clear_btn.clicked.connect(self._clear_condition)
        condition_layout.addWidget(condition_clear_btn)

        # Special WMS_Script commands dropdown
        self.special_cmd_combo = QComboBox()
        self.special_cmd_combo.setEditable(True)
        self.special_cmd_combo.addItem("None", "")
        for cmd in self.SPECIAL_COMMAND_SUGGESTIONS:
            self.special_cmd_combo.addItem(cmd, cmd)

        self.repeat_combo = QComboBox()
        self.repeat_combo.addItem("None", "")
        for field in self.field_metadata.values():
            if field.key and field.field_type in {"list", "table"}:
                display = f"{field.label or field.key} ({field.field_type})"
                self.repeat_combo.addItem(display, field.key)
        self.repeat_combo.currentIndexChanged.connect(self._on_repeat_changed)

        self.segment_combo = QComboBox()
        self.segment_combo.addItem("Main Rows", "main")
        self.segment_combo.addItem("Footer Rows", "footer")

        form.addRow("Prompt Text:", self.prompt_edit)
        form.addRow("Key:", self.key_edit)
        form.addRow("Data Source:", data_widget)
        form.addRow("Condition:", condition_widget)
        form.addRow("Special Command:", self.special_cmd_combo)
        form.addRow("Repeat Field:", self.repeat_combo)
        form.addRow("Segment:", self.segment_combo)

        layout.addLayout(form)

        help_text = QLabel(
            "Data Sources:\n"
            "• Field Value – use a value from another field\n"
            "• Literal – fixed text\n"
            "• Blank – empty string\n"
            "• List Item Value – current value from a list repeat\n"
            "• Table Column Value – value from the current table row\n\n"
            "Conditions:\n"
            "• Use the 'Edit…' button to choose when this row runs\n"
            "• Leave blank to always include the row\n\n"
            "Special Commands (auto-fill or type your own):\n"
            "• UPARROW / DOWNARROW – navigate in WMS (append a number for multiples, e.g. DOWNARROW5)\n"
            "• BLANK – send Save/Next\n"
            "• ENTER – press Enter without data\n"
            "• SEND – send the data column even if the prompt doesn’t match\n"
            "• FINISHED – end the script with a completion message\n"
            "• NOTHING – skip this row entirely\n"
            "• F2KEY / F4KEY – send function keys\n"
            "• CLEAR – send Ctrl+C to clear the current field\n"
            "• ITEMMATCH – enable item matching mode\n"
            "• WAIT – pause the script (add seconds, e.g. WAIT0.5)\n"
            "Type custom commands if needed (e.g. WAIT2.0)."
        )
        help_text.setWordWrap(True)
        help_text.setStyleSheet("color: gray; font-size: 10px;")
        layout.addWidget(help_text)

        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

        self._update_data_type_options()

    def _current_repeat_field(self) -> Optional[FieldDefinition]:
        key = self.repeat_combo.currentData()
        if key:
            return self.field_metadata.get(key)
        return None

    def _update_data_type_options(self) -> None:
        current_data = self.data_type_combo.currentData()
        self.data_type_combo.blockSignals(True)
        self.data_type_combo.clear()
        for text, value in self.BASE_DATA_TYPES:
            self.data_type_combo.addItem(text, value)

        repeat_field = self._current_repeat_field()
        if repeat_field and repeat_field.field_type == "list":
            self.data_type_combo.addItem("List Item Value", "repeat_value")
        if repeat_field and repeat_field.field_type == "table":
            self.data_type_combo.addItem("Table Column Value", "repeat_column")

        index = self.data_type_combo.findData(current_data)
        if index == -1:
            index = 0
        self.data_type_combo.setCurrentIndex(index)
        self.data_type_combo.blockSignals(False)
        self._on_data_type_changed()

    def _edit_condition(self) -> None:
        fields = list(self.field_metadata.values())
        builder = ConditionBuilderDialog(fields, self.condition_string, parent=self)
        if builder.exec_() == QDialog.Accepted:
            self.condition_string = builder.get_condition_string()
            self._update_condition_display()

    def _clear_condition(self) -> None:
        self.condition_string = ""
        self._update_condition_display()

    def _update_condition_display(self) -> None:
        fields = list(self.field_metadata.values())
        summary = summarize_condition(self.condition_string, fields)
        if summary:
            self.condition_display.setText(summary)
            self.condition_display.setToolTip(self.condition_string or "Always include row")
        else:
            self.condition_display.clear()
            self.condition_display.setPlaceholderText("Always include row")
            self.condition_display.setToolTip("Always include row")

    def _on_repeat_changed(self) -> None:
        self._update_data_type_options()

    def _on_data_type_changed(self) -> None:
        data_type = self.data_type_combo.currentData()
        self.table_column_combo.setVisible(data_type == "repeat_column")

        if data_type == "field":
            self.data_value_combo.setEnabled(True)
            self.data_value_combo.setEditable(False)
            self.data_value_combo.clear()
            self.data_value_combo.addItems(self.available_fields)
        elif data_type == "literal":
            self.data_value_combo.setEnabled(True)
            self.data_value_combo.setEditable(True)
            if self.data_value_combo.count() == 0:
                self.data_value_combo.addItem("")
            self.data_value_combo.setCurrentIndex(0)
        elif data_type == "blank":
            self.data_value_combo.clear()
            self.data_value_combo.setEnabled(False)
        elif data_type == "repeat_value":
            self.data_value_combo.clear()
            self.data_value_combo.setEnabled(False)
        elif data_type == "repeat_column":
            self.data_value_combo.clear()
            self.data_value_combo.setEnabled(False)
            self._populate_table_columns()

    def _populate_table_columns(self, selected: str = "") -> None:
        repeat_field = self._current_repeat_field()
        self.table_column_combo.blockSignals(True)
        self.table_column_combo.clear()
        if repeat_field and repeat_field.columns:
            self.table_column_combo.addItems(repeat_field.columns)
            if selected:
                index = self.table_column_combo.findText(selected)
                if index != -1:
                    self.table_column_combo.setCurrentIndex(index)
        self.table_column_combo.blockSignals(False)

    def _load_row(self) -> None:
        self.prompt_edit.setText(self.row_def.prompt)
        self.key_edit.setText(self.row_def.key)
        self.condition_string = self.row_def.condition or ""
        self._update_condition_display()
        existing_index = self.special_cmd_combo.findData(self.row_def.key)
        if existing_index != -1:
            self.special_cmd_combo.setCurrentIndex(existing_index)
        else:
            self.special_cmd_combo.setEditText(self.row_def.key)

        repeat_index = self.repeat_combo.findData(self.row_def.repeat_field or "")
        if repeat_index != -1:
            self.repeat_combo.setCurrentIndex(repeat_index)
        self.segment_combo.setCurrentIndex(self.segment_combo.findData(self.row_def.segment or "main"))

        self._update_data_type_options()

        source = self.row_def.data_source or ""
        if source.startswith("field:"):
            data_type = "field"
            value = source[len("field:"):]
            if self.data_value_combo.findText(value) == -1 and value:
                self.data_value_combo.addItem(value)
            self.data_value_combo.setCurrentText(value)
        elif source.startswith("literal:"):
            data_type = "literal"
            value = source[len("literal:"):]
            if self.data_value_combo.count() == 0:
                self.data_value_combo.addItem(value)
            self.data_value_combo.setEditText(value)
        elif source == "repeat_value":
            data_type = "repeat_value"
        elif source.startswith("repeat_column:"):
            data_type = "repeat_column"
            column = source[len("repeat_column:"):] 
            self._populate_table_columns(column)
        else:
            data_type = "blank"

        type_index = self.data_type_combo.findData(data_type)
        if type_index != -1:
            self.data_type_combo.setCurrentIndex(type_index)
            self._on_data_type_changed()
            if data_type == "field":
                self.data_value_combo.setCurrentText(value)
            elif data_type == "literal":
                self.data_value_combo.setEditText(value)
            elif data_type == "repeat_column":
                self._populate_table_columns(column)

    def accept(self) -> None:
        data_type = self.data_type_combo.currentData()
        repeat_field_key = self.repeat_combo.currentData()

        if data_type in {"repeat_value", "repeat_column"} and not repeat_field_key:
            QMessageBox.warning(self, "Invalid Row", "Select a repeat field before using repeat data sources.")
            return

        if data_type == "field":
            field_value = self.data_value_combo.currentText().strip()
            if not field_value:
                QMessageBox.warning(self, "Invalid Row", "Select a field to source the data from.")
                return
            self.row_def.data_source = f"field:{field_value}"
        elif data_type == "literal":
            literal_value = self.data_value_combo.currentText()
            self.row_def.data_source = f"literal:{literal_value}"
        elif data_type == "blank":
            self.row_def.data_source = "blank"
        elif data_type == "repeat_value":
            self.row_def.data_source = "repeat_value"
        elif data_type == "repeat_column":
            column = self.table_column_combo.currentText().strip()
            if not column:
                QMessageBox.warning(self, "Invalid Row", "Select a table column to use for this row.")
                return
            self.row_def.data_source = f"repeat_column:{column}"
        else:
            self.row_def.data_source = "blank"

        self.row_def.prompt = self.prompt_edit.text()
        # If a special command is selected, use it as the key
        special_cmd = self.special_cmd_combo.currentText().strip()
        if special_cmd.upper() == "NONE":
            special_cmd = ""
        if special_cmd:
            special_cmd = special_cmd.upper()
        self.row_def.key = special_cmd if special_cmd else self.key_edit.text()
        self.row_def.condition = self.condition_string
        self.row_def.repeat_field = repeat_field_key or ""
        self.row_def.segment = self.segment_combo.currentData() or "main"
        super().accept()


class GuiCreatorGUI(BaseDialog):
    """Main GUI Creator interface."""

    def __init__(self) -> None:
        super().__init__()
        self.gui_def = GuiDefinition()
        self.setWindowTitle("GUI Creator")
        self.resize(1024, 720)
        self.setMinimumSize(860, 600)
        self._init_ui()

    def _init_ui(self) -> None:
        main_layout = QVBoxLayout(self)

        header_layout = QHBoxLayout()
        title = QLabel("GUI Creator")
        title.setFont(QFont("Arial", 16, QFont.Bold))
        title.setStyleSheet("color: #CCCCCC;")
        header_layout.addWidget(title)
        header_layout.addStretch()

        new_btn = QPushButton("New")
        new_btn.clicked.connect(self.new_gui)
        load_btn = QPushButton("Load")
        load_btn.clicked.connect(self.load_gui)
        save_btn = QPushButton("Save")
        save_btn.clicked.connect(self.save_gui)
        generate_btn = QPushButton("Generate & Test")
        generate_btn.clicked.connect(self.generate_test_gui)
        help_btn = QPushButton("Help")
        help_btn.setToolTip("Open the GUI Creator guide")
        help_btn.clicked.connect(self._open_help_guide)

        header_layout.addWidget(new_btn)
        header_layout.addWidget(load_btn)
        header_layout.addWidget(save_btn)
        header_layout.addWidget(generate_btn)
        header_layout.addWidget(help_btn)
        main_layout.addLayout(header_layout)

        self.tabs = QTabWidget()
        main_layout.addWidget(self.tabs)

        self._setup_basic_info_tab()
        self._setup_fields_tab()
        self._setup_csv_template_tab()

        close_btn = QPushButton("Close")
        close_btn.clicked.connect(self.reject)
        main_layout.addWidget(close_btn)

    def _setup_basic_info_tab(self) -> None:
        tab = QWidget()
        layout = QVBoxLayout(tab)

        form = QFormLayout()
        self.name_edit = QLineEdit()
        self.description_edit = QTextEdit()
        self.description_edit.setMaximumHeight(120)

        form.addRow("GUI Name:", self.name_edit)
        form.addRow("Description:", self.description_edit)
        layout.addLayout(form)

        self.include_finished_checkbox = QCheckBox("Automatically append FINISHED row")
        self.include_finished_checkbox.setChecked(True)
        layout.addWidget(self.include_finished_checkbox)
        layout.addStretch()
        self.tabs.addTab(tab, "Basic Info")

    def _setup_fields_tab(self) -> None:
        tab = QWidget()
        layout = QHBoxLayout(tab)

        left_layout = QVBoxLayout()
        left_layout.addWidget(QLabel("Form Fields:"))
        self.fields_list = QListWidget()
        left_layout.addWidget(self.fields_list)

        buttons_layout = QHBoxLayout()
        add_field_btn = QPushButton("Add Field")
        add_field_btn.clicked.connect(self.add_field)
        edit_field_btn = QPushButton("Edit Field")
        edit_field_btn.clicked.connect(self.edit_field)
        remove_field_btn = QPushButton("Remove Field")
        remove_field_btn.clicked.connect(self.remove_field)
        buttons_layout.addWidget(add_field_btn)
        buttons_layout.addWidget(edit_field_btn)
        buttons_layout.addWidget(remove_field_btn)
        left_layout.addLayout(buttons_layout)

        right_layout = QVBoxLayout()
        right_layout.addWidget(QLabel("Preview:"))
        self.preview_scroll = QScrollArea()
        self.preview_scroll.setWidgetResizable(True)
        self.preview_widget = QWidget()
        self.preview_layout = QVBoxLayout(self.preview_widget)
        self.preview_scroll.setWidget(self.preview_widget)
        right_layout.addWidget(self.preview_scroll)

        layout.addLayout(left_layout, 1)
        layout.addLayout(right_layout, 1)
        self.tabs.addTab(tab, "Form Fields")

    def _setup_csv_template_tab(self) -> None:
        tab = QWidget()
        layout = QVBoxLayout(tab)
        layout.addWidget(QLabel("CSV Output Template:"))

        self.csv_table = QTableWidget()
        self.csv_table.setColumnCount(6)
        self.csv_table.setHorizontalHeaderLabels([
            "Prompt",
            "Key",
            "Data Source",
            "Condition",
            "Repeat Field",
            "Segment",
        ])
        layout.addWidget(self.csv_table)

        csv_buttons = QHBoxLayout()
        add_btn = QPushButton("Add Row")
        add_btn.clicked.connect(self.add_csv_row)
        edit_btn = QPushButton("Edit Row")
        edit_btn.clicked.connect(self.edit_csv_row)
        remove_btn = QPushButton("Remove Row")
        remove_btn.clicked.connect(self.remove_csv_row)
        up_btn = QPushButton("Move Up")
        up_btn.clicked.connect(self.move_csv_row_up)
        down_btn = QPushButton("Move Down")
        down_btn.clicked.connect(self.move_csv_row_down)

        csv_buttons.addWidget(add_btn)
        csv_buttons.addWidget(edit_btn)
        csv_buttons.addWidget(remove_btn)
        csv_buttons.addWidget(up_btn)
        csv_buttons.addWidget(down_btn)
        layout.addLayout(csv_buttons)

        self.tabs.addTab(tab, "CSV Template")

    # Field management -------------------------------------------------

    def add_field(self) -> None:
        editor = FieldEditor(parent=self)
        if editor.exec_() == QDialog.Accepted:
            self.gui_def.fields.append(editor.field_def)
            self.refresh_fields_display()

    def edit_field(self) -> None:
        row = self.fields_list.currentRow()
        if 0 <= row < len(self.gui_def.fields):
            editor = FieldEditor(self.gui_def.fields[row], parent=self)
            if editor.exec_() == QDialog.Accepted:
                self.refresh_fields_display()

    def remove_field(self) -> None:
        row = self.fields_list.currentRow()
        if 0 <= row < len(self.gui_def.fields):
            del self.gui_def.fields[row]
            self.refresh_fields_display()

    def refresh_fields_display(self) -> None:
        self.fields_list.clear()
        for field in self.gui_def.fields:
            descriptor = field.label or field.key or "(unnamed)"
            self.fields_list.addItem(f"{descriptor} ({field.field_type})")

        while self.preview_layout.count():
            item = self.preview_layout.takeAt(0)
            widget = item.widget() if item else None
            if widget:
                widget.deleteLater()

        for field in self.gui_def.fields:
            self.preview_layout.addWidget(self._create_preview_widget(field))
        self.preview_layout.addStretch()

    def _create_preview_widget(self, field: FieldDefinition) -> QWidget:
        container = QWidget()
        container_layout = QVBoxLayout(container)
        container_layout.setContentsMargins(5, 2, 5, 2)
        layout = QHBoxLayout()
        label = QLabel(f"{field.label or field.key}:" if (field.label or field.key) else "Field:")
        layout.addWidget(label)

        if field.field_type == "text":
            widget = QLineEdit()
            widget.setPlaceholderText(field.default_value)
        elif field.field_type == "number":
            widget = QSpinBox()
            try:
                widget.setValue(int(field.default_value))
            except ValueError:
                widget.setValue(0)
        elif field.field_type == "checkbox":
            widget = QCheckBox()
            widget.setChecked(field.default_value.lower() == "true")
        elif field.field_type == "dropdown":
            widget = QComboBox()
            widget.addItems(field.options)
        elif field.field_type == "list":
            widget = QLineEdit()
            widget.setPlaceholderText("List editor")
        elif field.field_type == "table":
            widget = QLineEdit()
            widget.setPlaceholderText("Table editor")
        else:
            widget = QLineEdit()

        widget.setEnabled(False)
        layout.addWidget(widget)
        container_layout.addLayout(layout)

        info_bits: List[str] = []
        visible_summary = summarize_condition(field.visible_when, self.gui_def.fields)
        if visible_summary:
            info_bits.append(f"Visible when {visible_summary}")
        elif field.visible_when:
            info_bits.append(f"Visible when {field.visible_when}")

        required_summary = summarize_condition(field.required_when, self.gui_def.fields)
        if required_summary:
            info_bits.append(f"Required when {required_summary}")
        elif field.required_when:
            info_bits.append(f"Required when {field.required_when}")
        if info_bits:
            info_label = QLabel("; ".join(info_bits))
            info_label.setStyleSheet("color: gray; font-size: 10px;")
            container_layout.addWidget(info_label)
        return container

    # CSV row management -----------------------------------------------

    def _build_field_metadata(self) -> Dict[str, FieldDefinition]:
        return {field.key: field for field in self.gui_def.fields if field.key}

    def _available_value_fields(self) -> List[str]:
        return [
            field.key
            for field in self.gui_def.fields
            if field.key and field.field_type in {"text", "number", "checkbox", "dropdown"}
        ]

    def add_csv_row(self) -> None:
        editor = CsvRowEditor(
            available_fields=self._available_value_fields(),
            field_metadata=self._build_field_metadata(),
            parent=self,
        )
        if editor.exec_() == QDialog.Accepted:
            self.gui_def.csv_rows.append(editor.row_def)
            self.refresh_csv_display()

    def edit_csv_row(self) -> None:
        row = self.csv_table.currentRow()
        if 0 <= row < len(self.gui_def.csv_rows):
            editor = CsvRowEditor(
                row_def=self.gui_def.csv_rows[row],
                available_fields=self._available_value_fields(),
                field_metadata=self._build_field_metadata(),
                parent=self,
            )
            if editor.exec_() == QDialog.Accepted:
                self.refresh_csv_display()

    def remove_csv_row(self) -> None:
        row = self.csv_table.currentRow()
        if 0 <= row < len(self.gui_def.csv_rows):
            del self.gui_def.csv_rows[row]
            self.refresh_csv_display()

    def move_csv_row_up(self) -> None:
        row = self.csv_table.currentRow()
        if 0 < row < len(self.gui_def.csv_rows):
            self.gui_def.csv_rows[row - 1], self.gui_def.csv_rows[row] = (
                self.gui_def.csv_rows[row],
                self.gui_def.csv_rows[row - 1],
            )
            self.refresh_csv_display()
            self.csv_table.setCurrentCell(row - 1, 0)

    def move_csv_row_down(self) -> None:
        row = self.csv_table.currentRow()
        if 0 <= row < len(self.gui_def.csv_rows) - 1:
            self.gui_def.csv_rows[row + 1], self.gui_def.csv_rows[row] = (
                self.gui_def.csv_rows[row],
                self.gui_def.csv_rows[row + 1],
            )
            self.refresh_csv_display()
            self.csv_table.setCurrentCell(row + 1, 0)

    def refresh_csv_display(self) -> None:
        self.csv_table.setRowCount(len(self.gui_def.csv_rows))
        metadata = self._build_field_metadata()
        for row_index, row_def in enumerate(self.gui_def.csv_rows):
            self.csv_table.setItem(row_index, 0, QTableWidgetItem(row_def.prompt))
            self.csv_table.setItem(row_index, 1, QTableWidgetItem(row_def.key))
            self.csv_table.setItem(row_index, 2, QTableWidgetItem(row_def.data_source))
            condition_summary = summarize_condition(row_def.condition, self.gui_def.fields)
            condition_text = condition_summary or ("" if not row_def.condition else row_def.condition)
            condition_item = QTableWidgetItem(condition_text or "Always")
            if row_def.condition:
                condition_item.setToolTip(row_def.condition)
            self.csv_table.setItem(row_index, 3, condition_item)
            repeat_display = ""
            if row_def.repeat_field:
                field = metadata.get(row_def.repeat_field)
                repeat_display = field.label or field.key if field else row_def.repeat_field
            self.csv_table.setItem(row_index, 4, QTableWidgetItem(repeat_display))
            segment_display = "Main" if row_def.segment == "main" else "Footer"
            self.csv_table.setItem(row_index, 5, QTableWidgetItem(segment_display))

    def _open_help_guide(self) -> None:
        """Open the markdown guide in the user's default application."""
        guide_path = os.path.normpath(
            os.path.join(os.path.dirname(__file__), "..", "GUI_Creator_Guide.md")
        )
        if not os.path.exists(guide_path):
            QMessageBox.warning(
                self,
                "Guide Not Found",
                "Could not locate the GUI Creator guide file.",
            )
            return

        guide_url = QUrl.fromLocalFile(guide_path)
        if not QDesktopServices.openUrl(guide_url):
            QMessageBox.warning(
                self,
                "Open Failed",
                "Could not open the GUI Creator guide. The file lives at program_files/GUI_Creator_Guide.md.",
            )

    # Persistence ------------------------------------------------------

    def new_gui(self) -> None:
        if QMessageBox.question(self, "New GUI", "Start a new GUI definition?", QMessageBox.Yes | QMessageBox.No) == QMessageBox.Yes:
            self.gui_def = GuiDefinition()
            self.name_edit.clear()
            self.description_edit.clear()
            self.include_finished_checkbox.setChecked(True)
            self.refresh_fields_display()
            self.refresh_csv_display()

    def save_gui(self) -> None:
        self.gui_def.name = self.name_edit.text().strip()
        self.gui_def.description = self.description_edit.toPlainText()
        self.gui_def.include_finished = self.include_finished_checkbox.isChecked()

        if not self.gui_def.name:
            QMessageBox.warning(self, "Missing Name", "Please enter a GUI name before saving.")
            return

        default_path = os.path.join(
            get_default_save_path_for_csv_writer(""),
            f"{self.gui_def.name}.gui.json",
        )
        file_path, _ = QFileDialog.getSaveFileName(
            self,
            "Save GUI Definition",
            default_path,
            "GUI Files (*.gui.json);;All Files (*)",
        )
        if not file_path:
            return

        try:
            data = {
                "name": self.gui_def.name,
                "description": self.gui_def.description,
                "include_finished": self.gui_def.include_finished,
                "fields": [self._field_to_dict(field) for field in self.gui_def.fields],
                "csv_rows": [self._csv_row_to_dict(row) for row in self.gui_def.csv_rows],
            }
            with open(file_path, "w", encoding="utf-8") as handle:
                json.dump(data, handle, indent=2)
            QMessageBox.information(self, "Saved", f"GUI definition saved to:\n{file_path}")
        except Exception as exc:
            QMessageBox.critical(self, "Save Failed", f"Unable to save GUI definition:\n{exc}")

    def load_gui(self) -> None:
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "Load GUI Definition",
            get_default_save_path_for_csv_writer(""),
            "GUI Files (*.gui.json);;All Files (*)",
        )
        if not file_path:
            return

        try:
            with open(file_path, "r", encoding="utf-8") as handle:
                data = json.load(handle)

            self.gui_def = GuiDefinition()
            self.gui_def.name = data.get("name", "")
            self.gui_def.description = data.get("description", "")
            self.gui_def.include_finished = data.get("include_finished", True)

            for field_data in data.get("fields", []):
                self.gui_def.fields.append(self._dict_to_field(field_data))

            for row_data in data.get("csv_rows", []):
                self.gui_def.csv_rows.append(self._dict_to_csv_row(row_data))

            self.name_edit.setText(self.gui_def.name)
            self.description_edit.setPlainText(self.gui_def.description)
            self.include_finished_checkbox.setChecked(self.gui_def.include_finished)
            self.refresh_fields_display()
            self.refresh_csv_display()
            QMessageBox.information(self, "Loaded", f"GUI definition loaded from:\n{file_path}")
        except Exception as exc:
            QMessageBox.critical(self, "Load Failed", f"Unable to load GUI definition:\n{exc}")

    # Helpers ---------------------------------------------------------

    def generate_test_gui(self) -> None:
        if not self.gui_def.fields:
            QMessageBox.warning(self, "Incomplete", "Add at least one form field first.")
            return
        if not self.gui_def.csv_rows:
            QMessageBox.warning(self, "Incomplete", "Add at least one CSV template row first.")
            return

        self.gui_def.name = self.name_edit.text().strip() or "Test GUI"
        self.gui_def.description = self.description_edit.toPlainText()
        self.gui_def.include_finished = self.include_finished_checkbox.isChecked()

        try:
            generated_gui = GeneratedGUI(self.gui_def, parent=self)
            generated_gui.exec_()
        except Exception as exc:
            QMessageBox.critical(self, "Generation Failed", f"Unable to generate GUI:\n{exc}")

    def _field_to_dict(self, field: FieldDefinition) -> Dict[str, Any]:
        return {
            "field_type": field.field_type,
            "label": field.label,
            "key": field.key,
            "default_value": field.default_value,
            "options": field.options,
            "columns": field.columns,
            "required": field.required,
            "tooltip": field.tooltip,
            "visible_when": field.visible_when,
            "required_when": field.required_when,
        }

    def _dict_to_field(self, data: Dict[str, Any]) -> FieldDefinition:
        field = FieldDefinition()
        field.field_type = data.get("field_type", "text")
        field.label = data.get("label", "")
        field.key = data.get("key", "")
        field.default_value = data.get("default_value", "")
        field.options = data.get("options", [])
        field.columns = data.get("columns", [])
        field.required = data.get("required", True)
        field.tooltip = data.get("tooltip", "")
        field.visible_when = data.get("visible_when", "")
        field.required_when = data.get("required_when", "")
        return field

    def _csv_row_to_dict(self, row: CsvRowDefinition) -> Dict[str, Any]:
        return {
            "prompt": row.prompt,
            "key": row.key,
            "data_source": row.data_source,
            "condition": row.condition,
            "repeat_field": row.repeat_field,
            "segment": row.segment,
        }

    def _dict_to_csv_row(self, data: Dict[str, Any]) -> CsvRowDefinition:
        row = CsvRowDefinition()
        row.prompt = data.get("prompt", "")
        row.key = data.get("key", "")
        row.data_source = data.get("data_source", "")
        row.condition = data.get("condition", "")
        row.repeat_field = data.get("repeat_field", "")
        row.segment = data.get("segment", "main")
        return row


from .GeneratedGUI import GeneratedGUI  # noqa: E402
