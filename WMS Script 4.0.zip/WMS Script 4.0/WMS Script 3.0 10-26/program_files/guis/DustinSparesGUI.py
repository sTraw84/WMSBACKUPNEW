
"""
Compatibility shim for an earlier GUI module name.

This small module re-exports the current canonical GUI implementation so
older import paths continue to work during a staged rename. It contains no
unique logic — import the real implementation from
`program_files.guis.PartBalancerGUI` instead.
"""

from program_files.guis.PartBalancerGUI import PartBalancerGUI

# Backwards-compatible alias
DustinSparesGUI = PartBalancerGUI
