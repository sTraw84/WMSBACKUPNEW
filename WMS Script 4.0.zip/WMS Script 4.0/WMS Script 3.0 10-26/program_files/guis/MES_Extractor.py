import os
import sys
import traceback
import json
import re
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import pandas as pd
import requests
from PyQt5.QtWidgets import (
    QApplication,
    QWidget,
    QDialog,
    QVBoxLayout,
    QHBoxLayout,
    QPushButton,
    QFileDialog,
    QLabel,
    QMessageBox,
    QTextEdit,
    QCheckBox,
    QComboBox,
    QLineEdit,
    QListWidget,
    QGroupBox,
    QFormLayout,
    QInputDialog,
)
import qdarkstyle

from ..utils.file_paths import get_default_save_path_for_mes_extractor


LAYOUTS_DIR = Path(__file__).resolve().parent / "json files" / "layouts"
DEFAULT_LAYOUT_FILENAME = "MSIT_REUSE.json"
DEFAULT_LAYOUT_PATH = LAYOUTS_DIR / DEFAULT_LAYOUT_FILENAME
TRANSFORM_OPTIONS = [
    "raw",
    "clean_program",
    "clean_location",
    "date",
    "blank",
    "hyperlink",
]
PROGRAM_CLEAN_PATTERNS = [
    r"Microsoft",
    r"GICLAB\d+",
    r"L3\s*-\s*MSFT\s+Reuse\s*-",
    r"MSFT\s+Reuse\s*-",
]
LOCATION_CLEAN_PATTERNS = [
    r"\.LAB\.WPC\.\.",
    r"\.LAB\.NA1\.\.",
]


def _default_layout_config() -> Dict[str, Any]:
    return {
        "name": "MSIT/REUSE",
        "columns": [
            {
                "header": "WO#",
                "source": "documentNumber",
                "transform": "raw",
                "link_type": "mes",
                "hyperlink": {
                    "id_source": "jobHeaderId",
                    "url_template": "https://mes.apps.wwt.com/orders/{value}",
                },
            },
            {
                "header": "SO#",
                "source": "soNumber",
                "transform": "raw",
                "link_type": "configit",
            },
            {
                "header": "Program(SS)",
                "source": "serviceTemplateDesc",
                "transform": "clean_program",
                "link_type": "ss",
            },
            {"header": "LED", "source": "scheduledComplDate", "transform": "date"},
            {"header": "Lab Loc", "source": "location", "transform": "clean_location"},
            {"header": "OM", "source": "orderManager", "transform": "raw"},
            {"header": "Expedite", "source": "expediteFlag", "transform": "raw"},
            {"header": "Devices", "source": "assemblyQty", "transform": "raw"},
            {"header": "Tech", "default": "", "transform": "blank"},
            {"header": "GIC#", "source": "gicTicket", "transform": "raw"},
            {"header": "Status", "source": "currentService", "transform": "raw"},
            {"header": "Notes/Handoff", "default": "", "transform": "blank"},
        ],
        "rules": [],
    }


def ensure_default_layout_exists() -> None:
    try:
        LAYOUTS_DIR.mkdir(parents=True, exist_ok=True)
        if not DEFAULT_LAYOUT_PATH.exists():
            with DEFAULT_LAYOUT_PATH.open("w", encoding="utf-8") as handle:
                json.dump(_default_layout_config(), handle, indent=2)
    except Exception:
        pass


class LayoutEditorDialog(QDialog):
    def __init__(self, layout_path: Path, parent: Optional[QWidget] = None) -> None:
        super().__init__(parent)
        self.layout_path = layout_path
        self.setWindowTitle(f"Edit Layout: {layout_path.stem}")
        self.resize(620, 520)
        self.saved_path: Path = layout_path

        data = self._load_layout()
        self.layout_name = data.get("name", layout_path.stem)
        self.columns: List[Dict[str, Any]] = data.get("columns", [])
        self.rules: List[Dict[str, Any]] = data.get("rules", [])

        if not self.columns:
            self.columns = _default_layout_config()["columns"]

        self._loading_column_fields = False
        self._loading_rule_fields = False

        self._init_ui()
        self._populate_columns()
        self._populate_rules()

    def _load_layout(self) -> Dict[str, Any]:
        try:
            with self.layout_path.open("r", encoding="utf-8") as handle:
                return json.load(handle)
        except Exception:
            return _default_layout_config()

    def _init_ui(self) -> None:
        main_layout = QVBoxLayout(self)

        content_layout = QHBoxLayout()
        main_layout.addLayout(content_layout)

        columns_group = QGroupBox("Columns")
        content_layout.addWidget(columns_group, stretch=1)
        col_layout = QVBoxLayout(columns_group)

        self.columns_list = QListWidget()
        col_layout.addWidget(self.columns_list)

        col_buttons = QHBoxLayout()
        self.add_column_btn = QPushButton("Add")
        self.remove_column_btn = QPushButton("Remove")
        self.column_up_btn = QPushButton("Up")
        self.column_down_btn = QPushButton("Down")
        col_buttons.addWidget(self.add_column_btn)
        col_buttons.addWidget(self.remove_column_btn)
        col_buttons.addWidget(self.column_up_btn)
        col_buttons.addWidget(self.column_down_btn)
        col_layout.addLayout(col_buttons)

        col_form = QFormLayout()
        self.column_header_edit = QLineEdit()
        self.column_source_edit = QLineEdit()
        self.column_default_edit = QLineEdit()
        self.column_transform_combo = QComboBox()
        self.column_transform_combo.addItems(TRANSFORM_OPTIONS)
        self.column_link_id_edit = QLineEdit()
        self.column_link_template_edit = QLineEdit()
        col_form.addRow("Header:", self.column_header_edit)
        col_form.addRow("Source Field:", self.column_source_edit)
        col_form.addRow("Default Value:", self.column_default_edit)
        col_form.addRow("Transform:", self.column_transform_combo)
        col_form.addRow("Link ID Field:", self.column_link_id_edit)
        col_form.addRow("Link URL Template:", self.column_link_template_edit)
        col_layout.addLayout(col_form)

        link_checkbox_row = QHBoxLayout()
        self.ss_link_checkbox = QCheckBox("SS Link")
        self.mes_link_checkbox = QCheckBox("MES Link")
        self.configit_link_checkbox = QCheckBox("Configit Link")
        link_checkbox_row.addWidget(self.ss_link_checkbox)
        link_checkbox_row.addWidget(self.mes_link_checkbox)
        link_checkbox_row.addWidget(self.configit_link_checkbox)
        col_layout.addLayout(link_checkbox_row)
        self._link_checkboxes = [
            self.ss_link_checkbox,
            self.mes_link_checkbox,
            self.configit_link_checkbox,
        ]
        self._updating_link_checkboxes = False

        rules_group = QGroupBox("Rules")
        content_layout.addWidget(rules_group, stretch=1)
        rule_layout = QVBoxLayout(rules_group)

        self.rules_list = QListWidget()
        rule_layout.addWidget(self.rules_list)

        rule_buttons = QHBoxLayout()
        self.add_rule_btn = QPushButton("Add")
        self.remove_rule_btn = QPushButton("Remove")
        self.rule_up_btn = QPushButton("Up")
        self.rule_down_btn = QPushButton("Down")
        rule_buttons.addWidget(self.add_rule_btn)
        rule_buttons.addWidget(self.remove_rule_btn)
        rule_buttons.addWidget(self.rule_up_btn)
        rule_buttons.addWidget(self.rule_down_btn)
        rule_layout.addLayout(rule_buttons)

        rule_form = QFormLayout()
        self.rule_if_column_combo = QComboBox()
        self.rule_if_operator_combo = QComboBox()
        self.rule_if_operator_combo.addItems(["equals", "contains", "startswith", "endswith", "regex"])
        self.rule_if_value_edit = QLineEdit()
        self.rule_then_column_combo = QComboBox()
        self.rule_then_value_edit = QLineEdit()
        rule_form.addRow("IF Column:", self.rule_if_column_combo)
        rule_form.addRow("Operator:", self.rule_if_operator_combo)
        rule_form.addRow("Value/Pattern:", self.rule_if_value_edit)
        rule_form.addRow("THEN Column:", self.rule_then_column_combo)
        rule_form.addRow("Set Value:", self.rule_then_value_edit)
        rule_layout.addLayout(rule_form)

        button_row = QHBoxLayout()
        button_row.addStretch()
        self.save_as_button = QPushButton("Save As...")
        self.save_button = QPushButton("Save")
        self.cancel_button = QPushButton("Cancel")
        button_row.addWidget(self.save_as_button)
        button_row.addWidget(self.save_button)
        button_row.addWidget(self.cancel_button)
        main_layout.addLayout(button_row)

        self.columns_list.currentRowChanged.connect(self._on_column_selected)
        self.add_column_btn.clicked.connect(self._add_column)
        self.remove_column_btn.clicked.connect(self._remove_column)
        self.column_up_btn.clicked.connect(lambda: self._move_column(-1))
        self.column_down_btn.clicked.connect(lambda: self._move_column(1))
        self.column_header_edit.textChanged.connect(self._update_column_from_fields)
        self.column_source_edit.textChanged.connect(self._update_column_from_fields)
        self.column_default_edit.textChanged.connect(self._update_column_from_fields)
        self.column_transform_combo.currentTextChanged.connect(self._update_column_from_fields)
        self.column_link_id_edit.textChanged.connect(self._update_column_from_fields)
        self.column_link_template_edit.textChanged.connect(self._update_column_from_fields)
        self.ss_link_checkbox.toggled.connect(lambda _: self._on_link_checkbox_toggled(self.ss_link_checkbox))
        self.mes_link_checkbox.toggled.connect(lambda _: self._on_link_checkbox_toggled(self.mes_link_checkbox))
        self.configit_link_checkbox.toggled.connect(
            lambda _: self._on_link_checkbox_toggled(self.configit_link_checkbox)
        )

        self.rules_list.currentRowChanged.connect(self._on_rule_selected)
        self.add_rule_btn.clicked.connect(self._add_rule)
        self.remove_rule_btn.clicked.connect(self._remove_rule)
        self.rule_up_btn.clicked.connect(lambda: self._move_rule(-1))
        self.rule_down_btn.clicked.connect(lambda: self._move_rule(1))
        self.rule_if_column_combo.currentTextChanged.connect(self._update_rule_from_fields)
        self.rule_if_operator_combo.currentTextChanged.connect(self._update_rule_from_fields)
        self.rule_if_value_edit.textChanged.connect(self._update_rule_from_fields)
        self.rule_then_column_combo.currentTextChanged.connect(self._update_rule_from_fields)
        self.rule_then_value_edit.textChanged.connect(self._update_rule_from_fields)

        self.save_as_button.clicked.connect(self._save_as)
        self.save_button.clicked.connect(self._save_and_accept)
        self.cancel_button.clicked.connect(self.reject)

    def _populate_columns(self) -> None:
        self.columns_list.clear()
        for column in self.columns:
            header = column.get("header", "") or "Unnamed"
            self.columns_list.addItem(header)
        if self.columns:
            self.columns_list.setCurrentRow(0)
        else:
            self._clear_column_fields()
        self._refresh_rule_column_choices()

    def _populate_rules(self) -> None:
        self.rules_list.clear()
        for rule in self.rules:
            if_part = rule.get("if", {})
            then_part = rule.get("then", {})
            op = if_part.get("operator", "equals")
            val = if_part.get("equals", if_part.get("value", ""))
            summary = f"IF {if_part.get('column', '')} {op} '{val}'"
            summary += f" THEN {then_part.get('column', '')} = '{then_part.get('value', '')}'"
            self.rules_list.addItem(summary)
        if self.rules:
            self.rules_list.setCurrentRow(0)
        else:
            self._clear_rule_fields()

    def _clear_column_fields(self) -> None:
        self._loading_column_fields = True
        self.column_header_edit.clear()
        self.column_source_edit.clear()
        self.column_default_edit.clear()
        self.column_transform_combo.setCurrentText("raw")
        self.column_link_id_edit.clear()
        self.column_link_template_edit.clear()
        self._set_link_type_in_ui(None)
        self._loading_column_fields = False

    def _on_column_selected(self, index: int) -> None:
        if index < 0 or index >= len(self.columns):
            self._clear_column_fields()
            return
        column = self.columns[index]
        self._loading_column_fields = True
        self.column_header_edit.setText(column.get("header", ""))
        self.column_source_edit.setText(column.get("source", ""))
        self.column_default_edit.setText(column.get("default", ""))
        transform = column.get("transform", "raw")
        if transform not in TRANSFORM_OPTIONS:
            transform = "raw"
        self.column_transform_combo.setCurrentText(transform)
        hyperlink = column.get("hyperlink", {})
        self.column_link_id_edit.setText(hyperlink.get("id_source", ""))
        self.column_link_template_edit.setText(hyperlink.get("url_template", ""))
        link_type = column.get("link_type")
        if not link_type:
            if column.get("ss_link"):
                link_type = "ss"
            elif column.get("mes_link"):
                link_type = "mes"
            elif column.get("configit_link"):
                link_type = "configit"
        self._set_link_type_in_ui(link_type)
        self._loading_column_fields = False
        self._update_link_field_visibility(transform)
        self._refresh_rule_column_choices()

    def _update_link_field_visibility(self, transform: str) -> None:
        enable = transform == "hyperlink"
        self.column_link_id_edit.setEnabled(enable)
        self.column_link_template_edit.setEnabled(enable)

    def _set_link_type_in_ui(self, link_type: Optional[str]) -> None:
        self._updating_link_checkboxes = True
        for box in self._link_checkboxes:
            box.setChecked(False)
        if link_type == "ss":
            self.ss_link_checkbox.setChecked(True)
        elif link_type == "mes":
            self.mes_link_checkbox.setChecked(True)
        elif link_type == "configit":
            self.configit_link_checkbox.setChecked(True)
        self._updating_link_checkboxes = False

    def _on_link_checkbox_toggled(self, checkbox: QCheckBox) -> None:
        if self._loading_column_fields or self._updating_link_checkboxes:
            return
        if checkbox.isChecked():
            self._updating_link_checkboxes = True
            for box in self._link_checkboxes:
                if box is not checkbox:
                    box.setChecked(False)
            self._updating_link_checkboxes = False
        self._update_column_from_fields()

    def _update_column_from_fields(self) -> None:
        if self._loading_column_fields:
            return
        index = self.columns_list.currentRow()
        if index < 0 or index >= len(self.columns):
            return
        column = self.columns[index]
        column["header"] = self.column_header_edit.text().strip()
        source_text = self.column_source_edit.text().strip()
        default_text = self.column_default_edit.text()
        transform = self.column_transform_combo.currentText()
        column["transform"] = transform
        if source_text:
            column["source"] = source_text
        elif "source" in column:
            column.pop("source")
        if default_text:
            column["default"] = default_text
        elif "default" in column:
            column.pop("default")
        hyperlink_id = self.column_link_id_edit.text().strip()
        hyperlink_template = self.column_link_template_edit.text().strip()
        if hyperlink_id or hyperlink_template:
            column["hyperlink"] = {
                "id_source": hyperlink_id,
                "url_template": hyperlink_template,
            }
        elif "hyperlink" in column:
            column.pop("hyperlink")

        link_type = None
        if self.ss_link_checkbox.isChecked():
            link_type = "ss"
        elif self.mes_link_checkbox.isChecked():
            link_type = "mes"
        elif self.configit_link_checkbox.isChecked():
            link_type = "configit"

        if link_type:
            column["link_type"] = link_type
        elif "link_type" in column:
            column.pop("link_type")

        for legacy_key in ("ss_link", "mes_link", "configit_link"):
            if legacy_key in column:
                column.pop(legacy_key)
        self._update_link_field_visibility(transform)
        self.columns_list.currentItem().setText(column.get("header", "") or "Unnamed")
        self._refresh_rule_column_choices()

    def _add_column(self) -> None:
        new_column = {
            "header": "New Column",
            "transform": "raw",
        }
        self.columns.append(new_column)
        self.columns_list.addItem(new_column["header"])
        self.columns_list.setCurrentRow(len(self.columns) - 1)

    def _remove_column(self) -> None:
        index = self.columns_list.currentRow()
        if index < 0 or index >= len(self.columns):
            return
        self.columns.pop(index)
        self._populate_columns()

    def _move_column(self, direction: int) -> None:
        index = self.columns_list.currentRow()
        target = index + direction
        if index < 0 or target < 0 or target >= len(self.columns):
            return
        self.columns[index], self.columns[target] = self.columns[target], self.columns[index]
        self._populate_columns()
        self.columns_list.setCurrentRow(target)

    def _clear_rule_fields(self) -> None:
        self._loading_rule_fields = True
        self.rule_if_column_combo.clear()
        self.rule_if_operator_combo.setCurrentText("equals")
        self.rule_then_column_combo.clear()
        self.rule_if_value_edit.clear()
        self.rule_then_value_edit.clear()
        self._loading_rule_fields = False

    def _refresh_rule_column_choices(self) -> None:
        columns = [col.get("header", "") for col in self.columns if col.get("header")]
        current_if = self.rule_if_column_combo.currentText()
        current_then = self.rule_then_column_combo.currentText()
        self.rule_if_column_combo.blockSignals(True)
        self.rule_then_column_combo.blockSignals(True)
        self.rule_if_column_combo.clear()
        self.rule_then_column_combo.clear()
        self.rule_if_column_combo.addItems(columns)
        self.rule_then_column_combo.addItems(columns)
        if current_if in columns:
            self.rule_if_column_combo.setCurrentText(current_if)
        if current_then in columns:
            self.rule_then_column_combo.setCurrentText(current_then)
        self.rule_if_column_combo.blockSignals(False)
        self.rule_then_column_combo.blockSignals(False)

    def _on_rule_selected(self, index: int) -> None:
        if index < 0 or index >= len(self.rules):
            self._clear_rule_fields()
            return
        rule = self.rules[index]
        if_part = rule.get("if", {})
        then_part = rule.get("then", {})
        self._loading_rule_fields = True
        self._refresh_rule_column_choices()
        if if_part.get("column"):
            self.rule_if_column_combo.setCurrentText(if_part.get("column"))
        else:
            self.rule_if_column_combo.setCurrentIndex(0)
        # operator may be present in newer layouts
        self.rule_if_operator_combo.setCurrentText(str(if_part.get("operator", "equals")))
        # value/pattern stored under 'equals' in legacy layouts; accept either key
        self.rule_if_value_edit.setText(str(if_part.get("equals", if_part.get("value", ""))).strip())
        if then_part.get("column"):
            self.rule_then_column_combo.setCurrentText(then_part.get("column"))
        else:
            self.rule_then_column_combo.setCurrentIndex(0)
        self.rule_then_value_edit.setText(str(then_part.get("value", "")).strip())
        self._loading_rule_fields = False

    def _update_rule_from_fields(self) -> None:
        if self._loading_rule_fields:
            return
        index = self.rules_list.currentRow()
        if index < 0 or index >= len(self.rules):
            return
        rule = self.rules[index]
        rule["if"] = {
            "column": self.rule_if_column_combo.currentText(),
            "operator": self.rule_if_operator_combo.currentText(),
            # keep legacy key name 'equals' for compatibility, but store as value too
            "equals": self.rule_if_value_edit.text().strip(),
            "value": self.rule_if_value_edit.text().strip(),
        }
        rule["then"] = {
            "column": self.rule_then_column_combo.currentText(),
            "value": self.rule_then_value_edit.text().strip(),
        }
        # create a short human-readable summary including operator
        op = rule['if'].get('operator', 'equals')
        val = rule['if'].get('equals', '')
        item = self.rules_list.currentItem()
        if item is not None:
            item.setText(
                f"IF {rule['if'].get('column', '')} {op} '{val}' "
                f"THEN {rule['then'].get('column', '')} = '{rule['then'].get('value', '')}'"
            )

    def _add_rule(self) -> None:
        column_headers = [col.get("header", "") for col in self.columns if col.get("header")]
        default_column = column_headers[0] if column_headers else ""
        # If the rule form already has values entered, use them for the new rule so Add behaves
        # like "create from form" when the user fills fields first and then clicks Add.
        if_column = self.rule_if_column_combo.currentText() or default_column
        operator = self.rule_if_operator_combo.currentText() or "equals"
        equals = self.rule_if_value_edit.text().strip()
        then_column = self.rule_then_column_combo.currentText() or default_column
        then_value = self.rule_then_value_edit.text().strip()

        new_rule = {
            "if": {"column": if_column, "operator": operator, "equals": equals, "value": equals},
            "then": {"column": then_column, "value": then_value},
        }
        self.rules.append(new_rule)
        self._populate_rules()
        self.rules_list.setCurrentRow(len(self.rules) - 1)

    def _remove_rule(self) -> None:
        index = self.rules_list.currentRow()
        if index < 0 or index >= len(self.rules):
            return
        self.rules.pop(index)
        self._populate_rules()

    def _move_rule(self, direction: int) -> None:
        index = self.rules_list.currentRow()
        target = index + direction
        if index < 0 or target < 0 or target >= len(self.rules):
            return
        self.rules[index], self.rules[target] = self.rules[target], self.rules[index]
        self._populate_rules()
        self.rules_list.setCurrentRow(target)

    def _validate_columns(self) -> Optional[str]:
        headers = []
        for column in self.columns:
            header = column.get("header", "").strip()
            if not header:
                return "Every column must have a header."
            if header in headers:
                return f"Duplicate column header detected: {header}"
            headers.append(header)
        return None

    def _save_and_accept(self) -> None:
        error = self._validate_columns()
        if error:
            QMessageBox.warning(self, "Invalid Layout", error)
            return
        layout_data = self._layout_payload()
        try:
            with self.layout_path.open("w", encoding="utf-8") as handle:
                json.dump(layout_data, handle, indent=2)
        except Exception as exc:
            QMessageBox.critical(self, "Save Failed", f"Could not save layout:\n{exc}")
            return
        self.saved_path = self.layout_path
        self.accept()

    def _layout_payload(self, name_override: Optional[str] = None) -> Dict[str, Any]:
        return {
            "name": name_override if name_override is not None else self.layout_name,
            "columns": self.columns,
            "rules": self.rules,
        }

    def _save_as(self) -> None:
        error = self._validate_columns()
        if error:
            QMessageBox.warning(self, "Invalid Layout", error)
            return

        suggested = self.layout_name or self.layout_path.stem
        text, ok = QInputDialog.getText(
            self,
            "Save Layout As",
            "Layout name:",
            text=suggested,
        )
        if not ok:
            return
        new_name = text.strip()
        if not new_name:
            QMessageBox.warning(self, "Invalid Layout Name", "Layout name cannot be empty.")
            return

        safe_filename = re.sub(r"[^A-Za-z0-9_-]+", "_", new_name).strip("_")
        if not safe_filename:
            QMessageBox.warning(
                self,
                "Invalid Layout Name",
                "Layout name must include letters or numbers.",
            )
            return

        new_path = LAYOUTS_DIR / f"{safe_filename}.json"
        if new_path.exists():
            choice = QMessageBox.question(
                self,
                "Overwrite Layout?",
                f"A layout named '{safe_filename}' already exists. Overwrite it?",
                QMessageBox.Yes | QMessageBox.No,
                QMessageBox.No,
            )
            if choice != QMessageBox.Yes:
                return

        layout_data = self._layout_payload(name_override=new_name)

        try:
            LAYOUTS_DIR.mkdir(parents=True, exist_ok=True)
            with new_path.open("w", encoding="utf-8") as handle:
                json.dump(layout_data, handle, indent=2)
        except Exception as exc:
            QMessageBox.critical(self, "Save Failed", f"Could not save layout:\n{exc}")
            return

        self.layout_path = new_path
        self.layout_name = new_name
        self.saved_path = new_path
        self.accept()


class MESExtractor(QWidget):
    def read_filter_payload(self, filename: str = "MES_Filters.json") -> Optional[dict]:
        json_folder = os.path.join(os.path.dirname(__file__), "json files")
        filter_path = os.path.join(json_folder, filename)
        try:
            with open(filter_path, "r", encoding="utf-8") as handle:
                return json.load(handle)
        except Exception as exc:
            self.log(f"Failed to read/parse {filename}: {exc}")
            return None

    def __init__(self, parent: Optional[QWidget] = None) -> None:
        super().__init__(parent)
        self.setWindowTitle("MES Order Extractor")
        self.resize(500, 400)
        ensure_default_layout_exists()
        self._layout_paths: Dict[str, Path] = {}

        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(12, 12, 12, 12)
        main_layout.setSpacing(8)

        info_label = QLabel(
            "One-click MES order extraction using your browser's session cookies.\n"
            "Make sure you're logged into MES in Chrome/Edge and have your filters applied.\n"
            "If automatic extraction fails, paste your cookie string below (from DevTools > Network > Headers)."
        )
        info_label.setWordWrap(True)
        main_layout.addWidget(info_label)

        self.log_output = QTextEdit()
        self.log_output.setReadOnly(True)
        self.log_output.setMinimumHeight(160)

        filter_layout = QHBoxLayout()
        filter_layout.addWidget(QLabel("Filter File:"))
        self.filter_combo = QComboBox()
        self.populate_filter_files()
        filter_layout.addWidget(self.filter_combo)
        refresh_btn = QPushButton("Refresh")
        refresh_btn.setMaximumWidth(80)
        refresh_btn.clicked.connect(self.refresh_filter_files)
        filter_layout.addWidget(refresh_btn)
        main_layout.addLayout(filter_layout)

        layout_layout = QHBoxLayout()
        layout_layout.addWidget(QLabel("Layout:"))
        self.layout_combo = QComboBox()
        self.populate_layout_files()
        layout_layout.addWidget(self.layout_combo)
        self.layout_refresh_btn = QPushButton("Refresh")
        self.layout_refresh_btn.setMaximumWidth(80)
        self.layout_refresh_btn.clicked.connect(self.refresh_layout_files)
        layout_layout.addWidget(self.layout_refresh_btn)
        self.edit_layout_button = QPushButton("Edit Layout...")
        self.edit_layout_button.setMaximumWidth(110)
        self.edit_layout_button.clicked.connect(self.edit_layout_file)
        layout_layout.addWidget(self.edit_layout_button)
        main_layout.addLayout(layout_layout)

        main_layout.addWidget(QLabel("Paste Cookie String (required):"))
        self.cookie_input = QTextEdit()
        self.cookie_input.setPlaceholderText(
            "Paste cookie string here from DevTools > Network > Headers..."
        )
        self.cookie_input.setMinimumHeight(60)
        self.cookie_input.setMaximumHeight(80)
        main_layout.addWidget(self.cookie_input)

        self.export_btn = QPushButton("Export My MES Orders to Excel")
        self.export_btn.clicked.connect(self.export_orders)
        main_layout.addWidget(self.export_btn)

        self.base_report_checkbox = QCheckBox("Run base report with all columns")
        self.base_report_checkbox.setChecked(False)
        self.base_report_checkbox.toggled.connect(self._on_base_report_toggled)
        main_layout.addWidget(self.base_report_checkbox)

        self.autorun_ss_checkbox = QCheckBox(
            "Autorun Smartsheets Extractor (add links to SO# and Program(SS))"
        )
        self.autorun_ss_checkbox.setChecked(False)
        main_layout.addWidget(self.autorun_ss_checkbox)

        main_layout.addWidget(QLabel("Log:"))
        main_layout.addWidget(self.log_output)

        self.setMinimumSize(520, 480)
        self._on_base_report_toggled(self.base_report_checkbox.isChecked())
        self._cached_smartsheet_context = None
        self._last_export_metadata = None
        self._last_source_dataframe = None

    def showEvent(self, event):
        super().showEvent(event)
        try:
            screen = QApplication.primaryScreen()
            if screen:
                geo = self.frameGeometry()
                center_point = screen.availableGeometry().center()
                geo.moveCenter(center_point)
                self.move(geo.topLeft())
        except Exception:
            pass

    def populate_filter_files(self) -> None:
        json_folder = os.path.join(os.path.dirname(__file__), "json files")
        self.filter_combo.clear()

        try:
            if not os.path.isdir(json_folder):
                self.filter_combo.addItem("<json files folder missing>")
                self.log("json files folder not found alongside MES_Extractor.")
                return

            json_files = sorted(
                [filename for filename in os.listdir(json_folder) if filename.lower().endswith(".json")]
            )
            if not json_files:
                self.filter_combo.addItem("<no json filters>")
                self.log("No JSON filter files found in json files folder.")
                return

            self.filter_combo.addItems(json_files)
            default_name = "MES_Filters.json"
            if default_name in json_files:
                self.filter_combo.setCurrentText(default_name)
        except Exception as exc:
            self.filter_combo.addItem("<error loading>")
            self.log(f"Error loading filter files: {exc}")

    def refresh_filter_files(self) -> None:
        previous = self.filter_combo.currentText()
        self.populate_filter_files()
        index = self.filter_combo.findText(previous)
        if index >= 0:
            self.filter_combo.setCurrentIndex(index)
        self.log("Filter file list refreshed.")

    def populate_layout_files(self, select_path: Optional[str] = None) -> None:
        self.layout_combo.clear()
        self._layout_paths.clear()

        try:
            if not LAYOUTS_DIR.exists():
                self.layout_combo.addItem("<no layouts>")
                return

            layout_files = sorted(p for p in LAYOUTS_DIR.iterdir() if p.suffix.lower() == ".json")
            if not layout_files:
                self.layout_combo.addItem("<no layouts>")
                return

            for path in layout_files:
                display_name = path.stem.replace("_", " ")
                self.layout_combo.addItem(display_name, userData=str(path))
                self._layout_paths[display_name] = path

            preferred = Path(select_path) if select_path else DEFAULT_LAYOUT_PATH
            if preferred.exists():
                for index in range(self.layout_combo.count()):
                    data = self.layout_combo.itemData(index)
                    if data and Path(data) == preferred:
                        self.layout_combo.setCurrentIndex(index)
                        break
        except Exception as exc:
            self.layout_combo.clear()
            self.layout_combo.addItem("<error loading>")
            self.log(f"Error loading layout files: {exc}")

    def refresh_layout_files(self) -> None:
        previous = self.layout_combo.currentData()
        self.populate_layout_files(select_path=previous)
        self.log("Layout list refreshed.")

    def edit_layout_file(self) -> None:
        current_data = self.layout_combo.currentData()
        if not current_data:
            QMessageBox.warning(self, "No Layout", "Select a layout file to edit.")
            return
        layout_path = Path(current_data)
        if not layout_path.exists():
            QMessageBox.warning(self, "Missing Layout", f"Layout file not found:\n{layout_path}")
            return
        dialog = LayoutEditorDialog(layout_path, parent=self)
        if dialog.exec_() == QDialog.Accepted:
            saved_path = dialog.saved_path
            self.populate_layout_files(select_path=str(saved_path))
            self.log(f"Saved layout: {Path(saved_path).name}")

    def _on_base_report_toggled(self, checked: bool) -> None:
        controls = [self.layout_combo, self.layout_refresh_btn, self.edit_layout_button]
        for widget in controls:
            widget.setEnabled(not checked)

    def log(self, message: str) -> None:
        self.log_output.append(message)

    def get_browser_cookies(self, domain: str) -> Dict[str, str]:
        try:
            import browser_cookie3
        except Exception as exc:
            self.log(f"Failed to import browser_cookie3: {exc}")
            return {}

        cookies: Dict[str, str] = {}
        try:
            chrome_cookies = browser_cookie3.chrome(domain_name=domain)
            for cookie in chrome_cookies:
                cookies[cookie.name] = cookie.value
            if cookies:
                self.log(f"Loaded {len(cookies)} cookies from Chrome")
                return cookies
        except Exception as exc:
            self.log(f"Chrome cookie extraction failed: {exc}")

        try:
            edge_cookies = browser_cookie3.edge(domain_name=domain)
            for cookie in edge_cookies:
                cookies[cookie.name] = cookie.value
            if cookies:
                self.log(f"Loaded {len(cookies)} cookies from Edge")
                return cookies
        except Exception as exc:
            self.log(f"Edge cookie extraction failed: {exc}")

        return cookies

    def parse_cookie_string(self, cookie_string: str) -> Dict[str, str]:
        cookies: Dict[str, str] = {}
        for part in cookie_string.split(";"):
            if "=" in part:
                name, value = part.split("=", 1)
                cookies[name.strip()] = value.strip()
        return cookies

    def extract_order_data(self, data: Any) -> List[Dict[str, Any]]:
        orders: List[Dict[str, Any]] = []
        if isinstance(data, list):
            orders = data
        elif isinstance(data, dict):
            for key in ["orders", "workorders", "data", "results", "items"]:
                if key in data and isinstance(data[key], list):
                    orders = data[key]
                    break
            else:
                if any(field in data for field in ["id", "orderNumber", "workOrder", "status"]):
                    orders = [data]
        return orders

    def export_orders(self) -> None:
        self.export_btn.setDisabled(True)
        self.log_output.clear()
        self._last_export_metadata = None
        self._last_source_dataframe = None

        try:
            output_path, _ = QFileDialog.getSaveFileName(
                self,
                "Save Excel File",
                get_default_save_path_for_mes_extractor("MES_Orders.xlsx"),
                "Excel Files (*.xlsx)",
            )
            if not output_path:
                self.log("Export cancelled by user.")
                return

            cookie_string = self.cookie_input.toPlainText().strip()
            if not cookie_string:
                raise RuntimeError(
                    "You must paste your cookie string above (from DevTools > Network > Headers)."
                )
            self.log("Using manually entered cookie string.")
            cookies = self.parse_cookie_string(cookie_string)

            session = requests.Session()
            session.cookies.update(cookies)
            session.headers.update(
                {
                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
                    "Accept": "application/json, text/plain, */*",
                    "Accept-Language": "en-US,en;q=0.9",
                    "Referer": "https://mes.wwt.com/",
                }
            )

            endpoint = "https://apirouter.apps.wwt.com/api/forward/mes-api/workOrders"
            self.log(f"Using MES API endpoint: {endpoint}")

            selected_filter = self.filter_combo.currentText()
            invalid_tokens = {"<json files folder missing>", "<no json filters>", "<error loading>"}
            if selected_filter in invalid_tokens or not selected_filter:
                raise RuntimeError(f"Invalid filter file selection: {selected_filter}")

            payload = self.read_filter_payload(selected_filter)
            if not payload:
                raise RuntimeError(
                    f"Could not read or parse {selected_filter}. Please check the file format."
                )

            self.log("Fetching filtered order data...")
            resp = session.post(endpoint, json=payload, timeout=30)
            resp.raise_for_status()

            data = resp.json()
            orders = self.extract_order_data(data)
            if not orders:
                raise RuntimeError("No order data found in the response.")

            df = pd.DataFrame(orders)
            for col in df.columns:
                if df[col].dtype == "object":
                    df[col] = df[col].apply(
                        lambda value: str(value) if isinstance(value, (dict, list)) else value
                    )

            tracked_cols = {name: df[name] for name in ("documentNumber", "soNumber") if name in df.columns}
            self._last_source_dataframe = pd.DataFrame(tracked_cols) if tracked_cols else df.copy()
            self._last_export_metadata = None

            run_base_report = self.base_report_checkbox.isChecked()
            layout_metadata: Optional[Dict[str, Any]] = None

            if run_base_report:
                export_df = df.copy()
                self.log("Base report mode enabled: exporting all columns without remapping.")
            else:
                layout_config = self._load_selected_layout()
                export_df, layout_metadata = self._build_export_dataframe(df, layout_config)
                self._last_export_metadata = layout_metadata

            if run_base_report:
                self._last_export_metadata = None

            export_df.to_excel(output_path, index=False)

            if not run_base_report and layout_metadata:
                try:
                    self._apply_layout_post_processing(output_path, df, layout_metadata)
                except Exception as exc:
                    self.log(f"Post-processing step failed: {exc}")

            self.log(f"Successfully exported {len(export_df)} filtered orders to {output_path}")
            if not run_base_report and self.autorun_ss_checkbox.isChecked():
                try:
                    self.log(
                        "Autorun enabled: adding Smartsheet/ConfigIT links to SO# and Program(SS)..."
                    )
                    self.apply_smartsheet_links(output_path)
                    self.log("Added SO# and Program(SS) hyperlinks.")
                except Exception as exc:
                    self.log(f"Autorun Smartsheets step failed: {exc}")
            elif run_base_report and self.autorun_ss_checkbox.isChecked():
                self.log("Autorun Smartsheets step skipped for base report export.")

            QMessageBox.information(
                self,
                "Success",
                f"Exported {len(export_df)} filtered orders to {output_path}",
            )

        except Exception as exc:
            self.log("Extraction failed.")
            self.log(traceback.format_exc())
            QMessageBox.critical(self, "Error", str(exc))
        finally:
            self.export_btn.setDisabled(False)

    def _load_selected_layout(self) -> Dict[str, Any]:
        current_data = self.layout_combo.currentData()
        if current_data:
            layout_path = Path(str(current_data))
            try:
                with layout_path.open("r", encoding="utf-8") as handle:
                    return json.load(handle)
            except Exception as exc:
                self.log(f"Failed to load layout {layout_path.name}: {exc}")
        return _default_layout_config()

    def _build_export_dataframe(
        self,
        source_df: pd.DataFrame,
        layout_config: Dict[str, Any],
    ) -> Tuple[pd.DataFrame, Dict[str, Any]]:
        columns_config = layout_config.get("columns", [])
        row_count = len(source_df)
        export_df = pd.DataFrame(index=range(row_count)) if row_count else pd.DataFrame()
        hyperlink_columns: List[Dict[str, Any]] = []
        ss_link_headers: List[str] = []
        mes_link_headers: List[str] = []
        configit_link_headers: List[str] = []
        document_headers: List[str] = []
        so_headers: List[str] = []

        for column_config in columns_config:
            header = str(column_config.get("header", "")).strip()
            if not header:
                continue
            transform = column_config.get("transform", "raw")
            source_field = column_config.get("source")
            default_value = column_config.get("default", "")

            if row_count and source_field and source_field in source_df.columns:
                series = source_df[source_field].copy()
            elif row_count:
                series = pd.Series([default_value] * row_count)
            else:
                series = pd.Series(dtype=object)

            if source_field == "documentNumber" and header not in document_headers:
                document_headers.append(header)
            if source_field == "soNumber" and header not in so_headers:
                so_headers.append(header)

            if transform == "clean_program":
                series = series.apply(self._clean_program_value)
            elif transform == "clean_location":
                series = series.apply(self._clean_location_value)
            elif transform == "date":
                series = pd.to_datetime(series, errors="coerce").dt.strftime("%m/%d/%Y")
            elif transform == "blank":
                series = pd.Series([default_value] * row_count) if row_count else pd.Series(dtype=object)
            elif transform == "hyperlink" and row_count:
                series = series.fillna("")

            if default_value and transform != "hyperlink" and not source_field:
                series = pd.Series([default_value] * row_count) if row_count else pd.Series(dtype=object)

            hyperlink_config = column_config.get("hyperlink")
            if hyperlink_config:
                hyperlink_columns.append(
                    {
                        "header": header,
                        "id_source": hyperlink_config.get("id_source", ""),
                        "url_template": hyperlink_config.get("url_template", ""),
                        "display_source": source_field or "",
                    }
                )
                if row_count:
                    series = series.fillna("")

            link_type = column_config.get("link_type")
            if not link_type:
                if column_config.get("ss_link"):
                    link_type = "ss"
                elif column_config.get("mes_link"):
                    link_type = "mes"
                elif column_config.get("configit_link"):
                    link_type = "configit"

            if link_type == "ss" and header not in ss_link_headers:
                ss_link_headers.append(header)
            elif link_type == "mes" and header not in mes_link_headers:
                mes_link_headers.append(header)
            elif link_type == "configit" and header not in configit_link_headers:
                configit_link_headers.append(header)

            if row_count:
                series = series.reset_index(drop=True)
            export_df[header] = series

        export_df = self._apply_layout_rules(export_df, layout_config.get("rules", []))
        metadata = {
            "hyperlinks": hyperlink_columns,
            "ss_links": ss_link_headers,
            "mes_links": mes_link_headers,
            "configit_links": configit_link_headers,
            "document_number_headers": document_headers,
            "so_number_headers": so_headers,
        }
        return export_df, metadata

    def _clean_program_value(self, value: Any) -> str:
        if pd.isnull(value):
            return ""
        text = str(value)
        for pattern in PROGRAM_CLEAN_PATTERNS:
            text = re.sub(pattern, "", text, flags=re.IGNORECASE)
        text = re.sub(r"\s+", " ", text)
        return text.strip(" -_")

    def _clean_location_value(self, value: Any) -> str:
        if pd.isnull(value):
            return ""
        text = str(value)
        for pattern in LOCATION_CLEAN_PATTERNS:
            text = re.sub(pattern, "", text, flags=re.IGNORECASE)
        text = re.sub(r"\s+", " ", text)
        return text.strip()

    def _apply_layout_rules(self, export_df: pd.DataFrame, rules: List[Dict[str, Any]]) -> pd.DataFrame:
        if export_df.empty or not rules:
            return export_df
        for rule in rules:
            if_part = rule.get("if", {})
            then_part = rule.get("then", {})
            if_column = if_part.get("column")
            equals_value = str(if_part.get("equals", "")).strip()
            operator = str(if_part.get("operator", "equals")).strip()
            then_column = then_part.get("column")
            then_value = str(then_part.get("value", "")).strip()
            if not if_column or if_column not in export_df.columns or not then_column:
                continue
            if then_column not in export_df.columns:
                export_df[then_column] = ""

            # work with string series
            src_series = export_df[if_column].astype(str).fillna("")

            try:
                if operator == "equals":
                    mask = src_series == equals_value
                    export_df.loc[mask, then_column] = then_value
                elif operator == "contains":
                    mask = src_series.str.casefold().str.contains(equals_value.casefold(), na=False)
                    export_df.loc[mask, then_column] = then_value
                elif operator == "startswith":
                    mask = src_series.str.casefold().str.startswith(equals_value.casefold(), na=False)
                    export_df.loc[mask, then_column] = then_value
                elif operator == "endswith":
                    mask = src_series.str.casefold().str.endswith(equals_value.casefold(), na=False)
                    export_df.loc[mask, then_column] = then_value
                elif operator == "regex":
                    # mask where regex matches
                    mask = src_series.apply(lambda v: bool(re.search(equals_value, v)))
                    # for regex we support substitution/backreferences in then_value
                    if then_value:
                        for idx, val in src_series[mask].items():
                            try:
                                new_val = re.sub(equals_value, then_value, val)
                            except re.error:
                                new_val = then_value
                            export_df.at[idx, then_column] = new_val
                    else:
                        # if no then_value provided, just keep original (no-op)
                        pass
                else:
                    # unknown operator: fallback to equals
                    mask = src_series == equals_value
                    export_df.loc[mask, then_column] = then_value
            except Exception:
                # on any error, skip this rule and continue
                continue
        return export_df

    def _apply_layout_post_processing(
        self,
        output_path: str,
        source_df: pd.DataFrame,
        metadata: Dict[str, Any],
    ) -> None:
        hyperlink_columns = metadata.get("hyperlinks", [])
        ss_link_headers = metadata.get("ss_links", [])
        configit_headers = metadata.get("configit_links", [])
        if not hyperlink_columns and not ss_link_headers and not configit_headers:
            return
        from openpyxl import load_workbook
        from openpyxl.cell.cell import Cell
        from openpyxl.worksheet.hyperlink import Hyperlink

        workbook = load_workbook(output_path)
        if not workbook.worksheets:
            return
        sheet = workbook.worksheets[0]
        header_cells = next(sheet.iter_rows(min_row=1, max_row=1))
        headers = [cell.value for cell in header_cells]

        for link_data in hyperlink_columns:
            header = link_data.get("header")
            if not header:
                continue
            try:
                column_index = headers.index(header) + 1
            except ValueError:
                continue
            id_source = link_data.get("id_source", "")
            url_template = link_data.get("url_template", "")
            display_source = link_data.get("display_source", "")
            id_values = (
                source_df[id_source].tolist()
                if id_source and id_source in source_df.columns
                else [None] * len(source_df)
            )
            display_values = (
                source_df[display_source].tolist()
                if display_source and display_source in source_df.columns
                else []
            )
            for row_index in range(2, sheet.max_row + 1):
                cell = sheet.cell(row=row_index, column=column_index)
                if not isinstance(cell, Cell):
                    continue
                data_index = row_index - 2
                if data_index >= len(id_values):
                    continue
                identifier = id_values[data_index]
                if not identifier or not url_template:
                    continue
                display_value = (
                    display_values[data_index]
                    if data_index < len(display_values)
                    else cell.value
                )
                url = url_template.replace("{value}", str(identifier))
                cell.value = str(display_value)
                cell.hyperlink = Hyperlink(
                    ref=cell.coordinate,
                    target=url,
                    display=str(display_value),
                )
                cell.style = "Hyperlink"

        if ss_link_headers:
            if "soNumber" not in source_df.columns:
                self.log("SS Link columns configured but 'soNumber' field is unavailable; skipping.")
            else:
                lookup, sheet_id = self._get_smartsheet_context()
                if not lookup or not sheet_id:
                    self.log("SS Link columns configured but Smartsheet lookup failed; skipping.")
                else:
                    so_values = source_df["soNumber"].tolist()
                    for header in ss_link_headers:
                        try:
                            column_index = headers.index(header) + 1
                        except ValueError:
                            continue
                        for row_index in range(2, sheet.max_row + 1):
                            data_index = row_index - 2
                            if data_index >= len(so_values):
                                break
                            so_value = so_values[data_index]
                            so_key = self._normalize_so(so_value)
                            row_id = lookup.get(so_key)
                            if not row_id:
                                continue
                            cell = sheet.cell(row=row_index, column=column_index)
                            if not isinstance(cell, Cell):
                                continue
                            display_value = cell.value
                            if display_value in (None, ""):
                                continue
                            url = f"https://app.smartsheet.com/sheets/{sheet_id}?rowId={row_id}"
                            cell.hyperlink = Hyperlink(
                                ref=cell.coordinate,
                                target=url,
                                display=str(display_value),
                            )
                            cell.style = "Hyperlink"

        if configit_headers:
            if "documentNumber" not in source_df.columns:
                self.log("Configit Link columns configured but 'documentNumber' field is unavailable; skipping.")
            else:
                document_values = source_df["documentNumber"].tolist()
                for header in configit_headers:
                    try:
                        column_index = headers.index(header) + 1
                    except ValueError:
                        continue
                    for row_index in range(2, sheet.max_row + 1):
                        data_index = row_index - 2
                        if data_index >= len(document_values):
                            break
                        doc_value = document_values[data_index]
                        url = self._extract_work_order_link(doc_value)
                        if not url:
                            continue
                        cell = sheet.cell(row=row_index, column=column_index)
                        if not isinstance(cell, Cell):
                            continue
                        display_value = cell.value
                        if display_value in (None, ""):
                            continue
                        cell.hyperlink = Hyperlink(
                            ref=cell.coordinate,
                            target=url,
                            display=str(display_value),
                        )
                        cell.style = "Hyperlink"

        workbook.save(output_path)

    def _normalize_so(self, value: Any) -> str:
        try:
            return str(int(float(value)))
        except Exception:
            return str(value).strip() if value is not None else ""

    def _extract_work_order_link(self, wo_val: Any) -> str:
        if wo_val is None:
            return ""
        match = re.search(r"(\d+)", str(wo_val))
        return f"https://configit.apps.wwt.com/work-order/{match.group(1)}" if match else ""

    def _get_smartsheet_lookup(self, api_token: str, sheet_id: str) -> Dict[str, Any]:
        try:
            import smartsheet
        except Exception as exc:
            raise RuntimeError(f"smartsheet SDK not installed: {exc}")

        sheet_client = smartsheet.Smartsheet(api_token)
        sheet = sheet_client.Sheets.get_sheet(sheet_id)
        so_col_id = None
        for column in sheet.columns:
            if str(column.title).strip().lower() == "so number":
                so_col_id = column.id
                break
        if not so_col_id:
            raise RuntimeError("Could not find 'SO Number' column in Smartsheet sheet")
        lookup: Dict[str, Any] = {}
        for row in sheet.rows:
            for cell in row.cells:
                if cell.column_id == so_col_id and cell.value is not None:
                    key = self._normalize_so(cell.value)
                    lookup[key] = row.id
        return lookup

    def _get_smartsheet_token(self) -> Optional[str]:
        token = os.environ.get("SS_API_TOKEN")
        if token:
            return token
        try:
            import keyring

            stored = keyring.get_password("WWT_WMS_SSLinkCreator", "ss_api_token")
            if stored:
                return stored
        except Exception:
            pass
        return None

    def _get_smartsheet_context(self) -> Tuple[Dict[str, Any], Optional[str]]:
        if self._cached_smartsheet_context is not None:
            return self._cached_smartsheet_context

        api_token = self._get_smartsheet_token()
        if not api_token:
            self.log("Smartsheet lookup skipped: missing API token.")
            self._cached_smartsheet_context = ({}, None)
            return self._cached_smartsheet_context

        sheet_id = None
        try:
            from program_files.guis.SSLinkCreator import SSLinkCreator as _SSLC

            sheet_id = getattr(_SSLC, "SHEET_ID", None)
        except Exception:
            sheet_id = None
        if not sheet_id:
            sheet_id = "9xwh2FwVR9WMgxpJ483m3wVxvCx6PJf8HqHc2q81"

        try:
            lookup = self._get_smartsheet_lookup(api_token, sheet_id)
            self.log(f"Smartsheet lookup loaded: {len(lookup)} SO rows")
            self._cached_smartsheet_context = (lookup, sheet_id)
        except Exception as exc:
            self.log(f"Smartsheet lookup skipped: {exc}")
            self._cached_smartsheet_context = ({}, None)
        return self._cached_smartsheet_context

    def apply_smartsheet_links(self, excel_path: str) -> None:
        try:
            from openpyxl import load_workbook
            from openpyxl.styles import Font
            from openpyxl.worksheet.hyperlink import Hyperlink
        except Exception as exc:
            raise RuntimeError(f"openpyxl required: {exc}")

        workbook = load_workbook(excel_path)
        sheet = workbook.active if workbook.worksheets else None
        if sheet is None:
            raise RuntimeError("Could not open worksheet for hyperlinking")

        header_cells = next(sheet.iter_rows(min_row=1, max_row=1))
        headers = [cell.value for cell in header_cells]
        header_to_index = {
            header: idx + 1 for idx, header in enumerate(headers) if header is not None
        }

        metadata = self._last_export_metadata or {}
        configit_headers = list(metadata.get("configit_links", []) or [])
        ss_headers = list(metadata.get("ss_links", []) or [])
        document_headers = list(metadata.get("document_number_headers", []) or [])
        so_headers = list(metadata.get("so_number_headers", []) or [])

        if not configit_headers and "SO#" in header_to_index:
            configit_headers = ["SO#"]
        if not ss_headers and "Program(SS)" in header_to_index:
            ss_headers = ["Program(SS)"]
        if not document_headers and "WO#" in header_to_index:
            document_headers = ["WO#"]
        if not so_headers and "SO#" in header_to_index:
            so_headers = ["SO#"]

        document_numbers: List[Any] = []
        so_numbers: List[Any] = []
        if self._last_source_dataframe is not None:
            if "documentNumber" in self._last_source_dataframe.columns:
                document_numbers = self._last_source_dataframe["documentNumber"].tolist()
            if "soNumber" in self._last_source_dataframe.columns:
                so_numbers = self._last_source_dataframe["soNumber"].tolist()

        max_rows = sheet.max_row

        if configit_headers:
            if not document_numbers and not document_headers:
                self.log("Configit autorun skipped: no document number source available.")
            else:
                for header in configit_headers:
                    column_index = header_to_index.get(header)
                    if not column_index:
                        continue
                    for row in range(2, max_rows + 1):
                        data_index = row - 2
                        doc_value = None
                        if document_numbers and data_index < len(document_numbers):
                            doc_value = document_numbers[data_index]
                        else:
                            for doc_header in document_headers:
                                doc_idx = header_to_index.get(doc_header)
                                if doc_idx:
                                    doc_value = sheet.cell(row=row, column=doc_idx).value
                                    if doc_value:
                                        break
                        if doc_value is None:
                            continue
                        link_url = self._extract_work_order_link(doc_value)
                        if not link_url:
                            continue
                        cell = sheet.cell(row=row, column=column_index)
                        display_value = cell.value
                        if display_value in (None, ""):
                            continue
                        cell.hyperlink = Hyperlink(
                            ref=cell.coordinate,
                            target=link_url,
                            display=str(display_value),
                        )
                        cell.font = Font(color="0000FF", underline="single")

        if ss_headers:
            if not so_numbers and not so_headers:
                self.log("Smartsheet autorun skipped: no SO number source available.")
            else:
                prog_lookup, sheet_id = self._get_smartsheet_context()
                if prog_lookup and sheet_id:
                    for header in ss_headers:
                        column_index = header_to_index.get(header)
                        if not column_index:
                            continue
                        for row in range(2, max_rows + 1):
                            data_index = row - 2
                            so_value = None
                            if so_numbers and data_index < len(so_numbers):
                                so_value = so_numbers[data_index]
                            else:
                                for so_header in so_headers:
                                    so_idx = header_to_index.get(so_header)
                                    if so_idx:
                                        so_value = sheet.cell(row=row, column=so_idx).value
                                        if so_value is not None:
                                            break
                            so_key = self._normalize_so(so_value)
                            row_id = prog_lookup.get(so_key) if so_key else None
                            if not row_id:
                                continue
                            cell = sheet.cell(row=row, column=column_index)
                            display_value = cell.value
                            if display_value in (None, ""):
                                continue
                            prog_url = f"https://app.smartsheet.com/sheets/{sheet_id}?rowId={row_id}"
                            cell.hyperlink = Hyperlink(
                                ref=cell.coordinate,
                                target=prog_url,
                                display=str(display_value),
                            )
                            cell.font = Font(color="0000FF", underline="single")

        workbook.save(excel_path)


def main() -> None:
    app = QApplication.instance() or QApplication(sys.argv)
    gui = MESExtractor()
    app.setStyleSheet(qdarkstyle.load_stylesheet_pyqt5())
    gui.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
