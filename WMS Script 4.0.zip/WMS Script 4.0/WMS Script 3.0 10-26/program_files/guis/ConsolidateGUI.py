from PyQt5.QtWidgets import (
    QDialog,
    QVBoxLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QMessageBox,
    QScrollArea,
    QWidget,
    QSpacerItem,
    QSizePolicy,
    QTableWidget,
    QTableWidgetItem,
    QFileDialog,
    QSplitter,
)
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QIntValidator
import tempfile
from program_files.csv_writers import CSV_Writer_Consolidate
from .MainButtons import MainButtons
from .BaseGUI import BaseDialog
from .InlineEditors import CollapsibleListEditor
from ..utils.file_paths import get_default_save_path_for_csv_writer
import csv

class NumericLineEdit(QLineEdit):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setValidator(QIntValidator(0, 999999, self))

class ConsolidateGUI(BaseDialog):
    def __init__(self):
        super().__init__()
        self.mode = "consolidate"
        self.csv_writer = CSV_Writer_Consolidate
        self.screen_indicator = "CONSOLIDATE"
        self._side_panel_width = 280
        self._min_left_width = 300
        self._min_side_panel_width = 200
        self._left_before_side_panel = None

        self.c40_list = []
        self.lpn_changed = False
        self.total_builds = 0

        self.init_ui()
        self.temp_csv_file = tempfile.NamedTemporaryFile(delete=False, mode='w', newline='')
        self.row_counter = 1
        CSV_Writer_Consolidate.write_csv_headers(self.temp_csv_file)

    def init_ui(self):
        self.setWindowTitle('Consolidate Questions')
        self.resize(560, 360)
        self.setMinimumSize(520, 320)

        self.main_layout = QVBoxLayout(self)

        self.splitter = QSplitter(Qt.Horizontal, self)  # type: ignore[attr-defined]
        self.splitter.setHandleWidth(1)
        self.main_layout.addWidget(self.splitter)

        self.left_container = QWidget(self.splitter)
        self.left_layout = QVBoxLayout(self.left_container)
        self.left_layout.setContentsMargins(0, 0, 0, 0)
        self.left_layout.setSpacing(5)

        top_bar = QWidget(self.left_container)
        self.top_layout = QHBoxLayout(top_bar)
        self.top_layout.setContentsMargins(0, 0, 0, 0)
        self.status_label = QLabel(self)
        self.top_layout.addWidget(self.status_label)
        self.counter_label = QLabel('# of C40s to Consolidate: 0', self)
        self.counter_label.setAlignment(Qt.AlignRight)
        self.top_layout.addWidget(self.counter_label)
        self.toggle_side_panel_button = QPushButton('Lists ▶', top_bar)
        self.toggle_side_panel_button.setToolTip('Show or hide the lists panel')
        self.toggle_side_panel_button.setMinimumWidth(
            self.toggle_side_panel_button.sizeHint().width()
        )
        self.toggle_side_panel_button.clicked.connect(self.toggle_side_panel)
        self.top_layout.addWidget(self.toggle_side_panel_button)
        self.left_layout.addWidget(top_bar)

        self.scroll_area = QScrollArea(self.left_container)
        self.scroll_area.setWidgetResizable(True)
        self.scroll_content = QWidget(self.scroll_area)
        self.scroll_layout = QVBoxLayout(self.scroll_content)
        self.scroll_area.setWidget(self.scroll_content)
        self.left_layout.addWidget(self.scroll_area)

        self.parent_lpn_layout = QHBoxLayout()
        self.parent_lpn_label = QLabel('Parent LPN:', self)
        self.parent_lpn_textbox = QLineEdit(self)
        self.parent_lpn_layout.addWidget(self.parent_lpn_label)
        self.parent_lpn_layout.addWidget(self.parent_lpn_textbox)
        self.scroll_layout.addLayout(self.parent_lpn_layout)

        self.c40_list_layout = QHBoxLayout()
        self.c40_list_label = QLabel('C40 List:', self)
        self.add_c40_list_button = QPushButton('C40 List', self)
        self.add_c40_list_button.clicked.connect(self.open_c40_list_dialog)
        self.c40_list_layout.addWidget(self.c40_list_label)
        self.c40_list_layout.addWidget(self.add_c40_list_button)
        self.scroll_layout.addLayout(self.c40_list_layout)

        self.scroll_layout.addItem(
            QSpacerItem(20, 20, QSizePolicy.Minimum, QSizePolicy.Expanding)
        )

        self.main_buttons = MainButtons(self)
        self.left_layout.addLayout(self.main_buttons.get_layout())

        self.scroll_layout.setSpacing(5)
        self.scroll_layout.setContentsMargins(5, 5, 5, 5)

        self.side_panel = QWidget(self.splitter)
        self.side_layout = QVBoxLayout(self.side_panel)
        self.side_layout.setContentsMargins(6, 6, 6, 6)
        self.side_layout.setSpacing(8)

        self.inline_c40_editor = CollapsibleListEditor(
            self,
            title='C40 List',
            attr_name='c40_list',
        )
        self.side_layout.addWidget(self.inline_c40_editor)
        self.inline_c40_editor.apply_button.clicked.connect(self._refresh_inline_editors)
        self.side_layout.addStretch()

        self.splitter.addWidget(self.left_container)
        self.splitter.addWidget(self.side_panel)
        self.splitter.setStretchFactor(0, 1)
        self.splitter.setStretchFactor(1, 0)
        self.splitter.setSizes([1, 0])

        self._refresh_inline_editors()
        self.finalize_initial_size(extra_width=120)
        self._update_side_panel_button()

    def open_c40_list_dialog(self):
        self.open_c40_list_inline()

    def open_c40_list_inline(self):
        try:
            if not hasattr(self, 'inline_c40_editor'):
                return
            self._ensure_side_panel_visible()
            editor = self.inline_c40_editor
            if not editor.container.isVisible():
                editor.container.setVisible(True)
                editor._update_toggle_icon()
            editor.programmatic_update()
            editor.editor.setFocus()
        except Exception:
            pass

    def _update_side_panel_button(self) -> None:
        try:
            sizes = self.splitter.sizes() if hasattr(self, 'splitter') else []
            if sizes and len(sizes) >= 2 and sizes[1] > 0:
                self.toggle_side_panel_button.setText('Lists ◀')
            else:
                self.toggle_side_panel_button.setText('Lists ▶')
        except Exception:
            pass

    def _open_side_panel(self) -> None:
        if not hasattr(self, 'splitter'):
            return
        sizes = self.splitter.sizes()
        if len(sizes) < 2:
            return
        left_width = max(sizes[0], self._min_left_width)
        desired_right = max(self._min_side_panel_width, self._side_panel_width)
        self._left_before_side_panel = left_width
        self.resize(self.width() + desired_right, self.height())
        self.splitter.setSizes([left_width, desired_right])

    def _collapse_side_panel(self) -> None:
        if not hasattr(self, 'splitter'):
            return
        sizes = self.splitter.sizes()
        if len(sizes) < 2:
            return
        right_width = sizes[1]
        if right_width <= 0:
            return
        target_width = max(self.minimumWidth(), self.width() - right_width)
        self.resize(target_width, self.height())
        left_target = (
            self._left_before_side_panel
            if self._left_before_side_panel is not None
            else sizes[0]
        )
        left_target = max(self._min_left_width, min(left_target, target_width))
        self.splitter.setSizes([left_target, 0])
        self._left_before_side_panel = None

    def toggle_side_panel(self) -> None:
        try:
            if not hasattr(self, 'splitter'):
                return
            sizes = self.splitter.sizes()
            if len(sizes) < 2:
                return
            if sizes[1] == 0:
                self._open_side_panel()
            else:
                self._collapse_side_panel()
            self._update_side_panel_button()
        except Exception:
            pass

    def _ensure_side_panel_visible(self) -> None:
        try:
            sizes = self.splitter.sizes()
            if len(sizes) < 2:
                return
            if sizes[1] == 0:
                self._open_side_panel()
                self._update_side_panel_button()
        except Exception:
            pass

    def _refresh_inline_editors(self) -> None:
        if hasattr(self, 'inline_c40_editor'):
            self.inline_c40_editor.programmatic_update()
        if hasattr(self, 'c40_list_label'):
            count = len(self.c40_list) if hasattr(self, 'c40_list') else 0
            self.c40_list_label.setText(f'C40 List ({count})')

    def validate_inputs(self):
        # Validate Parent LPN format
        parent_lpn = self.parent_lpn_textbox.text().strip()
        if parent_lpn and not any(parent_lpn.startswith(prefix) for prefix in ['C40-', 'L40-', 'RC40-', 'BTS40-']):
            self.status_label.setText('<span style="color: red;">Parent LPN must start with C40-, L40-, RC40-, or BTS40-</span>')
            self.parent_lpn_textbox.setStyleSheet("color: red;")
            self.parent_lpn_label.setStyleSheet("color: red;")
            return False
        else:
            self.parent_lpn_textbox.setStyleSheet("")
            self.parent_lpn_label.setStyleSheet("")

        # Validate C40 List entries
        for i, c40 in enumerate(self.c40_list):
            if not c40.startswith('C40-'):
                self.status_label.setText(f'<span style="color: red;">C40 List entry {i+1} must start with C40-</span>')
                return False

        return True

    def on_next_build(self):
        try:
            # Check if Parent LPN is entered
            if not self.parent_lpn_textbox.text().strip():
                self.status_label.setText('<span style="color: red;">Please enter the Parent LPN.</span>')
                return
                
            # Check if C40 list is not empty
            if not self.c40_list:
                self.status_label.setText('<span style="color: red;">Please add at least one C40 to the list.</span>')
                return

            # Validate inputs
            if not self.validate_inputs():
                return

            # All checks passed, proceed with adding to CSV
            if self.lpn_changed:
                self.append_uparrow()
                self.lpn_changed = False

            self.row_counter = CSV_Writer_Consolidate.append_to_csv(self.temp_csv_file, self.row_counter, self.c40_list, self.parent_lpn_textbox)
            self.total_builds += len(self.c40_list)
            self.status_label.setText(f'<span style="color: green;">{len(self.c40_list)} C40s added to CSV.</span>')
            self.counter_label.setText(f'# of C40s to Consolidate: {self.total_builds}')
            self.parent_lpn_textbox.setReadOnly(True)
            self.show_change_button()
            
            # Clear all fields except LPN and status
            self.c40_list = []
            self.c40_list_label.setText('C40 List:')
            self._refresh_inline_editors()

        except Exception as e:
            self.status_label.setText(f'<span style="color: red;">An unexpected error occurred: {str(e)}</span>')

    def append_uparrow(self):
        with open(self.temp_csv_file.name, 'a', newline='') as file:
            writer = csv.writer(file, delimiter=',')
            writer.writerow([self.row_counter, "UPARROW", "UPARROW", "", ""])
            self.row_counter += 1

    def clear_data_fields_except_lpn_and_status(self):
        try:
            self.c40_list = []
            self._refresh_inline_editors()
        except Exception as e:
            print(f"Error clearing data fields except LPN and status: {e}")

    def show_change_button(self):
        try:
            if hasattr(self, 'change_lpn_button'):
                self.change_lpn_button.setParent(None)
            self.change_lpn_button = QPushButton('Change', self)
            self.change_lpn_button.clicked.connect(self.enable_lpn_editing)
            self.parent_lpn_layout.addWidget(self.change_lpn_button)
        except Exception as e:
            print(f"Error showing change button: {e}")

    def enable_lpn_editing(self):
        self.lpn_changed = True  # Set flag to indicate LPN has been changed
        self.parent_lpn_textbox.setReadOnly(False)
        self.parent_lpn_textbox.setFocus()

    def clear_data_fields(self):
        # Clear all input fields
        self.parent_lpn_textbox.clear()
        self.parent_lpn_textbox.setReadOnly(False)
        
        # Clear all lists
        self.c40_list = []
        self._refresh_inline_editors()
        
        # Clear status message
        self.status_label.clear()
        
        # Reset counter
        self.total_builds = 0
        self.counter_label.setText('# of C40s to Consolidate: 0')
        
        # Remove change button if it exists
        if hasattr(self, 'change_lpn_button'):
            self.change_lpn_button.setParent(None)

    def start_over(self):
        try:
            reply = QMessageBox.question(self, 'Warning', 'This will delete all unsaved CSV data and will start over. Do you want to proceed?',
                                         QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
            if reply == QMessageBox.Yes:
                self.clear_data_fields()
                self.close()
                new_dialog = ConsolidateGUI()
                new_dialog.exec_()
        except Exception as e:
            print(f"Error starting over: {e}")

    def preview_csv(self):
        try:
            csv_data = CSV_Writer_Consolidate.read_csv(self.temp_csv_file)
            dialog = QDialog(self)
            dialog.setWindowTitle('Preview CSV')
            dialog.setFixedSize(600, 400)
            layout = QVBoxLayout(dialog)
            table = QTableWidget(dialog)
            table.setRowCount(len(csv_data))
            table.setColumnCount(3)
            table.setHorizontalHeaderLabels(["PROMPT", "KEY", "DATA"])
            for row_idx, row_data in enumerate(csv_data):
                for col_idx, col_data in enumerate(row_data[1:4]):
                    table.setItem(row_idx, col_idx, QTableWidgetItem(col_data))
            layout.addWidget(table)
            ok_button = QPushButton('OK', dialog)
            ok_button.clicked.connect(dialog.accept)
            layout.addWidget(ok_button)
            dialog.exec_()
        except Exception as e:
            print(f"Error previewing CSV: {e}")

    def on_finish_csv(self):
        try:
            # Check if the CSV is empty (only has headers)
            with open(self.temp_csv_file.name, 'r') as file:
                csv_data = list(csv.reader(file))
                # If CSV only has the header row, show warning message and return
                if len(csv_data) <= 1:  # Only header row exists
                    QMessageBox.warning(self, "CSV is Empty", 
                                     "CSV is currently blank. Fill out the information and add it via 'Add to CSV' and then 'Save As'.")
                    return
            
            # Check if the last row has "UPARROW" in the PROMPT column
            if len(csv_data) > 1 and csv_data[-1][1].strip() == "UPARROW":
                # Remove the last row and rewrite the CSV
                csv_data.pop()
                with open(self.temp_csv_file.name, 'w', newline='') as rewrite_file:
                    csv_writer = csv.writer(rewrite_file)
                    for row in csv_data:
                        csv_writer.writerow(row)
                # Adjust row counter since we removed a row
                self.row_counter -= 1
        
            CSV_Writer_Consolidate.append_finished(self.temp_csv_file, self.row_counter)
            self.row_counter += 1
            options = QMessageBox.Options()
            options |= QMessageBox.DontUseNativeDialog
            file_name, _ = QFileDialog.getSaveFileName(self, "Save CSV As", get_default_save_path_for_csv_writer(""), "CSV (MS-DOS) (*.csv);;All Files (*)", options=options)
            if file_name:
                if not file_name.endswith('.csv'):
                    file_name += '.csv'
                CSV_Writer_Consolidate.save_csv(file_name, self.temp_csv_file)
                
                # Prompt the user with the dialog after saving
                msg_box = QMessageBox()
                msg_box.setWindowTitle('CSV Saved')
                msg_box.setText('Would you like to start a new CSV or continue adding to the existing one?')
                new_csv_button = msg_box.addButton('New CSV', QMessageBox.ActionRole)
                continue_button = msg_box.addButton('Continue', QMessageBox.ActionRole)
                msg_box.exec_()
                
                if msg_box.clickedButton() == new_csv_button:
                    self.clear_data_fields()
                    self.close()
                    new_dialog = ConsolidateGUI()
                    new_dialog.exec_()
                elif msg_box.clickedButton() == continue_button:
                    # Remove the "FINISHED" row
                    with open(self.temp_csv_file.name, 'r') as file:
                        lines = file.readlines()
                    with open(self.temp_csv_file.name, 'w') as file:
                        for line in lines:
                            if "FINISHED" not in line:
                                file.write(line)
        except Exception as e:
            print(f"Error finishing CSV: {e}") 