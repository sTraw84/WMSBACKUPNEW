"""Runtime GUI generated from GUI Creator definitions."""

import csv
import json
import os
import tempfile
from functools import partial
from typing import Any, Dict, List, Optional, Tuple

from PyQt5.QtGui import QFont
from PyQt5.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QFileDialog,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QScrollArea,
    QSpinBox,
    QTableWidget,
    QTableWidgetItem,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

from .BaseGUI import BaseDialog
from ..utils.file_paths import get_default_save_path_for_csv_writer


class GeneratedListEditor(QDialog):
    """Simple list editor for generated GUIs."""

    def __init__(self, initial_items: Optional[List[str]] = None, parent: Optional[QWidget] = None) -> None:
        super().__init__(parent)
        self.items = list(initial_items or [])
        self.setWindowTitle("Edit List")
        self.setModal(True)
        self.resize(360, 420)
        self._init_ui()

    def _init_ui(self) -> None:
        layout = QVBoxLayout(self)
        layout.addWidget(QLabel("Enter items (one per line):"))
        self.text_edit = QTextEdit()
        self.text_edit.setPlainText("\n".join(self.items))
        layout.addWidget(self.text_edit)

        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def accept(self) -> None:
        text = self.text_edit.toPlainText()
        self.items = [line.strip() for line in text.splitlines() if line.strip()]
        super().accept()

    def get_items(self) -> List[str]:
        return self.items


class GeneratedTableEditor(QDialog):
    """Table editor for managing structured repeat data."""

    def __init__(
        self,
        columns: List[str],
        initial_rows: Optional[List[Dict[str, str]]] = None,
        parent: Optional[QWidget] = None,
    ) -> None:
        super().__init__(parent)
        self.columns = columns
        self.rows = [dict(row) for row in (initial_rows or [])]
        self.setWindowTitle("Edit Table Data")
        self.resize(520, 420)
        self._init_ui()
        self._load_rows()

    def _init_ui(self) -> None:
        layout = QVBoxLayout(self)
        layout.addWidget(QLabel("Enter values for each column. Blank rows are ignored."))

        self.table = QTableWidget()
        self.table.setColumnCount(len(self.columns))
        self.table.setHorizontalHeaderLabels(self.columns)
        layout.addWidget(self.table)

        button_row = QHBoxLayout()
        add_row_btn = QPushButton("Add Row")
        add_row_btn.clicked.connect(self._add_row)
        remove_row_btn = QPushButton("Remove Row")
        remove_row_btn.clicked.connect(self._remove_row)
        clear_btn = QPushButton("Clear")
        clear_btn.clicked.connect(self._clear_rows)
        button_row.addWidget(add_row_btn)
        button_row.addWidget(remove_row_btn)
        button_row.addWidget(clear_btn)
        button_row.addStretch()
        layout.addLayout(button_row)

        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def _load_rows(self) -> None:
        for row in self.rows:
            self._add_row(row)

    def _add_row(self, values: Optional[Dict[str, str]] = None) -> None:
        row_index = self.table.rowCount()
        self.table.insertRow(row_index)
        values = values or {}
        for col_index, column in enumerate(self.columns):
            item = QTableWidgetItem(values.get(column, ""))
            self.table.setItem(row_index, col_index, item)

    def _remove_row(self) -> None:
        current = self.table.currentRow()
        if current >= 0:
            self.table.removeRow(current)

    def _clear_rows(self) -> None:
        self.table.setRowCount(0)

    def accept(self) -> None:
        result: List[Dict[str, str]] = []
        for row_index in range(self.table.rowCount()):
            row_data: Dict[str, str] = {}
            non_empty = False
            for col_index, column in enumerate(self.columns):
                item = self.table.item(row_index, col_index)
                value = item.text().strip() if item else ""
                if value:
                    non_empty = True
                row_data[column] = value
            if non_empty:
                result.append(row_data)
        self.rows = result
        super().accept()

    def get_rows(self) -> List[Dict[str, str]]:
        return self.rows


class GeneratedGUI(BaseDialog):
    """Dynamically generated GUI from a GUI definition."""

    def __init__(self, gui_def, parent: Optional[QWidget] = None) -> None:
        super().__init__(parent)
        self.gui_def = gui_def
        self.field_lookup: Dict[str, Any] = {field.key: field for field in self.gui_def.fields if field.key}
        self.field_widgets: Dict[str, QWidget] = {}
        self.field_display_widgets: Dict[str, QLineEdit] = {}
        self.field_containers: Dict[str, QWidget] = {}
        self.visible_state: Dict[str, bool] = {}
        self.required_state: Dict[str, bool] = {}
        self.list_data: Dict[str, List[str]] = {key: [] for key in self.field_lookup if self.field_lookup[key].field_type == "list"}
        self.table_data: Dict[str, List[Dict[str, str]]] = {key: [] for key in self.field_lookup if self.field_lookup[key].field_type == "table"}

        temp_handle = tempfile.NamedTemporaryFile(delete=False, mode="w", newline="")
        self.temp_csv_path = temp_handle.name
        temp_handle.close()
        self.csv_headers = ["NUMBER", "PROMPT", "KEY", "DATA"]

        self.setWindowTitle(self.gui_def.name or "Generated GUI")
        self.setMinimumSize(540, 420)
        self._init_ui()

    def _init_ui(self) -> None:
        main_layout = QVBoxLayout(self)

        if self.gui_def.name:
            title = QLabel(self.gui_def.name)
            title.setFont(QFont("Arial", 16, QFont.Bold))
            title.setStyleSheet("color: #CCCCCC;")
            main_layout.addWidget(title)

        if self.gui_def.description:
            desc = QLabel(self.gui_def.description)
            desc.setWordWrap(True)
            desc.setStyleSheet("color: #AAAAAA; margin: 4px 0;")
            main_layout.addWidget(desc)

        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_content = QWidget()
        scroll_layout = QVBoxLayout(scroll_content)
        scroll_area.setWidget(scroll_content)
        main_layout.addWidget(scroll_area)

        form_layout = QVBoxLayout()
        for field in self.gui_def.fields:
            form_layout.addWidget(self._create_field_widget(field))
        form_layout.addStretch()
        scroll_layout.addLayout(form_layout)

        button_row = QHBoxLayout()
        generate_btn = QPushButton("Generate CSV")
        generate_btn.clicked.connect(self.generate_csv)
        preview_btn = QPushButton("Preview CSV")
        preview_btn.clicked.connect(self.preview_csv)
        clear_btn = QPushButton("Clear")
        clear_btn.clicked.connect(self.clear_fields)
        close_btn = QPushButton("Close")
        close_btn.clicked.connect(self.accept)

        button_row.addWidget(generate_btn)
        button_row.addWidget(preview_btn)
        button_row.addWidget(clear_btn)
        button_row.addWidget(close_btn)
        main_layout.addLayout(button_row)
        self._refresh_field_states()

    def _create_field_widget(self, field) -> QWidget:
        container = QWidget()
        container_layout = QVBoxLayout(container)
        container_layout.setContentsMargins(0, 0, 0, 0)

        field_label = QLabel(field.label or field.key or "Field")
        field_label.setStyleSheet("font-weight: bold;")
        container_layout.addWidget(field_label)

        control_widget: Optional[QWidget] = None

        if field.field_type == "text":
            line_edit = QLineEdit()
            line_edit.setText(field.default_value)
            if field.tooltip:
                line_edit.setToolTip(field.tooltip)
            control_widget = line_edit
            if field.key:
                line_edit.textChanged.connect(partial(self._on_field_value_changed, field.key))
        elif field.field_type == "number":
            spin_box = QSpinBox()
            spin_box.setMaximum(999999)
            try:
                spin_box.setValue(int(field.default_value))
            except ValueError:
                spin_box.setValue(0)
            if field.tooltip:
                spin_box.setToolTip(field.tooltip)
            control_widget = spin_box
            if field.key:
                spin_box.valueChanged.connect(partial(self._on_field_value_changed, field.key))
        elif field.field_type == "checkbox":
            check_box = QCheckBox()
            if field.tooltip:
                check_box.setToolTip(field.tooltip)
            check_box.setChecked(field.default_value.lower() == "true")
            control_widget = check_box
            if field.key:
                check_box.stateChanged.connect(partial(self._on_field_value_changed, field.key))
        elif field.field_type == "dropdown":
            combo = QComboBox()
            combo.addItems(field.options)
            if field.default_value in field.options:
                combo.setCurrentText(field.default_value)
            if field.tooltip:
                combo.setToolTip(field.tooltip)
            control_widget = combo
            if field.key:
                combo.currentTextChanged.connect(partial(self._on_field_value_changed, field.key))
        elif field.field_type == "list":
            row_layout = QHBoxLayout()
            display = QLineEdit()
            display.setReadOnly(True)
            display.setPlaceholderText("Click Edit to manage list items")
            edit_button = QPushButton("Edit List")
            edit_button.clicked.connect(lambda _, k=field.key, disp=display: self._edit_list(k, disp))
            row_layout.addWidget(display)
            row_layout.addWidget(edit_button)
            container_layout.addLayout(row_layout)
            if field.key:
                self.field_display_widgets[field.key] = display
        elif field.field_type == "table":
            row_layout = QHBoxLayout()
            display = QLineEdit()
            display.setReadOnly(True)
            display.setPlaceholderText("Click Edit to manage table rows")
            edit_button = QPushButton("Edit Table")
            edit_button.clicked.connect(lambda _, f=field, disp=display: self._edit_table(f, disp))
            row_layout.addWidget(display)
            row_layout.addWidget(edit_button)
            container_layout.addLayout(row_layout)
            if field.key:
                self.field_display_widgets[field.key] = display
        else:
            placeholder = QLineEdit()
            placeholder.setEnabled(False)
            control_widget = placeholder

        if control_widget is not None:
            container_layout.addWidget(control_widget)

        if field.key and control_widget is not None:
            self.field_widgets[field.key] = control_widget

        if field.tooltip and field.field_type in {"list", "table"}:
            field_label.setToolTip(field.tooltip)

        if field.key:
            self.field_containers[field.key] = container

        return container

    def _on_field_value_changed(self, field_key: str, *_args) -> None:
        if not field_key:
            return
        self._refresh_field_states()

    def _refresh_field_states(self) -> None:
        for field in self.gui_def.fields:
            key = getattr(field, "key", "")
            if not key:
                continue
            is_visible = self._evaluate_field_condition(field.visible_when)
            container = self.field_containers.get(key)
            if container:
                container.setVisible(is_visible)
            self.visible_state[key] = is_visible

            if not is_visible:
                is_required = False
            elif field.required_when:
                is_required = self._evaluate_field_condition(field.required_when)
            else:
                is_required = field.required

            self.required_state[key] = is_required

    def _evaluate_field_condition(self, condition: str) -> bool:
        return self._evaluate_condition_string(condition, default=False)

    def _is_field_visible(self, field) -> bool:
        if not getattr(field, "key", ""):
            return True
        return bool(self.visible_state.get(field.key, True))

    def _is_field_required(self, field) -> bool:
        if not getattr(field, "key", ""):
            return getattr(field, "required", False)
        return bool(self.required_state.get(field.key, field.required))

    def _edit_list(self, field_key: str, display_widget: QLineEdit) -> None:
        editor = GeneratedListEditor(self.list_data.get(field_key, []), self)
        if editor.exec_() == QDialog.Accepted:
            self.list_data[field_key] = editor.get_items()
            display_widget.setText(f"{len(self.list_data[field_key])} items")
            self._refresh_field_states()

    def _edit_table(self, field, display_widget: QLineEdit) -> None:
        if not field.columns:
            QMessageBox.warning(self, "Missing Columns", "Define columns for this table field in the GUI Creator before editing.")
            return
        editor = GeneratedTableEditor(field.columns, self.table_data.get(field.key, []), self)
        if editor.exec_() == QDialog.Accepted:
            self.table_data[field.key] = editor.get_rows()
            display_widget.setText(f"{len(self.table_data[field.key])} rows")
            self._refresh_field_states()

    def clear_fields(self) -> None:
        for field in self.gui_def.fields:
            widget = self.field_widgets.get(field.key)
            if field.field_type == "text" and widget:
                widget.setText(field.default_value)
            elif field.field_type == "number" and widget:
                try:
                    widget.setValue(int(field.default_value))
                except ValueError:
                    widget.setValue(0)
            elif field.field_type == "checkbox" and widget:
                widget.setChecked(field.default_value.lower() == "true")
            elif field.field_type == "dropdown" and widget:
                if field.default_value in field.options:
                    widget.setCurrentText(field.default_value)

        for key in self.list_data:
            self.list_data[key] = []
            display = self.field_display_widgets.get(key)
            if display:
                display.clear()
        for key in self.table_data:
            self.table_data[key] = []
            display = self.field_display_widgets.get(key)
            if display:
                display.clear()
        self._refresh_field_states()

    def generate_csv(self) -> None:
        if not self._validate_required_fields():
            return

        rows = self._build_csv_rows()
        if not rows:
            QMessageBox.warning(self, "No Rows", "The template did not generate any rows. Check your repeat data and conditions.")
            return

        try:
            with open(self.temp_csv_path, "w", newline="") as handle:
                writer = csv.writer(handle)
                writer.writerow(self.csv_headers)
                writer.writerows(rows)
        except Exception as exc:
            QMessageBox.critical(self, "Error", f"Failed to write temporary CSV:\n{exc}")
            return

        self._save_csv()

    def _save_csv(self) -> None:
        default_name = (self.gui_def.name or "generated").replace(" ", "_") + ".csv"
        default_path = get_default_save_path_for_csv_writer(default_name)
        file_path, _ = QFileDialog.getSaveFileName(
            self,
            "Save Generated CSV",
            default_path,
            "CSV Files (*.csv);;All Files (*)",
        )
        if not file_path:
            return
        if not file_path.lower().endswith(".csv"):
            file_path += ".csv"

        try:
            with open(self.temp_csv_path, "r", newline="") as src, open(file_path, "w", newline="") as dst:
                dst.write(src.read())
            QMessageBox.information(self, "Saved", f"CSV saved to:\n{file_path}")
        except Exception as exc:
            QMessageBox.critical(self, "Save Failed", f"Unable to save CSV:\n{exc}")

    def preview_csv(self) -> None:
        if not self._validate_required_fields():
            return
        rows = self._build_csv_rows()
        if not rows:
            QMessageBox.warning(self, "No Rows", "The template did not generate any rows to preview.")
            return

        dialog = QDialog(self)
        dialog.setWindowTitle("CSV Preview")
        dialog.resize(720, 520)
        layout = QVBoxLayout(dialog)

        table = QTableWidget()
        table.setColumnCount(4)
        table.setHorizontalHeaderLabels(self.csv_headers)
        table.setRowCount(len(rows))
        for row_index, row_data in enumerate(rows):
            for col_index, cell in enumerate(row_data):
                table.setItem(row_index, col_index, QTableWidgetItem(str(cell)))
        table.resizeColumnsToContents()
        layout.addWidget(table)

        close_btn = QPushButton("Close")
        close_btn.clicked.connect(dialog.accept)
        layout.addWidget(close_btn)
        dialog.exec_()

    def _validate_required_fields(self) -> bool:
        self._refresh_field_states()
        for field in self.gui_def.fields:
            if not getattr(field, "key", ""):
                continue
            if not self._is_field_visible(field):
                continue
            if not self._is_field_required(field):
                continue

            widget = self.field_widgets.get(field.key)
            if field.field_type == "text" and isinstance(widget, QLineEdit):
                if not widget.text().strip():
                    QMessageBox.warning(self, "Missing Field", f"Enter a value for '{field.label or field.key}'.")
                    return False
            elif field.field_type == "dropdown" and isinstance(widget, QComboBox):
                if not widget.currentText().strip():
                    QMessageBox.warning(self, "Missing Selection", f"Select a value for '{field.label or field.key}'.")
                    return False
            elif field.field_type == "checkbox" and isinstance(widget, QCheckBox):
                if not widget.isChecked():
                    QMessageBox.warning(self, "Missing Selection", f"Check '{field.label or field.key}' before continuing.")
                    return False
            elif field.field_type == "list":
                if not self.list_data.get(field.key):
                    QMessageBox.warning(self, "Missing List", f"Add at least one item for '{field.label or field.key}'.")
                    return False
            elif field.field_type == "table":
                if not self.table_data.get(field.key):
                    QMessageBox.warning(self, "Missing Table", f"Add at least one row for '{field.label or field.key}'.")
                    return False
        return True

    def _build_csv_rows(self) -> List[List[str]]:
        rows: List[List[str]] = []
        row_number = 1

        def append_row(prompt: str, key: str, data: str) -> None:
            nonlocal row_number
            rows.append([str(row_number), prompt, key, data])
            row_number += 1

        main_rows = [row for row in self.gui_def.csv_rows if row.segment == "main"]
        footer_rows = [row for row in self.gui_def.csv_rows if row.segment == "footer"]

        self._expand_rows(main_rows, append_row)
        if self.gui_def.include_finished:
            append_row("FINISHED", "", "")
        self._expand_rows(footer_rows, append_row)
        return rows

    def _expand_rows(self, row_defs: List[Any], append_row) -> None:
        index = 0
        while index < len(row_defs):
            row_def = row_defs[index]
            if row_def.repeat_field:
                items_info = self._get_repeat_items(row_def.repeat_field)
                if not items_info:
                    index += 1
                    continue
                field_def, items = items_info
                group: List[Any] = []
                while index < len(row_defs) and row_defs[index].repeat_field == row_def.repeat_field:
                    group.append(row_defs[index])
                    index += 1
                for item in items:
                    for grouped_row in group:
                        if not self._evaluate_condition(grouped_row.condition):
                            continue
                        data_value = self._resolve_data_value(grouped_row, item, field_def)
                        append_row(grouped_row.prompt, grouped_row.key, data_value)
            else:
                if self._evaluate_condition(row_def.condition):
                    append_row(row_def.prompt, row_def.key, self._resolve_data_value(row_def, None, None))
                index += 1

    def _get_repeat_items(self, field_key: str) -> Optional[Tuple[Any, List[Any]]]:
        field_def = self.field_lookup.get(field_key)
        if not field_def:
            return None
        if field_def.field_type == "list":
            return field_def, self.list_data.get(field_key, [])
        if field_def.field_type == "table":
            return field_def, self.table_data.get(field_key, [])
        return None

    def _resolve_data_value(self, row_def, repeat_item: Any, repeat_field_def) -> str:
        source = row_def.data_source or ""
        if source.startswith("field:"):
            field_key = source[len("field:"):]
            return self.get_field_value(field_key)
        if source.startswith("literal:"):
            return source[len("literal:") :]
        if source == "repeat_value":
            return str(repeat_item) if repeat_item is not None else ""
        if source.startswith("repeat_column:"):
            column = source[len("repeat_column:") :]
            if isinstance(repeat_item, dict):
                return str(repeat_item.get(column, ""))
            return ""
        return ""

    def get_field_value(self, field_key: str) -> str:
        field = self.field_lookup.get(field_key)
        if not field:
            return ""
        widget = self.field_widgets.get(field_key)
        if field.field_type == "text" and widget:
            return widget.text().strip()
        if field.field_type == "number" and widget:
            return str(widget.value())
        if field.field_type == "checkbox" and widget:
            return "true" if widget.isChecked() else "false"
        if field.field_type == "dropdown" and widget:
            return widget.currentText()
        if field.field_type == "list":
            return ", ".join(self.list_data.get(field_key, []))
        if field.field_type == "table":
            rows = self.table_data.get(field_key, [])
            return ", ".join(str(row) for row in rows)
        return ""

    def _evaluate_condition(self, condition: str) -> bool:
        return self._evaluate_condition_string(condition, default=True)

    def _evaluate_condition_string(self, condition: str, default: bool) -> bool:
        text = (condition or "").strip()
        if not text:
            return True
        if text.startswith("{"):
            try:
                payload = json.loads(text)
            except (TypeError, ValueError):
                return default
            return self._evaluate_condition_payload(payload, default)
        return self._evaluate_legacy_condition(text, default)

    def _evaluate_condition_payload(self, payload: Any, default: bool) -> bool:
        if not isinstance(payload, dict):
            return default
        raw_rules = payload.get("rules", [])
        if not isinstance(raw_rules, list) or not raw_rules:
            return default

        results: List[bool] = []
        for raw in raw_rules:
            if not isinstance(raw, dict):
                continue
            results.append(self._evaluate_condition_rule(raw))

        if not results:
            return default

        mode = payload.get("mode", "all")
        if mode == "any":
            return any(results)
        if mode == "all":
            return all(results)
        return all(results)

    def _evaluate_condition_rule(self, rule: Dict[str, Any]) -> bool:
        field_key = str(rule.get("field", "")).strip()
        if not field_key:
            return False
        operator = str(rule.get("operator", "equals")).strip()
        value_text = str(rule.get("value", "")).strip()
        field_value = self.get_field_value(field_key).strip()

        field_value_cf = field_value.casefold()
        value_cf = value_text.casefold()

        if operator == "equals":
            return field_value_cf == value_cf
        if operator == "not_equals":
            return field_value_cf != value_cf
        if operator == "is_filled":
            return bool(field_value)
        if operator == "is_blank":
            return not field_value
        if operator == "contains":
            return value_cf in field_value_cf
        if operator == "not_contains":
            return value_cf not in field_value_cf

        if value_text:
            return field_value_cf == value_cf
        return bool(field_value)

    def _evaluate_legacy_condition(self, condition: str, default: bool) -> bool:
        if condition.startswith("field:"):
            clause = condition[len("field:") :]
            if "!=" in clause:
                field_key, expected = clause.split("!=", 1)
                field_value = self.get_field_value(field_key.strip()).strip()
                expected = expected.strip()
                if expected:
                    return field_value.casefold() != expected.casefold()
                return bool(field_value)
            if "=" in clause:
                field_key, expected = clause.split("=", 1)
                field_value = self.get_field_value(field_key.strip()).strip()
                expected = expected.strip()
                if expected:
                    return field_value.casefold() == expected.casefold()
                return not field_value
        return default

    def closeEvent(self, event) -> None:  # type: ignore[override]
        try:
            if os.path.exists(self.temp_csv_path):
                os.unlink(self.temp_csv_path)
        except Exception:
            pass
        event.accept()
