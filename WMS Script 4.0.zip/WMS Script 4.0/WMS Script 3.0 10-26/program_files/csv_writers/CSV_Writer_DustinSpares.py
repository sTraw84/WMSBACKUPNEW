"""
Compatibility shim for an earlier CSV writer module name.

This module re-exports the canonical Part Balancer CSV writer so older
import paths remain functional during a rename. Use
`program_files.csv_writers.CSV_Writer_PartBalancer` for the implementation.
"""

from .CSV_Writer_PartBalancer import *  # noqa: F401,F403
