"""
Compatibility shim: re-export the canonical Repack writer.

This module is a small compatibility shim that re-exports the canonical
`CSV_Writer_Repack` implementation under an alternative filename to avoid
breaking older imports. The module contains no unique logic.
"""

from .CSV_Writer_Repack import *  # noqa: F401,F403
