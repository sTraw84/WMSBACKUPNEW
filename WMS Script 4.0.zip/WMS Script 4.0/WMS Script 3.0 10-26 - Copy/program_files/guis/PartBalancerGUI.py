import tempfile
import os
from collections import defaultdict
from PyQt5.QtWidgets import QSplitter
from typing import Any, Dict, List, Mapping, Optional, Sequence, cast

from PyQt5.QtCore import Qt
from PyQt5.QtGui import QIntValidator
from PyQt5.QtWidgets import (
    QGridLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QRadioButton,
    QSizePolicy,
    QVBoxLayout,
    QWidget,
    QScrollArea,
    QTextEdit,
    QTabWidget,
)

from program_files.csv_writers import CSV_Writer_PartBalancer


from .BaseGUI import BaseDialog
from .MainButtons import MainButtons


class IntLineEdit(QLineEdit):
    def __init__(self, parent: Optional[QWidget] = None) -> None:
        super().__init__(parent)
        self.setValidator(QIntValidator(0, 999999, self))


class PartBalancerGUI(BaseDialog):
    def toggle_side_panel(self):
        # Toggle visibility of the report panel
        sizes = self.splitter.sizes() if hasattr(self, 'splitter') else []
        if sizes and len(sizes) >= 2 and sizes[1] > 0:
            # Collapse side panel
            left = max(sizes[0] + sizes[1], self._min_left_width)
            self.splitter.setSizes([left, 0])
            self.toggle_side_panel_button.setText('Report ▶')
        else:
            # Open side panel
            left_width = max(sizes[0], self._min_left_width) if sizes else 500
            right_width = (
                max(self._min_side_panel_width, self._side_panel_width)
                if hasattr(self, '_side_panel_width') else 320
            )
            self.splitter.setSizes([left_width, right_width])
            self.toggle_side_panel_button.setText('Report ◀')
    
    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle("Part Balancer")
        self.screen_indicator = "REPACK"
        self.csv_writer = CSV_Writer_PartBalancer
        self.temp_csv_file = tempfile.NamedTemporaryFile(
            delete=False, mode="w", newline=""
        )
        self.csv_writer.write_csv_headers(self.temp_csv_file)
        self.temp_csv_file.flush()
        self._side_panel_width = 320
        self._min_left_width = 320
        self._min_side_panel_width = 220
        self._left_before_side_panel = None
        self.row_counter = 1
        self.csv_headers = ["NUMBER", "PROMPT", "KEY", "DATA"]
        self.starting_sheet_path = None
        self.spare_mode = None
        self.plan_consumed = False
        self.row_entries = []
        self._suppress_row_change = False
        # Part identifiers (how many parts per C40). Default 1, up to 5.
        self.part_count = 1
        self.part_id_widgets = []  # list of (label_widget, lineedit)
        # storage for last generated report (used by Save Report)
        self._last_report = None
        self._build_ui()
        self._add_lpn_row(mark_dirty=False)
        self.finalize_initial_size(extra_width=120)
        self._update_add_button_state()

    def _build_ui(self) -> None:
        self.resize(800, 600)
        self.setMinimumSize(700, 500)
        self.main_layout = QVBoxLayout(self)

        # Splitter for left (form/buttons) and right (collapsible report)
        self.splitter = QSplitter(Qt.Orientation.Horizontal, self)
        self.splitter.setHandleWidth(1)
        self.main_layout.addWidget(self.splitter)

        # Left panel: scroll area for form and buttons
        self.left_container = QWidget(self.splitter)
        self.left_container.setMinimumWidth(500)
        self.left_layout = QVBoxLayout(self.left_container)
        self.left_layout.setContentsMargins(0, 0, 0, 0)
        self.left_layout.setSpacing(5)

        # Top bar with status and toggle button
        top_bar = QWidget(self.left_container)
        self.top_layout = QHBoxLayout(top_bar)
        self.top_layout.setContentsMargins(0, 0, 0, 0)
        self.status_label = QLabel(top_bar)
        self.top_layout.addWidget(self.status_label)
        self.toggle_side_panel_button = QPushButton('Report ▶', top_bar)
        self.toggle_side_panel_button.setToolTip(
            'Show or hide the report panel'
        )
        self.toggle_side_panel_button.setMinimumWidth(
            self.toggle_side_panel_button.sizeHint().width()
        )
        self.toggle_side_panel_button.clicked.connect(self.toggle_side_panel)
        self.top_layout.addWidget(self.toggle_side_panel_button)
        self.left_layout.addWidget(top_bar)

        # Scroll area for form
        self.scroll_area = QScrollArea(self.left_container)
        self.scroll_area.setWidgetResizable(True)
        self.scroll_content = QWidget(self.scroll_area)
        self.scroll_layout = QVBoxLayout(self.scroll_content)
        self.scroll_layout.setSpacing(6)
        self.scroll_layout.setContentsMargins(5, 5, 5, 5)
        self.scroll_area.setWidget(self.scroll_content)
        self.left_layout.addWidget(self.scroll_area)

        # Title
        title = QLabel("Part Balancer")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title.setStyleSheet("font-size: 18px; font-weight: bold;")
        self.scroll_layout.addWidget(title)

        # Upload box
        upload_box = QHBoxLayout()
        self.upload_button = QPushButton("Upload Spreadsheet")
        self.upload_button.clicked.connect(self.upload_spreadsheet)
        upload_box.addWidget(self.upload_button)
        self.file_label = QLabel("No file selected")
        self.file_label.setSizePolicy(
            QSizePolicy.Expanding, QSizePolicy.Preferred
        )
        upload_box.addWidget(self.file_label)
        self.scroll_layout.addLayout(upload_box)

        # Source radio group
        source_group = QGroupBox("Where are the spares coming from?")
        source_layout = QGridLayout()
        self.location_radio = QRadioButton("Location")
        self.location_radio.toggled.connect(
            lambda checked: checked and self._set_spare_mode("location")
        )
        source_layout.addWidget(self.location_radio, 0, 0)
        self.lpn_radio = QRadioButton("LPN")
        self.lpn_radio.toggled.connect(
            lambda checked: checked and self._set_spare_mode("lpn")
        )
        source_layout.addWidget(self.lpn_radio, 0, 1)
        source_group.setLayout(source_layout)
        self.scroll_layout.addWidget(source_group)

        # Spare LPN entry
        self.spare_lpn_container = QWidget()
        spare_lpn_layout = QHBoxLayout(self.spare_lpn_container)
        spare_lpn_layout.setContentsMargins(0, 0, 0, 0)
        spare_lpn_layout.setSpacing(6)
        spare_label = QLabel("Spare LPN:")
        spare_lpn_layout.addWidget(spare_label)
        self.spare_lpn_edit = QLineEdit()
        self.spare_lpn_edit.textChanged.connect(self._on_rows_changed)
        spare_lpn_layout.addWidget(self.spare_lpn_edit)
        self.spare_lpn_container.hide()
        self.scroll_layout.addWidget(self.spare_lpn_container)

        # Part Identifiers (controls above the C40 header/rows)
        self.part_id_container = QWidget()
        part_id_layout = QHBoxLayout(self.part_id_container)
        part_id_layout.setContentsMargins(0, 0, 0, 0)
        part_id_layout.setSpacing(6)
        part_id_layout.addWidget(QLabel("Part Identifiers:"))

        # Container for up to 5 part identifier edits (label + edit each)
        self.part_id_edits_container = QWidget()
        pid_edits_layout = QHBoxLayout(self.part_id_edits_container)
        pid_edits_layout.setContentsMargins(0, 0, 0, 0)
        pid_edits_layout.setSpacing(6)
        # create 5 pairs but only show according to self.part_count
        for i in range(1, 6):
            lbl = QLabel(f"Part {i}:")
            edit = QLineEdit()
            edit.setPlaceholderText(f"Part {i}")
            pid_edits_layout.addWidget(lbl)
            pid_edits_layout.addWidget(edit)
            lbl.setVisible(i == self.part_count)
            edit.setVisible(i == self.part_count)
            self.part_id_widgets.append((lbl, edit))
        part_id_layout.addWidget(self.part_id_edits_container)

        # +/- controls for part count
        self.part_add_button = QPushButton("+")
        self.part_add_button.setFixedWidth(28)
        self.part_add_button.clicked.connect(lambda: self._change_part_count(1))
        part_id_layout.addWidget(self.part_add_button)
        self.part_remove_button = QPushButton("-")
        self.part_remove_button.setFixedWidth(28)
        self.part_remove_button.clicked.connect(lambda: self._change_part_count(-1))
        part_id_layout.addWidget(self.part_remove_button)
        part_id_layout.addStretch()
        self.scroll_layout.addWidget(self.part_id_container)

        # Header placeholder (will be created after the C40 controls so it
        # sits visually under the "C40 Builds:" label and +/- buttons)
        self.header_widget = None

        # Table widget (shared grid for header + rows). Using a single
        # QGridLayout for the header and all rows ensures perfect column
        # alignment regardless of the number of parts.
        self.table_widget = QWidget()
        self.table_layout = QGridLayout(self.table_widget)
        self.table_layout.setContentsMargins(0, 0, 0, 0)
        self.table_layout.setHorizontalSpacing(10)
        self.table_layout.setVerticalSpacing(6)

        # Controls for adding/removing rows (C40 Builds: label, +, -) -- placed above the rows
        controls_layout = QHBoxLayout()
        csv_rows_label = QLabel("C40 Builds:")
        controls_layout.addWidget(csv_rows_label)
        self.add_row_button = QPushButton("+")
        self.add_row_button.setFixedWidth(28)
        self.add_row_button.clicked.connect(lambda: self._add_lpn_row())
        controls_layout.addWidget(self.add_row_button)
        self.remove_row_button = QPushButton("-")
        self.remove_row_button.setFixedWidth(28)
        self.remove_row_button.clicked.connect(self._remove_last_lpn_row_split_style)
        controls_layout.addWidget(self.remove_row_button)
        # Small Paste button to toggle Paste Multi panel (keeps controls compact)
        self.paste_button = QPushButton("Paste Multi")
        # Make the button wide enough to show the full text on most UI scales
        # (using a slightly generous fixed width so the label doesn't clip)
        self.paste_button.setFixedWidth(92)
        self.paste_button.clicked.connect(self._controls_paste_clicked)
        controls_layout.addWidget(self.paste_button)
        controls_layout.addStretch()
        # Wrap controls in a widget so we can reliably find/insert the header
        # directly after it in the scroll layout for consistent alignment.
        self.controls_container = QWidget()
        self.controls_container.setLayout(controls_layout)
        self.scroll_layout.addWidget(self.controls_container)

        # Paste Multi widget (hidden by default). This provides a tab per
        # column (LPN, Start1, End1, Start2, End2, ...) so users can paste
        # columnar data into each tab like Split/Repack/Transfer.
        self.paste_widget = QWidget()
        paste_layout = QVBoxLayout(self.paste_widget)
        paste_layout.setContentsMargins(0, 0, 0, 0)
        paste_layout.setSpacing(4)

        paste_buttons = QHBoxLayout()
        self.toggle_paste_button = QPushButton("Paste Multi")
        # Toggle visibility of the paste area and rebuild tabs when shown
        self.toggle_paste_button.setCheckable(True)
        self.toggle_paste_button.toggled.connect(self._toggle_paste_multi)
        paste_buttons.addWidget(self.toggle_paste_button)
        self.paste_apply_button = QPushButton("Apply")
        self.paste_apply_button.clicked.connect(self._apply_paste_multi)
        paste_buttons.addWidget(self.paste_apply_button)
        self.paste_clear_button = QPushButton("Clear")
        self.paste_clear_button.clicked.connect(self._clear_paste_tabs)
        paste_buttons.addWidget(self.paste_clear_button)
        paste_buttons.addStretch()
        paste_layout.addLayout(paste_buttons)

        # Tab widget: one QTextEdit per column
        self.paste_tabs = QTabWidget()
        paste_layout.addWidget(self.paste_tabs)
        self.paste_widget.setVisible(False)
        self.scroll_layout.addWidget(self.paste_widget)

        # Now that the controls exist, create a single block that will hold
        # the header and the rows together. Putting both header and rows
        # inside the same widget/layout ensures the header grid lines up
        # exactly with each row's grid columns.
        self.rows_block = QWidget()
        rows_block_layout = QVBoxLayout(self.rows_block)
        rows_block_layout.setContentsMargins(0, 0, 0, 0)
        rows_block_layout.setSpacing(4)

        # Build the header (it will insert into rows_block when present)
        self._rebuild_header()

        # Add the rows container into the rows_block so header and rows
        # share the same horizontal origin and spacing.
        rows_block_layout.addWidget(self.table_widget)

        # Finally add the combined block to the main scroll layout.
        self.scroll_layout.addWidget(self.rows_block)
        self.scroll_layout.addWidget(self.table_widget)

        # Add stretch so extra space is at the bottom when resizing
        self.scroll_layout.addStretch()

        # Main buttons at bottom, outside scroll area (stationary)
        self.main_buttons = MainButtons(self)

        # Add a container widget for scroll area + buttons
        self.left_panel_container = QWidget(self.splitter)
        self.left_panel_layout = QVBoxLayout(self.left_panel_container)
        self.left_panel_layout.setContentsMargins(0, 0, 0, 0)
        self.left_panel_layout.setSpacing(0)
        self.left_panel_layout.addWidget(self.left_container)
        self.left_panel_layout.addLayout(self.main_buttons.get_layout())
        self.splitter.addWidget(self.left_panel_container)

        # Right panel: collapsible report
        from PyQt5.QtWidgets import QTextEdit
        self.report_panel = QWidget(self.splitter)
        self.report_panel.setMinimumWidth(400)
        self.report_panel.setMaximumWidth(600)
        self.report_layout = QVBoxLayout(self.report_panel)
        self.report_layout.setContentsMargins(6, 6, 6, 6)
        self.report_layout.setSpacing(8)
        self.report_output = QTextEdit(self.report_panel)
        self.report_output.setReadOnly(True)
        self.report_output.setFrameStyle(QTextEdit.NoFrame)
        self.report_output.setStyleSheet(
            "background: transparent; font-size: 13px; border: none;"
        )
        self.report_output.setSizePolicy(
            QSizePolicy.Expanding, QSizePolicy.Expanding
        )
        # Add a Save Report button above the report so users can export the
        # current inline report to an Excel file.
        self.save_report_button = QPushButton("Save Report")
        self.save_report_button.setToolTip("Save the current report to an Excel file")
        self.save_report_button.clicked.connect(self.save_report)
        # Place the button at the top of the report panel
        self.report_layout.addWidget(self.save_report_button)
        self.report_layout.addWidget(self.report_output)
        self.splitter.addWidget(self.report_panel)
        self.splitter.setStretchFactor(0, 4)
        self.splitter.setStretchFactor(1, 2)
        # Start with report panel closed
        self.splitter.setSizes([700, 0])

    def _remove_last_lpn_row_split_style(self):
        if self.row_entries:
            self._remove_row(self.row_entries[-1])


    def upload_spreadsheet(self) -> None:
        from PyQt5.QtWidgets import QFileDialog, QMessageBox
        import pandas as pd
        import re
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "Select Spreadsheet",
            "",
            "Excel Files (*.xlsx *.xls);;All Files (*)"
        )
        if not file_path:
            self.file_label.setText("No file selected")
            return
        self.starting_sheet_path = file_path
        # Use os.path.basename to support Windows paths
        try:
            display_name = os.path.basename(file_path)
        except Exception:
            display_name = file_path
        self.file_label.setText(display_name)
        try:
            df = pd.read_excel(file_path)
        except Exception as e:
            self.file_label.setText(f"Error loading: {e}")
            QMessageBox.warning(self, "Error", f"Failed to read Excel file: {e}")
            return
        # Build a normalized column map so variations like 'Start 1', 'start1',
        # 'Start-1' are all recognized as the same logical column. This makes
        # the upload more robust to small header formatting differences.
        def _norm(c: str) -> str:
            return re.sub(r"[^0-9a-z]", "", str(c).lower())

        norm_map = {_norm(col): col for col in df.columns}

        # Require at least LPN + Start1/End1
        required_base = {"lpn", "start1", "end1"}
        if not required_base.issubset(norm_map):
            missing = sorted(required_base - set(norm_map))
            self.file_label.setText(f"Missing columns: {', '.join(missing)}")
            QMessageBox.warning(self, "Error", f"Spreadsheet must have columns: lpn, start1, end1")
            return

        # Detect how many part columns (startN/endN) are present (up to 5)
        max_parts = 1
        for n in range(2, 6):
            if f"start{n}" in norm_map and f"end{n}" in norm_map:
                max_parts = n
            else:
                break

        # Ensure the GUI shows the correct number of Part identifier edits
        delta = max_parts - self.part_count
        if delta != 0:
            self._change_part_count(delta)

        # Do NOT auto-fill Part Identifier text fields here. The user must
        # explicitly enter part identifiers to avoid incorrect part numbers
        # being used in the CSV output. We only adjust visible count above.

        self._clear_lpn_rows(add_blank=False, mark_dirty=False)
        rows = []
        for _, row in df.iterrows():
            # Use normalized mapping to find the original column name
            lpn_col = norm_map.get("lpn")
            lpn = str(row[lpn_col]) if pd.notna(row[lpn_col]) else ""
            entry = {"lpn": lpn}
            for i in range(1, max_parts + 1):
                s_key = f"start{i}"
                e_key = f"end{i}"
                s_col = norm_map.get(s_key)
                e_col = norm_map.get(e_key)
                entry[s_key] = str(row[s_col]) if s_col and pd.notna(row[s_col]) else ""
                entry[e_key] = str(row[e_col]) if e_col and pd.notna(row[e_col]) else ""
            rows.append(entry)
        # Populate rows now that GUI part_count matches spreadsheet
        self._populate_rows(rows)
        self._set_status(f"Loaded {len(rows)} rows from {display_name}", success=True)

    def _populate_rows(
        self,
        rows: Sequence[Mapping[str, Any]],
    ) -> None:
        self._suppress_row_change = True
        self._clear_lpn_rows(add_blank=False, mark_dirty=False)
        for row in rows:
            self._add_lpn_row(row, mark_dirty=False)
        if not rows:
            self._add_lpn_row(mark_dirty=False)
        self._suppress_row_change = False
        self.plan_consumed = False
        self._set_status("")
        self._update_add_button_state()
    
    def _set_spare_mode(self, mode: str) -> None:
        if self.spare_mode == mode:
            return
        self.spare_mode = mode
        if mode == "lpn":
            self.spare_lpn_container.show()
            self.spare_lpn_edit.setFocus()
        else:
            self.spare_lpn_edit.clear()
            self.spare_lpn_container.hide()
        self.plan_consumed = False
        self._update_add_button_state()

    def _rows_complete(self) -> bool:
        if not self.row_entries:
            return False
        for entry in self.row_entries:
            if not entry["lpn"].text().strip():
                return False
            for i in range(1, self.part_count + 1):
                if not entry.get(f"start{i}").text().strip():
                    return False
                if not entry.get(f"end{i}").text().strip():
                    return False
        return True

    def _update_add_button_state(self) -> None:
        enabled = (
            not self.plan_consumed
            and self.spare_mode is not None
            and (
                self.spare_mode != "lpn"
                or bool(self.spare_lpn_edit.text().strip())
            )
            and self._rows_complete()
        )
        self.main_buttons.add_button.setEnabled(enabled)

    def _set_status(self, message: str, success: bool = False) -> None:
        if not message:
            self.status_label.clear()
            return
        color = "green" if success else "#ff5555"
        rich_text = f"<span style='color: {color};'>{message}</span>"
        self.status_label.setText(rich_text)

    def _collect_rows(self) -> List[Dict[str, object]]:
        if not self.row_entries:
            raise ValueError(
                "Add at least one C40 line before creating the CSV."
            )
        rows: List[Dict[str, object]] = []
        for idx, entry in enumerate(self.row_entries, start=1):
            lpn = entry["lpn"].text().strip()
            if not lpn:
                raise ValueError(f"Row {idx}: LPN is required.")
            values: Dict[str, object] = {"lpn": lpn}
            for i in range(1, self.part_count + 1):
                label = f"Start{i}"
                s_key = f"start{i}"
                e_key = f"end{i}"
                text_s = entry[s_key].text().strip()
                text_e = entry[e_key].text().strip()
                if not text_s:
                    raise ValueError(f"Row {idx}: {label} is required.")
                if not text_e:
                    raise ValueError(f"Row {idx}: End{i} is required.")
                try:
                    values[s_key] = int(text_s)
                except ValueError as exc:
                    raise ValueError(
                        f"Row {idx}: {label} must be a whole number."
                    ) from exc
                try:
                    values[e_key] = int(text_e)
                except ValueError as exc:
                    raise ValueError(
                        f"Row {idx}: End{i} must be a whole number."
                    ) from exc
            rows.append(values)
        return rows

    def on_next_build(self) -> None:
        try:
            rows = self._collect_rows()
        except ValueError as exc:
            self._set_status(str(exc))
            return
        if self.plan_consumed:
            self._set_status(
                "Plan already added. Start over or adjust the lines first."
            )
            return
        if self.spare_mode is None:
            self._set_status("Select where the spares are coming from.")
            return
        spare_value = (
            self.spare_lpn_edit.text().strip()
            if self.spare_mode == "lpn"
            else None
        )
        if self.spare_mode == "lpn" and not spare_value:
            self._set_status("Enter the spare LPN before adding to CSV.")
            return
        try:
            rows_for_writer = cast(List[Dict[str, int]], rows)
            # Build part_names from the visible Part Identifier edits
            # Require the user to have entered part identifiers for every
            # visible part. Do NOT auto-fill defaults here; force the user to
            # confirm the values to avoid incorrect part numbers being used.
            part_names: List[str] = []
            for idx, (_lbl, edit) in enumerate(self.part_id_widgets, start=1):
                if idx > self.part_count:
                    break
                text = edit.text().strip()
                if not text:
                    self._set_status(
                        f"Enter part identifier for Part {idx} before adding to CSV."
                    )
                    return
                part_names.append(text)

            transfers, leftovers = self.csv_writer.calculate_transfers(
                rows_for_writer, part_names=part_names
            )
            if not transfers:
                self._set_status(
                    "No transfers needed; everything is already balanced."
                )
                return
            self.row_counter = self.csv_writer.append_to_csv(
                self.temp_csv_file,
                self.row_counter,
                spare_mode=self.spare_mode,
                spare_value=spare_value,
                transfers=[transfers] if isinstance(transfers, dict) else transfers,
                rows=rows_for_writer,
                part_names=part_names,
            )
        except Exception as exc:
            QMessageBox.critical(
                self,
                "Error",
                f"Failed to append to CSV: {exc}",
            )
            return

        # Only show final transfer summary and leftover overages in the inline report panel
        summary: Dict[str, int] = defaultdict(int)
        spare_summary: Dict[str, int] = defaultdict(int)
        for move in transfers:
            if isinstance(move, dict):
                part = str(move.get("part", ""))
                qty_value = move.get("qty", 0)
                if isinstance(qty_value, (int, float)):
                    qty = int(qty_value)
                elif isinstance(qty_value, str):
                    try:
                        qty = int(qty_value.strip()) if qty_value.strip() else 0
                    except ValueError:
                        qty = 0
                else:
                    qty = 0
                summary[part] += qty
                if move.get("from_spare", False):
                    spare_summary[part] += qty

        # Add leftovers from balancing, record which C40s need unpacking for
        # each part. We'll produce a neat table with columns: C40, Part#, Qty.
        leftover_rows = []  # list of tuples (lpn, part, qty)
        if leftovers:
            # Determine which start/end keys correspond to each part name
            for part, qty in leftovers.items():
                # find index of this part in part_names (fallback to LinecardN parsing)
                idx = None
                try:
                    idx = part_names.index(part)
                except Exception:
                    # try to parse LinecardN
                    if part.lower().startswith("linecard"):
                        try:
                            n = int(part[len("Linecard"):])
                            idx = n - 1
                        except Exception:
                            idx = None
                if idx is None:
                    continue
                start_key = f"start{idx+1}"
                end_key = f"end{idx+1}"
                # Find which C40(s) have the leftover for this part
                for entry in rows_for_writer:
                    lpn = entry["lpn"]
                    start_val = entry.get(start_key, 0)
                    end_val = entry.get(end_key, 0)
                    if start_val > end_val:
                        leftover_rows.append((lpn, part, qty))
                        break

        # Prepare data for export if the user wants to save the report.
        # We'll store transfers, summary totals, spare summary, and leftovers
        # so Save Report can write them to an Excel file.
        self._last_report = {
            "summary_count": len(transfers),
            "summary": dict(summary),
            "spare_summary": dict(spare_summary),
            "leftovers": leftover_rows,
            "transfers": transfers,
        }

        # Build message with table formatting
        style = "font-size:12px;"
        leftover_table = ""
        if leftover_rows:
            # Full-width header row inside the table. Use a readable text
            # color (white) and no bright background so it is legible on dark
            # themes.
            leftover_table += f"<table border='1' cellpadding='4' cellspacing='0' style='border-collapse:collapse;width:100%;{style}'>"
            leftover_table += "<tr><td colspan='3' style='font-weight:bold;color:#ffffff;padding:4px'>Parts requiring unpacking</td></tr>"
            leftover_table += "<tr><th>C40</th><th>Part#</th><th>Qty</th></tr>"
            for lpn, part, qty in leftover_rows:
                leftover_table += f"<tr><td>{lpn}</td><td>{part}</td><td>{qty}</td></tr>"
            leftover_table += "</table><br>"
        else:
            leftover_table = "All C40s balanced. No leftover overages detected.<br><br>"

        # Transfers table: put the table label as a top row inside the table
        transfer_table = f"<table border='1' cellpadding='4' cellspacing='0' style='border-collapse:collapse;width:100%;{style}'>"
        transfer_table += "<tr><td colspan='4' style='font-weight:bold;color:#ffffff;padding:4px'>Transfers (move instructions)</td></tr>"
        transfer_table += "<tr><th>From C40</th><th>To C40</th><th>Part</th><th>Qty</th></tr>"
        for move in transfers:
            if isinstance(move, dict):
                # Use the same keys as the CSV writer for report output
                from_c40 = move.get('source', None)
                # If move came from spares (no source), show 'Spares' instead of 'None' or blank
                if (not from_c40) and move.get('from_spare', False):
                    from_c40 = 'Spares'
                elif from_c40 is None:
                    from_c40 = ''
                to_c40 = move.get('dest', '')
                part = str(move.get('part', ''))
                qty = str(move.get('qty', ''))
                transfer_table += f"<tr><td>{from_c40}</td><td>{to_c40}</td><td>{part}</td><td>{qty}</td></tr>"
        transfer_table += "</table><br>"

        summary_table = f"<table border='1' cellpadding='4' cellspacing='0' style='border-collapse:collapse;width:100%;{style}'>"
        summary_table += "<tr><td style='font-weight:bold;color:#ffffff;padding:4px'>Summary</td></tr>"
        summary_table += f"<tr><th>Move Instructions</th></tr><tr><td>{len(transfers)}</td></tr></table><br>"
        parts_table = f"<table border='1' cellpadding='4' cellspacing='0' style='border-collapse:collapse;width:100%;{style}'>"
        parts_table += "<tr><td colspan='2' style='font-weight:bold;color:#ffffff;padding:4px'>Parts summary</td></tr>"
        parts_table += "<tr><th>Part</th><th>Qty</th></tr>"
        for part, qty in summary.items():
            parts_table += f"<tr><td>{part}</td><td>{qty}</td></tr>"
        if any(spare_summary.values()):
            for part, qty in spare_summary.items():
                if qty:
                    parts_table += f"<tr><td>{part} (Spare)</td><td>{qty}</td></tr>"
        parts_table += "</table><br>"
        summary_msg = (
            f"{summary_table}"
            f"{parts_table}"
            f"{leftover_table}"
            f"{transfer_table}"
        )
        # Show report in the inline panel and open the panel
        self.report_output.setHtml(summary_msg)
        self.splitter.setSizes([500, 400])
        self.plan_consumed = True
        self._update_add_button_state()

    def _add_lpn_row(
        self,
        data: Optional[Mapping[str, Any]] = None,
        *,
        mark_dirty: bool = True,
    ) -> None:
        # Create an in-memory row entry (widgets) and append to list, then
        # re-render all rows into the shared table grid so indices and
        # positions remain contiguous.
        entry: Dict[str, Any] = {}
        index_label = QLabel("1.")
        lpn_edit = QLineEdit()
        lpn_edit.setPlaceholderText("C40-#")
        lpn_edit.textChanged.connect(self._on_rows_changed)

        entry["index"] = index_label
        entry["lpn"] = lpn_edit

        for i in range(1, self.part_count + 1):
            s = IntLineEdit()
            s.textChanged.connect(self._on_rows_changed)
            e = IntLineEdit()
            e.textChanged.connect(self._on_rows_changed)
            entry[f"start{i}"] = s
            entry[f"end{i}"] = e

        remove_button = QPushButton("Remove")
        remove_button.clicked.connect(lambda _, e=entry: self._remove_row(e))
        entry["remove"] = remove_button

        # Populate initial values if provided
        if data is not None:
            self._suppress_row_change = True
            lpn_edit.setText(str(data.get("lpn", "")))
            for i in range(1, self.part_count + 1):
                entry[f"start{i}"].setText(str(data.get(f"start{i}", "")))
                entry[f"end{i}"].setText(str(data.get(f"end{i}", "")))
            self._suppress_row_change = False

        self.row_entries.append(entry)
        # Rebuild table rows so widgets are placed into the shared grid
        self._render_rows()
        if mark_dirty:
            self._on_rows_changed()
        else:
            self._update_add_button_state()

    def _create_row_entry(self, data: Optional[Mapping[str, Any]] = None) -> Dict[str, Any]:
        # Convenience factory (kept for compatibility if needed elsewhere)
        entry: Dict[str, Any] = {}
        index_label = QLabel("1.")
        lpn_edit = QLineEdit()
        lpn_edit.setPlaceholderText("C40-#")
        lpn_edit.textChanged.connect(self._on_rows_changed)
        entry["index"] = index_label
        entry["lpn"] = lpn_edit
        for i in range(1, self.part_count + 1):
            s = IntLineEdit()
            s.textChanged.connect(self._on_rows_changed)
            e = IntLineEdit()
            e.textChanged.connect(self._on_rows_changed)
            entry[f"start{i}"] = s
            entry[f"end{i}"] = e
        remove_button = QPushButton("Remove")
        remove_button.clicked.connect(lambda _, e=entry: self._remove_row(e))
        entry["remove"] = remove_button
        if data is not None:
            lpn_edit.setText(str(data.get("lpn", "")))
            for i in range(1, self.part_count + 1):
                entry[f"start{i}"].setText(str(data.get(f"start{i}", "")))
                entry[f"end{i}"].setText(str(data.get(f"end{i}", "")))
        return entry

    def _render_rows(self) -> None:
        # Remove any existing widgets from rows (keep header row at row 0)
        # Iterate in reverse over layout items so indices remain valid.
        count = self.table_layout.count()
        for idx in reversed(range(count)):
            try:
                r, c, rs, cs = self.table_layout.getItemPosition(idx)
            except Exception:
                continue
            # keep header row (row 0) intact; remove widgets from other rows
            if r == 0:
                continue
            item = self.table_layout.itemAt(idx)
            if item is None:
                continue
            w = item.widget()
            if w is not None:
                # Only remove the widget from the layout. Do NOT delete it
                # here because we re-use the same widget objects stored in
                # self.row_entries when re-adding them below. Deleting them
                # earlier caused the RuntimeError: wrapped C/C++ object ...
                try:
                    self.table_layout.removeWidget(w)
                except Exception:
                    pass

        # Re-add all rows from self.row_entries starting at row 1
        for ridx, entry in enumerate(self.row_entries, start=1):
            self.table_layout.addWidget(entry["index"], ridx, 0)
            self.table_layout.addWidget(entry["lpn"], ridx, 1)
            for i in range(1, self.part_count + 1):
                self.table_layout.addWidget(
                    entry[f"start{i}"], ridx, 2 + (i - 1) * 2
                )
                self.table_layout.addWidget(
                    entry[f"end{i}"], ridx, 2 + (i - 1) * 2 + 1
                )
            self.table_layout.addWidget(entry["remove"], ridx, 2 + self.part_count * 2)

        self._refresh_row_numbers()
        self._update_add_button_state()

    def _rebuild_header(self) -> None:
        # Rebuild header into the shared table_layout row 0.
        # Remove previous header widgets from row 0 if present.
        # We'll iterate all items and remove those at row 0 first.
        count = self.table_layout.count()
        for idx in reversed(range(count)):
            try:
                r, c, rs, cs = self.table_layout.getItemPosition(idx)
            except Exception:
                continue
            if r != 0:
                continue
            item = self.table_layout.itemAt(idx)
            if item is None:
                continue
            w = item.widget()
            if w is not None:
                try:
                    self.table_layout.removeWidget(w)
                except Exception:
                    pass
                try:
                    w.deleteLater()
                except Exception:
                    pass

        # Create header labels and place them in row 0
        col = 0
        lbl_num = QLabel("#")
        lbl_num.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.table_layout.addWidget(lbl_num, 0, col)
        col += 1
        lbl_lpn = QLabel("LPN")
        lbl_lpn.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.table_layout.addWidget(lbl_lpn, 0, col)
        col += 1
        for i in range(1, self.part_count + 1):
            lbl_s = QLabel(f"Start{i}")
            lbl_s.setAlignment(Qt.AlignmentFlag.AlignCenter)
            self.table_layout.addWidget(lbl_s, 0, col)
            col += 1
            lbl_e = QLabel(f"End{i}")
            lbl_e.setAlignment(Qt.AlignmentFlag.AlignCenter)
            self.table_layout.addWidget(lbl_e, 0, col)
            col += 1
        last_blank = QLabel("")
        last_blank.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.table_layout.addWidget(last_blank, 0, col)

    def _rebuild_paste_tabs(self) -> None:
        """Recreate the paste tabs to match current columns (LPN + Start/End pairs).

        This sets up one QTextEdit per column for Paste Multi input.
        """
        # Clear existing tabs
        try:
            while self.paste_tabs.count():
                w = self.paste_tabs.widget(0)
                self.paste_tabs.removeTab(0)
                try:
                    if hasattr(w, 'deleteLater'):
                        w.deleteLater()
                except Exception:
                    pass
        except Exception:
            pass

        cols = ["LPN"]
        for i in range(1, self.part_count + 1):
            cols.append(f"Start{i}")
            cols.append(f"End{i}")

        for label in cols:
            te = QTextEdit()
            te.setPlaceholderText(f"Paste values for {label}, one per line")
            self.paste_tabs.addTab(te, label)

    def _toggle_paste_multi(self, checked: bool) -> None:
        # Show or hide the paste widget and rebuild tabs when showing
        if checked:
            try:
                self._rebuild_paste_tabs()
            except Exception:
                pass
            self.paste_widget.setVisible(True)
        else:
            self.paste_widget.setVisible(False)

    def _controls_paste_clicked(self) -> None:
        """Handler for the compact Paste button in the C40 controls.

        Toggles the Paste Multi panel. If the internal toggle button exists
        we flip its checked state so signal handlers are consistent.
        """
        try:
            if hasattr(self, 'toggle_paste_button'):
                self.toggle_paste_button.setChecked(
                    not self.toggle_paste_button.isChecked()
                )
            else:
                # Fallback: directly toggle visibility
                vis = getattr(self, 'paste_widget', None) and self.paste_widget.isVisible()
                self._toggle_paste_multi(not vis)
        except Exception:
            # Best-effort toggle; ignore errors
            try:
                vis = getattr(self, 'paste_widget', None) and self.paste_widget.isVisible()
                self._toggle_paste_multi(not vis)
            except Exception:
                pass

    def _clear_paste_tabs(self) -> None:
        for i in range(self.paste_tabs.count()):
            w = self.paste_tabs.widget(i)
            if isinstance(w, QTextEdit):
                w.clear()

    def _apply_paste_multi(self) -> None:
        # Read each tab's lines and build row dicts accordingly. Then
        # replace current rows with the pasted data.
        cols: List[List[str]] = []
        max_lines = 0
        for i in range(self.paste_tabs.count()):
            w = self.paste_tabs.widget(i)
            text = w.toPlainText() if isinstance(w, QTextEdit) else ""
            lines = [ln.rstrip() for ln in text.splitlines()]
            cols.append(lines)
            max_lines = max(max_lines, len(lines))

        if max_lines == 0:
            self._set_status("Nothing to paste.")
            return

        rows: List[Dict[str, object]] = []
        for ridx in range(max_lines):
            entry: Dict[str, object] = {}
            # LPN is column 0
            entry["lpn"] = cols[0][ridx] if 0 < len(cols) and ridx < len(cols[0]) else ""
            for part in range(1, self.part_count + 1):
                s_key = f"start{part}"
                e_key = f"end{part}"
                col_s = 1 + (part - 1) * 2
                col_e = col_s + 1
                s_lines = cols[col_s] if col_s < len(cols) else []
                e_lines = cols[col_e] if col_e < len(cols) else []
                entry[s_key] = s_lines[ridx] if ridx < len(s_lines) else ""
                entry[e_key] = e_lines[ridx] if ridx < len(e_lines) else ""
            rows.append(entry)

        # Replace existing rows with pasted rows
        self._suppress_row_change = True
        self._clear_lpn_rows(add_blank=False, mark_dirty=False)
        for r in rows:
            self._add_lpn_row(r, mark_dirty=False)
        if not rows:
            self._add_lpn_row(mark_dirty=False)
        self._suppress_row_change = False
        self._set_status(f"Pasted {len(rows)} rows.", success=True)
        self._update_add_button_state()

    def _change_part_count(self, delta: int) -> None:
        new = max(1, min(5, self.part_count + delta))
        if new == self.part_count:
            return
        self.part_count = new
        # show/hide identifier edits
        for idx, (lbl, edit) in enumerate(self.part_id_widgets, start=1):
            visible = idx <= self.part_count
            lbl.setVisible(visible)
            edit.setVisible(visible)
        # rebuild header and adjust existing rows
        self._rebuild_header()
        # Rebuild paste tabs to match new column set
        try:
            self._rebuild_paste_tabs()
        except Exception:
            pass
        self._update_rows_for_part_count()

    def _update_rows_for_part_count(self) -> None:
        # Ensure each existing row entry dict has start/end widgets matching
        # the current part_count. Add or remove widgets in the entry and
        # then re-render all rows into the shared table grid.
        for entry in self.row_entries:
            # add missing fields
            for i in range(1, self.part_count + 1):
                ks = f"start{i}"
                ke = f"end{i}"
                if ks not in entry:
                    s = IntLineEdit()
                    s.textChanged.connect(self._on_rows_changed)
                    entry[ks] = s
                    e = IntLineEdit()
                    e.textChanged.connect(self._on_rows_changed)
                    entry[ke] = e
            # remove extra fields
            i = self.part_count + 1
            while True:
                ks = f"start{i}"
                ke = f"end{i}"
                if ks in entry:
                    s = entry.pop(ks)
                    e = entry.pop(ke)
                    try:
                        s.deleteLater()
                    except Exception:
                        pass
                    try:
                        e.deleteLater()
                    except Exception:
                        pass
                    i += 1
                    continue
                break

        # Re-render rows so remove buttons move to the correct column
        self._render_rows()

    def _remove_row(self, entry: Dict[str, QWidget]) -> None:
        if entry not in self.row_entries:
            return
        self.row_entries.remove(entry)
        # Delete all widget objects for this entry
        for w in list(entry.values()):
            try:
                if hasattr(w, 'deleteLater'):
                    w.deleteLater()
            except Exception:
                pass
        if not self.row_entries:
            self._add_lpn_row(mark_dirty=False)
        self._render_rows()
        self._on_rows_changed()

    def _clear_lpn_rows(
        self,
        add_blank: bool = True,
        mark_dirty: bool = True,
    ) -> None:
        self._suppress_row_change = True
        # Delete widget objects for each entry
        while self.row_entries:
            entry = self.row_entries.pop()
            for w in list(entry.values()):
                try:
                    if hasattr(w, 'deleteLater'):
                        w.deleteLater()
                except Exception:
                    pass
        self._suppress_row_change = False
        if add_blank:
            self._add_lpn_row(mark_dirty=False)
        # Re-render to clear any lingering widgets in the layout
        self._render_rows()
        if mark_dirty:
            self._on_rows_changed()
        else:
            self._update_add_button_state()

    def _refresh_row_numbers(self) -> None:
        for idx, entry in enumerate(self.row_entries, start=1):
            entry["index"].setText(f"{idx}.")

    def _on_rows_changed(self) -> None:
        if self._suppress_row_change:
            return
        self.plan_consumed = False
        self._set_status("")
        self._update_add_button_state()

    def clear_data_fields(self) -> None:
        self.starting_sheet_path = None
        self.file_label.setText("No file selected")
        self._clear_lpn_rows(add_blank=True, mark_dirty=False)
        self.plan_consumed = False
        self.spare_mode = None
        self.location_radio.blockSignals(True)
        self.lpn_radio.blockSignals(True)
        self.location_radio.setChecked(False)
        self.lpn_radio.setChecked(False)
        self.location_radio.blockSignals(False)
        self.lpn_radio.blockSignals(False)
        self.spare_lpn_edit.clear()
        self.spare_lpn_container.hide()
        self._set_status("")
        self._update_add_button_state()

    def on_csv_reset(self) -> None:
        self.plan_consumed = False
        try:
            self.temp_csv_file.flush()
        except Exception:
            pass
        self._update_add_button_state()

    def on_csv_loaded(self) -> None:
        self.plan_consumed = False
        self._update_add_button_state()

    def save_report(self) -> None:
        """Save the last generated report to an Excel file with multiple sheets.

        Sheets: Summary, Parts, Leftovers, Transfers
        """
        from PyQt5.QtWidgets import QFileDialog, QMessageBox
        try:
            import pandas as pd
        except Exception:
            QMessageBox.critical(self, "Error", "Pandas is required to save reports to Excel.")
            return

        if not getattr(self, '_last_report', None):
            QMessageBox.warning(self, "No report", "No report available to save. Generate a report first.")
            return

        file_path, _ = QFileDialog.getSaveFileName(
            self,
            "Save Report",
            "",
            "Excel Files (*.xlsx);;All Files (*)",
        )
        if not file_path:
            return

        try:
            # Build DataFrames for each sheet
            lr = self._last_report
            # Summary
            df_summary = pd.DataFrame([{"Move Instructions": lr.get("summary_count", 0)}])

            # Parts
            parts_rows = []
            for part, qty in lr.get("summary", {}).items():
                parts_rows.append({"Part": part, "Qty": qty})
            for part, qty in lr.get("spare_summary", {}).items():
                if qty:
                    parts_rows.append({"Part": f"{part} (Spare)", "Qty": qty})
            df_parts = pd.DataFrame(parts_rows)

            # Leftovers
            leftovers = lr.get("leftovers", [])
            df_left = pd.DataFrame(leftovers, columns=["C40", "Part#", "Qty"]) if leftovers else pd.DataFrame(columns=["C40", "Part#", "Qty"]) 

            # Transfers
            transfers = lr.get("transfers", [])
            t_rows = []
            for move in transfers:
                if isinstance(move, dict):
                    from_c40 = move.get('source')
                    if (not from_c40) and move.get('from_spare', False):
                        from_c40 = 'Spares'
                    elif from_c40 is None:
                        from_c40 = ''
                    t_rows.append({
                        "From C40": from_c40,
                        "To C40": move.get('dest', ''),
                        "Part": move.get('part', ''),
                        "Qty": move.get('qty', ''),
                    })
            df_trans = pd.DataFrame(t_rows)

            # Write to Excel
            with pd.ExcelWriter(file_path, engine='openpyxl') as writer:
                df_summary.to_excel(writer, sheet_name='Summary', index=False)
                df_parts.to_excel(writer, sheet_name='Parts', index=False)
                df_left.to_excel(writer, sheet_name='Leftovers', index=False)
                df_trans.to_excel(writer, sheet_name='Transfers', index=False)

            QMessageBox.information(self, "Saved", f"Report saved to {file_path}")
        except Exception as exc:
            QMessageBox.critical(self, "Error", f"Failed to save report: {exc}")
